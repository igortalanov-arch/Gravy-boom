
/* =============================================================================
   ГРАВИ-БУМ! v4.1 — «Башня четырёх этажей»
   Один файл, без зависимостей кроме встроенного Three.js. Работает по file://.

   Архитектура:
     1.  LEVEL_CONFIG — геометрия стакана, физика, палитра
     3.  I18N         — RU / EN
     4.  Sound        — синтез WebAudio (без файлов)
     5.  Collider     — поверхности вращения, цилиндрические стенки, капсулы
     6.  Ball         — тело шара (примагниченный / свободный / заряженный)
     7.  GlassWorld   — физика: гравитация, CCD, столкновения, ловушка, кнопка
     8.  Magic        — match-3 с таймером 10 с, цепочки, взрывы
     9.  FX           — искры, слоу-мо, тряска экрана
     10. Rope         — трос и его разрезание свайпом
     12. App          — ввод, камера, HUD, модальные окна, главный цикл
   ============================================================================= */
(function () {
  'use strict';
  const MOBILE = matchMedia('(pointer:coarse)').matches || /Android|iPhone|iPad/i.test(navigator.userAgent);


  // ===========================================================================
  // 1. КОНФИГУРАЦИЯ УРОВНЯ
  // ===========================================================================
  const LEVEL_CONFIG = {
    // Стакан: ось Y, радиус 15, от стеклянного дна (y = -6.5) до верха (y = +22)
    glass: {
      radius: 15.0,
      yBottom: -6.5,
      yTop: 22.0,
      wallThickness: 0.35
    },

    physics: {
      gravity: 9.8,
      restitutionBall: 0.92,     // шар — шар (бильярд)
      restitutionSurface: 0.88,  // шар — площадка
      restitutionWall: 0.90,     // шар — стенка стакана
      airDrag: 0.02,             // линейное трение о воздух, 1/с
      surfaceFriction: 0.05,     // трение о поверхность
      angularFriction: 0.08,
      maxSpeed: 16.0,
      substeps: 6,               // подшагов на кадр (CCD для тонких плит)
      stuckSpeed: 0.1,
      returnAfter: 3.0,          // шар стоит > 3 с → возврат на трос
      returnDuration: 1.0
    },

    // Наклон стакана
    tilt: {
      max: 25 * Math.PI / 180,
      lerpIn: 0.3,               // сек на выход на целевой наклон
      lerpOut: 0.8,              // сек на возврат
      sensitivity: 0.0022        // рад на пиксель движения мыши
    },

    // Встряска
    shake: {
      impulseMin: 0.6,
      impulseMax: 1.2,
      visualAmp: 0.15,
      visualTime: 0.3,
      cooldown: 1.2
    },

    // Трос
    rope: {
      anchor: { x: 0, y: 20, z: 0 },
      length: 7.9,               // шар висит на y = 12.1 — над чашей площадки A
      swing: 0.12                // лёгкое покачивание до разреза
    },

    // Площадка A «Чаша» (y = 11)
    platformA: {
      y: 11.0,
      // толщина больше глубины чаши (0.8), иначе чаша прорезает диск насквозь
      thickness: 1.1,
      radius: 11.0,
      bowlRadius: 4.0,
      bowlDepth: 0.22,
      rimRadius: 14.2,        // v4.1: перила сомкнуты и прижаты к стенке — зазора-выхода нет
      rimTube: 0.4,
      rimY: 12.1,
      exitAngle: 0,              // (не используется с v4.1: выход только через центральный люк)
      exitHalfWidth: 22 * Math.PI / 180
    },

    // Площадка B «Воронка» (y = 5)
    platformB: {
      y: 5.0,
      thickness: 0.6,
      radius: 13.0,
      funnelTopR: 10.0,
      funnelTopY: 5.3,
      funnelBottomR: 1.5,
      funnelBottomY: 3.5,
      holeRadius: 1.5
    },

    // Ядро щита и три тела (y = 0.5). v4.0: зона смещена от оси — шар, падающий
    // из люка этажа 3 по центру, НЕ должен автоматически разбивать ядро
    finalFunnel: { x: 9, z: 3.5, throatY: 2.3, holeR: 1.5, slope: 0.045 },
    shield: {
      y: 0.3,
      x: 9, z: 3.5,
      coreRadius: 1.2,
      orbitRadius: 3.0,
      orbitOmega: 1.2,           // рад/с
      bodyRadius: 0.84,
      bodyMass: 1.73,
      releaseSpeed: 3.0          // касательная скорость после освобождения
    },

    // Финальная кнопка (y = -2.5)
    button: {
      y: -1.8,
      radius: 1.6,
      thickness: 0.4,
      pressDepth: 0.15,
      // v4.0: кронштейны развёрнуты — не ловят шар, ныряющий к смещённому ядру
    bracketAngles: [90, 210, 330].map(a => a * Math.PI / 180),
      bracketWallY: -1.2,
      bracketRadius: 0.2,
      bracketInner: 1.4,
      glowRadius: 4.0
    },

    // Ловушка (сетка y = -4.5, стекло y = -6.5)
    trap: {
      netY: -4.5,
      netRadius: 14.0,
      netHole: 1.6,
      netTilt: 3 * Math.PI / 180,   // уклон к центру
      cellSize: 0.5,
      glassY: -6.5,
      glassRadius: 15.0,
      gameOverDelay: 2.0,           // драматическая пауза
      dissolveAfter: 30.0,          // шары на стекле растворяются
      dissolveTime: 3.0
    },

    // Магия match-3
    magic: {
      chargeTime: 10.0,
      ringRadiusK: 1.9,
      slowmoTime: 0.35,
      slowmoScale: 0.35,
      flashTime: 0.15,
      sparks: 24,
      sparkSpeed: 5.0,
      sparkLife: 0.5,
      screenShakeTime: 0.25,
      screenShakeAmp: 0.2
    },

    // Игровой шар
    player: {
      radius: 0.75,
      mass: 1.0,
      colorNum: 0xffffff
    },

    palette: [
      { id: 'red',    colorNum: 0xff3355, emissive: 0x551122 },
      { id: 'blue',   colorNum: 0x3d7bff, emissive: 0x112255 },
      { id: 'yellow', colorNum: 0xffcc00, emissive: 0x554400 }
    ],

    // Камера
    camera: {
      minPolar: 20 * Math.PI / 180,   // от вертикали
      maxPolar: 85 * Math.PI / 180,
      minDist: 18,
      maxDist: 78,
      defaultDist: 46,
      defaultTheta: 0.6,
      defaultPolar: 62 * Math.PI / 180,
      targetY: 4.0,
      fov: 46,
      near: 0.1,
      far: 400
    },

    gameplay: {
      maxTimeText: true
    },

    // v4.0: четыре этажа
    floors: {
      holeR: 2.0,                 // радиус центрального люка (ТЗ v4.2: 2.0)
      gateOpenTime: 0.6,          // анимация открывания люка, с
      transitionDur: 1.2          // переход между этажами, с
    },

    // v4.0: резонансные плиты — полосы скорости шара в момент касания
    resonance: {
      weak:   { min: 0.4, max: 1.2 },
      mid:    { min: 2.0, max: 4.5 },
      strong: { min: 6.5, max: 12.0 }
    },

    // v4.0: палитры этажей
    floorPalettes: [
      { name: 'bowl',       bg: 0x040a18, fog: 0x0a1830, key: 0x9fd8ff, hemi: 0x9fd8ff, hemiG: 0x0a1830, glow: 0x00d4ff },
      { name: 'pipe',       bg: 0x100804, fog: 0x2a0e04, key: 0xffd9a8, hemi: 0xffd9a8, hemiG: 0x180a04, glow: 0xff8800 },
      { name: 'resonance',  bg: 0x0a0418, fog: 0x1e0838, key: 0xd8b8ff, hemi: 0xd8b8ff, hemiG: 0x0e0420, glow: 0xd946ef },
      { name: 'core',       bg: 0x180408, fog: 0x380810, key: 0xffa0a8, hemi: 0xffa0a8, hemiG: 0x180408, glow: 0xff3355 }
    ]
  };

  // ===========================================================================
  // 1b. ДЕСЯТЬ УРОВНЕЙ (v4.1, ТЗ «Этап 4»): башня из 4 этажей одинаковой
  // геометрии; сложность растёт плотностью правил, а не числом загадок.

  // plates [{kind, min, max}...] · magicTime · echo · rewind ('free'|'pen50'|
  // 'reset'|'pen100'|'pen200') · perfectCut · hints (2 все/1 без нижней/0 нет) ·
  // blink (плиты мигают) · bodies (3|4) · ballBoost · dark · name [RU, EN]
  // ===========================================================================
  const VERSION = '5.0';
  // v4.5: палитры 10 уровней — «цилиндры башни своего цвета» (как в МАТ-БУМ! 3):
  // pal[0] — тон стекла стакана, pal[1] — тон дисков этажей, pal[2] — акцент (пояса, свечение).
  const LEVEL_PALETTES = [
    ['#37c8f0', '#3a97c9', '#37c8f0'],   // 1 — небесно-голубой
    ['#4f8cff', '#4668d8', '#6f9dff'],   // 2 — синий
    ['#8d5bff', '#7a4fd0', '#a97dff'],   // 3 — фиолетовый
    ['#ff5fa8', '#d84f92', '#ff7fbf'],   // 4 — розовый
    ['#ff7a3c', '#d86a34', '#ff9a5c'],   // 5 — оранжевый
    ['#ffc93c', '#d8a832', '#ffd97a'],   // 6 — золотой
    ['#5ce65c', '#48c95a', '#8af07a'],   // 7 — зелёный
    ['#2fd8c8', '#2ab5ad', '#5ff0e0'],   // 8 — бирюзовый
    ['#ff4f6d', '#d8445f', '#ff7a92'],   // 9 — алый
    ['#c9d6f0', '#8f9fc4', '#e8f0ff']    // 10 — ледяной белый (тёмный уровень)
  ];
  const LEVELS = [
    // pipe: { color, roads: [массив 'K'|'S'|'M' дороги A, null|массив дороги B] } — ТЗ v4.2 п.2.11
    // plate3: { weak/mid/strong: [min,max] } — пороги м/с по ТЗ v4.2 п.3.13; hazards — шары-помехи
    { id: 1, name: ['Первое знакомство', 'First Steps'],
      sockets: [[0, 1]],
      pipe: { color: 0, roads: [{ layout: ['K', 'S', 'K'], gapAfter: 0, gapSide: 1 }, null] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 0,
      magicTime: 10, echo: false, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 2, name: ['Повторение', 'Repetition'],
      sockets: [[0, 1], [1, 2]],
      pipe: { color: 0, roads: [{ layout: ['K', 'S', 'K', 'S'], gapAfter: 0, gapSide: 1 }, null] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 0,
      magicTime: 10, echo: false, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 3, name: ['Первый выбор', 'First Choice'],
      sockets: [[0, 2], [2, 2]],
      pipe: { color: 2, roads: [{ layout: ['K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 0,
      magicTime: 10, echo: false, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 4, name: ['Плотность', 'Density'],
      sockets: [[0, 1], [1, 2], [2, 3]],
      pipe: { color: 0, roads: [{ layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 0,
      magicTime: 9, echo: true, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 5, name: ['Первый вызов', 'First Challenge'],
      sockets: [[0, 2], [0, 3], [1, 3]],
      pipe: { color: 1, roads: [{ layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S'], gapAfter: 0, gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S'], gapAfter: 0, gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 0,
      magicTime: 8, echo: true, rewind: 'pen50', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 6, name: ['Время', 'Time'],
      sockets: [[0, 3], [1, 3], [2, 4]],
      pipe: { color: 2, roads: [{ layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 1,
      magicTime: 7, echo: true, rewind: 'reset', perfectCut: false, hints: 1, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 7, name: ['Ровная линия', 'Straight Line'],
      sockets: [[0, 3], [1, 4], [2, 4]],
      pipe: { color: 0, roads: [{ layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: 0, gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 1,
      magicTime: 6, echo: true, rewind: 'reset', perfectCut: false, hints: 1, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 8, name: ['Идеальный срез', 'Perfect Cut'],
      sockets: [[0, 4], [1, 4], [2, 4]],
      pipe: { color: 1, roads: [{ layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K', 'S'], gapAfter: 0, gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K', 'S'], gapAfter: 0, gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 1,
      magicTime: 5, echo: true, rewind: 'reset', perfectCut: true, hints: 1, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 9, name: ['Светофор', 'Traffic Light'],
      sockets: [[0, 4], [1, 5], [2, 5]],
      pipe: { color: 1, roads: [{ layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K', 'S'], gapAfter: 0, gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K', 'S'], gapAfter: 0, gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 2,
      magicTime: 4, echo: true, rewind: 'pen100', perfectCut: true, hints: 0, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 10, name: ['Мастер', 'The Master'],
      sockets: [[0, 2], [1, 3], [2, 3], [0, 4], [2, 5]],
      pipe: { color: 0, roads: [{ layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: [0, 2], gapSide: 1 }, { layout: ['K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K', 'S', 'K'], gapAfter: [0, 2], gapSide: -1 }] },
      plate3: { weak: [0.5, 6.0], mid: [6.0, 7.65], strong: [7.65, 16.0] }, hazards: 2,
      magicTime: 3, echo: true, rewind: 'pen200', perfectCut: true, hints: 0, bodies: 4, ballBoost: 1.1, dark: true }
  ];

  // v4.1: параметры текущего уровня (модификаторы)
  function LV() { return LEVELS[clamp(W.currentLevel | 0, 0, LEVELS.length - 1)]; }

  // Применяет параметры уровня к LEVEL_CONFIG перед постройкой.
  // v4.1: башня фиксированной геометрии (11/8/5/0.5) — меняются только правила.
  function applyLevel(idx) {
    const L = LEVELS[clamp(idx | 0, 0, LEVELS.length - 1)];
    LEVEL_CONFIG.platformA.y = 11;
    LEVEL_CONFIG.platformA.rimY = 11 + 1.1;
    LEVEL_CONFIG.platformA.bowlDepth = 0.22;
    LEVEL_CONFIG.platformB.y = 5;
    LEVEL_CONFIG.platformB.funnelTopY = 5;            // уровень диска «Резонанс»
    LEVEL_CONFIG.platformB.funnelBottomY = 5 - 0.45;  // низ трубки люка
    LEVEL_CONFIG.floorPipeY = 8;                      // этаж «Труба» — посередине
    LEVEL_CONFIG.shield.y = 0.3;
    LEVEL_CONFIG.rope.anchor.y = 20;
    LEVEL_CONFIG.tilt.max = 25 * Math.PI / 180;
    return L;
  }

  // Высота плоскости этажа (для проверки «шар провалился ниже этажа»)
  function floorY(idx) {
    if (idx <= 0) return LEVEL_CONFIG.platformA.y;
    if (idx === 1) return LEVEL_CONFIG.floorPipeY;
    if (idx === 2) return LEVEL_CONFIG.platformB.y;
    return LEVEL_CONFIG.shield.y + 2.0;
  }

  // ===========================================================================
  // ===========================================================================
  // ===========================================================================
  // 3. ЛОКАЛИЗАЦИЯ
  // ===========================================================================
  const ICONS49={"ui-back": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAmWklEQVR42tV9ebQlRZnnLyIy8y5vr/eqXkGxyioWVbIriKDSdDv06Z4Z6fGoNAgMLq09QMuI00oLDa5HUQQE24VedKZbR3uw9Qy4ICqgIC2yFPUKqIVCauNVvf3dJTMi5o+IyIyIjLz3dXuOc7zn3PPuvS+XyPi++Nbf9wWpjb9CQr+kzD+CEJJ/J4QE/09BwKUACEAIBYQAZH4AJAGodM+zr2Oua34r34cAyCCJuq453LkcQX5P9X9iXa/8XUr32awB688kHwsh5heS31sIAoIIQHm8xDy39Sz585Hiec1fIQQiKSUopc5JpOIilBAIKUEJyR+MEqoGLvUQ9CmElgloD7g0QP2bGU/+YCTKJ8Y5ReoxEOEQwCW1fbw63BmTLOZdmmco6AAC/xkkKKOQ0qK6+Z8mtiE0JdRlPILSMxNCEJmH9Tk/tAIMESABIov5VodZ5xACKfREuveEyLnLvb5PfAAuIfJJl/kDSykByRxuJPBXiSx+lQA1q8BMoce96uGchQwp/et5DGQISBXRINxnM599CQJArQD3QKLEiZouh9IORSkBkRbnElhLt+B0SdwbEricVSX+7FVhL217UgkASTXn6ckkBQn0dcIrDf79CUpcnd+P2OfpsQCKyUAgiDTcpc6DzCWA1AT1Gc58jlx5aHNzQV5nJdlyW4uanJ/0A4v8RuXJlIb9iCuCiRZv5gHy5UUsTvXunTO2WTGW/IaZCE8uET15BV2K4yQKAvoMYu5t1hMhBKCKCA7DGW4X0iGcO8eWuPUn1YxWSqEJQVH5IvAeBhCQzsQFH8RMgvNgimtACvEuiVmDFrVsxrDEVkl0EotT7TFY0kzq+xaPE16ZUhYj8OU4KAnqm8rjvRUflSkkK8VOaBn5Mi50Q/X/wEqS0iKUFiGaYyW8a3vL2KwKaT8kNdztTmQhDsyKNQuWBJ9TSgliW3M9xGVIX0qHrGUrz14xkXsRj00CVPS5rXycthYo9cxAm2iKGGpiUFqilBZjKXSKzI8Nm5NhQ6IQo8TiSmhLxv3uX4/YK12vBCHKYiok20NjCo0tcilD8xVgT0DIRC3rDKIsJELQ7WbIOstAmqnRMwoQqp9U2KZThWgjZRPSNfZ7vApd5Jo7gevb1zU6xlbQnANcm0AxQ9xsIokiSCnAK2R7v5dPtKigNa2kZtVSLTg2gpQSy3MLAATGJidwzIZjccThh+DgtZNYtWoYzYEmarUIEYtAwUCofW0KQqnlbBHbpSj0ixBBuSq1nSghnTELIZ35lJCA0Ko2V+BCm5nSMQakEEjTFPtn5rDzhd145pnt2LxlK+an54AkRnOomY+nSiT3Wgn5/Wrj66URP2apFytA9lAkJGem1swComYNrz3zFJx77uk49qjDUIsJsjRDu7MMKQUYjcAYA2FMixHjdaqVpyZCFJaQKLxXRlmuMKWU4BlHt9tFN+2CZ1z9xjmyjHuiUvkdQnBIISGECBgFAKMUlDJQSsEY0+KTgFCCWpJgeHAItVods3PLeOLprfjefQ/hyV8+CdRraA40ITKO/rxfQZDa+IkyTEVeSV0pgSiK0Wq1ITsdXHDBubjwP52PNRND2L59J554/Als3bYN09PTWF5uQQiRhy5kbmYKbXUY+S6UdycLb8GwL5HGTic9bPVcMjv6yA9xhM4phVy0SOJCgIBiYKCJQ9YdjGOOOwYbT9yAsfFV2LxlB/72H/4Pnt20BbXxVc51KmSPYzDkc2oTIGQFlb05AhZFaM3OYt0hk7jmystxzNHrMDU1hfvuux9TmzcDhGDVqlUYHR3F4OAg4jgGIdTxC2yf3/WLpG/yW9+9cET+PRTqAMpCzCWQEj0iH4s/Bikl0jTF/Pw8XnppH+bn5zAyMopTTz0VZ575KkysnsTd37kfX/7KPyFpDoBGkcO4zgMYo6PfCijkogzqOxYlWJ6exqvPOh3vu+piHJjehx/88If4xSOPojnQxMtedhTGx8cRx7F+EOmGAypiTSXZGLi5O9llPV5lc/vHKv0gggoyqAOpMjCWl1vYufMFbN++HZOTk7jgggtwyskbsfnZHfjQh28BB0WUxEHFnHvzHlsECaBOLFOSMorW/jmc84YzcfV734rNTz+N7373Xmzbuh0nbliP1avXgPNMixyAMQqAgFISmKSQeYKewcDqCQ7Hr8Iiwaw4WRmnsb8bvaEIJhHHNQghMTU1hX379uJNb/rPeO3ZZ2LPS/O4+pqbIFgEQlnZaDHi1BJBQgiwqDl5fdjc9DifRWjNLuCVJ5+AD77/v+LJx5/AP//zt7Fnzz6cdvppSJIYnU7HuoaRwcLzsGXwXcWJVZPT621bTE54QNpePsA5D54vhHAUtv17p9NFt9vF5OQkGo0GfvSj+zE4OIyN64/FhpM24J7v3Iek0XAsMj/gaP/Ooubk9f7kG/FjEyPrZhgdaeAjN/4FXnh+B771rbsxPT2DDRs2oNNp52FkN7oqHUfMiKTQhBVchtKD+5Pej5Bm8lwTU+bBRhPdNP8r/krr3IJY9iow/2u1Wmg0GhgbG8OP7/8RJtcejDNOWQ+a1PHog48gGRzI40QhX8ohQNgHsqkUoTMzg/f993dg9dgg7r77O9i0aQrrN5yIdruFiEU5wWxKw4p/FlwZntDy5KPnhIdWQ5nQtigpjAghZP7dZpbyOQJqWMWqMOdKKdHtdhHHMZJ6Hb/4xSM46uhj8NqzT8eDjz6BmenZXB9UecHaeRW5J1uEI4TlZFG05xex/rRX4swzTsRjv3oc//qvj+HY44/H8vJySY7ay1f9FRCC6+WukmbqAUj+FgLWX3NewZ3qHOjPouI+Uh8n8uu511fXMGLHTCrnXL9lfpx/fc7VW13P/V+r1cLY6Bg4l7jn3nvQWl7C5X/6JvBWK2hk+HosKkw86cTRC2VGIbptvPk/noel+SU88OCDGBweAWNRPqlAWZQYkcQ5d8RSwQEyHOKWRmyJ0rjC+sD+LLxncM8LhY2rsnJVotFmAqXQCZaWl3HoYYfhySeewqZNm3HqKSfj6PXHYutzLyBp1CuNDamyi7bpKUoT0261cdARh+OUk16OJ5/ahOd3/BrjE2vR7WYAmOIYUa24fEvCl6XlN7zPcDjWVZbFMbZVacYSOscfR/maIr+uEOVjbf1ijuVCgFKKKErwy18+BkKB33/9WZDL7TzdG+J+QoibEfN1AaUUYqmFc159EpKIYmpqCwiJVV40ywCWQkoGIQCm40FmsMbMCmn/kNK3865upNPEc6hlzdkcTPWxwlsN7jhCgTCbYCGTtIpJlOgS4EKC69863S6GR0awbds27Nm3Fxs3HAs6WM+vXRlHC5tHJkSgoqOveMVR2H9gBrt27UK9UYcUXMstZecLnesVPUxDn/urrJxCWfqcbnOl8VpJ5TXLFlFZb4T1iKiwhgqdUeSoi2SxEAKNRhNz8/PYs2cv1kyMYO1Bk+h2OpUEkFKCuraqiZOrN+ccdKCByYkJzM7OYm5+HrVaHYJrqkoKqVOQwkyU98A+IWwZG1r+ZcIUE63eJmdNSp5wL4vp32PO9nqOIn+liCCEAGUUWZpibnYWlBIctGYCMs2cZ/f1DSXE5njoZInUS5ej0aghqVG02220Wy1EjBWDsMUVVFRRBpLgVR6mr7RDWTWbYJRSCMGxuLiIdrtd6Zj1Mlur/IxQpits7lqWkpQ5bEFFTymEJFicXwRPMzQaEcAFKGEl89x8psXEK5FSZIbUpMRxhLSbqSRLJlTcPrc4OITkJVFg29KhCQ6FhatAWoUnzjC/sABCKY4++ihMrlmDudk5dDodR9GthOt7EaJqNfrXDIlcgxLJsgyt5bZiRoKSV+yYoSbp7qLBdNpQ/95qtcG5cJwXNckcBJFafpSuOBsUAmiFkXE6bxpF2L9/P0477RT8+Z+/F+sOPghpt4ufPvAQvvA3X8Ls7CxGR0fyfEDv3DR6/u4mdDzlbZm0wgvcwcKlEUrQ6aR6vtRcVsWmaEg+WdlTQFKkado3Ke0Gf2Xfh++VO/XBWS+9NI03/sH5+OhH/hrrDj4IUgrESYLXv/5c3HbrZ3DySRuxb990nkjpd79eXrVPBB+ABfSIXeU/U3S6GbI0dVAfobgQLUNSjFSjOqMkkHGO8tzK3AoyuUSxQo6rmvSQqbp//wH86UVvxTXX/IVyCoXIoTKcc6xevRof+9hHcNFFb8GBAwfAOa+MmvqTXCWXq5AeeZAxkKKllBboDgKkaQouhMqFg1pzRTwsk0NFUYbzEWV6FfkmO6hVWCOyT8i4F8oi5I1ynmFpaQlXXfUeXHbZJbk4sEUd0waBEAKXX/Z2XHvtNUjTjgMo6IVOCDFJKGTgHqO0MPXiXiYED0hQoqQG51zDWoxUKVCHOTBLxf2lpYQNAbhaAdobNDF9I/+4EDnBesXpq7jLFhe+vO92O8iyFH913f/AH//RH+XhjKoJpVQ98Pm/dx7+wxvfiIXFBURRVLnK7O/+7yGCFMeQPPxA/cSKJ0k4FyBCOoE+X/wRQgw00fVaCzSHbTIWyloKoVBrQkBK6iQdpKVDiIdc6xWUklKCMYbFxSUMDjbw4b+6DuvXvwKcczDGeq4oIQTiOEan28Fzz21FLUms1RwGRoUmOogxsqNRts/S53whhIu5I9KKURVXjYzZ6aMdpIVGdiwkYwFwAchMZc5IUkwypRbSuCwnq6yTKIowOzuHdevW4sYbr8ehhxy64smnlGJpaQk3/PVNeGrTZoyMDKvl3ye7Fgq+ub8bkav0jRDS8oSJF0VWoocYx1RwSOIGCo1lpcxmFLigsDMiQIiEkEXIUQol7O3YScaBjAvEEUGSxGAsQhSpt4RERN2lHpqMKGLYv/8A1q9/OW64/jqMja1a0eSbY6anp/HBD12PbVu3YWzVGLIs62nZOM9rsEYeXF2FqAVSniHLMqRpiizLoOhKEccxoojmofu8RoDYZroopRZ9BR+VoenSorAalTDOlRZLVN/BYHiyjCPLBLrdTEcFI0QRQxQxJLECYzFGc9xNEahTqc4DBw7gzDPPwAc/+AE06g2VK13h5G/bvgMf+tCHsW/fNEZHR5GmadAxC4WZC3seEIJDCIEsMxOegXOJjHMndWmMjjRNUa/XEMeRFi/Cq37hsNDtDsjZzkl7K8BCMUhdXCEFeJZpmSddO9jhJqITFxxpKkCIAKVK7MRRhCSOEccR4jjW3BOBsQjT09P4wz98I66++ipVgbMCp85M/q9+9Stcd90NaLe7GB4ZBOdZCfEgbZkspXYoeR5YyzhHN+XIsjRPzpiYE0Bz9KKLnVVjaLc7IIQiiiwdqiGRjrdPlDgvmKAYX1SGhRT1AVJIILIfSELKLIcylpDTdnpPmBg9R5pKtNoZGJOIGENSSxAzhna7gyuuuAyXXXqJE+9ZyeTff/9P8NGPfQKMUgwONsGzIvFjrDcuODIhkKXc4uwUQigUnRBCjVMSDzVRgLo8aE9RUUOICjm0Wmg2k7xOQsUOTWCSaD+AlABjuQgyVBGC54hmKV3cPhdCEQOFUraLI0KKzMDPJVTET8VIFAhqeXYBWdrFDdd/EG/+L39SyhtUlXgJnoGxCHd/+zv47Gc/i3q9AUIZ2t1uDvjNuFqxaiWmyIQAzySyjOfhExeSQhxUt5uHcOW11CVa9rNynqHbpajVEl3hpK6pRJAspe2UMvbAuTZQ1Ta+cqvHLE3IINTOTr4gx3YKE2rNBxzHCVqtNqKI4fbbPoM3vP51K1K25nzGItx119/hc7fejuHhYSwttZEJnos+Fd/neZw/z3ySyFqpLIfAm1iNbaX4TpptNNBgrQDQ7XJQmqFer+XiRlh+UjGnogT3iaTkWkFQSwHLvEyFgIBnMlxo5jsslmVhiyRj48/Pz2FifBXu+PxncdIrN65o8u0V9YlPfQZ33vlFjIwMYXZ+SSXJhSgKi3JGIiC6ujI3J7wqySKwWNQz2CLY/I8xmoc3qiwqITg6HYEkiVyUBQiKSg8X+qgAyUBUyDrioMZsEcOFsoHVFYoyzXxQefUJLUxWa5AsYpidmcFxxx6BO++4HUceccSKJ18KiW7axQ03fRx/+3f/E2NjI+h0Ui1vFYiYeEBSVUrL7FS+4nAUyRwjsnLzURZixlxNhRMEBgcHS7EhP5DHuUCnkyJNs1wHFbB4BErA1J2iELC1t4dIy8BTOx7iODPazJzej1efeTLuuO0WrFo1vuLJh1UE+JY3vwmXX3qRlbaUgXXoh5RRVDUaniLSCooJB/hbFGuoP8vLLdz19/+Af/n2vRgaHgLnose8EGSZUH5FTgARBETY5QBRODleAHRBAK5laxBg67v6Rl5qm3/vS/vwxxecj5tv/uSKbXz/VaslOHH9evz/eN3yyo3Y/eJePPrLxzE4OJh72FUhaZMnyD3mfHUKqxDGmPO8SMoXKOaisoeUMlgBqEnVsiTA9P79uOySt+Lzt38un/yVJG6qQg6/7XeadgEJnHLKyWi12vnYgxDKYlrV2ipQXhbQTZbyCVGZ82VJsUrhJ8ldu9+unTXvubl5vOfdl+MD739fMJT8b339Juf+e19SsqLIGrIIW9jxIrgVm3mlEclDaaVwtpNwqsyRmosSA1CVTqDOr7+1JWu73cHRLzsS115zdTDx8Tv5KgH7iRsR9dKSmTaLkftEFYzlY/bd7FTRAENKUfgBPcK2KpnC0Wg2QLwmIL+rLzV84eBGg/F9E7agNA9c2kZpyJSnrgiiXisY7c0KNw4uK0rwTQxkYKCJTZum8IMf/AiUUic6+bvJ/AJSZpoJXWZ2bDFbBxrTnriheF950145XKvM2QsxhHE7tjVVSxJc9b4P4PEnn0IURbn18LsoeQxzUp3rYJY+IpY+FFZxihCmJjrsVZcIEMyFwoJkG6VBytUzuUeodYcQAklNhR0uufRdmNryDBhjvxERuAMl/228BTKewcd72E1FgsgIBNrf9Mh/U5+LS02GQFXNrhBOjqAUlrAVrY4NDQ4OYmFuAW+7+Ao8t337b0QEpv2K396bopbUAAA/e+jnaDQbyrnqAS6mhJqcvXIgJdBDbbr5ALcng+6SIhVUMfceJRwERFXO1dAozTIMDg1i5sAMLrn4nfhfX/sKDjvsEHAudAHfyl7dbhf3//jHYDTWnrHdSsFGRVN4Vaxe/EWaBkO5FWd4lHrhdICg2+3im9/6Nh57fBOGhkYKZ9QKvzicbZWhitzrprpEl1ch40gpa+THLITpH0RkCXhlO1e+o2UsouHhYezatRuXvP0K/OM//j0m16xesVMmhEAURXjiqadxww0fxcTEBDi34zLWatQJkdwktmNTBWvmk0dD+suS68prjzA4OKB9GeKEXkrOp+lLZ4KAhFoBwLA48jpmeUrVgHWt3g0SqExuV8EC0zTFyOgItj2/HZdd9k587at3YXR0ZEVEUOlFgWuuvhIZF7jt1tsxOXmwDnqRShhJVReV4GqV0ouCOkagFptF7qBSDHkwF5VDceE7RVJeFsg4uxrSNyslqBN3WwnUsOSg6ezRqrHVeOKpzbj8He/G8vKyFZPva4mDc44PXHM1LvyTC7F7z4ugFLnCtDH9qmdElucwMusYkxUz59nf7TxCUTsmrAYhtH/I3OC24DbysytO7ckvIeMqPBAra1T8FGr2F+IuE6AjhCBNU6xevRoPP/wo3v1nV6KbpmWiVzycgqYLfOrjN+H3z/897N8/jThmQQCYgcfIwGoy1+oHXaxcLbb5CTjF1/YRzCrWJiBFbMgbLw0jg52UQt6GsUDmVcOtfR1gx40Mgm3NmrX4wX0/xpVXXQO7dnglSRkWMdz2uZtx2iknYWbmAOI4rm4zZoih37mZHIKq6wcv2enUBZ7ZRmm4xIrofnFaHGlsEdX9knwCU5fKAuUaLc051Gpk6sH6QjAQBwLi5Q/SNMXk5Frc/S/34tq/vE5z98qIIIXEQLOJL9x5O4488kgsLCgYYkiRhnBBXg/K8gq2z9HEsnvcVUEcXcdVeK4sCdYIGIhjuHmGBTGMWAxKmNVTkJRKi3wYomMh2ITQK0QRYRJf++o3cOONHwNj1IPzVStlLgRWr57AXV+6A2NjI1haXnZyDFXg3yDsPFC66rbYhEu4itVKLLMWuqMMzc1S4hSylzzhUFxH2ClFFoFSlidobI+vVxK9qrOVeWVpijWTk7jzzi/j05++BYwxiBU4akzXHx9xxOH44p23IokZ0jQtiA8EOTZvZ2kTosexTqcToLJ5SK7ncmuRII5ruUjK06ABXUurzLaCBzTSLY7y3/yGqKHyotBgi56dxSrJsgyr167Fzbd8Hl/40l1gjK0oeGeOO+mkjfjkJ25Eu93K207KYIig4Ghb3BQhFpIr1X4ryZf9dss04yfEUaQ6WkqRAwVCqUwqLcSbPf32tySOkcSx1XKlv83d6zc/hCGEwPj4OG666ZP4+je+iSiKVkSEKFLlURe88Q9wwgnHY6m1nNewlRjAI4issHiCDlaFPnKeyTS8I8r6iqMo2HzQ9x1oOe7nesEEipoGby+rTM1eYYlAnElYaTzzGh0ZxQeu/TDuvff7igh9xJF9vU6nk+OQSlD4HhNX5dMY46IqmeSLsVzECGUxJrUkb0RoK/Vy/CgXJ6alGHVqhQkliOMIEWOgpjCBkMp4UIjbq2oCSgqWUTQHB/Hfrn4/fvaznyPqEbyz0Xyfv+Nv8OyzzxQBM79KMjS5+k2skES420uf5k5ed17TLzpOGCLG4LZDI45lRAhzEzIm9KwGQXORU68lSGox/PqoXlwfgm/0q8sVQiCKI1AW4R3vvhJPPfV0MIJqI+Vuu+1OfOKTN2N4ZMyqSqyYLBN8s/9nd3zvU+oaKjiBX1WpbfVaHCmfSAc2iQNblzlWibqTRd00jAbLDgw0ECdRMFCHCoVXtTp8V9w3DbMsQy2podPJcOkV78b27TscxWwn+D/68U/hE5/6NMbGxwGwCryOG6xzelfrFZCLBc/er/RFAk6cEddSCEQsQrNe0xFfWbmPAmC1Kijf0NyIo95IkCSx5YaTEgKun4gJNti29YGFjuaco9lsYObAPC6+9J148cVduQ4yIYlrrv1LfP6OL2BiYhKCS9W/IiT/LW/YBhPY4kn6oDL0KFUNKHOvEAARo6jV64gYBQR3IramRIkQprJsYcUkAY3ipYyg2WggiRPnIaoG1asOq5fyE55lwjnH0NAAXty1B2+7+HI89NDPsbCwgKktW3DZFe/C17/+LaxZM4mMu86bWEH32hICxNu1w/YXQpXylTpNSkioXEeSRGB5oaDV4t+zNqPy8lLhU6LDwBFjqNUSqPyJDHZTr7Ii+rUfIAHlZ4uqLOMYHhrCrl17cfHl78LkmrWYmZlBu7WI8fFxZJkbdUUo9FFhEvcqRw1t8FDFWE4RnzbgKaNgjAT655VxQVF5ckgO4YYsnC4uMmVjyf5ip6oHaK+tPBxoBykcqoxz1SIHCmkXRxEGh0aRZqJyIqu8+5XkLhzrxvOEq2S/L7oZpWAEeXtm3xuxY21RtXhQGSVuWtBAOGiAqvOq7Ox+ew8455WQyAXSoqqiscpcDK3Sqs9VFZMykNQ1NRD+KjARW1VE7nJ/T1hKyMyihKCbZkizFBKqCoQL3le09HJuQhxrTLiqhh3G8vGDfqHrVLWcqVqVVf08S8TpJ9akhOQcURRhYGAAlDIsLbYAxnLqhLr1Ut/5KFBgEowyLC+1sNzqIIljjIyOoNvp9nXPQzcKDbpXn9Aq0RBq8hRCq/lECHXA6hU4DDlcDrGsSKoJWbc7HQwONjA6Oop2J8XufS+BxHERb6KmSiaADQ0Va1NKIJbbeGl6BkODg1i37mC0WkuqMVOPJV2lF3r1hy7tvmSJj37mbb8obNXK62UVOeLMstCk/9kyGhYXF7Fu3TqsWrUKe6cPYHrfASQJK1k+zgooc429fQgAITG1ZRvqtTqOOeZocJ5a/f5lz7YzVW1heu3dshIsaaiXm/T2J/u3tj72xaS/X03oswOwohRLS4s44YQT0GjUsWXLdoilTr7RXZH4p+GMmIsMEHkinA428cDDv0Kr3cYJL38FVo0Ood1pwS7j7NV7x87B9uvN5hPHlv22uPKzcCZo5ounfiZo1Qqw7xeCKYbEYrfbwWAzxgkvPx48S/HAw48DtVgjIphzFWfluFmsIiRhkuX1Zh07ntmJzVPP4qCDDsKZrz4D+/bsRpIkPRVXryZ5K5mIqo2D7Enqp+BDzVpX4qBVraQq0zmJY+zdsxunnXYqJlaP48Xd+/DYY0+jNjTo7LETDECWl3TRJtjEVwmj+Oa3f4Q4jnDeeedjoFFD2u32FCekByjVr7IJ2fB+v81+BO2lgPtZQitCQ1QF6nSOm0Di3HPPhRAc3/3+g+DtrkZGkJ6hGRriMGLVdXIO1EdH8cBPf46np7Zicu0k3va2t+D5HdtQq9XcPpoVDx7SATanBfd2qSBovw1HQ75F1aTaIqtfaCUkpqQUqNXq2Prcc3jLmy/E8EgTL700h+/d8xBqoyM9cbBOPqBKBtsV7yxp4pbb7wKlwGvPORuvO/csPL9jOxrNpjOBvVADVdzay0Lq5UytpFFUyKdYyb5fVaEWaSXm67UGtm99Fq8561ScfvqpkBL46tf/LzKeYw/6XjvfP6BfAC2q17Dv+RfBIfGq016JjRs24qknn8D2HTsxsXo1eJZWhKSJA76q2r7kNyll6rWFVOi+Vauk1/7JthIVUqJWr2Pnjm047NC1eO97/gyLC3P46cOb8f177kdjdLjAkvYZN2ONNdeHcru+pyiFQG1wGI/9/FEccugkjj32KLzm7LMwtfkpbJl6DuMTq0vmICHoiZ7oJT56Ie76iQx/ZYVa1fTyC3rlNCghqNfq2LbtGRx1xMG4+uorsW/fXjz/4n586cvfQHNsAoILHXIOXiTPWwMAiwfWXt/LXHMfliNuDOG+HzyAI49ci6NfdhjOPvscLC0u4Gc/ewj1egP15qBl0pKemMpecaN+nFN1Xq/VsFKUg79Lq7EMVdHJEp7f/hxe99qzcOmll2Lv3t3Ys28Rt975T4ibQ3k1kZnjEiN7LMlYY831ZTmM0nZRZk9TAoKoXscP770PzYEBHHfM4Tj9jDNw9FGHY/PTm7DrxV1gLFEJiShSZ0kZSIyXd7CAhTAuIzFDVnloa5DeoshnrLK9r/tkUKKLzdUGdK3WMvbueQFDAwkuufgivOpVr8KBmQPYsnU3vviV/42o3gSJ/H2YS6VERV8989fsokSCWXsL6yKlbvWibkAoRTozjdeccwYuffubcci6dViYX8BDDz6Inz74AHbu3AUuKKIkQa1WU1sYMpaPQzrYI3uvmWJfr2KjtQJtTEzsxem1IYvSIQRa4JMik1fsj0NLG0RbHT3AOUen20WrvQzILg6aXIMzTj8NGzeeBCEk5uZmcP9PHsH99z0CNjys6t+JKsqjhEFKqmM/ZQyVsPLTJLG3sXI4RplZUggImQKC64YXRUO/iAHpwgIGhhq48MILcN7rz8GqsXHML8zj2Wefw+apTdi589fYv38GrVYHmeBOuFuFuXVzpxDIyerhCwuHSjRagxA4/Uyddqf2hp2kwJUWFDWYKWltnWucJolanGB4eBiHHrIOxx13DA47/HBQGmH/gf2YmnoW3/veT3BgehZseKgoSSVqp0ACCkIiXdjH9NipuxIMAWKzAggBccxD3XhCqi5ZUnCdd9X1wvp/ESVI0wzI5jAxcRBe94azcPqpp2DN5FoQStFutbC4tIhWexmCi7x8k1KFnzSYo1qtpr1rAsaYzgG7jZE6nQ46nQ66XbWXZKfTQcYzSN3N0E/+51BBs0usVoAG9U1pBEqLjdqUVcIQJwnqtRpq9RoiEmG53cYLL7yAqc3P4OFHHsPuXb8GokFESQIuRd4Vi4Aq0cUilfOFBmcR6BxwIGkU+yLIyQAJQApdJ8whkakdSgVXK0LnjiE5GKXI2h0AiwCt45ijD8Pxxx2Pww8/HOMToxhoNpHEiZr0OEaSxEhqNcRJgjiOUUtixFGUl4PSiBUNnyAhuUQ3TdHutMEzgTQ17cdEKeysQsQGk2zGj7ylJCFq926qj4CJV+mNRQXnmJ2bx949e7F9x3ZMbXkOz2zZhk57EUADrJHoWjlV/yWpTrDTCITFRXdcG9JOWNjQqU1skMJLPNgtZyBN9ymZi4tCRGUgQoBIASEFiJRghKgETjoPwPT4j0BoHbGuPlSriEIYMaf1lpRm/wK9ygjLZbLbi4KCUKb6dNrWhtWdqbyFIlHlzUIgb54hXGQEdKE65xw8zQCk+j81kGQALGZavVK9Wx5RO72SSI3Fh7WYmjVZVshFStLEXILZJF2grJM6REo9JzodJ1WgT+pCSqJbXFKWgNQH9FyIvJVYVwiAi7CFk5feqE1RpG4OZVr5CK+XDzjcXgrGeiG2oZcP3MobUisNIq3m2tZwKAFtUIVqyBv4UUhiirSp7oVHdYcyovarRrE7KyHEuW6VcxeJAMILVgbHTAQlLupYORNJ4fQ4lYCxalugZ4pIFZAtWqIVWHoiiwS4a5zKXIZLCac4mqogilNqSixAsW7bVjJwJNQKzbfesmVyDkRAsYW53lMYUk0tdbrkWtFXKR34uYF3qho4EfT+c1SEX//kN2EqOy3+zqS+rKMOmkAissw/N+pa1PwSULNxRGlzXQlGKJis2NK8aOzplcZYBxC/vFT/7KDmqHOuvXOrv7NsKZwRaEpCSLlwxRaKDiqiKsMT3tfFdnZ4z8IF6xEciEbe0jL3XhkA3WXR911AlH6hNOxQ6QZ4hlg5t1HijcAbJ+mxh4BThCIrg3vVoRG3UR+x8Kd5esZIGedigfaM4Ti8zJPLK83X2nnmIlNmlKoo9pYvue7uJPmQ8V4d2vvlhKs2cPCDiSsNhfhJohA4GXajJylVyIJ4eBz0KDkt9p53vbyVFGkUrdsLSLxn+JawSe5GoFgR+Nc+NwRVcfGv1bnmlQbo3O/2NcsoOh/QQPsl1n1OUYoZQRe73/5cag5dIii6243t7Lh975xAOFHCi14X1vZcVZs798pYVcn8XqlTP+Fob5JkGzvmmf4fMgjySblxfc4AAAAASUVORK5CYII=", "ui-sound": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAaa0lEQVR42u17e5ydVXnus9b6vm/fZ89tzyWZhFwJmQCBEBAtNsFQxGrxctyjRY9a24P1gi31tPYods+2clTUeqzKEZCjaLEyg9YLFZFCErlFQxCEiSEk5DaTyczsPfv63dbt7R8TEI9BaAX9HQ/vP7P3b/9+8633Wc9633e97/MBL9gL9oK9YC/Y/7/GfpsPJyIGjDIAYKxMAOh3HvFSqcRpbEwwxk742+8s007kdOmvLu2951tXn3n31/5hYxEQvw0QnvcjMFYsipHxcfPk909dcVp3X+7P0tmOFy8+aWilDWvdM5Ua/CC8uzpXK4289+N3lkolXi6X7f/rALCxYpEvOH9S8tb//bq39ncnL6Vk3+n9iwacgWXDmK9O4/5H9n7hkYcf37/65L7diwoDZs+Du5tv/ZtP3vebAuF5AYCIGGOMAOCqy95w4YaTu67acPaq9cobBEt1orPvJN1uVfkPbt2Kh24ZeywM6/3zM2HDZNL/6+WX/82Pjz44Mfm3H7/28FP/z/Nl/PlyvlgqedeU3vG501d03LbxrMJ6P1YmUVhpc71LSTjC2XXvfZzvvZ2PXNi/5uItqzsv2LL2pJVp9um93/rKJYMXFP0SwE8UKE/0PCLiY8WiIFrY0P9IHHmuGcBKpRJbhmUeOTu/uSTZfMWaM1cYz42Z07eJZ/uWIpHK4fC+3dh751exZqnG7j0Nqsg0RCpBNF8zRx5+zI1Wrbmw9I+33l4sFsX4U+LHs7FLzzrLvXbXLvVsj5DzXKa3Jz5L98HrV2TUK/JZpjp7hNusZtCzeC1gFaxVOPrYAzh1OIeD+6cxZ/JMuh5kbJnX3UeFxQ1Upw58hIj+DYxZ9qs3j24fG8uvPLXn1fu/cfXhYxU1nd14Qd8FjYto5D3lu6lU4uwZQODPlfPlctmWy2U71OWd2pOylwhVMYtWL3ejegVuzxpw14VIpFCbPYoUZsBMiMl5jpglEEgDaS1ibYTpW2wX5ZxzbvzYm17KABorFsWJnrm1VBIAMNBXe4/dc9sNGWdq67qV/s6uoz/qKvT1v+rrn/nr81m5bOkZjsOvDUBxbEyUy2X7F5/82Mvf/sWvLUrEx97fLXzKdbro6MkgbCpkFw3DGgkmBOZnDqO302BquoWmSqAdxvBjjVBqaKUgMxmb7MwhUd3/FgCYmJ09IQk2j8ICQGv/3VvQ+Jl1vUimUjKX9Q5dl6gdGctmUu/8P5/8qyUYLdNCxfncAMBKpdJCwCmV+DXXXOqOj4yYt1911X9x8j3/fXPr4XM6XXMJs3XK9XYIkjVoyiOZ7wVZCxu3odrHkPQIMxUDP9Lw2xHCUEEpDSklLEle93JwlPz9a4jc8vbt+oSxanw3A4DH7vnRY9br55Zc3pgPTCZt+7z44av7hlbdlAA+ABAwOvrrAUA0JsbGigIAlctlOzI+bli5bN/xjmvVa6+4Yn1vf9/NhUL3NTysvj/FfLhcIpvPIqxWwNKLwLkF5xxBqw5B85BBgFrTIvRjxH4MpRSM0tBag2TEfTdHQrgrln3+beuOHzH2C1UlwEYnxokAdtude//nfXfsmM70rROAZY2mNhmn/aJMdcd5p5979tmfH/3zIiuX7djYmPhPBUHGAMZGFiLxcMn7xJZjq5y4me9wfBv19KZ3rzrlxlQ+99Ule29n2bQ4VwXzJpVUwku6aB7xkVo5BCt9COYiajeRTsZoTLXR9C1iX0IqwAAQjKCsgWYaItVtmPQc0Zw9D8CDm7GNlwFLVOKMlRcCYxm0rlT0vlYeP3T67NSfHttX+F5hyXLbOrZXNEA2jf1/edrat+Dg4wf+eqEgLdr/EANKpRInGhNEwEPb//ltO276++/+65sf++n6oeZPz96Qu3fzBct38OHT70znO3t6osanYthRiuoEEzNrFGAlgpZBorMHOmoDZBGHDaQThMZ8iMBXMFJBGoIiC20kTOhD+z4AjZYVoCh4MQDM7d5Ox2+MFiBWKl3efdmbLuoYKY/L+y89y/3bW2q37n5kYtRKVyRzBWOU4fXZx83BnbfZM8550YZPfvBtL2GM0XEWPzsGfLhctuUysHvHzf+Y9/dcFrrHsPjMPpDjom/JUnrs0DGzz1vD0zIcz03dvyqdoOFormoEj4TxACvbCHwL4XLIoAXhpWHiGgRiNKoRZKTB4gA2CNH2HbA0R0IYGA0g18Ej7kGr9hpwF8XhDxBRmR3+8ec+61c+VXv0Z2ybd/6GC9Yv7fU3fvSfPrK1tMk5v7z9w/+y7PHXrj1j7fqwOWtEIidmHrldn73hAuesc8/YAOC+QmGYPSMDFnYe7FVXXtm/defWmzrNscv8xuOmd/linRkYsL1rziTuH2EPTHFKcofnZOvLMo7ebdsVsnEbOg5BsFCBj1hyGNlE7NdhtIJVDVDcRqMhwU2MIaeBLev78NK1g+iwGlGjCYQhWFBnkidglR3Yumusk5XLdtuVL3pr9OAP3j19z41XDLFd/7Kiwz7Sk8LFn3nHKz9zfnm7JiLMHtn3nsqxKiU6Csxog6A2jcbBB3DGxrPXAaDNm0fpGQEYHR0FY6BXbDjtcxsHxYg/+RNdWHmKcFMpJ9nRyb2EYJX9+4zpGXbRrnyj88hO67FoU1A5RkZKoWUMwCKst2AoidivIjwOALMhZDtAs6WxPK+w6XUvR9i3Bvt0FwprT0U2nYIMfDhBC4aAKNaFrgP/1gcAfkO9zq8c00FzOg6Dam5q4s5PbB4ZSa9amn/vB4vnXcQYo3eM1+6uz85+vyM/yElJQ9zlkw/fC27sa776mTd1MMbME+XyCQEYW7iz28u/84NNZw71vN7fe5+yXIp0ZwcYZ+DJLKG2F9WZqNXw6VIS+rIw8D9qmxVu4oCMklBKw2iFVqUJA4GwVYcMfeg4AqcIYSARterYeP5GHGm7+PJVX8GRb3wDE3fdi0RXDzwiUNhmsJIMwYvnmz0AcGBi6kG3Y8BJpvKiWYvIBMcGZyfuWrf+ZRfazoT+3GWXXdZBBFadOXZD7MdgiTTABK8cnCARzg6cf8Frz1lIn2P8aQEoFosEAEMifN+QG6I5fYBne7qYVSGsteCCITi8B9UG8csvueS6nj13bUlReE4wP2eMUsIoBRVrGGXQrMeILMFv1GG0hVYSVrXQrEXo7etAatEQHrljG84d7kbW87B47iBEZQrpzi6wsA1BseXCgY0xCAA3f2/mqnu3Pnh/3/J1DtfKKpugA/f/K6WyGVp7+tqVfPbhP2MMdPtDR7ZOH6vOpbNdwlhLcdg08dwhZLs6X7LgZOHEDCiVSpwxZl/zzbtX9pjmhVQ9QLW5Kc45IWpUoOMWSDVY/eAR1CPecdWnr/ig8YOPRrVZIqWYUQpSWUhpYLVBEEhosvCbDVhrYYwGowj1+SaGTlmDeiOEixBr1g1h+caTkctmsFRUAQAJYSGsXKhBEPQBwA85b99z1+E37p84UMkPLmM6iiDDFpvZcxdOPvMM6upIvXnr1q3OP/0Us1Hgfy+dygLWGEtg85OPQQBnHa8h7YkZsHkzB4DVWfUHBREnwvljtjY3x8L6HJrTh+FXp6CaR1GbqqDeCOD4tY8gqA3Jdotpo7nRFkYbSGVhjUYcEQwBgR/AGAutYkAFCAONXF8fWtU6khkX9XaIwUVd8PoXw9Eh8gkDz3PhUUQEBqNsAQDu/NCS5Ffm2P6Hdj76cU+keTKVttYyHN2zk3f1drP+QufKW7d9cwAAa7f9HWQYABfEBKvPHIEK2sOXX15MMcbsU+PALwXBHNMbnPYc/PkatWp1NGbmMD95FM3pSQSzR1E92kC7HSKozFjlN8loBaMMtNLQxkJrA6UM/JCgiUHGMSwRtIqgwyYIHKl8AZMHDyPpOsh5ArHUYN09YIYjzSJ4CQ8eSYAzgIkuAMhN95pSifi3dwc3TE7OzWc6eoXSROH8LNP+PAoD/TlTq/YDoKl6fNj3JRh3OTHGmnMzJNvNFef/wQWnHuf7LwMwunnzQrXXmj9NN2ZRn6uxoBmgNlvH/Mw8ajNVtGbnUJ0JEYQRbORzHUdMqwUAjCFoZaC1hY41gsiAGIGMBpGBkSF0FAGMw1oLGwaw1oBA0MaCp5Ko+ALQCsl0Ai5fWI7riCwAnHXBCju6G+zBNubmqo3ve44AJ25UHCOcP2L6+roY53QKAMxUo30NP5ScO9xaQAUt6+iIN2zqL0+cBp9oPY0dTrmRPyjbTcxX5lkYa4TtCO1miFbdR2u2jkpDIZYaJo5glDru9MLuK02Q0kJJjVgaABZGK5DWMDKCCmMYEtBhDUmuQNqgFWp4gmAAaCcBVxBSGQeeB8Y4QXheDgDGAWybBQPAeFi/HdaAc860sWhVZ5D2CIIJDwDaB47OOLAzgnGQtaS0ggqqgI5OBUocKNMJK8EVXcozh1rJoO1DNlsskgZ+O4LWFkobeLaOWqAQ5S1gNchYWE2wxoKRAScLaCCONSJloK2FUhpaxlBKIvRDEDmQYYS52TocJZFyPISRgnVcdHUmke9Jwcs6sNJCWgbGeOqJ9c31gQDQfGAaSioAgCUgbDXB0zG0VQQARx+H0kZJh2hhfQws9lswJp/HqxYlGUMAIgbG6BdiwJLBFSbWVjeDCO1mm8LYoNmUaDQlarUQ83MtNCKLyAIxMWgAigjSEpQGtCEoYxHHBm2pEUsFKTWiKISSIWSooKRBu1qBxwg6lmj7McgCjmAQuQT6VgwglU3BcQQ44zCOkwOA4sQ4TcxuYgDg5LJZKSWMsQAYjJTUbjYgifUBQCuf96SipNYGhsCMAZOxgh/FXvfyyHnaOmBvdNRGuW7blhYtP0Q9INSbCrWmQr2hUKtFaMdAAAeBSCAmB4oYpGWIjUWkCbG2CCODWBHCUCIIYgTtJoyMIUMDJQ1a1XkYQ4iUhbEMgTSIwgiLhzLoXLoEjicgXAHHdZDJZHwAwLoi27wZIICtGsqmjdTQyhLAoY1llUoDoRUNAFjT06BUwoHWBkQAg6A4ihDGqjkfvzd88pr7JADHv0x/99ooynY22iIDP4jRDID5pkStITHfkGi2JNqaoc1TiL0cYjcJCQfSMigDSEOIDBDFFmQYWkGMRitEq+nDaIMgULDGIgwU/ECi3dYAMQjBQSpCYUk/vK6T4AjAEofneUjlOupPZmpstgwgOO4rdKRAALMW0IbjaKVNobJtABhcs6hfKtMTRRIAYwwckTSo+jLCIMyJGEBExFEu2zCVOxJ2DiCWmloKaPkSfqjQ9jWiUENahshNQma6ECey0NyFAYcGgzIEZQmRXEiHzXaMZjtEs9GCikPE8UINsgAIwLVGoxHCb0sU0hrdy5ZDWo5EkiM2IC/hwPW8NgDsqnVxjJbpY29aNeQRXtZsB8QFOEFQEJGYnGtVa+jYBgCL+rpXe65Iyji2ZC2EcKitGULDDqHMbIlK/IlB7M/T4LZtHABMJvfjuP8kImFJMYFIEbQmWGWQYAYCFpo50Ok8VLoLsZtAzAVicEhwKMsQSEIkFfwoRhRJNOpNqDiGVAxaKwhm4CRc1EODtMvgWYWurEKmsAxhqwnH5QglRyKVBIlkEwB6vFgwBjp5KPc+LnVOkzbWWuZ4aZpvRDRZDeZWvHq4QgBLZryXuhyw1lhrLYSXoLnIohLRoQVnf+73kx92z80RAFQq1XvCrkHWUejlSc8FB5BkBBeEzjRHt2dBFpCJDKJsL2QqB+kkoJmAISzc4rSFtQpSWshYo93yoZWEsgLWELhhcFMeiHOADBblJBb1ZWC9BILGHGAtQuUglU4j35k8DADL/+SG6NYPnfbS7oT77tm5uhUJIaQ0SOc67VTFZ8ca6pbP/uFfxAygzo7kqe2WD8ss0xYQbpIdDQWq0tkBANtOFATHR0YsGLD/tu/c1xbpw97J61jWgRXcQacHZF2GTJrhpDwgggiSC6hMF3S2G9pNwXAXhgkYBmgDuJZgNIGMQRSGUHEMy5KAVWi0NTIpB4sGu8G1hKnPobB8FWamq1CtOkJfI1CcpbJ5TMf5DABc/87TVmS81HhYabrc0TDaMIgMcSfBdx8Nw6pNXA+AlV65ekU66b60VmsQGDgsI7hZcaBu5KTbsWMhlsCeKAvQpju3Oruvvrr9eKU9XutfwXo6XMs5R2eKI5tg4A7DykUukvX5hRTnpiAzPTCpHIybgOEODAQMMbhWQ0kFkIWWCnEYAiIBE/qQXhbxTBXu4BBc5qK30ItjDeBnD+1DUvqoNhg0MUrmctgzpzcAwIo+/l41U++vzle18Bwe+hqLhxbp3YcafN+8/dLD9977KABad3L+DSluO2QcGiIwwV3bQgLHIvbww9E7D4LAnjox+oU0uH3bNguAPfjAvs9OHGo0Fy8d4Jw7lEgKdGQckAZ6+z30x1WYuRlEhhAl8wtMSGZgHBfEOLRlcJmGsQaCczBDiPw24HrQYQjR1YUjMzEmHzuA1HlbEJz5h3hw1gNrzcBvScxHLriT4MxxyXXtOABE0lnbM9hp4tC31ZmWHVo2pITnuHdO1OdmTO7DpRL4pkIh29Od+q/T01ViHFzHBslklg5JF1PSHUeZ2U2jJfH0HaFy2RaLRR5d/aFDB+fjvz+WG+SplKOrEaNsikNqBiQ9nNITQO3dC78+D8ldRKk8ZCoH5SZhuUBMAg43cCzBdcVC4IxDOOkMmDbQxsAsPQWzkzXsunUrdt59P8Tc42BaYc7nqGuPMpkkd1P5Wj6ltgLAAzsP3dxK9IkVG17kDZ++mvctW+T+89bpw9NR4pJDEz+aKZdh3/vfVr0964m1jXrdcs44GU5OJif2+k5w2GTHAGD7U+gPHFdlPNV2795NxWJRbPvqDfew5acPrsrZc44erTEdG9MKyQYxo6EOop9MGZp0OynpLIDIVQSmIrA4hJEai7wIbeSQ7fDgWYVCbxZOrgfR0f2IEjnoriXIL1mMTEcCSwouOjoziCyHAUfVJKmQTbKT12149IpP5j9bLI6zv/tSsGsgbEwuXtHflxsYOHr1bXM7r/9+8LpjlT0P3TRWFMP1auHM0wdunNo/k1Y6Zkobls7kbCvdw++sdXzzp9d+/oulUolv/79mhSfsCo+Pj9tSCbxcvunP8294TWPJYnPZw0emU55R+FnNYEmWY0OqgX3tEJUjoe3JOJwTAdwDZwJEDI7gSCofnGeRTXJ4TIOEAHdTMH4dNs9BiSwS+QxMwsBHDEcwgIB2zKk7l4Z0vNnx8RFDRHx0lDHGZq7/6F0z1z91Orrz0rPcjSPj6kef2XydbsqBubmqSaQ9YTWhp9DLvjXDzN6a84njm8uebVucymWACIyxb73/j95cvC4Z2LMOVKMzDaPT9vhUWOK0bCc/Fh7pXrpZzMxacjQHFDgxCGKQzEEWIQTj6Mm68LiFYhpeRx620oC1ChwCKraIBeC4LiwAywS0DGmwtwtSuA8c3xLGGOxYEaI4Bis4o6+//vViYniWbSxvV3dcee5H8gnv4nsn9hsn4YowkCgUenU70ek8VKGvT3/7hl1PN2r/VZMhYuzJye8+APsA3LQAPccuYgCOou/iFVe33a538voBBSZdx2gIAG0jsCgZo6kUuvIJeALwHIu4ZwB86ihM1AKSHWCMLdwniMEBEBoBR9d5rqsPUarv9gVGLixoZBxmoZdDQBEoj2zXd3/6/Iv7OhIf3LFtr46NcjhxCOHaoZVL+Bd+EtV2VbrfTwTGRofpPzUbLJfLtlQCLxaLYtMmOCWAM7IgGIZiUcx+58Z3RSS+G6R63DhUOo4tLBEakqEnC8hWgGQmAdfh6EoDrLMfKU6QjSosLBRZKEOIDUNsOOqxpd6kYSw/EP5g59QMAExMTPzS4ovH/0aKv/XxR6btfL3BmCsQ+hGtP2O1eWDe4Xc8Zi6L7hk/PDJS5HgancCzEkiUy7ALLQlg+8/PH2F8nFAq8dlbdr2R92a+m8gMvMyrH1IJguvHDHA40GxDYjEyjkVHysLJ5JDu6CCqTMH29DM4CUjDwRhBAWg1WvaUVXkucvkfXloc2U1EnDH2S4sf/fzC2Hznbjl59qrF3Dk4GQW1Fq09dSVUR8G9eVvl6smd2258JpXJr6sPsCgD2HVL4Dn69W2W3tpK9bk+ebopOc0EDhYlQ1TrGq4nQKTRnSF4Q8Ms41dYMD8HGLXQQYo1apFFpjWHFctXMpPMf3GB6+MnHm1v3mwZgB27Hv3ioZpub371q5LnX/QSp2/1aucLd0xfu/UHW98ztuD8r1SIiF9fH7KdUCrxxnXXhU3dO5bszg2TcNdxGcFIQ+sHLTtcd7F0cRZEnHq702xfq+OgnXosM1sLmEhnGLhApCza83Xze7mQn/SSLT+dPPWN77sGADv/PSd0YPv27UQE9sfv8md6Xf39QpennI6OB27ZUSl9/us//DRnwNjEbjyT/Pa5FElxHC8yBs89/3/02PaVPUGFvXJxQ2skxNJTVrKBDmvWnbVaPDIZf+mub91LUP7bD/NO6fUUXHgJKkztMcWRLW7hFX980eIVf3QbjY0JNjLyK0VStNDNoF/UM+AJgdkzSuzEcwgAHQeUtycP3pU4ac19kon18z4bXJ9ts2nfMdpYZqzFYCG95mDY+wFTq5yRVv6isOmz/MwRtuXFwyKz8bzPnXzOn352bGxMnPoMzi/IBIBSCXx08ybx5Xefw9ZhHT91ZPezFlg+L0LJJwPPueemhiJ88PeSc5euTgYFk+9DV8LKC39/uTtZN3d88/Flby3M3fMPYTvcsn5VIR6+6MLrX/z60RL93Yc4K/9m1OPPn1S2WBR4Ivquuqgwkpu4LJtOXCpynf19acKW0/N4tGK+9q5rd7wp7Qm0W36CMRb/rr0vwIrFIr95fNwQgPNWrSoklw1coJT5kyUZe9bGQbd7qmam5lnqplaMG296S89DoxPD9JsSSv8mX5hgxSL4+PhTGpJnXrzoRZ3zg2ekw36V7NAm2/HjG274dv0JAeTv7HsDxWJR0G/5TZXfBgOe9ngAwPDwb5b2L9gL9oK9YC/YC7Zg/w4FjSxDyG6ttAAAAABJRU5ErkJggg==", "ui-sun": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAizUlEQVR42t17eXhd1XXvb+1zzp0HzbMsyYM8yCMY22GUIBhC4AUCEiSQQMsUkqZJ0yR9/TpIavqapt9r0jYpKSkpFEIhEpSxzCBhjLGNJ2zLsi1rnnWvdOd7z7jX++PaxCE2oSGP9r39fefTvVdn2Hudtdf6rd9aC/gvGMxMAHDffXt8f9s15j39t//vB3O7AIDhdx/eku7/4a7swb/fObrnXy8EAG7P/+//rQUBxNwuPuwbZGZqb28XieF/fY3lk+zsvIenXvnW8EQiUQwA9OH0IP9M4CNrzUeVOIEZRJ0y//GD3yAzExHxZTffXaw5+jpYLmd8YtQ0RvfX+2OvXgcAr7/ern7wPUDMyD+TOT+H/woBMIMAcDM1K8N7H11JYEHUKZm7lF93rbsqpDBJBcwKuf0iF5lg5CYvA4Dm3t5fI0AwkeDBA//eSB35OZycy2801I+weGy//3vBpgsK/tnrT7ekjz94ePrQc39GdPUO5i6FqM351Ss7CABrxw+XIyQ9gAJFc5ORSRNLfekzk+yjasqe0pRfNZyEnsOzgfWeZ//RXxi/fP7K7736OJ75EvA/cswgIvDHowHdXYIIvHwNX1NQ7r1RLaou8xsDl9arJ14YHXr9M0RtDnPrGTShiQCgrsbd6PErHoClmUqRoZsIhdXSy6tQdpqg3v9QQQTeEHzn+wXV4ovxvp1l9sTeL3zud+gqIjC6u8THtwVaWxkA3HWbMvO7e6HPHZVZv8dKD+8IVdjHfzYWHdtE1O1w1/u2Q28pAYDiJDYJjwYoUubmJiGEAlItYUA/43x6enpUojZndvzQ9X5P6k7otn301Tc5k4jJYJ27MD+nj9cGMAgYKm95lUrqj6R3Py3coWI1zSyNwd5ASfqNnz4f5RD6+vg070Bo7pXHj7NbkfPng9xANk6JsQkIATi26Z2cmfOe1IDTVL9HbWlpsYcm9OUF6qEfqEqCkyODYnZwXAnUlAozrcQ/diNIRMyyVVlPlPE1XfqDQFkd0mPjsrRpvZg4etDWJnpWb3Fe6aDOToneXuUXBqxT+gqNepeILYG0kZs6JhIzaWKymW0z7EpnQgDQ29shTl4jiFrsgQmurXT1drmM4VqYC/LgU0+J4uIAhWoaEvunG98+qZbyY3aDq5iZ6Zh9wTNYdN4Jjo8r7mBQsjegDO3e4YTMI1+ZiU5eTi0tNvf0qECv4K4uxWUPLVOMqXJpTsvUyCHouiTpsHS5WStQ9DLu6lKaS5sEMysA8ZsHubACz3V7rCNr4Q3aQz09yuHtJ5w1FzWBKtb1bGmsn2BuF+83mv/XBUDUKdHboawP0pwSWrLDRSb02Jj0FRfRxEiScgefdYWc7T967jkupJYWGwgStbU5em58laJE4MSH5OzAIKWyErmszZBJpM1YFbW1OWhqtYjI+cb32bOu7Ol/C6hHNyNUbc/37VJ3PLGTFzWEqHjVGkTtZQ8CznvG9eMHQs1NzAwS4YqXTFchzx/cLzQXkMw4Yt/LRxzv/AuNF2/Z8eNXrv2r4raOL9Jg+48uLE+l77ITE0iMDCuzYzGkDSARtxUnMoyqTPz3h/7kBxfHH/unuunvPNTwnVtf/0lQO3IlCtZa6aG31V0/fwGWbstLrmkSeuH63p9EN7yQB1+/mfqfVQDMTMxdSk9Pu8rcpbSfFaO3SiLwkdSGN9TCmqQ+NSXik/NMgtA3kFMOPf4iB/HKjZu/seWNfyn5yuu1df6XXS5aYhsZ5JI6zUdyMCUwM2dRZmoWrqCzomZJ4MWAofWUbK1/w2e8dQvUJmlGDmtHuh/D5IiJFY1u4V/bjAVx8Q86V5MJNNHZ1D+PGruU/HFmqK6e2cYRI69bp2FeQHK7CnQ4px5IRJwHINqkPv/o3qJy36V7eifZMJl0y8A7ux0qqX5QVl5f3ARRA5nOwXRNsKdgNTmj/ZifTcNyCOm0g4l3x7Fq5SCjrsGreLR6lG+H4wRYEbYYfeYnGD+eg1sacu0ly4UZWLvrn3/U8PxJwOSc4QUKoJvyYOxMgOwsGnAK3j7/8MOhmb0/vGtqz73t0cHHbz9+eNsqhgKiTlsQ8S/D3R6FYCPLi58qbGyAnY7KTFbCpREWMhbefCUuktsflGjsd3itzVrIT7Z7PUZ2HUYmYSCbMeGwxM7tUcwf2U7aRoXt2gEpVUeqVato+sW/w1RfFNEFC9XVDvsbV3PEaPpJZyfZQLd4v9Yyt6tEJInanPuf6g9OjL7Qmpz7jzte3PFi0ZnCbvX0qA5gHHjom/6Gc2IPhlZtvA65GBAZhBcjuczME9ss/+Kf/jyw5ikisogAKXtU9AKyq0vp27/y6dD6Ld9euvKVmrldFjuSSbDEyLSBN16MiDWpNxAoqYbjKsTEm/+B7HQKy5aWIKNLOCwBSBx4vR/Lcg9RaeNKopIGjHd/F2M7DmNu3oFjmbx0fZFi+Tcnp16032Jmgb17Bfe0E7V0Oqdr7YGj0w0VgWPXBaydd/ld5nJjYhirZ3NXMY/dDJB+Omz+xRbgdiIiGZ/dU4F3H2wePbrXLmxq5FBxWNFs06ss7LvCZ41ccZvev+2G+IkfP/7zJU8QkXXq8uNf/84KpXZTuOr8TVzS9yZypgqLHQhDx9ThMfjYRMXqDAAT3rAHizfUwM45gCMhmSA1FwwmTB0bwdzRE1gYHcdCzAZUDyILJgoCDpWu3SCV5JJg/dxLnyZa930AeePXzuLQDWOLK8siF2rm3Fa36+0L3Wp6EaxJHH5umzOx5xA133bLxZGkVVsWxvG84ez85VDydNWI7PjOA5ndT916ZO8Ru+a8NaJx6yVCKIqTHB5ASVWlgopG5MSSPSmj6kfT28Te8oHXzissV//Svbyhyql9hwefe4B2vJ6AFU2hbk0Vlp2/BELRkBqfgh2Zg2IZkFLCMiVgS0hJSBsqDJvhCYbgLgqAYGFmKolY2sJ8ilBfaaG18+vsjJ1HzokpPZN2fTtx4RXbw9WDF2ty+jrNMTa6fcIPZIDELObHxu2+HYeU/duO2FdcsVxbfPXNr7wmvnXNpx7psNDRwe/ZsTNFXPPgYCD6s/+dObLzzmPPPoV0znLObWtRFDdhYXDOCRaGqKSxQiBcDN2snfdEaoqRMmEUEGtV0zT/7lvYfe9jaLzqQvhKg5jffxBqZh6F1cUILV8J1esGWyk4uTRyCQOs+eArrYCVMTD59gGMHpyF1PwIVAehWw5ODGfg9Up87o+/AE/RNUyTcaICF3Ku40mvay4Elw+cA9ILUbkwNimHDo+Kgf5ZkZxLOhecV66su/Hm1HTRFS1Ll166Nw+aOuXpxv2sXIfBI61i4okfDj/9s/LjewbtxouaVEESkfE4PF6vrGgIcVmDVxFlNQ7UxYK1IJl2ECNP3YeC+iqYsRlkjx5E0aICBCqKQaFFIH8VLFsFQ0DJg2RIh0CCIFQLnBjG3IHDOPb2LMaHTbjLQ6iqC2JmKoml62px3i2fhaHnmM2IdIXqFBFeZGenjojpve+Ikf1DGB1LIhqzOSAs56KLF6mrPntTfL7qxi9Wlq5/tou7lLb3hel0VtKyu01QW7czMD/atNS1/V+jz91/7ttP7bI8lRWabZvIJHJwJFBWXcTl9YVUUF4Ak93ITU6idP06pPp2Q0uPo/ITy6GEPUiMC5hcDFe4FKq/AMITAClKnt5hCWmbcMw0zPgczPlJzB0ZQnImhehoBhkLWLS+ArGEjeWbl2DJhedAKW2CmTN5fv9rNPTWLpzoT2A+RfCwJVcsAjZfe6nwbbxiz7DninuWlq7c09XVqrS1dTu/+po/kPjoUYla7Od3Rmu2Ln/l3/XtPz7vjYe3OwsoUSy2YGRNWLoFtwoEPCrKgybW/E4bMkcPwq/lULa1BdmxceTiFshbDFdBCYQ7CKG6QIoHDAVgG3BsgPJaYGUWkJkZQXxoDKEgUNlUjzd+sgNH+mMIVvmgKoSG9bVwuQA9EkF0OouJOQeWLVCmpZxPNNcoNVffZJlVn7y319z651eVUJJ72lVq6bTPrOe/lv3JC2HbvqnSTQ0vP6QeffDKdx7udQYjhUoyZ8POmfAqhHJNx8Y7PwWZSwNj76D6+jbk5oHU9AxcRcXw1zRCeAsBZsA2Ia0cHF2HpeuQlgmwBCkaABu5+WksDE3AiMew+BPL4dEkHvmTlzFnaigsVOHzq/B4BFK6RCwl4RMSTZVZueWLWwWtvfHYnOuir1UHlr2Un//Z2KkPSYkRtdj5sJQil9TxdS/sKnpoyzfrW4se+bncf8glonBByaZQs7kernAA6XdfR+0Vy5EdG0Uu50ZwyQq4KxohfLWAcAN2CmwsgDM6bD2CXCwFWzfA0gE4D0hsPQvTMhGJ6nB6D6O80ofaOhcm95lAWAWYYZHAXMKEjx1sbrJ4w513iHTR557f9ermuz7Z5p/kX6BW5yMHQ0Qkub1d3TZG+j9XDN+RGmvra7z9D8X6c1mWBN0oLHahdO1iJPbtQdGyEODRYOqAt3oxPJWrQKE1YFc1oBSCXSWA5gdLC7aeQWYhisTsLOJTc1gYn8bc8AQio7OIzaWQSluYmzcxOpgCk4qyoERs3obFAum0CT1t4oJzwBu+8gcwotcm+j73yrc+2eaf5MNdLqJO+8OEyOKMnHt7u2Dmk0eXwtyjoqMZUvaoX8PXknL/wDRGNqF2621cV82oWlUDaTqwI5NQgyEkJwhqUQ08FctA3mpACYGgnGQsFRAcsJWGkU3CSCYxNx7F+OAcpkaimBiOYnBgHjPTaRiGDagK1HAAlSsqcN6WItiGiYypIJMD6hd5se537wFPnUvy8BBVXxvS8iCnD8z8AUHcmaAwMwEdCtApiTolOjvPeMGJP/67y/yFwS1SN1mtbRJLtl6M2MgEUoNjKF1UCumrQXrOQGGVG1A8gBoEWAezyDNpMgtppWDnYrAScZiZLPRkDtNTOWQMCZYMw3TAzCgIqqhZpKGoMgSP342KLbVYkAN4a+c8KmsD8IdVKIUryZ5VHW9hQYhGfOcQ3f4uABPoPLmuVgW9XyY0NzPQDaCPgV8AIfVUuoqIJAAbEDg+frRGszlokUXCzhUWu0VFGo7Pb6TX+jILt6kePWAqw+wKVxP5F0PBKLILCwi0XALpDsMc64epZ+FTNAAEkjoABWAJNmcg0xMwkjHkElkkF3JgR4IgsRA3kLMYYEAlhkvkU0X+oiA0TwhO2IemT/vx1rYXUVgQwNzELAaefQj1F18mrFAIZcsDf5Vqe3xTXAnvF2pD34lExRBRYDq/8NNHJ04BIvXUhzefe2TximV8m4bk+V5lVz0rSlDaOSHUTNjtIa1A2IAnDWgx2LkUu5RCSk0aOPHcz1FSVwm3xnAHvFiYnodly7xrkybYSYFO5rvYioPTEzAT08jOLUBPmTByNhYWdKRTFlhK6AZDtyR8KpBzA4ZuAxBQ/SHoKR1hv4rCkBuJmA5PwIOZiXmUDu8hxe+GxxesCDjhLwVcYdh2v11aXDyUmnriuEneA25fw6BlIT0TmZva57u4n4hizCCVqFNGh5/+bKjQ+bEWLigDygE7B9h2PrZKp2EnZh3W02xkspRNpEU2nqbZkb0Y3XcULpYIhTyAZUFJH0NmmpBOWAil0nDSUxDsgNQAwCZkZhpGYhrpmRnEp2PIpnQ4loNszkZKl7Bsgm45yJoM2wb8boZjWTAzGXiKTEhTYqH/BBzdQCyeRTiswtJ1TE8mUVRRhkRkge3cpCTbYcWlKoECf2NBeUUjCiuvBg0CrMKjpu1FqTenZw/c+ydEX35YfX7nzpAY7OqwKwvKZvbOGLmZccXW04I0F7kDXrhdBCubVZKzUaQXkohFUpidTiEZN5HLAosrVeTmM3DiFtIjJ5CaDSOVcmF+ZAYu72H4SqNQPEHAMWGmF2DEY4iPzSAxl0I8ZiIe15HTJUwHmM/YyJoMwwZcboKiKjAthmVaYNuAdGxMDUYQjTsIeyRYSmSSBib6hjB2cAiW5ZB0WEklTGQNyYqqylCBlwuL/QiGfAQhkEzooszLtcsvu6Jz+sCJl9RFmzfL5APfS0y/tBMTkaTbtiVMk6EbtgSprHo9bJMqcqZDhs2U0SWyBoFYhcUW0oaEY9iIRSRGD+iwvEFkkxlMD9mQjkRhVRyq1wM4DMswoScziM0lkcuYSCQMRGMmkhlG1nBg2AzDBCyWkFDgcRNMi0FCgBQVnNXhmA5yDuB2CHVhDUIBRkbSyBkStiMgmQBmdmzJuqHDGc+SoAgLgBWW7CIbl7csFbajT03acUNdTZQePfhPf1C1qKqzOJteR35PwDYNr4d1lzUfQWJyGsnIHFJJE/GUZaclCUNVRNpSEHcYhi2R0iV0kxGuLIGuBjE0Mov0vAHHYSSjaSguFZpGUIhhWRJz0znkMjZiCQtp3UEiy9AthsMEhxiayNuMnOEAUkJRFDADbBuoqA3A74/BEYRMzsZEJAsn5yDsduB3sfS5mANBl+L2uIkVFcwKJCtQ3S74wwF4S8u4dPnyPdPFG39/46qNCRUA6tZ+aQ8U7dNsm6EBIESR/rLyouxKMz2yJLQwtkUxp5dwbLTGbSZ8eiqG+FwEseEI9vUxolkX0raAqgoUr29ENmnCd3AO0aSFyckk3Asu+L0qVJVgmTZsy0FWd5DVgazBUBUFpmPBsPMo0K0BLiHgUwHDZIAJRICVSUNzEwrW1ENTp1Bc7Mex8Rgq3QYuPTeAwqUNXFhTJUIlZcgJb07xh1Oq26fbWSeTytpZJRCOuAPFg1r58lfe8bW8fD5RjpnpPTcI6mQiSgJIApgAsO+U09iT5srqyiOLPDRX6xuZu6Wi2vxMxYWjTM8/QjteHYcn6IE1wUjNplHQEEZBWMHYrIFYQkLLOtB9KlRFRc6wkctZIAJsB8gaEoadd3uaAmiagAAgCPBqQNCjQCiE1HwKtm6idmU5hk/EkcwCi7wqNNvC1ptWY+XVX5DI1gk7S/sSdZV/k/QWDDvh8mQBSowIkH6kD7nO1Wr6dJ73lOtX30ty/BIr1EFAE/X29lFz5AhTgKYBTAPY1Y6vvfqtHza+6VuxbHXNFb8jN9PPRHImjUlNw9GXj+KCm2oQ8jJgSVgGwXEkHMeC13MSByoClsVwThJzigACPgV5LoahnPyrKgJ+r4CetTE3GkNRoQZR4mDH08NgrxczMwmsWVeElbf8HqwdblAkhvGBzB8v/uvWl88U8XW1Qmn9cjt1R5q4ra3NObVm9f05v19wpL8Y7e3torm5WTQ3R0T3V/7RJlpuUFhA8DyWXXcLdnz/72G7gNFBA/7HB2BKBW4QVCJYDkEIBZIZqkJwuRQoar6qwefOuzuHGRIMloBkAp081wEhkbLhQxaupIPXDk3h4AEb5fVhSOHAzOZgDO+S7tqrhR6x5ozy9CjzfRr2Ajj3LiefZO04ReE76O78zYKhjo4OLi3tFURt5pb62y90XbKiySzZwe7iSjKywOzELGxJ0Pwq9h1gDI3aKPECQRegCoKqEgQRhCLg9ijw+RV4vQo8XhX+kAqfT4HHrcDnVeE7+bvXJeB3ASEX4JE25iYyePEdE2rIBw0W1q0vRjJD6H/6KbL4GamdX+32aetLie62cG4j56nxTklE/EFBkfj1fEC7ADpo9epOc2wwuqn0xqL7qOBFj/BWg9xFdPixexHLqMiaBEMwHCgQDGz4RBiNtT4UagRVMIgYikJQFAGXJuDxqHB783G916fA4xFwuQC3RvBpBI9KKHARltV70HROAaIpRoy9ANmoaQihfmkB6pcXIqFW0NSuHbCjPwxXXJd46MSJE+cStdg9PT0fqvrlA0/q6WlXiTrtS9pZnR6/5veKXM/+pcsZCMK/TlqZmOj76f/CWF8EFlTotoSPCL4iBWbUgb/Kj/PXFUB9YgSjEQu2IGiCQCJfCUaCQAw4joBCEoqqgpihMMOxJFQwqkoEVrfUwppP4/AEobxMQ1GIsaypGIZuoboqiLmpBA4f10R0uk+u2vSjhrrNqWf7J0ZuWFlTv+MUmfPBVV4fsPiWlk770LFjK5eE+n/g9USuYClB/kqZOr5N9HU/hpH+GCJpIKEDtlQQcDFqCoHcvA6vlGi5qRTzx9IYOqHD9HigelxQPAISAnlGnOE4gMIMtwIokIDNMA0bnDHQtMKLgoYw7r1/BoGAD8LlwHarKAqqcHkEwgEBx5LIZizYUkN5yLbPv3KZGm65I7LAl91aVtzwAvN9GnDXWbmBM5Oi7e2COjvl1PEnry/0z//QU15SCdvnGAtjYvKNR6nvtT0YmZDQbQHVNp0SVw4lxUKJmxqytgvFBRoiYxnYEQOhEOByA0WlGsrrgnCEgqwOJLPIozwGNIUR8hF8PgJLRmQkhcicgfkk0B9RULkogIpiwpGJFJoqGcU+IJeVMmZ72XG7BSsK2WbexTbWeuSnbtogvOfdmEp6z7+7OLj60Xxe88zUmPqrez5/YmT0+bsK/JP/qPo9anrkmD21s1edfPcgpkYzSKSJvbBkQ9ig9U1BpeLc88AlyxzTyCnbul9HKuVAC2lgTUEqbsLK2HCpFrZc5YW7vhzp6Sxm341g/EQWQhAalvtQurocgXIP9JE5DOyP4uC0ihS5EaoSCPlsHBrLYfO6MD7zxa3Q/AWOiI8rkf4+9L87zdNxxUlqHqGbCu0fyAj52LvykoV0sGzL5CPp9FubntTPbyei5ElqT55VA05RxxMnnryszD/xgoChDfa8Jo/37hSJiO4oJDjoV9S6ajcWrSyFf1EjnNoNu3l+neKOOeeiRvLc2BMUHTiEI4diiI5E4fOqMNKMTMxEeSlh7SXlKAgDE3sjGBk0oQigbqkH5evKMBOxsfv1CMZmBYLFXgRcJkKlXlguF8aGpvHN734WRTW3AkMWdJ84TDUTCxTr22IO7ncdf/s4hqakMxhXKBo3xOIqN2/eUMBrLr9MKIsv2jeUWvzFZcsu6nt/YuSXGKGOjg7eMcbewEL7n2Un+rRDrx+0Jg5PKJqqOsuWlSv1axrgqV3quCuqh+2yulem+dznnn5tzbZM2wq65x/uuT+o1bT5SoKysaFZJPUdiIzPI20CHr9AYYEf2Ryw7Zk5GIYDGwK2oyAnCbsnbXi3T4A8bmihEOobJfyaRFF1CdZ+ogpvvTmFch/ghi150hDpvvGHn+3o+cbN6WfjkwvHtoSXHb55zbo9N644vL1w72tHcXCY7Jl5U7y+Y56OHe22Lv3UsXPqL7j6/tF4/KoO/CBxeh2ienoRY2dnp+zo6Chd2D28fNdTLyGZJXX1mhqqPf88uJesOYDiJc9n/ec8f7+2ZN8fEuXy9gKCCPLag7Hvaluqr1YDmpdKVrOm9pLH70LSANKmDUUHikMaCsoKYWZNmGkT0pHwOQRJhEDQDZfPBT1lwWSgYkURFtWHkIjn4IINzeXm9NhxoW00FvoO+75zc/q5KHO3QtS2HcD2HQOzf7vm0hV3blq86/MrDvXXnDhwAkcGExgaNwWe2Y9ra5Yu9wYPlnZSZ6yDIU6BPfX0mp+u1lYFwFSOCx+obVr7baWowK5vuaiHl33yp49j48tfyMcKp2oJBHrbBZo7uB0dQttya47Knk1qMuyzbIdz81EYNmE8aiCkMNYsIrj8wORUEkW1hQgXeSBtB6GQBsNwsP1AEm5OYd0yN8hhDByYQzJho7rKg4AHmFHcGDs2w6Xn7fNXf/WOSq5rH+ztLaV8rUI3iMpPAPijUY7fV9rw6nWrG3dcX3Cof0MuGncRkT05w/clWi4a5vYPlRskzI08eo4MVdkVpZ88CMd8L0kC9EqiTj4lQWZWiMhZmNpzT6Hxb/fKQJ0ze/BtZdfPnsf+IRuqYePK9eSs/vyN7K5eK4afeUgM9E+gbvNyRMci0FTC7n1RzAzFcMvnV2DZp2927OQUjj75KHbuzYrixcWkAZiZzqAkaNut39iqJmp+928Kqj7zR8w3KET5dFc+julVTvn9Hma1ydi9uHBmcJmheicDNdcd+NBAiMFE9Te9Fw1yT7uK5g6HiOwzuFH5wAPscVv/9iUIASuXouFtb2FkWsJPhEtWmXze176lYGELMKCj4arb2Ej9NfmLw8gl0hjqj2B0PIfPbAlg1dbrGZHliiZXYcPvL4PnRx14+1ACaqEfrBBmF6RYGJmGv3ryqvYu+WeCyDxV7HByT9vM7QK9veLkXI+fPHC2WmJxFnDA3N4uTvHq1HLmJENPT7tCRHz1p47c4BYTa6WrWI70viIO7YvCsBVsLM/IzXffQrFo84vR3uF/MEYTY8KqonB9JdwuQPNqiC9kEXQDlcuLGKij3InU3sjbA38aOb7yeyvv/LJ5ToMjnZzFDgipHNP4YByqlVpx3fojTfkJtdP7y/eo5Q37VBDX1dWq5NX+zIXUZ4XC1NkpP0Tbi9PV1eH1mQ/eo7jSmD8+Inc/v1ekbR9W+OftS+++Us2tuOO+ovCxrwLftI79z+//fcM5rmcD5dWrkpF5tiymdMZCyCtlWU2h0Jm37Xu7+OoL/+X2FADMzfSk1989/Z3o9x5xBnMFiiVBE2MxuQ5xtSY00wxgf29vswDOPNfOX7OGj1gn2C2IiC/e/M7lGk9+IjkyILc/+rKSNVyo92XtrbddpFrn3vHYRd+65KvMd9u8o8u7/K+/MZSurP6bUFEVsnMRmU3oyOQkAj6S4fIKLBR4Hr/wX65N8QPtHuYetayi+a9ytVe+tOmac5USVXf8QQ/GxtNsTR+HlyNb29tZbY5EGB9hfAQB9DFIRUAduVXVx2nfC+/w9LRBxZppX37jZhWXfOWFBwauv33PfeR0d7eKXqPP4vZ2YSjhcVPxsbQtis5mOGcwB32qcDwVUHxLxpiZcFuH1d0dYSKSJ+Jbvh644PrZFYsDKPQrMhJzxPF3jrEbCxd+/taJJmprcz5Mk8ZvVQCnCp/fmoqVcexwy7GXt2PiRFy4wc7GixtVX/Ntu57su/HmuzdSFmBua+t2IpEmps5OGXeXRaTHF1eFEPG4AdthFBe4BRXWzeV8G4+dtDXc1tbmSMnK2oaGo6mi8zuWXfFJpUgz2eXz0sFdY46SPhqoLDh6S14Zuz9eDejuztfnNYmd56QH+8P9e6YYNssVi32i5qq2sX556+dvvohi+bgibzxbW/sYACoLCzMurztt5Bxk0iZrArKiphiWp2xoZN49crq1JiKHuVUp8F3wE7PuE0+u37RUqQyxNTVnq0ee62F3bM+tPbuGK6it2/lN2+5+IwG0nmxOCIfUmuTYAsUS0tIsAyu2XoZs7aVfXVtBQ2crTHADrMDFlglIWyLsBVc01EB6ive2NJAOtCvA6R5nFTOIow23frn68usPbl5brvk9qtX70pCVGz5UetGK0a2nbNLHaAPybzOb4UOmBSp22a4tF61RPI3n/zisbXrmzIvvYALwyFFEU/FcFKyCJXPAQ8JdUQ0KL9p7sq2Gf6UqHV2igQIzudV/ekPDlTfsb95cr1UEXa7I0QgUJz1/+pw+lqapfHcYiOjSXQOP3P7VDc2uz/mWNPV6G+75C+Yv05mqt4kI3NWq0Eoldf27ndOnBOD1a4JdQc6kvBNn2875HqR2QUQDo8yXVTn8B57yIy1ZUfAiFV3zH6cz2/8lo535fSW3ZzGePfmewMzYT//28HfPkf9wpd/62U1hjr99T2b70O7lZ6rl/dUi6Pe+/Fa6TD/yTbpaW5UOIoe7WhVmJsIHtK41d0gAEJXrXvKVVZFPI5Ygx0rl9NUN50U+VKkOM3HPJSoT8cng7b9B++x/wgIzg/Ywa5PP3vXs/m8v5d1fX8ZTT93583w5Dv5T9/ltzF39bdzkP9evw9hIZI2Ndd1aFI93sq36nYaL//zU2/2wnbC/SZPkf5/x36hR/v8ALsek5c7v2skAAAAASUVORK5CYII=", "ui-moon": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAabklEQVR42tV7eXCU55nn73m/q78+1YeOlpBAIHGDwIDBgEFg57DjxJlNJCe7yc4k2Z2tqZ11MlO1UzWV2pKc2mztzm5tjt2dybGTw5s4Nthjk9j4hJaNsQ2ISyAOISF0Iqnvu7/+jmf/kPDYE9tjJ7aDn7+6+uvq733u6/cCHwAxMzGzvI9ZeqvnmYGBIDMvYualzNzKzEuYuZaB3/p9Tw8LZpaZmT6Is9L7zXhfX5+0Z88e6x+/G9eBho2AcgssqyORLTRXDK6XZNVtgxTTskHMbFarJccyEsEaz7THpZz36NpJXL/eTy0tqTf8vwzAJiJ+v84sv1+MAxBEZAOwEq+95g9v3bQDkO+Znkl/YmJ2snUmVRaT15NIZYsoFMtw2IFCBFWRoCoKNE2D2+uCz6vD7/WgxqMg5HPNprPlF3wKH5ASiUNElAKAfcxSF+C8H4Kg94F5QUQOAMyMDNTXL133lVzeuG/g8sSGgYvjuDI2jXKpjEi4xl66pJ7blkTR1BAmtyqIHRv5QgmpTB6ZfBm5UpUL+SIXChVYpkNV05FqagJY3lqPVe1NZwJu+QmPz/NDIpr5g7vAG7U+dPD/+dvv+tKfTs7lv3Fi4GrTc4ePoVAoO+tWL+HV7U1i7Zo2WtxQAwJQLpUwNHwN584P4+p0BnlDgmE57NiW45gmZFmSPB43VJcOj9cDCIG5dBl1kTBaGsPwqkgsCru/vWGt+n+BuiIA/D6WQL+v1k3T/ESxwt8+PnBl06NPHEKxVLb37L6Vtt26npoaQ2QbFfg8GiavTaDvxVdxcmAY8TzBUoOQZMGSWXC8bk2KNi9CU0sT/G7N8gY8Wa9bu+rR9euaWzOICPF0Th4bizfZDtralzSH3Fz60bb1i/7dwlkYAH8oMYCZJSKyzzz7oGdZ55e/eWxw4q8fP/AMRoavWXfdtVfasXOjxJaJUDgA2DZSszN46JkYXj0xiLmCBEcLQpOZ/faM7a/xy4vXrJZaFjeW21rqjrU0hp6tV52XFV2/CCCjSGS/rikiVC1HAhA40n95VSJPNwLt78z8e7aAG8yXZ8eW5bToD17tv3TnT/7+51jU0mzf2/U5qbm5Dla1BL8qQSULh557AU88eQjTqQqEXg9V88LtpNnjlrh90+2iY+Pq7LplDb9c2ej9OUAniP4JI8zU09tLAPDAA70MvH/R/z0L4AbzhVSqY6rs2v/MwUPth59/wdzauVfZsHMHFBlQycHiiA+pyWt4+OGHcfz0RVThAdQaSGwgqBr2klW3SGu378aGlY37tyyTe4n8FxYSvoh19orOTjgA+O38eiH2UG9vLx544AHnQ0mD+/btk4jInp2c3T4U50cfefgX0cGz/dadn+lWGlpbEY8n4fO60RrxoP+lPjz22KO4Np2B2x9BS0MT5qYnEXJbVtP6TnnnHbvin9+06BuyJj9kA9i3jyVgP7q6uhyi18367TX2e/j772QBNzQfj8c3pYvqr3/24K8ar1w4a3ds/5jkD9bAJapwfFGsXhzGyOmXcODAAaTyNrz+EAxHg4CBkAvWiu33yLfv3Hz+zo3Rf0VEA137WNrXBb4RTP9QJN7pYU9PjyAiOzGRWJSrar868OTBxqtXLlgdW3dIiiqjnM8hWyY0+SQM9R/Gk0/+Bpkyg4UKfzAMBWX4JcNu3/YpeU/nliN3box+jIgGYjGW93eT/Ydm/h1d4IavffrTn3aXZPVnTz3V1378lZet7vs+JxsmY3J6GkJ2oTVah9z0IJ57/lmk8jaWti6GyxvAufPDCMglu+22z0i7O2+90LlOuo+IZhYsysJNQu8UAwQR2aWC+Z9jJwbvOPTc09a2bbfKNgTq/A6yaQ01fg/kagLPv/QiDEuBpknQ/LWQAw0IqINO88pttHX37tk7O0L/kki73t/frxCRiZuI5HeM+IXKPeOziW88/NDD9q4dW+VwbQOmr42g6FHQuqgZbpeEgwcPYi5dgqJ6obgVjM/kYV+5gmh9I992513SrrbgXxFpZ/v7+5XNmzffVMy/pQCYWQDg8fHxkAXpv+x77CCaGkJYvmI5qpUSGlcugyxLqK8P4pVXX8XUTBKy6gULGY0tLYinSqjkS/aKzfdK69vqH62NeB/sibG8eTPddMy/nQUQEdmGYd8fOza47sL5c9bX/uQ+2SEZ9aEwVIUQDAYwMjKM06fPgWQVwlFgODJmMiZQSDhNrSupbcWKXEdrsJcBrOkE4yYl+Z8OH4QQdmp6enEmX/j64088xTu3b5EqLCOsE2ojfkiyBFWV0X/yNPJFA6YjIxL2YEnbCpw4fw1UzfC6rfdKK5fWPUREg7xv3p1uVgG8KQ12dkIwM4LR6P1nz1+pUYXtbNu2ibhaRkNdEC5dQygSwsWLlzE7mwAJaf4vJBl5xQ/VKcLrC0iR+qixpt71Q4CArptX+2+ygAXft1PTqcWJdOGLz75whHfdtom8Hg82rG6F26PCpSmolMq4cOESKhUDkpChKALxdBmJ02chl5L2iq2dUktj7WHStDMLdYRzMwtA/BPf52A0+PmLQxPRfDbrrF+/WmiqgMulQpZl6G43RkevIZlMAwAURYamyGhuikDlClRF8NL2dtT6lKcAEDo7BW5yev2AJITd09Mjl8vWfUdeOYEN69rJNBn5fA5enw5FkWCaFsZGx0DMUBUNiiKBwMjnKxCOwW7dK4dqItmIj44C4DXxOH8kBMA9PQLM+OZf/FXHxPTsxsnxCd64frXwumXUhf0AAE1zIR5PIpvNQZYVuN06PLqGaH0IumAosLgmEoXHq1/1eDyjANDV1eV8JATQ19srAEAJuD85OjEj+7wuZ3FLI7xeHV6fF2AHkqRiamoasizB4/XC7/NDlmUsXr4cqzrWQSbHiS5qgc+njxFRdqGYuuktQAaA+P793IMekcuXdl0ZuoqWplqYTKjk83DrYQgBOLaJVCoFv98LEhJUpQLbsTA8eh0etweKLCgUDqDG7xn7IEbuH5gAFmZqdjEebyxW7WXjkxO4Y9cWujIyjrBfQ3NTHRxm5IsFVMolhIJ+aC4NebUIVVVQY1Rh2xZmhYBb16E45uQbRlX4KFgAAYA7EGkZHRlrLBXz8Pn91NxYD90lUK4YcLlU5LJZMIBATQCqZkBTNQBp2JAQ9rlx8aIDVVXgDehFfITodQFAwZJcoahb1art8Xolo2LAsRiSRLAsgVw2D0VR4fF6IYQCWZLB7EAoFYSCftgMInbgklD5SAmgr68PAJDKFJric0l4XC62hQvDE5OIBl1we1yoVCrI5vJQFQW6yw2wgCJL0Fwa6uoYzAQhiB3Hhmna/o+SAERnvJMBQEjulmQmj0DAR4PXkngmdhzpbA7FYgmlUhmlYhGKokBVVaiKAq/PByYJqTKgeALw6G5UjSpsm0IAgL6PRhAU+29ELFX4jEoZZYsRcktoawqBGMhm8yjkCjBNE7IiQZIFZFWBS3chPpdC7PhVmORCU2M9J1MZOIT2+cbiI+ICg//YrLhN04Jh2iiVymhqbECxbMBx0tA1FZZlg0hAkIBEBFmWsaQlChYK6r0yguEQTV6fhlEuNH/vP3xPA1BlZrrZa4HXm6FKFcwMGFUHmUIFTnoGikyo8esoqgqq1Qocxw8SAiRLsG0H4UgEDdF6uDQVi5qjdPLsZVQMc9n937+/iYiu3hiu3EwM8zxm4fXN8uu9QNUyGULAtGxcm4pjcuo65uJpJJMpxONJFEtlWJYJAkGAIAkBl6Zg9NoUTpy7ilUrl4t8PmdPTc3WA1h3Y3l6kzFPRPQmfIG4sH8/AUCp5OSEpKBaKaCYzSCdryKdySGZyiKeSCKXz6NcLoMdhhACQgjYDqO+IYwljSHUhkMIBQM8cnVcALhn4SU3Uy9ARMQnTg3fffz41RXzPRAL0dXVBQDI5TLTiqrDMQy2zSpcmoxsroBUOotkMo1sJo98rgDHcSBIADy/yHO7XPNWISRs3bxBOnb8FJKp3Kenh6Zricj5oKAt71XzzIzzo6MNmj9wwBfStwMAeiHEYF8fAYDm1SZcHh8EbJQKOWRyJRSKRaQyWWRzWSSTKWRSKZQrBkgIMBwQEWzLwenBUZy5lsbWbZspmZi1R8dn6qNLo/ctvF+6GbIdEbGu+L4W8Hhl07ZmAaCvDxCdC/lKkb3XZU2DLMlUzmc4mSmgYlRRKJZQLFeQyeQwG08glUpBliU4DoPZAZNAKZfF0SPH4fEF0LGuHf/w+G+4YDn/JhaL1QBg7mHxB9S+AMD5fL6+WrW/NjQyVtG9wRkAiMfBN7axaIvao5rHO6d5/ZJpVmDZJiqGgXKlinLJQLFYwcxsHGPjE2DMb6ot24FLU7DpllX45M4VCHhl7N2zXTp96pRz5uzFjh23d36NiOy+zj9oMBRE5AjVfX8yWWjNlayZtkZPZn5egdfTFGlIT3pc2nggFIZtGQ6TgKaqcGzAqFqomibSmSwuXxlCuVwBEQHsoGIYqKsLY1FTFNlsHqtWtGHn9g7xs5/8gjPZ8jcr2ezyPXvIWtDEh0oLW21rdja9IZ7M3n964ArLujsBYO6GgQgi4p5YTCKKFnWv62RNpJF1WXCxZOC+z30Gd31sJyzLgmlbKJUNjAyNYGpyCoIELMsGwKhWTRAxzg2O4tzQFP71lz5P6dQsP37g2WBF8vxwaGhIA0AfZkBkZlHb1UVnnj3jMUn5u18/9ZK3UKlSJOK9RESFfQsDGwEAaxb6gaX1gcP+SB0RCeHVNRwdTkPy12FjxxqUKxUQgNm5JE6dOgvbssHMcGwHC00QmhvD8OsCNYEAvvSFe8Vjjz1mv3J8sLOucdl/IyK7D5A+DCHceMceIqt9T8f3T54d3jY4cLEaCteiNlTzCgB0vXEk1tU1HwdaavVDHp9n1uOvFZpk82D/cex/5AmcOHUOmqpDMGBVbRw7dhLjExOQJQHLMuHYDoxyFbWRIFyajLGJWazfsgW7d2yQ/s/3v28PXBr7eiZX/es981th+iDdgZnF/v37BRE5yaz5rdjRC189e/qktWXTGtXldpWDrvLhNw5sxEKFwD09PUIQJVuitQdb2leDbNP2qAxiC0JIkCUBEgRFkTE7O4ejrxyDaZqwbQdmtQrLqqJiGMjm8hi8NI4r4wnctv02rFgWFf/7u9+1+y9MfDudt3uJyFmoD6QPyOed7u5uu2hy75H+S//pxRdfthvCPspWwI2Nda9E/P4hzFeEzptK4c7OTsEA1i7x/Kq+qcnUPX5RNQ00NS/CqpVtABwISQJJBEWV8NqxExgYGARAqJomKtUqCsX5MVk+M4cLJ47BMqu4fecO8utCfO+//1fu6x/uSRT5Qc5dihCR3cMs9u3bJ70fjDOz6O7utnlsIFhi/mnf0fM9sUMv2uvWtIkzA5cRCDdQfY3rUSLinr4+6beaob1791o9zCIMHInW1x6vbVm+IzvwqmVYJCezFTADJAhCEIREyOWyOHjwOUTr6+DxeWEYBoyKAcuy0Na6CMlkFtl0HgVTwvbOj9GR2PP44f/4lp366p9/eff2jk2mWf6GQvT8GxoU4D3AX5mZsH+/QFcX3QBcmOXy3qkSfSf2+EvrX3qp3/nMp3aLl/qOcBUeEQyHJ9YtC/1mQdvOby1GmBlr5uvlyqZVtf9rSfsa6G4fGYUsMpkMIrW1kBUZIMCxGW7dhaujo3jm+cPIZbOoGGUUSyWk0znkC2VYNiOdK8MyiijbhM17P0tta9ZLTzz4Q/uXD/3D6tcuJw+WmH/CzBsWGhSbiHihbJWYWY7FYvLCZykWY3kBNX5jkMvU3W0TkcXM65j57y9MJJ/92x88uP7Zw69Zn/mjT4rLFy/RxbE4r9+0haJ13p8T0VRPLCY/8IZ13Zu2w91Edk9Pj2gIeR9dtiQam1qxac/QwBFb1X2S7PGByyVUTROqPN8HaLqKo0dfhaaq2LB+DQzDRLFUQT5fRrFswpFdMKsMy7ahygKf/uKfYPzqFemFJx5x+l97WfrsF774ld3bOj5XMfkZ2Ma+4b5TsQVA9D+7TX755Sd8O3bcu9uynO7x66l7Xj1xPvjM0zEOtSyz//grn5LPv/ICnn1thNe3LxOLFjfM3LbG87cAE/p639Sg0Vv5U3d3t12tVnf8/MkLh448/ahUKmUkw7RIgQFFIhjVCuxqGaqmwKiUoaoa9u7ZjcaGBpTLBkoVExXDhgkNrPkh9ACEVcSKJj8QiAIuN4ZPH8eRw302CVnqvGMPbt2yDo2Rmun6sO+obZpnJEUZhoWkWS5XFJdsgsgNWQ7BtFuhSBuT2cL267Op1tNnR3Dk6DFAkuxtH/+kdOuaNsQefxhPvDaFsGpYd9z9R/KuLW1/ubo18J19+1jq7n7zqp7eOqiw9MUvkN1/Kfm9Jw+duv/0oUcslmRZlmX8i3vuwMT4KIZGhnF9+jqEAKqGAb/fh1u3bEYwGEa1asEmBVVbgS25oPjrUFcXxNSVQUQaoth8+zYEdBXZZAr9r7zK506fdeKZovAHw7RyxTK0L21BfV0YqiAosmTazLZhVF0kBJKZPMbGZ3H+/BDiiQQ3tzTaqzZ2SO3rOygiGfj1Lx/CUxcNeKyEvWbFaunW27ed+OxObc/+/Q2Vrq7fjjH09oMDgBmBAy+Pvfj0b55enxg9adtCkWqWb8Jir8DVC8cwOzcDQQTbtmGZVdT4PVjfsR61kXpA1iEUPxxJg3D54AmFEAiFEfBICAV0TIyMoqmpDmuX1qNiOLhydRxDgxf46viMk8zkUSxU2XRY6LpLuDQVmWyeidiJhGs4GglRc0uDaFnaSv5IBB6PhtToVfzsp7/C8bkAapQyN9WovHnP3aWv3r14J5F2todZPPAWq3r5bSYHPJ9TuzPM1X+by+15+sVKPpieHnKuD10Qw5kEVOQhSMCxGZYDMBQkM0UcP9GPVSuXo7llGbyaB7JbB2QZLnLgkR143S5IghBtakDA68LE+HUMXplEqL4O933+bgIgVU0L+VwBhVKJixWTHQiEvC7IsiwZEIjWBuAwYFiAXTXQfySGHz/4JEYrEYRcCY7ojt2x/T555/ravyTSzt4Aff1z+IA3UXd3t83MMpF6/FO7Wv5s8+6PsyfYxK5qinVNgck6NtyyBS7djXzJgA0CSy4UDQlnz1/B+XOnMTt1BWYpAU0leLxu6DKDbBuwLdQEPNAUCV6/D3VBHcmxq4inMmBmTM8kYTiMxc2NJAmJ4okMSYpM4XAAxXwBhmFBAEhMjuHHP/gpev/nrzBaCiCIJLxmwlq581554+rw91Y0B3/c0xOT8Q4gjXcNlb06lfr6Y4eGvnv06UfYLCa4YiuCZQ0uUYaAiblkFsD8tFjXPdBkAZ9HQrjGi8ZFLWhuX4uW1pWorQtD1yVIcCCxDUUiuBQJuksFOwxZlpAvlMDswOtzI5crIp3OIRIJocbvBQAMXR7Bc4eP4vDLp3BttgK9Jgq/yMCn2NXVu7vVXdtW/GLv+tqvdfb1OX2dne94x+hdNSY9MZYf2EPW4Njc1596afQ7Jw/9hivZSU4XTEnW3NBdArlsBvVhP4TiwvVEHj6fBz6vC35dhkwWJHIQDNZhcfsqLF3ejmh9BAGPBrdLhSbP7xsU+a1xm5WKgbnZOC5cHsHJs5dwdnAYE9NpmMIDt67DiwyHI0F73a7Pyttuad23a03dHxNR5d2M5d+VAAjAI8xSN5E9myn+2YG+0e8fff4ZOTV13i4ZlpTMVlFTW4vuez+Ga8OXcOLcMFxeH3RdQ204iGhtCB5NgVHJo5DLoFypQtN01NXVor42jIDfA4/HDV3XISsyzKoFo2qiWCgikcpgZi6N6dkEZhMZGCajWBUoGYDGZShWyqlrbBUbOu/B7Vtbf3JrW+TfE8FgBr0bfNK7gsvzQpEUi7FcX0N/x8wTAZ/+o76+SPTa2RetxrAkHFUTL5xNIKC44fUHQEKGz+0DKX4Y5EHA50ewvgmaKsG2TVSrFdhGFal8CbOpDNhxIMkSFEWFEDIcBqoWo1SsIJWpIlMRSFdU1IcCcNsW5qbGucZl26GV2+WN23aWOjdGv7m2NfJdZ77bxLsFZ9F7bzzmiwnmysrYufx3jh678MmhUy8jOTVsm46QyB+dR402hOBVBYTLD42LcLlURBa1QNdU+D06Aj43PG4XFEUGsQMWEkzLgmFYKBbLyOQKmJ1NIpHMIpEqIJM3YBgG7EICXIzbtQ1RsWb7x2nFqrYLn9hU++c+XY/19LDo7X37yxbviwDeGBhViXDleu4br56f+Y/nBi42Xuw/ikJ6xlY9AfLWLRbhRUsRCPpRzc6gko1jcfty+IN1kCVAVWTY1QrYMeHx1yCXjGNq5DICdc1w9BCyc5MgoSNXJaTmZpCdm3aM1KQjCZKWrN1GHbduLd2yuumnG1tL3yKKzsViLO/dQ9Z7XUP97tfm9u2TqLvbXhBI+5mJ3F+cHhj98tjouHf80gDi02M2FBWhxiWibtkqUjx+LGqMwK27IIggKwpK6Vk4ZhWh5qVIz01jYvQqFjUtgSF0JGemEZ+c4NnxYaecnuNAMCS3rupAc+syp21p64Hda2v+RlXV1wAgFovJb7yt+qEI4AbFYizv2TPfjjLz2jMjiT8dny3ePX5tfNnEtRFMXB1BYu46C1l1fKEw10RqEQgFSfN6SXO5IYSAY5kolg0Usnk2s2lOJmaoks+Rokhi0eJWLFu5Fg3R6NzSpQ2xjmbvj/xe/bBpAz09Mbm3t9P+0O8NvtUYqrcXeOCB+cDDzIvGZgu7UyXrrsnrc7sTiUxTKpmmxMwc8tkUCvk8KhUDlmnOR1hBUDQNHrcbwXAI0cZ61ISDiITDheZo/St+r+upZQ3u54jo0nxe7hHc20vvBwb5/b48Lfr6IG5YhABgcyoABLfM5sw1mbK5PpNKNZo2R1RNC9g2y8zOAtyGS7ArCX9NYM7j0i7Vh1yntXL6FPTg+A0N98Ricm9np3Ozw2/BzCIWYxk9PeKtnyf8zNzyhuvzrcxcx7Ee+a3dLCZ/UIPU/w/6Iwsyb1GcHgAAAABJRU5ErkJggg==", "ui-play": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAnnElEQVR42pW7d5Cl53Xe+XvDF27sOD09OQKTMMAAIAAiESQIgkmggLLAYBWllVcqFiW5tKKq7PKqtDAo765t1cpllSSblpXXVBEwFQAwARRAgEgEMMiYGUxE90xP53Djl96wf3y3B0MFl/dW3erb3d/9wnnP+5xznvMcwf/4JXjgKSW+eqfx3l/254OjEz/3a8Pb948Fm+phVHdBjVArrTX60jGGAODS3wxQfi4/lT+57HgufXvwX20wg4OK9UNM+SN1Nu+aTrK4WuRvHZ3Jsr/51QWgv342770Qn31Y8vBn7f/4Af+x1wMPSL76VUf54MHOL3/tlhtuP3LnhsnRa4NGfXtYi4akklpYFwnjq+A0Qvr1M0rAA0IIhBxcTAjE37mkBwQef/nteA94nB98FIO/+fV/O+GFzIUSiZMi99ZnWae72Gn1pmYurLzw8n//zuMr3/43xwF46CHFZ+93IPz/vAHueEDz9IMGiDb8/O98bveNR35589aN14uoIld7PVZWWrR7PfK8wBUOh8MLQAhAIJXEI0GWFxAC1h/dC4mQAi/lZZf3CO/xzoKn/IzADrxOePDegQfvPQKP8KVBtRKEUUizUWd0dIihWkzR7aYLF5Yffec7T/5e968feBqA+x9S/5A3/H0DDA6cvO83buht2vZbk4f236GFY3Z6xre6fee990JKqYRCKIEQQggJHoEUAoQo7eAtSkq8DrA6xmmNkBIpPFp6lBhcXAgcYL3EIrAOhHFImyOLDFyBt5QG8750BO9Kj3Ae7723zmGd9xjrpUJsGBtRm3fvYHW5lXfOTH/t2hMnf+P73/93Le6/X/Hww/YfN8D99yvx8MN24rP/5+fXqvXfD8bHRlzet0laiKBalToMkKp0cI9HCIkfrC4DV5beQxhiKzWcVFRJmHBrbNNttoUpk7FhLJY044BYK7yA1DhaScF8KpjNI6ZtjQumyapokhMi8gSVdHGFASnxvtw0YrAr/KXt4XHWknW7+H5qm6MjwgWRZHnlpZ397Atvff0rZ/+uEcTfXfkN9//mF1sq/ENbCbUMQiuiQOtKBYTAC3Hpa6U7+3JfexA4qNSwcY3AdNmVT3NjvMjNk5rDO8bYsWmS8YlNiPoYBHUgBNTgfBZIIW2TtZZYXJzj9PmLHJ3p8MJKzOtuM7PhJnAe1Wvj8wKPwPsBdlwC6IFbeYcrcly748mN9ULquDAnJ1X4qdN/9itneOAByYMPussM8ICEB92We/73Dy5G1adsHMWqEjniWKo4vrTSIAYr/r7lhHeIKMbWhqikS1xbHOcnxte466pJ9h++Bj2xG6hB3mdl8SJLi/MsLqzQbnXI8gwpFbVajbGxYTZs3MDo+CYqwxuAANwSa+fe4fW33uG7pxK+093K6eo+kBLZXsVZi/f/AIyV+wSfZ9gkgSQ3vjC6arIXblprfeyJW+oJDz7oAS9Ka8D1d8023tu453st528S1dgShEpVKkil1lFs4OQl+HgBUoBvjiBtweHl5/jc6DnuvXUvOz5wIzQ2sXJ+lldeepVnn3uNF9+a4sxcQjdXFCrGBlWcCsE7tMkIbEIoMiaGFFfvHOOW6/Zx8y03cOjIQWRVw4UTvPL8K3zjzR6PyBuYbu5HJh1Ev4dHvY8L+AFYOnAeV+T4tA+dpFBBEIwp8Zszf/Jr/8e6xwseeErz4EfM3i//p19sVxu/tzx73shaVYtKHall6eLvx7FyK+CRYYCpjzK28Db39v+Wzx+JuP6W64lHNvD6O1P8979+jseePs3xbpWRzQfYes0HOHD1VezZs4ONE2M0GzVCHeCdI8lSVlbbnJ+Z4/iJ05x77XXOn3iNsH+eO66o8k8+eR2fuOs6Nk40WTx7imefe4c/md7IDzd+nCJsItaWsJ6BN3hwpTGcc+AsNi+g23d468cmJ1fjEydun3rs/36X+++XJWT7PdHB3/y3r8wsrR3qLC153WhKggChypBVGkCAlAgsVOvYIOLQ2W/zU+J5brl+GzsP7Gd6Zo0//6uXePiZWTpjh7j5U/fxkU/eyaFDexkdiUFAbkvQM9ZjvEMAWkliLYm0QCvIE5ieWeSl517liUceY+ZH3+fgWJcv3XsVd995FaLo8+7Rt3niDDwydi8LGw4hWkt4YweR4X0D+MLinYciw6wsm21HDusxU/xfr331n/76/Q95JQAO/+J//qg6tO/7bz/3oicMhYwreCGQgUZIBbKM3xIHjSbeWG4+8afcHb/L3gM7GRob4m+fP8f/+9QCM7WD3PbZL/CJz9zN5m0byZ1luZuy0M9YSQztwtIvHJn3GOcRAgIliJWkHihG4oDxSsBEPWa4GlP0M9569Rjf/G/f5OKzj3H7phb/7DP72DbR5Oy75zg50+Pbo/dwZsddBJ1FfJYPEiiHtx5vDBiL955iddWN79gs9u3Zcfa5X/yZq2G2LwBu/93v/dtlGf/LY99/ygYjQ8pLhZAKGWhQcrDyHhrD+LTHR0/8V64PzjG6dTOVOOQbT77HU9MN4ps+zU/+L1/g8MFddNKcuU7CTDtloZeykhX0CkfhwQlZRpRLiZ9HDWJCpAT1KGBDJWJLI2ZrM2Jjo4JJcr71vWd5+Rt/wfDCK/zsbU2u3jPM+fNLJK0ejzc/zrErfxLdXcJmOd55/MADKEwZMbIUifM33v0h0Xr26Iff/oNfeVoDVIcah6dnFsuMzHm8t2WCYm257Z2F+hA+6XPXsf/MAX8WMTLB0mqfrz9znnPNG6h8+nbuvPsORjdu4KVTFzm/2me2m9AxFi8lUitUoAnCAKkkYuBV72e+DmcdqTH0WxnzSy1OAOOVkK0jVXaM1LjlQzdigwqvPnMlv/PiE3xsaoqPXTtBkXs+sfYd/Ek4tvcedD6LtRYKD9binQNrkEJQtLrOikCNXbPvMPC0pvnB0bBe25KunkQghDcOoQRYixACjEfEMYVx3HnijzgoziEbo7Q7GX/+Qpfl7XcSHriWQ9deTdSo8/Tb77HQ6pF5j4oCoihCaIlQCoQEa8G5Qbh2Jb4M8mUpQGkNSiNCi8kL5jt95lfbnAoCdo83uPKKnVxcarFSq/L4S9+n9ewZPnPDGF1n+fjad0nPVDmz7UPoZAbrPFgDzuFNuZiYwqdJwthI/QoAvfeWj46ISmUo63RLhLcWgQJR5uZKSFJd4+b3vsF17gR5XKdIcv7byzmrez9FuGs/cmiYVGmeeeMMiYeg0SAIQ0JZxmLnJX7ghniH1EHp/daCVGUNUPpfWSsoBUqgtEbXNS7P6PRTXjk7y8VGhfrYKPOLK1Rv/RQ/eulJihfe5DM3jFMIzz3tR/j64ijzzd2o5Tm8E2AMwpqyQnOWrNsnGB3bDCC3Hd6lwekizcoKzlm8M3hnESYnr4yw4+KzfFK/Tjw6Agi+8VKftW0fIty5DzMyhg0iTk7NkQGN0Sb7Z57j8OnHYG0WHzdQ1qLSBJlnkGaIPC9vKMuQpoAsw/dTRJJA0sP3urhOD9fr4YsCqUPiep1Ko8bFtQ7n55dR1RqZrBBfeyuvZnt5/PUl6s06k6Mx9yz/NWHSwUVVvM3BGrwzZVjEYZI+QRxHAHK4GtW8sVWT53icwJnS/YscH1QIu3PcZ59hbHyIMA751ps9FiduJti2B1OrUwZISaXZoDo2Sjh/jk8t/SUPfXEPv7VrjsNLz6JCkEMjBBJCb1HOopVCUyZT0nlEYSAvEHkBeY7PMnySYds9fD/BW4cMIiqNJrpWQ3gBWpOLiOjaD/P86laOnlyhPjbEzTssH209gdFVpLOlhzkL3oITwmY5Gl8FkEFYqXhnK84UCO/BmDJ0OEfhNR/uPMNtV1apDzd5/KVZTha7iHYcIK8PIWS5p4N6jTAKyptMOjQqgnOn3ubOqzbzJ/cM8S+qL7M3P0MwuRE1Pk6gBWEo0YEi0AotBMo7pC9BWOQWkVtkYRDGIJzD9vu4NEUHIVG9jmzUwVhQMSZsEBy4mb952zE922bb3u3cv2WWne13KOIhpM1L3Bk8l7EGYUUDqEkVhcJbJ7Fl1uSNQRQZVleY6Jzivm3LbN2znRPvrfDsTI3h/UcwYYAMK/jcoOIYrSU2SfB5jlaSnbt38uZzz/Oz936J//jv/ph7Dk7yF3cqvsxzbI07qB3b0ENNokiWhgglSoGSHg0o71CAzwu0EghrIc0JnCMQHmcMYb2KajQgT7FCUB0eQ+7+IN94bpl213Dk8Fbuq7yJFCW3QGGgsGWN4MAJoQAl0bpEZzw4i3BmkE067qqc5NYP7GS1k/LwMws0r/4Io9t3Y1GIPIciQ0UBPk3wSQ/X7RBXYsBycrrDnZ+4gbHI8ZWf+VUe/rNH+dIHhvizw3P8tHqHjRMV1J49BEMNolij4gAZaqTySAVKWoJAEQQKl6aEoaJSC0nXWpDnaCEJmk1QCtHvkMmAKz/4IU5nm/nmE+9SHx3j3iNVDubvYnQdinyQKboyQ8R5wEszKGtxrnybAqNCNpqL3H91yKad2/jOD05yuj/OgZtvpy+iErn7Hei2Ic0w/T50O4iiQAUaKwQCz7FXj3Pf5+/ml//5TzD95pv88y/+K6aOvsED1yl+u/YCn1GnGNu9Bb17J9FQhbCikVGAigKElsT1COUNYaioNWOSlTWEtYgiw2cpAoeXHowl7adUN25h500f4bFXlnn3vUWOXL+fT41eKBdVypJQ9LbkLQZZmNRQAor3eOfLpMcLbq7NcNtNVzAz3+GRFxeYvOkOKpMbWUtzEA5sgeusYRZmEUkPX2QI6ZFKEISaejVmdnaJF59/lcb4GF/+5fv51a98gaPf+xb//td+g6H2NP9m3yL/2nyPO4ZaDB0+iN62hbARoqsBUSNGaYlUktpInazdQVqDxiKdRWQpxdoaIgjLLLXTYbnd4cCtt7Fa2cvfPHGcuDnEPdcOs13OYVWIsAV4VxInA4Kx9ID18tEUOKkIfJdPXqkY37mdv33mbd5Lx7n2wx9jNbNkWYYoijKJCQOKxTl8r1PuNWeII02oNWmaU6tFvPXaaQySlVbC2IZxfunXf45PfPJqfvDHf8QjX/sDjlQW+A8Tb/Hr4odcv61C45qrqW3ZSL1eQYeayugwLsuR1qAkCGsQeU7e7eBdjkzTMpO0GQszszQ3TbLrtrt47MU5Tp+d4/obruS20ZWSMbLFpWLRugF5q837qahwBQ7NHrXIHdduJ00KvvvDM4zsv4HNe3cxt7CK77bLBCbLIC9jbLaygjcFKEkYaKJAkheWWiTRSvD6i28xvmmU2ffOsDTXYcehw3z+Vz/Pns2aJ/7T13jpe9/mJxpT/Mf4B/wzXmfbvi2EBw/Q3DJBIMsUSQUBwnrIc6x32DzDXpzBLs2XlbqUdBYXWG33uO72W7mQDPP0C8eJJye5c48i8H2cF2ANTlzmAcTgxIB/9iVIXDeWsPfgHk6evMAr51KuveVWcqFZuTgHWVK6Eh5flECIzemvrWI96DggCCRaQC3wjI9VePPNKWbOvsPOI1dRHx8liByWgKs/fhf3/MLHEYvHePQP/pil4y/xC5WXeHD569wlzjK6bxdy62bCaogesKhOKbK1FfLpM9i11XJViwyhA3yvx/mpGXbs3kW08zBPvXAKZ+ED+ybYGrRxaHB5ud0vbYEyNJbsifMI2+e6HRFqbISjr55kWW5gzzWHuLC4Srq6UlLaA2JEDo0gRsehWsEJ6HZb4CzVSoV6JGnGAiU91apieW4JmywQj4wQTeymsf0ALqihhzdzy+d/kjs+dYTpHz3JI3/yl2xoneEr2WP8zMk/YH+1TfWqg9iRYawv6C/Nks7PlBEr0AN2uBgwQI6L07P4QHP4uht4/XSX2fOz7Nm7mX3NBLwA78rK0K/3L3RQkpve452goRKu2jUG1vLaO+cZ2bSHoY0TnL8wB/0umKIkRWt1RK2OGttAMLmVeGwcWa2jNdQaVeJQ0whBC8/OjSEjow0unDrD2tSbFJ0uVgyhhnYRjF+J0cPEG7dy58/+JDfetJmXH32E733zCa5ae4Vfmfov3Df7GBOTdfrjGzBKEdQqyCgqkV2UAC5s2TfoLC+zsNpl71X7ea8bcvrENLWRIQ5NAGKw39cjHiAxBdaJS+4/Hhds31DHrK1xYrrF2I4r8FKxNDsLeQrO4Nsr+PYq3pYnVFoRDY8QT0xQH6pRiSMqkaIRSeqxZNfWOkEIc3MrzM+ukKxOky+8je11cb5JNLaTeGwTmQ0Z2r2POz97OyNhn2/+6VOcePkYH138Hr905nf4SHCO0WuP4LfuRsQRMpCg1/sFDiE9LulzYXaBiS2T5MEwp05fACXYOxGiRQmC3rpLIKjBvG8R79kQGUbrISsLy5xfzhi7ejOdJKO3tFruNRw+CMsCo72KsznW1bHUkFJSr8WEUUg1UgyNanQkaTZiglDRWushxTzVRoPxLRH53Cl0GBDUJwjq26hPCNamT9JKNIfvvJmJXRf5q2++yjPPCe7+8BX88sQyzyWbeHTiJo4FB8neO4VcXcIJwBmEN/hCsDC/TLx3C42hCc5OL0Kesmk4oKYsLS8Q3iEHGKC11j9GJI7FjkB5FpZW6JqArSNDrK51KXo9hLU4W4DJ8L5SssNpHyccuTD4bhstmlSqFaJAMTQUImqa4eEAEYesLnfopwZj3uWG4SbOC2yxhp+dI6w1qA4NoRvjVFspU1Mt+i7mto9fzduvX+CvvvUWm7eNc8+dBft65/irZDs/nLiKea8RS3OD+F6m863VNVLnqQyPMb+6iO12GapIqrqgRUn4iHUDGGNwboAI1lEPLNYkrK62cASoKKLd7kKalr0BKcF56HfKCOBruEBibIDJEryrE9caRKEmEiACmJhssOY1q0tdZGrodBPixgkOXr2PLLOYLKHbajN/9ixChTSHa1TiNmfOdkmtYHjTFo5Ux3j9tbP8hz96mQ9et4kvXpFww9oZHhLbOVrZCDbH+wCcJ2136WU5ut6g1bf0e11C6YgwlzpI9v0+tP6xXpv0hixJ6HQ6OO8QAnq9BGxWupjXZdNTR4hKBVmrI2sNdK2GrDep1yvIQBHFkqrSZDgqQxW6WUhuC2wiMAbeees9KnGIkJ5eu4t14K0l6fZICs/oeJPJ7aO02gX9XkazUWHr5BHOzyzx7omLdNYyfv7n7+Cm8zP8b88KXjUbkOkiHkFe5PSTBK8USWbIkhyBQ2HBqZIv9CUI6AKDs+tNBUtRWHrdDlmaIBCkSUJK5VKxhPcIB94ZEB4rBV56pAaXF1hrcbY8TkqPyXNEoAlEjMkLlnueSuTwzvC1P3yCTi+jVtEIIanGmnotxAuFTQ3tTk4nMTghqMSaPHekvYLNmyfouoCv/vtHqNVCot1fgOW8zEtkBAiSXoIxBiHA2Bxb5CVPiMQ7MAOv15iSmysf0JPmjs5aG4whDDWtdgcpqyDVoHVt8EKVe6goIOnjlMBXIlye08sKbFHQTwztJCccV4RxhF0t6PVzUmuwRcHKmmWllWAcSOUYrmmywlG3nm1Vw6n5FicvZESxRipYWDCEKmD79k0IaTh1fJqFaAvptk9zcSmAzlzZGJEC5xxpu4tJU6qNgLTXod1uU5hggHVu8MwDDPDOXYqPaz3DynILnKBRlbRWVhiujA4kD+uKhtJYOIcQHoRC6JCwVkMASXuFLM3JhEM5KLp90m5GNzEYoTGFY2EtoR4K6lqi8AxXFDfsG6JapBw9tUbXwc7NFdqdDO0UW7dNEtYjXGuRpbzC8u0/y2xjP8vHT2GXT4AMEF7gpUB6S9JuY5Ieo5tD0l6XpaUOSTYMlImQsesGwGDcIDF0luWOZXklo1KLGI4dC8uLDG/aVWaAiEvo6Z1DeAsqQNYaqEYDLyVJktGlTZIUYC1ptWBtbo00j0gKS1QLWW1nKDyxkozXFTdeM8EHD4/Rm1vmqaNtWk6xqSGpWMuyHoJmg8i2SbIeU4c+zpm9H+P8TIf86FFEZw0hQ7wv8GEMOiRUil6nQ95bZbQmSToJF5cS+tlQSfo4V3aL1kHQWncpjKwkMLfcZVI6NjUVry0ukvf7BFqRD3gDgcbHMaJSRdQaCG8wK0vkS4t0Jpr0fcpar2B2LWVr07M036VrEyySTq+g1UnZ0Ij44NUbuOejW5loaF4/Os2rJ9sEccRhkZMVIQu+Qlwk6GyefN+tvHvtT/Nqq0L36MuImSlElr2vVVAaghCvNaFWrCwtI02HkapmdaXL+aWMzArA4AHn18NgYXDe470Eb+gUARdWcqoBbB0JcNMtZqfPoFQAQVSyxUoDEpf0IevhwgA1NIwoDIX19HsJ7dSw3LIMp473pluoKEApWO7kHN4zwuc+vIX9exvMzbZ4/MVlcuvZXFe0FnIyXacTecJkBbFxL2dv/V95rnEN519/B959EdXplFvZUrbuVIiPKqBDZKWC6bWZW5llU1PSCBVLy22mVstUv/QAjzX2khyrpIi8RXhL4jRTK44x3WEobjAWpcwvzeNlhAgifNrH5+mgN24HHL4qQ6iQ5IWh2+/STy29XJAYwdxKgYolUai47/pRDm2NyLtdnvnhCq1ezmhNMSJhalEyL6sI02Z04yaWP/1lntz+E7z67hz5E08glxbwWYbLCvw6iSskhBEEISKqgLN0l2Yo8h67GgasZ34xYapXK3HMl9FsvRrUiSlwxg1c2+C94r1OzK6oTUzAnqbiYtsgncGHNYRUeJOAKJsb640UGVdxRU635en4sjfXN5LVrqM20WBxqcOIDuh1Ml46mWGkZqTi2SgNyZLnRF/TrDuu2Vhh7op7+faBL/JCq8rKkz9CnjmO6vexWYrvJQhjEcaUDFYUI1QASkMU4VYXkRICl7Nn1NFqp6y0cy70JwbFULn/7Y+HwQFb6gXgmOpXWet7wqLDnuGI55dayHgcUxT4MIIiLS0pBEQxolLDZSl2aYGkOUxfF3gPmRP0c8FCO2f5/BJLHUvbKzaNamp5xuzFjOVajcktEQc2gNt7Cy984Es8Hh/m5ItHMW8+jlxawqYZpCn0+1AUJVxZg5CDB1cKwrDs4Kc9bByzWbbYUDWsrvQ40wpp2QpSFDhkWQ6vG8AwCIPOARJhM1ZEjdkkYDhpM9FosCPucE5vQGQpPmiW5IOzUKkhwgDXW4O+x1dq+KxKZnJ6mSEznpGhmIvn51huGUZHI6oYzp1oM1yvsHfXKBPNgua27Zy99Rf4m5E7eOP4BdSZ7xCtLJOvdXBJgk+Skn0qilLtV5hShhdW8EojdFjiU79LpARF2mP/cEKv0yPr5pxsD+GdRggLQuK9w7nLMcCWe8IjkN7hvOJM2uRwsMrSSovrNlY4e6FDGJUPR1SDAdPqkw7CZIgwhCTBZxmpyukXlsJLpMnxRYbXcH66hTKCq/eNsntS0BiqMXP4Pv5090/x6oKBV55Hzc7QW1wgaI6BF+X2zHN8PyubqM6U76haemO1BoEGraC1jKxWGFo9zd7hlKW5Lk5EnCtGwJtLRI7wl/Sc6JIRcuVJxUCPZwxT+ShXBkuszbc5cGCYrcxxUV+J7Ge4cKhMKHprA3GkLLtJeU6RpCRBgXPQrIYsL67y7lSbfurYtX2UW/dX2dCQTE3ezF/u/xyv+AlaP3gdPXUKYT2iUqdotzC9PmporEy8jEVgS17fGISOIIohCiDSEMT41gqxlqR5xq1jbTprLZLUMC9G6foGwhd4GYEd8AHWDGqBwpRAtp4MCYWgILER5/Jhtusu700v8KGtm/n6e4sE9QmyfhsRhXipL5OoAUVG2u7Rr+ZsHQ2ZvtjhqaMrbJqo808+OsFkw3PCbeVbW+/hjaGDrL5zEXnueURrlcKUCYpsFIDELs4hvEZWmth2C6xDZBleRRDXSldWGuEVGIdcXYDhMSbWTnDlZMI7x1qMNGLe6Y+XWasvn41B4efXM0FMgjXmUkXoocz7jeVktoGttVXmF1aYGB/i+sYyLxcjhNKSO4eMqmVXiFLeSl7gs5SWSanUI7bvHObggYydEwHTSZU/Dz/EK80jLM4sw3N/iXYOhMJlWXmTxuB9u6w5jMfMnUdu3AZhFdHp4FUAcWWgjiwVpcQaP3eBSmOIbGmGu7avMj21QEUJzmcjrLoRhMvwIuAS9+st3l4iRQ2uMIh1KyEQQiO9JfMxx9MNjNVjXj92kRs3p4x2TkMUIbM+XiqIK2U9gAAncHnOu6eXWOykfOj6BmE14utLV/J74h6+uzDE4g+fRL7xInJtDZsMYnph8HkBWQ7tTqmk8kCW4BYuInSIrzYQUXWgmx5EoDDGL80RK0+S5dzSnEGmq8zMdwjiKseKzYNWnyjDNx58yYDZwjAGSN/vCVcY4dcLHDxeylLbawum7ARrcphQeY6duMCn96T4lfNEjTq+20JEEdRqeCkQJmU1lbTVECP1kK/9yPO7rdt5sr+b+eMn4NjLyHYLn3t8VjY8fZpAkkFegPX4ovQi70uCh14HCoMYniipOClL3VKlXqJ+0cfokF3pMa6bTHjjxDyTIxVe74/Tp46wBV7pgRxnIKD0Hm+c8CB00coLt9EUCBnCoCqUElQAtsA7wRv5Vm6t91ldaTHeWuKT2+CRKUltYiv9TguGRhFI6HdIewnnD3yWk4uznO8Cy8vQbyOULHuKxuMHPKRAlPHYuTK8XcbWltlMDEqVdX4QQLWBL3JEGOGTHpFJkY0RmvOv8cl9fV55Y4rxRsisG2ZabEWYrMQpoQcyWn9Jtm+yPBuFTOZJt50Xti2kLptkYlDzSg06RJiCVNR5LdnC+EidM9Or1G2bT2xapL90kbhRR3RWcUJBfQiRdDj55nHOz3WQa0vILIGwipchuIEExxQIW+oQhDFgXLn6QparrENEXENU6oigWuoVTYGIYmR9CN/vEWMQlRqN+Tf43IGEU2cuohCkosKbbjfClRSfV6oEP+EYhDnvEfTTZOU0ZNovLmY2yXK0LvedFOuTDiBD0BZRpKyEG3krK7h66CLvnl3gqisl9+1Y5tEzGdGWvVhnyHODCGOkLUpA1FHpekKUDqbVIP4O0EiWrilCWba51fuKVC9lKaCytlQPRXFZs7RWaTTrpEnCxoWj/NTBgqmpi/jCooIKL9krsCpG5AkEUenJQl5C//LqknxtLQPQtZPH17oHDrUIQ4Tz3iuF8A4vJV7LAdPqEHnGbLANnTsONGY5dXaePTssP31Q8K1Tx1nbcIDmcJNep4utjqAaGpJu6dJCgAzwA9mtlwJQA4WYLI2uden265pEW7JUotaAIMT1+kS2S2XDEP2LF7hGn+OjRyxnTs9gMoMVIS/aPaR6GJF0QYd4HYEM3idynADlhdOKotObBlDL+cVE777x40aI/W510QulpXdlyrj+LuVlFmELWuEYvcKzrZLS7XSpqoJb9jXoL84x1zLUNkwSVysUlSFccwxRayKCuMzbpR6I2mWZdq9PjUgxePjBtouqyKERGN0AcYXYG0ZCgS56MPUGd0/McuOWnKn3LoKD5UTzor+CVI9Bv4vQwQA/glLqxwBfvAAd+GB8Ugbdzh/2T73wmvaAaK29Kqq1e4WS71Pf63sGiVchBA6KFJElzEU7SLOQD0TTZFnC/PQUd+2a4HC2wg8vdFiNNzI6sQNX2UAWj5DoGCtVmeiYtBRDGTs4vSx7fINyVsYxMgxQJiPqtYk7LYrWLHbuDFdWV/nw9Z6i02V6ahVp4WQr5M1gH0ZUEb0uXuty5XU4yFLXR3A8QghPtSpdr1tEF+dfuTQvsOm6f3r98tDwi0V7Qfk8F2U0GMTO9UzPm7IKNDnCOXxUJaLDYXmOfUMZoRaMjjWpjU9wcknzxqxjkRHUhq3o8U3QHCevNigqDUwU45XCi1IPGAhB6Cw6S9FJG9lexS4tks9Po1oX2R62uWEHTMQpqwtLJP2c5Y7l5ZUG78VXlFVumiCCoCRHgsqlvqHwlFI5BEIIx8iEiHT80p89+Xu3fhac4IEHpH/wQV+9+ee+m2DvFu1l63Wgynk1CUqsz6UgXA4mL8kIm+Pj8kJb3QzXN1fZ3HREkaA5MkzQGGeuF3ByyXG+rWmLKr4yjKg0ELUGMq6BDnHelVVenuB7HYrOCkG6xpjqc+UY7NsoGAlSumvLdDoJ3a7j+JLntWwznWAjIu2VJfLA5QnKfS/W5xucK1viKkLgrRyZVLW8/0vtF/7897njDq35wQ+kADPa7f1WUdEfMZcGAqQoFRXBoANbAhcqHIzLgEgThJRciLaz0N3Anv4MR0ZTQtlFFBnbGzWu2NfASM1qkrLQmWepd5HOmie1EutLijWQnoryjNUlGzdINjUko7UQkXfpttt011K6LcvJRcXR1WEuqo3linZW8CjQA7TXwaCWKW+wbJkXoCIk3nodKp2mb00a81AbJE//wIr1YakHHj7of/vIqd/vifxLPu0Ywqr2rihXfgBepZLElictirJRYrMy2wpjUCERCbujNQ6OJOweE4w1FbVKQBjH6ChCBiFeBOWNI8p8R4HCoYRFOIszOUk/Ya2dMbWU886c59hajYtuBOcDRN4HU4ZZoQO81uXCyKAMq4P2l/cGIRRCB95nmVNRTQ1Z+ZnlN//iUbhfwcNWXD48dfDg/bUzIns898XNeFf4qBqUYmM/WPV1fXtZPgtbGsM7CyYrw6eKQIWgDGOqx65mwa4hy+aGZ6wKjaomChXhQAAlB1c3FpLM0upZ5rueqTXPqRXBdLdCz1XBgbAZwuU4qUuXFiUP4HUAQpeZpWBd8QFSI5V2Pml7qaqqoeN/3XrzoQf9ZZNjl00clRY5dOhz28743kOZLz7onTVCB9KX0xJlBXZpMKlsMODKQqqUoxqEzQd0rS6zP6VBOiJpqAeW4cjSjBwV7QlLLpXMQLcQtHJFJ5N0jMZZVe4zaxAuQ3iPU6qM61IjhCq5C6UGErjLb9AzUNBZbzIthaahqv/Px44H//JhFgQ8bblU+v39QUq/f/+9Y1Mi/e1c8DNeSbCF94W13ntxSdcuhFjPrMR6EeVLF/beI3wpuhTe44XACVmmpOvzwVIMfl8f/hvw3KxL9SzCO5wQCKXLiDE4h1ifXRLi8nHbAaLgkEIIHSkhHCIzS1Vde7B94tHf/bFR1X98crR0DwEMH/rM5/u++Iqr1q73lap0xuCzBF+YctZvvaHi18/pLxtbY1DOrRfhDuHd+w88mBq+NBe8niQPGKb1Mdwf+ykGU8livWwv5fUoWeJUGCBUiHQg+t2ezrOHK07+1srp7x67bJzZ/88MTwt4QMCD7nquD07v23ibadY/6aL4CJXGFrRuOCEipFTKU6McoR2s0GCO1PtLN3rpxvGD0dr3V06IS6YYzAVzibH164PD7vJRa48vh0aNl7LnrZXCWyOMT0TeWxOd9mnR6b/YXFh7dGbpmVODYWgNT5v/f9Pjl+HC5QePsX0Tm7c3bKMRuThUVT1cI5aipJeCgYdfPhyv/95Z/8H/BFw2J//jw/Q/9i0DmILMO1PIouezTIh21wadXlJZeHZlCtZ+bAL+wWPi8mf4u6//DyRuwQ+umEq3AAAAAElFTkSuQmCC", "ui-help": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAVJklEQVR42u1bZ5BdR5X+uvve+3JOk/OMpVGwwsiycBi5sAnG4DVmhmATlmS8xrsULtiiamufZilqCbZhFzBrCliMbWDnYZZ1EBiMNCNbEWV5JEsaaXKeNy/fd2P3/hgLiiKsJDQDpvb8eH/efX1Pf/2d09853Q9YIksmk1T0drHf/WajPDp6pHpsdqz17NmpVWcHplZlszPNg4O7479vHNHbxZJJ0KXyk1zpAQVAkOxkpKffAoBsdk9Y1ozricJXc87WWDqt8gR8CShOl21TBQJgEtcttVTUysVJl4IxXbCXha4PlOnE7srK95UAYGeyU7qpp99efMVfKACiF4x0wwaAz23pXNHZKe5yNLT+bcOWt1c7HRxuDwOVXeC2AGHA4ocAtzmIIKCUw9JNqLoMLTsjRn7x7ROleeu7zzw2/6OHMwNjFxhBulP2XxQAAiApdNFupOydyc6oYuJTLj99/+SImjB1gfV338flQEw4FUs43G5CJUaoJAGUEggBYXPBbQu2YQqtWBJCCpD00efp4WefI4mEFzX1jvO8gG/TMeurK7+zp7Czs1O6qf/KsOFPji2RTFIA6KYpe/QLm+7KvLKwF3rx01Yhl1CLBasxropYUKWJ5hXMH6+XFF+cKZ4wlT1+qngDRPEGieIJUoc7Rl3BahaqaZPiNREW0s6QlS0KN2FYai7fNDqy8LlJO/tS6b9vfOtN/f1WEiBCCPJnZYAACAHAJCaGvtjx5d37c58YmrER8XPL71XYtevdpFzSUX/DG+C64X4QuwRAAkAgGPs1/oSbALcBYUPIftgz+5Hf/hVkbIZomws7eyf55HiJC51Lba0+u+ON7Q9Hu576NLds8htXlhkAARD0gmKgk/xqfvaRw+f0j8wVbSsRkSlnhLbXEVQoNtwbr0fVtdUoHp+GoRG4ojKcDVGQaA3gCANWEWJuBOXzMyjNleFJhKAELEgNjTj5H0+DzE8APieOnjegZQyez9uojPtpZVT+6o1fv/0Tqe6TpCuV4uQyQWCXC8DWJKTGj8N+2/rgl8dnSn93elazKmMS021B19TYuLqag7sj4ISAD50EMI3iuXEwfQayPg5inAZRByDmX4YYOwt9dAzq2CQUVxbUnkd5cALZoon5oQwCtAxFYliwJCLJNoanVTubtbeknzsv3ZHa+Ut0QuofAV82AHq7wG57BPbT71r5sZpa8tlcrmSZVJI0QcjGGhvtFQxWogYk4IE+Mg6nLOC/oREuH4O7KQraUgcSbYDw1wLeKGjQA0fUA5dXgtJWBeL3I/38IfhCDLrbi/kJFYquwrIJMiYjboVQt2TY0TDp3BCrOveZHbNHe3vBUqlLZwG7nMl3pcDv/Nz6tbnJhe+fGSzIslsmskMmTR4DcZ8Mqb0V3oQL5uA4fGEHHHV+ZI5PwVXpB22+GiTaAuJZAeJYBeKKQjgJhExBFaB44BTKkzk4Yx4Uzi2gMk6ge3w4N2LAzJUgUwLZJSPk4iKmqMQwRecGr+vpj/17cR5J0P7+SwPhMgBIEtLfL7Z94gOPqiJwNZc0vq7eYM1xE/5QEO62RvidKjAxDU+NH8qKCpx7aRR8NgfFKyC7TBAtC4giYOWA8iR4dgRkdhSF8WlM751C+mwOtt+JUK0X82dyiPgEbMUN1SDwF/KQDR2yW6JD0+AuSj0bOmpra/dP/rCzT5D+S8wF5FK3PNLTw48n71wbbF95oOhsUBJSPwmEx0Hq3gxhMxj934cwdTjqgrBrGzCzfQDFmTyypTKqwhyxjloo4QSI2wXq8gCCQhRy4LaKmePTmDk6gbQuw8EpomtjiPmB7FAeTr+CdJohUOtC+uwkUNBRszmBFwdX8kQsiHgkuHnlh7908IKPS6ID+i4874vfHQgrDqqO8rnD4xAlB1DZDHt6AKQmAue6BpA1m5F9cRjMtpAu2JidsjE8bKCY0Wy7Is5F5dWc1L6Fi6rXcTNaxy23y9YX8jynC6SzBnLgGN4/g3MTBuSoC4wAVTET8TV12PjAFjSscYLpJvxOW/hdCoVmvuO3fLxIky569RdFh32wyhWoqDNvsZkJWpwi7rZqcKkEvudHACnCsbEePKtDkBgCbW7sf/w85mYtxKMKZEW23dEWJutxwOMFXAlQ2wU6OwFJs0DoeRTTOb6QAy2pZQQiDpAzGVRdF4fDReFSSmCKgD7HMTpqQVVl1LcUUB0PIWuHbtjz0EOuLZ98QBPbBCGEiCsKAFLdlHSn7LmRh1vZhN06NTAnvJEgiddzlKeyoKoOR00ZJDMDPmtCPfoYcnkCn5NgQaHwBBlvu+lGpgYSP2Xh6JO25TPZvEPYCIOGVgoanou6R8bu3+CR2qU9E/aRU2UGS0PH6yMgxIDwSmBcBvU6oGV0CIOifks7RDBKzk8CkRhtq2qebyQEJ0VyG71YcXTxAHR1AUhBcbd2wjruIdyyPFG3pI6chzpTRKBZAZ8uADEP8hMl5EcNTE2pCPgYKioVu6qpnqVz9neeemzk4w+kHiz/vleUXrjnmfRc/omqaHarXqlzb52XZrMGxLSFaIsbvqAMbSwNz4Yg1t5bC2s+grTqo5rI2mUiRRNVzhYAJ7EVFD0XpwsuHgAMCIDC6453FGwCiXLi9Enghhee8jBc694A89wgxMwQMufLEFSGqQvkinN8/QfeyQw5/ljl6x/8kBCCfLJvm4Stq357hQ69QEnHoxPb39TSvend7T+pXpd93ZGfn+QzC5w2X3c9HEoGufExkJIDDnkGijMPVu2FNMzgIFx4vU6Y3sAqAE//zthXBoAeAcJg5Gbcet6EFKwEaAm0dBKOKgcEzYElKESxEjx/EkQ14BSmiK+KULLyGvWU/75thDwEpFKUdPdYv+cF9sFHPyp33PPNufEf7/6Uf++/7KwKHZJD7bWQ6qJwlQnM7BiE4FDP6CjNLcB3lwHJ5YQiycTlkeGtbWn+zWJd4V2AEAjBLZIdHArDGYPbC3L2sV6c7ptEYXAB9qwFVn0raPvdCG1aj7m0BkATdW+6GSK27tTDITImuCCkq/sPUnPjRx+1BEB+dSw+SZvqjeYOD3EGmXB4KFxVCsIdAfgaPIANaCUBIQxIsgSnU4HsVUC8lf5LLW+ki90BCCFibO9epxuehKFOgp/4T9LSbuH4mQD2Pp/B6mwfonWHoasU6nwZVHGBQxfMm4BtKSdSBLaAoIQQ/n8IE7EvAsvhNG0WlmAaEiS/AhoMQDiqwYoKPPkMFEMBZRSECDAmAMHBbU6XBIALlm9uDlTMHqj96Ze/LcI1BavK4SaKpqHpKob8vAYiOGamDShCoLGOoqB5rfLwOFScPgwBoG8bBf54chJJULSiPJ06wD0ZC1JUhiNWCaFkQHwMxM3A2vNgsgoiUQhuwTRNWEUdHnVCvdSiULo4+i+iOhdXtNiunx1vr+PXzOsxWS1IiDV5Ubu6CrS9A/CEUXv+FcweHwHJZeCXspLgDNr43KnFAU7+Ue8OfbND6uiBuYPeuqLCOestl2XEPJwIhxvUaQFOHyC7gYYgYOZBFA7LMGBZtjAMCwsL6dFFAFaRK80AIQBCSCib3Fh5071vr/vI/Lnc6wslh5CqIuLIAd12Hu6jFe0JCMUpcZfT0ouyYRQ8Tj5rZkprPAOLW2kv/0MU3dnZKXXc02/OP9V5rXHwlcd1WZLyZXDzlTJt2WJBeJwgVAFBFFBWgEdehlXOweYKDEMQzk0gO/ryomQduGgALqMhQq5oY3ZRYRJKCOzSsTtvH/rhkW/zkhUp6TpXVSfdfM+74UpcBfg8oGEHIEUAEoA1/z3ktv8Ms1q74DwIfzxUMii2ttzx+UO9vV2s+yIbp9JluEx2JjvZ3Ml+gS6gq6sLSAHoAvq2zZKtq+ICSAEDnQSr+sWrAooT8ruoCZGkIAQEkq1Nf/CTudSeL504UKI2M3hzWyXd0H07XPGVIBUURPJCmFFYZ1Kg1gjsTBaOTBqGnhGyg1BiOs7O+8VZIUCAP8y0JT8XuPiVT1JCeniXEMoTU/c+mOndcf9Af0YwDxHe2jrasvkGuOqbwVorwBwKBKsBn/ox+MhL0E+Po3RuAaFNCezuc9tgEVbRFv+39o8+8YlXzw+sZesKX14nuVMipIdPiAejT5648yntqR33H//lrAWXQGxNO23Z3Am5th7SyiCYi0JwP0T+ObBEEbRxFRYmZOgOBT/61pTY/fNB4rKmTMlLHgOArdv67CXbBq/I5B/dKJN7+s3csa6r5NQPnxjaM94xdE61gpUuKdC8CqGqZrCmerhWhEGEBl60gIWnQWsT0AfTGH18N3IqRyEHLJSYtbqRyo5S5ittdz1+pLcLjBBiX2pGWy4joheUdMOe+t7GzerZzA/ODRQbi2XbitcoUqy5FZ5II/zXrYGv0QnBbfAygLGnwa5qhTYwhexPjyJddmBotAibc6smJkvnzpjPjmdv6M7vS+nbAHGp3WFpeeIdBKnFyZ/5yrr3lM4sfPXA3mK4xIVVU+2UAhUNYO44/Fub4ItpEOUCeNECGf4F6Op2FPafh/HSYejOCLiqYnxStRRQSS/S/X3F2Pu+sTeliVfl+qX6tuQALOoHCIDYL3647Z+c5cJnf3VSRdEGr69ySa5AArbHj8StdfAq8+B5Ciurgg3vBlldg/SO07BPDYP7I8gvFLHraNmyVEjr1voOGlKs6xvPHMz0doORFC7rvJAs+coTYDjz5UD5c488ZBnaB3W3xDPjKgxTpk5PFKHWMNrfEofTssA9IWjjGcgzx4CrohjblQamMqBhHwplHYcOFE1mELnpqsCO697Y/B5y+46Z3q4u1p26/MPSJQaglxHSbc/t/8d7XcOjj/R+Z6dllDXW3uQjJgnCVenE+i1eUM7AamPInxqHqzAOsSKMU9vnQPIalIiMhawhhk+r9sb1YSm+qe7Z6C0t7yWhx7K9XWDdl7nyyxMCqRQAYPLFU4oSqOOrb7uNVIWnCZkegWEzhGME2eEy/CsrkN1/Dkp+BsVGD459dxxeKuAMKxgc1kR6qMjf8s4mKXbHbU/M1n7hY4SQ0qWovT97Epxd0EVQnaJyMGJHNt4ImZ+FOXEOUqIOPq8XmRf2whqbgmgJ4GBqHooMlD0E506XbW1OZ7fe1Uqi773zn1noC5+F+CKSySTt7u65IncElgWAqFfiLmYgZ2TJ3KHTSFRmoKwIg9a8A3yqDz5/BrTZi/0v5OB2yxDCwrGTmi0bFnvr3RW52IfedJ/k7nlSJAXdhiR6LqHv/2cFoG9glgBAdas3NDUwi4XsvPB5a+GTigg68uCeXSDZE7CCYRglC6FQFqV5E6pO7NYwY82bAqPRt1S+R3J/abfYCQlbhd1zke3uvwwpvPXVZBhkjpKqwyiWUC7qKM0WYY6qsM6cgnliDNp4DkIw+Ota4A4HuJsSVpHw9Inaxk53y0u7dyYhkZtgkSs8+WULAVck7pLoIEzNRDFdhE8uoWSUIZCHNlyCWS4hw93w1LTwyNo6qsyM7/v4trm37flWf+HVe0fWUvlGl5YAixRw+uNxhySga4bIZQvQSiYyMwbmJ4rIzBoo5zjyeRuZ6QVRmi4iWFV7fg9OFw5+dKN84dLVUtkSM6APAKDlZ7OWboKbFlRVR5nZcDAOdSYPZgKcMBRUC8wvwJiBYLMnDCHIJkLMpWbnkjKgb3H+MMeGFjJpDeCcwDShF1QEozLqrl+FcMIHXbWgajYADlOzYFMmIEtCLEN4LksO4LIu6aYGXbdQX2OipsEP/xoJzpvXoexLo2CoiKlOSMRGUeWwDHPZqtRlASA3mC5HfARGyUDrdX5Et64DccQAw4TScRNaWhoQPT6Ml58vQaYSaHrSghAQ4kIh9RoHIDObK9U3AkGfA8RUYc0IOFbfDEgSqK7BKGpA7hiiIYFEXAKFVYLNgW1XuAO73ABsXdUvAMAXhJEd121/BbOtkirO/+QFNEztB/F4CM8UMHqkJJhQUVvjsCcXPPDXBF7N/EkAPa/9EHAL5mY+B5t9pcSiNUBVnRNuiQIuByAsVNdryE0IzBzKSq6oAu14ybf4y57XeA4YWKTvdNGxO6rY/zpeZnZ+itH2GypEYcsdHqfv6qBROq1ZrmcXpl45i6EJ2BuCtkQgH311/gL/b0vcqFy2nuC2ToZt/TbZJsjEu58J57gp80JeaEwiEWeN+HTP3EIq1W0cfHSjvHHykE16wP9qUE4mkxSE4tGNCAz/8EP/VTjxcEaf+0FaL+/KaPnn0sXBb+Vmf/7Ajiff37YCAHq7uthfDQMu7OVPtiF6zQN3POmLxN6QPf0iGrZUw7FiE/jcGCb2nkQu40Auz8fKOr39lof3HrlwJ+E1DYAACITAN28h/tve37WdBFtfNzSqWS1tceYNecCcCoQtwLmM5772NVsUF6TNb14zPp1zvfHaf0id7O0F635NF0O9vZQQYo//z9//jdPlf93QsGpJvCxJ4Qa4V10Hq6xC8viQO/ELlKeGpHSZGUOHB2sidXX3AeQ+LMMmsMQdoa8TANi3fV9ztK6NK+FKEvC74bb3A6UZMIcXMAiU0nbEAsBETmIvn8iK0KhWSQgw0L30CCwtAH39AIBje49R19HTtG3TBtu7IoQzzx5BfasDgdXV0KfyKI8VEa0OoEqzoKkgoxMFXQixHEJwmQ5HFTfcTiBzYh8mC0HMqjIKBRtr3Rqmz+oYPa3ByTREZBtZmaAkUQIA25ZBCy5tLbAV6OkH1q4NIGoW0XLzKoBYIDtnUBllULwGqK1DL+uoandjZZsLw/tm4a/0uNmvKNDDlzwElvh+QCcA4NrXB4WXlHl5KgOvT0d7I1DfDChuIF7L0RQ34GAcZsGEmrH42s0+LihdFpW2LF1hh8fBNt57M/W0XcXtdBmuSgXYcg34ig3w3HI9Iu0BqBkTB3dmRagqREMu2eCGBSGS5DUNwNatfbYQIBl+7eMLctVg1R3vloO33GB6rw4LVvdmzqLv4rTiVu5f3yQotaypGUjT3J82m258ZFE+/zUowSQo6QF/DGjr+HznM+13BNu0sbNgiZshh66GnjsNffCXWDg8gZcOs/mTB3Nv/9ep4ovL0Q0C/oS/zV2s9fRDCJGk63p2zTftG36htsbcYM0BVBgLRJrMF88OZrKnpgu2xcZPnhUf+MzL87vEzk6JNI789RRDiwUOGAjB9x6427Prk2vbpsWzTVkhmsvixaZf3Lei7fk71sZ//dwy2v8CCGsgUy+XSXAAAAAASUVORK5CYII=", "ui-train": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTEyIDMgMSA4LjJsMTEgNS4yIDktNC4yNlYxNWgyVjguMkwxMiAzeiIgZmlsbD0iI2ZmZTlhMyIvPjxwYXRoIGQ9Ik01IDEyLjZWMTdjMCAxLjggMy4xIDMuMiA3IDMuMnM3LTEuNCA3LTMuMnYtNC40bC03IDMuMy03LTMuM3oiIGZpbGw9IiNlOGM1NmEiLz48L3N2Zz4=", "ui-ach": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAA7DUlEQVR42sW9ebRlV33f+dn7nHOHd99Q81yqkkqlGQkkEMKAwcIGY4kgxybE2HEIjh3TttM47navxIuElQ44a8WJHbvTNh5pGzsY28QYMIPMIAxGMhIIoRGpBtVc9eoNdz7T3r/+Y+8z3fdKprM63U/rrnq67w7n7OE3fH/f33erq65/vSilEBHcj/gHiAhKKeo/GkApxP8uYvl/86f4vup6Nv978VO8bvZ9zXuq7uVKn/vt/mz2fbPXVLvaxv9ZEcS/VwEKISxeo5QC/4LizeWXIOXfiy8V/3z1RfX3Fu+v/iJ+bt1zzYHY7AY2G6wrve5K/3+lyZr9/P8nEzP72isP/szE1V5bDD5AWKxm5V7hBkykOXtaI9Y25lM1Lqj+Rap6vvZFotxUuIn89m762725b3fgZgf975qk/85vuuIENF+h/AQULyh2gqjC0CBKYVFot2YRsRgdlKsYa8rBt2x+Q9bPtxLc5/jZbkzazKD8j/zZbIeINE1ufaKs8ovzv2PVz5ruwrjbchdAqBSIdetWlF+pSrsvFEEpQUS7L1W6XOWFDyg+CG+iNtva9Qu27k5RgNbN3fP/189mu6F6buO6FhG3JJU3z/LtmSArgta6vH+AUET54fQzLgqUQispnazVGveVuvy0ctBVaWScwak7PqSxysSbOJQuTVN9Mb3w9lebbOb/8T8i4u9X+TUmjVBFrmh0mg5awA3+zOtDURrRzj4jGo1FifWz68yRtqZ6m/YOVelqY9VmdIPdE++ClUIVvkU501TsnvrWry7c73rv8K3W7vViy8n7/2KS/JIpx0PKr1Ebwo7Zu6/vKF3fCXUTBCAWlC5sn/ZvFh9iKr9KxV2AElDazbydjZqKmffjrBQipnLUSlcX3bCptdVShE7FRGiNEkEX7r3YRbL5MKticGTj1JSBtlg/OOrvcJf+s1RzoYhUjrQesMjf4YpFpLIaIpUTLiKTYqWK0iB5MYo+gjGAoCXEIoiCQAkiClGBH1hV2qcg0OXFixUQi3FL2l2D+IFoTJz47yrmR1DF7hLBiqDqk7j5uqtNbt0fUQ6cIN6O602GvbGkUNr5KmtnciNrfaSnGjE+qv6pm4SwtcUgzgnXLrIMG/0qV/XL8fZLLLp41kdJ4t+ptSJQkKQZw9GEPLMEAbRaIVErItBVEuK+TzcdmCoD5mob1Yak/s7NVrZqRHRFUEC54pQSlCiU0psar2qA3Co3IqSZwRqLVkIURSita0momwzrV/ZMRoJ9gQC1GPeQmQRhQ7jV2MvF3nNmyvq7D7SLkMbDMZnJ2LNrC698+S3cdtsNXHfkIPv27GBxfoEgCL39N4i4kFSsYMW61S/e7Im7Ofe8N39WsNYiuH9zYzDGlM9ba8nzHGstxrjdKkL5t+J567/DrWj/md7RIoK1QmYyJpOYtf6AS5fXuHSpz8VL6ywvDxlMYsIgpBUF7vqsRevAL2Jvoqwtd0PdlG6WOYeznroxU377K9VcZy4TdqslDDXj0ZTM5Nz10pv5gTe/jtff/QoOHthffsl4NGI8GpFlGcZarA2w1g2GlWIQvP+ReiQVlE64HqsX8IcuHGFpo/09S90hVI6//Azvu8SKn2j3mW7uFQqL0hprLZPJhPMXLnDs+EnOnDnPuYsjnnt+meXVId0oLENp991u0pXWG7Nl2dxwqsM33yO2vHJmIhoPOGgfschsuKhYWxtw263X8C9+5kd48xtfh9IBFy6c55vffILTp04zHA0wJi/tLsVKR7AWMmNJ04Q0Tclzgy1XtvU3VoEeSkCJIBiwFjEWi3XPk/vQWRMExSMgCCOCsI3WAajAOVSl0TrAqsAtiOI7pLrzIAjpdrosbZln987dbN22leGwz2OPfYMzZ5c5d2nCE8+cIUlyWq1WbUysn28X9dX9WiMkLyK/w7fcK/UVVp8AZ0qdwy2sj4iglSLLLfF0zDt//C38/Lvewfz8PE8/8zR//cUvs3x5hcXFHr1elzTNGfTXGQ77JHHqB2AmerDizYMtTYJtrHip+QSFxTl1a63fMUVy5Fe9Bq20d/DaRXj+P4t4H6B8XFfzO36QtFZErYiF3jxblhZBGbLMsHXLVg4dOsTxE8/xtYcfZhQL33hqmcuXB3Q7HaxYvws2Ymeb4UkCqEO33CvSxAVqOM9MfOAHP80sqIz/9L6f4x/8/e9jOBzyZ3/2UY4dP8aOHVtJs5gnnniSp58+Tn8wJQhbzHV7hFELrYMqCihXHpXtr8WX5eCXAKCfCAmc/S7cnJ8E5TN5KXNuVcsMmvdR7saZ/7dS+BuDMTmddovDh/by0ttfxN69uxj0+xw5ci1hGPLxT3yM8djw3IkBz59bo9ONEGuqAS5M+GbRWhEYHLrlXikGfRayLbaOxpa21Bghz2N+69fezT3fezfHjp3gDz74R1iTEQaaL3zxr3n2uRPs238Nt7/kDq6/7ijbt2+n1WkT6KCRJ7gVXDlRd9HUJqUIGW1pp7HOdNmZ91lvSqRwujVzV5qY0uZ7JywKK87siQhGBOOdep7lxJOYtbVVTp8+zfnzp9m7dzv33fu99OY79Ho99uzZy4c//CFGw5hjZzLOn1+h1QnL3bvRpNfgmGKRH7r5Hqk7XWbwm8Ldiscx1tfW+aV/9y7e8fa38MQTT/GBD3yQXq/DiePf4jP3f5GDh6/njW+8h6NHrqbdbmGM8RGL9QNZrXbrow6KQSlqC6Wz1AgWEZeJSzHwfgAbPmXmAaqc4AIKF7EuhykinuI5KSIlKQMDjPXRjPu88STh2Wef5dhzT/Hme+7mzpfeStTqMNfr8cE/+ACWNk8eGzEaxwSBRikPzVjbyENkBo5Xh2++R66MY1QmSGvN6lqft953N7/xa+/h2LET/Jf/87dYXOzw0Fe+wlcfeYp73nQfr/3O1xBGobPpRYgH5Y3VV7NYEOuuzIjBKn+xPiwUq90EKSlDRDfmBiPOACmj/GQWE1VMgs9orJ9spCqIFGZGSRmOiv/88pqtRayQiylDWKUU/cGQB//mb7j91iPc96bXs7hlKxcuXuLDH/pD2nO7efxYn0DDhlTcJw9WHHhXWJpgaff179mYRFTmx+cx5Jlh27Yev/Erv0Cr1eLX3/87KK352wf/hq8/+gxv++G3c9ddL8daIc9zjLiVX6yuPLcYY8mNJbcWk1uy3NnZ3PgBNRabV4/c5G4ic8EY6x9uNxn/GmOst9d+oHL/d2swJsNaQ2ZNlTfkufseY53pMd4EGcEa60yQ/9dYcbvO/5tlOYEO2H/wKh7++uNcvnSBW2+9mR3bt7O2ts7pk9+iNbeFwTAlDAIQW0I8BXZc5MnKh5ShqoEopdNQfhX61F5rTX845Mff/lYOHz7Ehz/8EcajMc8/f5KvPvIE3/8DP8xNN91IkqRu65erXPwWLmJuf4OlzbY1gMatuDpyXjjkutkqw9MyWrKl87QFeCcW8ZZWrGC8P7HWNhw8pY+plQwV3s/YhklzJtRFa2IML37x7Tzy1b/lC1/4Ev/oH/1DXnTrbTz22DdoqwlhqL3L1GWgUQcKC7xKKQhLu1+r9TrHUVh/RZpbtm3t8Q9/8PtYvnSJRx/9BnE85q8f+BJ33PEqbrnlJtLUlKBajmCN22pWFfba218riFUuEbMVDK4ErLGkJiE3xuUE1pZOtRgwLS5BczCJrcATEYwoFxuJxZn/wke429dKCLVCa0qbX4/zRDlTpi1lQCBYHxXhr9nt5lAFHLrmGj7z2S9x993fyS233MyuPXu5tHyRXVt3cW55QCsKvXmzG0x6sQhCqaXFUsGYvnrlV/9gyOte8xKOXnsNf/7Rj5FkGY8++ihBe4E77nwpIgrjbaZF3O/ilm7uVyhWMMpvaVNEMC4bniYZJslptxWLCx0Wd2xly9Y5lhY7zM/36HY7tFsBUVsIg4yAMcpMIZ1CmmDTBBsnmCQlTSzxVIiznEliGcfC+kRYGQsrQ8vaRBhNDEHYotPRzm/UIABBUKYGgxdBrbXeXLnnsyxl29JWzp4O+dRnPsf/9r+8i8OHr2Z19SI3XLOP589dptOOMKaA2uu7oVYP2FhkboD5KKXIc8urX/lSQHj22RNMJxO+9dwJbrn1LhaXFsiNASNl2FhMBoKfDBc+msJUGBdniwhJnLJ/9wJ33XWAIze8iG2LEDFEmxgTD4jHfdL4IiaNMfGIPFklm6whowFBlqEzQx5nGGNcFqyVgxFEQaShFRLsCIhaXVTUYqTmOBvs4rMPX+Lxp4dE3a6z1VKDLmzDCJamz4p1vsJaNxFKsWXbLh752pP0B31uufkmHnrwyxw6tIcoerzcYTTKtbqEw1WBBW1a6/QzZkWIWprbbrmB9fU1BoMhF86fJzeaQwcPIRKQZAYwZdQh4lZ6kaE2oiFbRR7jacaBpZyfeftr6C6kXH7601x+8hwqVIjRZLEhB2hFELVQgSbQHaL5vaj2NjAJOkuR4RA7HJFNhiRJ4lFMoT+0rA0yhoklViHzS4vs29Li5f/gKm6/7Sjvefdfcjw5TKDF4UpFqRG3WKQgEBS7GR+aFs6anE63y5kT5zlx/HmOXnedM71YFuZ7TCYpWmvqSE/BNlH1esBmP9Zvh8xaunMR+/fu4MyZiyRJzOWVy3Q7C/QWlshSj/P4EEusRRkqJywWpSBNDePxGGNy74QVadDjwGLCZz/4H9h1YCdX3/5aot4eWr0WqtXB2IA0yUkmQ+LxKiadYpIhTCaY6Zh8MsJME+w0Jk9TbB5gTAfElVNpG7Zsb7EjbDG/1KNz9dUMW3P8zn/8IOsnV0nbe8nIWZ0maBRBqMmtEAaKuU5QJoRFEaeBrkoBUwekRjhz6hS33nYz7U6H8XBAr9tjNIzRgfY5iGnWxn2KHF6pjllaImvpdjt0uh1OnTpFnmVMRiNanS5hGJLmaVkpK2JpJarcshqYTBJaUc7dr3kR111/LVqnnDv7LI99+St86ZsJSzdMufveaxmgiVdPMb6ckhhFbjpA4Fyt5KASMFPI+gSTKQxj8kmCmSZkScYkyxmnGUmWM40zxokht4oobNPrTdi+MmH/HS/m4FX76D/2HI+kO+nuz3jDK7bwsuu30tKGS8sJD36rz9efTYgCTRDQgCusrZxyEabmYlm5fJleu8vc3BxJEm+k5dRAiTLjr0/ABmqI3zeuku9WQxLHpGlGEifoYB5jLWmWO1yjltCUCRAQT6bs3T3PT//U29mxOOXyycdpRXDrd+/j7tuOsuWXPsWFfpfJ+hP0Dr+Mrft2EkR9gugAim7NhubAKnAepsuwvA4rQxhOsJOYLEnJ0pRJlpLmKWmcMUmdk+8sbGFh6wLRDTcyDraSfO0LTOeWCNM27/4ewyteuYOTjz3L2uUhd+zoce+btvEX3wz5zfv7GKNLvF/KcLbKEZI0J8sNyWSEwhBFLRf1NWAIQUoOSZGEOUcTlpWdeoVJpCwcN2BUwJiczLjYIDMGlTsTU0ADbiINAFlqaLcV7/qf30L/yU/zsd98H61IMTAdtu3Yyt1v/0He+qO38zvv+SBq7i0s7NrnvjDvIzZzJcwSR8/QaoTkQ+xwjBqnyGhKPklIJglpkmDSjCQ1JLkhzjLizKB0QFcpui3Fln3b2TG/RGd7zh8ur3PP7oij8wf4/d/4CA89eoHh0LDQzvnuu1/Em99wG4NkGx+4f4VOhzLHKKAQY3JX65iMEauQPMPmWVl9r0X9rsawCYNPKVVzwkXRYEMKLWWxQ6gAtFwMSZJuKO8VpkdpRb8/4B3/+LswK4/xgX/1c2zbfpAn2i/iYraV9MKUs7/7CO/8uXt46+sOYE9+HXvdMoTbUR77USoA5W+hKKIrTaAUysZMgzYxMVFgCUIQo9GBJRBNYAO0sSXhTGuN6BbZhYscO77G/v6YH/rZe3ngdMwfP7mNQXgIvQN2p+f56889xaFDB/ieW/by+SfnOHZmSKcVNgIKQciNZTKJXX1BAda+AEmlaWWKCdHSoONegepROYQy80zznDhJybOMLMv9IyPNcvLcMI0z5rptXnbbLh782IfY2tvJNzrfwXFzFUQ9wqWdfPzJLk+dTOnd9d3ovbsw6cDH4gmicreTlAFlUZIhKkZsgolTpuEe2tfeim4FDEYxWWYxWY7NU8QYxOSUFWulUSGo1iL5yDBvxrzx791BsmUbH3005FK6m7AzhwQdTnSuZSXaw8rZc3S6cOuhDmnqfJvxcEaeO0bgdDIlzw3K03oURYlSNwhPL8TGC5vFF7UpTbBgz4kIyoEjZKllOIppRR1fpaJMXLTANE45fHCRjl4nH64w3n8Tp1cXmAtiTC5opUmShIuXDdfu24bo7WiVoUSDTUByLJEroovFSo61Cm23EWzdR7Q15bmHPkdnrc+evTsYTS1CQJCkBNkUnVmmK+soSVw4GQUQzmGMZsfuLnF3nrPjkJMXY1qBJs9DEKGlhGPsxWgH7O3ZqkEJJje1yA6MsYxGY58kOFjB2LxkGc5yo+qrvpEJU6OBCJsQVz18WmLcYlDiit+D0YjFhXnvgKtUPkATxxmttgYzYqnbYtDaTpZmtNruYtYGA376n97Fd7/h1Tz5Z7/Mof2XEJu7sqGNnc2njbEdbHwMbdeIpznpcMr6+dM8/8ST6NTQCTscP3aZHdsX2bJ1ns7cPHO9NsPWNjCnMMvH0VqjgxBUhChB2YyzZy6z66qE//ije/jXf7rG2jAnCDWIIbEheaeDshaF80VlQd/HNkmSkqaZX/2ga0QyhAbTRF6AZR1KgzNROduqRFkSBlxIJYZAcpRSDIcj4u0p9UzDYfqa2Ob0B1OsgcWleYyAzQ02dMCMNZCsr7D28Ic49cjnWXks4DVHR8hCBMagSFFkKAKCSHP6ocdYXR0jcxEta7jlpTeyc76D7Y9YPnmJ48+vcer5S4yThFtecj29rXOeHaF8mdEx+Wz/Ap984ByXgKvir7J49CjG5BhrcWi4wlqIWhoxGWsjS57k2K4u6wVKKybjyYyzldJPblZ+vxLVPtRWY5V4O0sJylVbRpWzUA/BtNaMRyNGkwntVrtE/Ky1LmQUw7mLfYZjy64jV9F+/LKDqXNnLVutFr//58/y0OfOcnllB7cuDviuNAUirNUgQ5TuAgadZ+TGctPr3kBnoQ3TU3BxmbXhPKMLF9iz2GXhaIsszRjnOa09exhO0iq606DCyKWXgxUeOWt40C4yd2FM/PBFJrJAEPrQUiDSKVvn2mSJ4exKRpbnGBticx+PJRlJkniirVtwbghtyUeq6Iyb9RZYTwBQhKI8n6UsxUpps+ocR6k5GTxVMM8Na2t9tm/f1mCOFevg3OUxzz6/wu27trN//gJ5rsiMwlgFymJ1yNcHR5jkMa+5AfJ4TEQLsREqn0IrRYi849cYM0bsFNPvY2KhNb+T1YtfpLd1AbKMLLcYBViH+Tt8yLHzCENAMRr2Wdi7Bzu9msumjSYnwGBzhVaG2Giu6RkO7uyxPLZ861wCWP95zsFOk2nTxhfVLisNmkxBQ6wz7twk1Dij1td7lVJ15g8lmENlWhQWbEoUaMf8VzAYjhiNJ6RZTpKmpPVIaJrwla+dJ+otce2BNh0dM01y0rx4TU5LxQSSMUoD8jwFApS0IJuASlBkYAVlDTafotDYPCDrHSSUEdlkysXVEboVIaEi99izteIKLUo7JxyGgGE4GmPaW8lzgzYxyuS+CGNQIkwnCa++sUNvaZFnzuQcPzcmDCD3deM0T0mztNZmRIM0UHgJqZdWVY3kW9a9VcU3FBwNT8/S5zwVEXGVHMe7zAkCjYhCW0FZGA/G5EmKSQ0mNeRJTpaktLTiC18+w/LYcPTobq7fkzKcZJDn2CwnzwxpZshyYWVkSeMJkLgtnScgCUICuSHCkozGXHj6DEwj2pNVsvMnWVxcYmFpkeU05MlzI+LU8U2NGIx1AxUgqKANZExHEyZEJLlbY6ZWb0hyWGpNuOfVh1lez/jyt8asr0/RyhVkrAhJkngzq2tAQwU6qhro0EAVZhKwkgKzIWRSylWg/EeVhRox3nYJWjfDqTzPGY0nJGla7oI4zdFaOH5qyP0PnGPftfv43ju3EpgJWe6KGnluyLMcawwrA0syHiNMUISQZIhNQE0dUTi3dFqG+YWMi88+gSyfg/6QbtRiNE14+tkT7I4M3SgArbFpRpYliApdP0IYASmjccLYtMkzV7a0xtEcFZbV/pi3fucO9uzq8vVjq/z10zEt7a7TWENmMrI883G+eKY4ZbNGQSqQMnt3XCR9hSy4iJ4arHpb0sirwVc+Ay7oKUqrRqglIqQmZ5rGJFlampg4zQgj4Tf/9BmOHVvhtd91A9/74jaX+xMULp3PcwPWsDJIiYcTlBm5UDRJIUtQaooQoxUk/RHziz22XH2YvLcdEYO1hqnAdVftYlu3Ta4iAoTpeIiNE0QH7g6jALIRk1HCKI0wuTM7uXFk4/Wx4SUHLD967/Uce/Ycn3g04fKlIYEWz9izZFlaRTNayhC00bBhbZMl/AJZroig7UybimpEQNRYCtpBtojj92yo4ktZMzW+2J5lbhecXTP88u9+E9D82NtexIsPZKz0ExCDzXKsGC6PMwb9BNIhogJIDSQpSuUIhlYrZLLehzimPbfEcH3Iw0+e5fj5NQIVEnS7TOIpujNHkqQMB2Mkzcp700GATIaMhynDTDBiPT3eMM2EBT3mPT9xK8Pl83z6kXW+9HhMOxIyT/jNc0cQ0KogFc8OrHjTVKz7TZgRm+QC+ttqaNOqogcW5FPPjpZasaVJfHLPZ7mh14bPfCPm9/7gEQ4emOfdP3UrBxdG9MeZgwsEBhPL6loC6TpaKSRNkDRGmYwMQ2+ux/TiKuTCmXMDnnn8ODcfWOLq7XOcfH6ZS/0Ui8bOdZms9+kPBlVDBBodKLLBKqsjQz8N/aISMttCpn1+6SeOsKObc/9XnudPHk5AUr/DpGRRuNWsPP+92adTkcTKeKcM51+weW+zRjqZAeUKiEEQv8UqEyQ1lkGDMFX7HLFCu615/6fW+OP/+gi33XyQ9/38S9nfHbM2toSBYjJNubA2hbTv4vU4RU1S1DQmjBQmgHauuXjsNDvzy9x5aJFIK6Io4MY9HbqDZfphl7m5FhcurTCZTBFfmhSlUUFAvLrO+sgwSQJCBYkNyCbr/OKPHeKmq5e4/4Gn+OBDzhzpwIXLZVgtrs5Ra42YadyjTPzK0uZm4ObsBGzWvDzbqkltRedU9Uwtjj9kRDmClVUlObUoR+oqJsPogF/80xV+/7c/x8tuvYpf+bev4oYdY9aHMblYzi0n2PEQsTmSChIn2MmUFooYw+L8PCunLsNoSG4zxnFKnBgkSzCRpnNwDyoe8ezJ84TKDaDFhaHKGiYXV1keWxKrmRpFKxvwyz95NXfesIW/vP9xPvCg5cwqdEIQI1VTeektr4xXlvyheu/Ut7sDqJFJN3hrqmTCosltVd2xm/RWiahGP4HUapyhFjJC3vfRIb/6K5/k5sOL/B/vez3fdSRjdZBy4nJCOh6glCZLM+x4CpMEOxyzbesS68MhexaXOHP2IhdX18nzjDSLuWQ1rSNHuWrXFj77wOM4ooPGeCqJAZgkDM5dZnkCl6aKA50hv/Guo9y4v8WHP/lNfvdB4cyKZi7ylJYCUnCc+Ka5r9E2y9sztgxp/67GbylyFRG3A9QVnG8d7HBUQrfajdT/UHxg4QcoL8IVdiqWsBUIlUWCDr92f8K73/MJtkSW//y+e3nHXZonj6+Qri2jtMVkGflwDIMJDCaE04Sd2xY4ffocW3tLhFoxHA+IF+e5+vZb2b99iY/8yZcYro2IwoA0F4zVfhdA2p8wOHua55Y1L5pf57ffdZRelPF/feybfPChkIsDTbtlGw3nqgHFSyPzLf9e/Dk3jgHSKGC9kN6FQgWOo+Qa4WaELRqhkhQDa8CCcakOuiJu+NjXuuYJcURaGkCVlPcRiqXd6fBfH+3wc//mUwz6Q/7Ne76P198onHvqGUjXyTOIB1Nsf4IMJmTrY1qi2LFlG48/c4r1geHAgau49tB+Lh4/y+/9zicZrq/Tm+syTYXMQGbAGMgySIZrnDmzzC7p82v/0/Ws9gf83p9/i488Ns84jmiHymFQhblRNVp7QU9VNDttqPnlIjKqTVbRwSPqCtxbl/E0e5k2VQLxSYa1jo4hvk1PGn2+tdeLr3mqSgNBVNVHaT1tZaEbcv/Jecx7P8t/+sV7uPfel9A58wicOokYYTSYgEDUDh16GsdYhH27d/OtU2c5fn6ZcWy5sDxi59ICOuoyyTJHDECjPYcnySyj5WW2rF/gZ+95CcM040OfPcsnjy2hVUAYOVpj2f5a9KNbAetxMO2aCguWx2wZNxdnguosRHmhypi30kXnmG8BVRtS5To8LeJIV1B1UIrdyAJu7qCqTb+iajtAylpYmgu5/xnNn//lMyzt3kkSCNPTzzIdTuj3h6ytD+mvTxgMpozHLpNN0oz9O7fTa3WZiwKOHNhJEIWkcUaWWdJcyDNDlhsyYxknGeefOsbVW9tsu3Y/Dz65zOdP9lAqQGvPKW2MWG0hSmWKRIoaSVMVQOGYgXme19QBVJUTCJv7VqGiJqoXchw++XDsTuUFLGSGcOR6r8TWGj3sxs7xYsu6iVKIEZJU8YmvTvmhtxzkzNkxo+QZLto9TGIhzXK6nTZKhVhjiJOEaZIRxxnWKLQKmUwz0jRnmqVMczdQAQqVWaYpqOUVnnvkGNfs2MHeuS6Pr/Q4sz5i96KUsHCxHKUg8c+EmFhvhmj2HVeEM4s1eTX4juXLhkbTmZ9QbdK9vVnzeEF4tWhXiBdT5geOOdacxXojX4GqiszoSVgg1LzpriUOX7WDoLfEyePrPPhVy54jhqDbYzGeY66bEYWRA8zSlEmSkKaGJMmJU8M0N8RJxjQzJDkYpYgIQFv644STxy7yla8NeMvrdnHT1gV6cp7XXG05MewwjfNGo3g1soXWhS7bVBxBgDIPcmEmvhzpuEJqQ41dXlBDIixX5RXCpUYHvGgf66qSyGpFvOTKleydo4orVdsV4hrhkiznqr2L/MH7fxgbzPHoJ/+YVdXjQ+u7eHvYJl8+Q5xaeklEKwrRAnnq+D5x6rCmJLNMc0OSGuLckBuNCTShVRgVsDIY0u+PuLjlFlYmK1w4foafesNOtnT28GN/NOSRJ1bozUU1GKEpRlU20+lqxxcOtGCLFBR6RVWMn3W8myl4AYTGWXQCpf2H1FrcSgkD28iGiw8IRKE9h9Q18OkNXyKFvICVWn7grrjdijh9Zo3/8uuf4PDihEcf+Fu+fnGeb13ucny0leuWRpw5v8727fOEYYBGYdKMOM2Ik5hxmhOnjqGRGU0ijpGkgpCWEcaxIUvG2Pl9nEo7fPJEyvAvH2Pb/h1cNIs8e9rQbmnvx+wmvfdNLL+iKqqqr0CqkNNqF2sXvGq+DSWYsGjlFBGPdlZ6Bk1Mm9JRFzJMZbOz9i37Xj+h+N11iFcyA7PwhsJgtOI//N6TbO9OydROBqbDfFf4k4fW+Nl7DtDujTl7aZ2F+TnEWpJpzGSaEE9jxqmvJ4giVwGoEIKAMIJxKmBi9h04xKefnUdLxhPjXZw6NiZ7ckrfBrTbbQJV1XOr7sZqIrSnnJQOuDGYTUTU6WPUoQpdip9UGEatOONMkK611RcFBV3sqUb/cF2FRFShIlKZqEaHZW2yZh1bOVkIgRLChQXWzDwKSytwWNM4tXzggRE/9bojjJOnWF4dEQSaYX9AMp5g04w4yxmmkEmADTWEbVqdiMC4z7j22v08dLrH+bWUXjvACoxZRDpLzCmDMlIxNwtbL/UuHWrPXcmc+JhfacIwaujoVYw4X0+pg5pqM2EPCRAbOFwHBWL8CwI/SbWO8lpfbVOsaabL0qqmQfQEAEoqk8ZYS+AdnMGZwvl2wNlVy289MGHf4WuZ67bpD6dM44ytpNy+JeOmecMOyemZhDBJSacJw0lGbjKOHrmKR89t46kzeTn4eKpvIL6foT6o2pbZvNIWpTcuqA0E5tI6KNABQRTW/IMuEwsRqVVedKNW3JgAJZVzdV8QeHWrQjFKEXgdhFmounLYdsbu1c1O0ec1W7Cm1ons3mOMYaGrOXbJ8v4HYnZefTX7di2Q54YbdsAPv6bL2+7sctOC5VV7havnDcNJzEJbc8N11/G3Z+Z59PmU3lwx+IUKjKopr1QEApFZO602cKTqEgPNLeGVWLSu/IWuzExppnzCqnymrZSaoaerQrNHvGtWiLKbBjhS6zKv1z5FuWipfE5VlJZKrE81qnB1MYuS4KQURixLc4pTK/D+z2f80Cuu4SVBxiu3X2SuYzk9ylibWG7cEnDNkmItmmfh2hv47PEuz6/kLHRD6thYIUBVXZc0lB9L7EdeOILZtLKlFUEQNErASilUXRev1iOmqqK8pXhYZf3MaQymBq3aKvujdqG1puOyv0x0c8uKri6g9rt25ROC0iRJY7UVD2MVvY7m8kjx/s8nnFHXMO3t4AtPh/zFEyFjabM6DRnoBdhxE59+eo5zq8JCO6SZpPsdTdVPrJSqbcIiWrCb4s0FyruBXlgmZgFahxUtRTbTTZylPGjCunenIaSnShyolAoqU+zahahvQ/Su1JlgQzZcJGp1RHVDt45AK9IYgfd/acLL/vef4tXv6HFkrc8Dv/XHXHXH9dz/ZMzH/tsKC4uKTsuH1BtW7mbymHW5Gb+AVLGYCqzf8YGKKK/Re127B00z4GkIutVJbjUzrQvlkGZpfka2yyFRnkYRNLR2mhPYjP9niz0F36jEhrzkl1gFTZewUYZPKfJcuG7/Fq7aoYm6XZaSs1y7JeHGQ4sc3LtAr20JPKtjIwtBrpCVVj27UtNMrUdBzozYTYsrWipYWiuhoXQibDrh9XxZazzhCvsCZTOFLi/MlnlAsUM2rDJlr4gFOjUZx3QrxJkK7U0tvtWvIXWpPfwBaZrxn//9P+HO23ejsw6ZabNt7z4e+atH+JE3Xsc733Yr/fXRTDyuQJlaYFFk9Q5aKSZHpKZpKFXkVhTf1SZbXUnBAioWXFB2ClXNLmyiZeHEqUQUYUOK0RqP83jcQ+oSiN76+9UgM/um6Xx06VxFZIPMpKoVskuHWERzNR2fihLpBiKMQk48+iCnP/IFVtdGLA8MDz9ziQvDjLvPfpiV8ABRu1UzlzNFrFodW5cyzbYMyDYDzkpsbUZGp6EiVnKCbK3B+9sTzwydSq5PG0qcQ1OphlYKsUXCYryOtLKu4O7Sybrq+iYDMHM5VWcOtRWoXPGnpjJedOhYIAgC3vvbD/Ovf+gGXvWKOfJBn/3drzLdsodPfq3PoysDut25ksffiNNnmB5VaEpDImdjsugXgZoRC6wpJhZ9xKgqHP92xI2VUoRaCl6/T50RRLlExAnziY/fdakm5b5MY7WPImr2vnR8hc0VVfVJiXHvk5pmgt9pStQGzaICnbR+8luR4vJIOPydb+KW73gZXP4CybmT3PzmN7L8387zxfc/wq5drrG8uQCqQkpzD26yS2pYl3O81c5Rig33KNq16BqxhS5zrU4QeJjHbtod40T7apFBYekLSZdKKLGCGoIgcBWnpqxWk8hFFdc3IhGly4ijIdgqNAQtNuoVOZMRJzlHD23j1pt2Ye0E0jFxZulfOMedt+0hCgyCronObqQC1gHCjVXAeqmxYIkHjcHfALX7HZbntuYLaDjaTc2hV0xxI64qh6O8RgRWoTwbDi+MIeKb3WztwjdLUEqL1Gx58uoFVRIslWz+lZK94jWB1kzGU17/mpvobrkeo3aioy5bFiLS82e489o2V+1uk6RNm95c1UXEs1FCsh61KWkGGHWR3Q0T5s1bIS7S7K2TKzTpVUmvrjdTNr5wE6ep1GxGKZtGByi74ctLuQKfeMlsuDur1DUTwqa5ZdtiwI/8wKsRcpRaxqoh++ZSOP44Cxef495X72YyHDaiIGboZQ1aoGbTaxCv6qLQ/jU1P1Jenx9F//c8szMVQJ9TFOU0rHO3ZX+AUxyewU+rYFxpSj/ATNmxwjZUQ92wmXXqJivCX0CVDHkgT+lSzWozYVNwwrD99Zh/8cN3cs21YCafRNtvQChsWVQs5uuceuhB3nLnVo7uzBhNLYGu5zdV8qgUm6/6DadTNLGfugBfkzfr3pvVdoB49cRyIPEPUbXmF0Ut69jIdXTfYRsrw/qiig5UM6eYAavqvTlSnkPQdHAVFX6j+bE1qFdruLgy5Ee/7wj/7PtvIT/7DfRoglKvgu4N6C1zdDod+pcuk188xc98/z4W1CrTFI/lq5pNLhziZpRB1aAcNmEKf39WmmLK4s01CuPVXzYgBFLsBO2PwmgOnVZWoSzoIt7XzkQYEYfW+AMcjM3LInNdBXYz9EAw5cOlUZ6iWN+aVpd4hK5tMiMOolZBQJ4HrKxN+fH7buS9P/kK8njdbcgtrwX2IMF+6G0h6HRZ6EYsnz7LTTta/Nyb97KjPWI8sQ6jUfXVrjf0aTXNXpWpOoupSyisbqJUDb9SXgXGeCqObZKENq0Fl1XE6hCGWjMeG4o4rk/WWtcVHgRl9HIlm30lVtjmzpZKcsxHA6vrU6Iw573vvJN/+2N3kmdjV/DacxvSuskptIdL0OnQ6rbY2oItOiHtr3DnNYv8/H17uP1gxng8YZpu1CCtm5DNIIPqvuzGvvUSI1MlgqtUEf87ZfWyfqI2HlJR1AxcGKpVJetVZp4KLc0TlNbXB1hrCMOQdquNIrlismHtRrmDkv4yo/vvVpRuYC2BVrzte47yT+67mZuPbmE0HNFqh9jAki2fhsFHkWAekguY2GLmd2PtlMWFkCQMGfXX2LPQ45/de5CHTkz4/NcnnF0zpfxmo7JXRHJlELDJkpnl37iUEa1sSehqtZpKkfX6t5R66xtR1JDai4vCuhIwqthebrWvrFxGK02n0yEK3PwZBVEhA1mVphtfZJjtJJFNE6Aix1i+sMI73vYGfvnfv4W8f54knrLYW0SYYqYD8sEyMnmKvD9gtDZgfX3KaNQiTgPCMCLPIYkN8z3DVdft440/chvX/9GXec9vPkZKm6h+LYWArAi6OCVKav0QDTilaXLLhjwv6LRjxy6y3JBmaYOiX1XcTE0QNyhD+HDDATZeY1N7GCDUmtxYBqMJO7YusLi4SBRpAu2Uo1yrdy2NL4+pap4h08QBPRXQgzxxYgi0YnU04nWvuoVf+Nm7mVx4jlAMnbCFhB3QGq1yCMF22gTtHrlu0bOrZLmQ5FOn3ttqoRfaSBhx4dIarecv8KYffAWTNOMXf+8psrxd5i5BqD1lxjtYPYNiFtWPcnfohpa2Vk4hMoiE/Qf2Ov2M6RStddlJuYn9agBnDfn6ynY7bMJhFQHxNGW9P2Ln1nl27NjB0tIS6vQKFBz6uhpskXxtkjmqmk/ROsDkGVorrt6/gyh0Zu4lt+xnMRrSf/whOiZDtSNUu4tqBUieYMdjzHDCqL/GifNDTl7sszZyall52SakUGGAQXF+eZ07Xns7+WSNbb2QTFpEEeQGVvsJUTTTC+1p3KoWflcD6dExVYkbWjHMdyP279vDZDplOp0gBIynaSMfKYVki9pBscBnO2NKT6/dG4JAM5lMWF0bku7fyeLiEnv37ePRbz6Dlczx8KUm1SsFkbWQrbxCSU8gSQ3vfPvf4xW3X8vZcxfIMqe/8Ot/+BTWLGJzJ7yamwRjMkyakiUpaWJIsi6TVJOlXfLcNfuluVNsMbkTh82NgecuIp/+S4zV7NrWpt2J2LNnF4cPH+KTn/0Gx04u025HFQxtqhM4NkZ4nnxraiZdGbYt9Th49VUcO3GKPDMMhglxnBJFQVNHui6KwswRJrMRQqHqJFhSYzlzfp0br5kyNzfH/v1XsX3rEpf6Q1qyFa1teUVKVcX3SkNIGjsv0Ir+eMJrvuMWXnvXDTz97EkuLV8myw1hGGDF5Qc2dz1meZ6TZYYss+SpYDJDllvXdZ+HZdursRpLm1wMWZaSpDlJlpKnhdqKJYqcT1tc6PHau67h/KU+aWbc8So1euKVuLJKVYf6WIF2kHPTTYfZs2cff/pnf4G1hvMXB66EWUIw0vjsBhr6QodfFmFYt93mmefO8sqXXstSu8WB/Qe5/SUv5uOf+gI23UXU7RY6tc2prqGIqva74Lbu0uIcJ06e4Mmnn+HSpYt02l063Q4mF7IsJ44T4nhCkk5IkqR6pKkLi43xZwk0oWRjDEmckGYJxqRYQy2i02hywhBuuv5aevNt4tUhAUGNEc0V+ZzFn3QQEE/GHN6zwBu/93u4fPkyDz30IEHUZW1sXbIqtgSmtXJlr9kWAP13INaIaNrtFs+fucDpi33W19fZtWsn1994Pdcd2ceof6YUitIF/CCOEVYQeVWd4uGdVyAKkzmtz7IGrRXWBK6B26QYm2JsjjGCMbWKkrWlwgk1KKHx8KcfaR2gwxAdhoRRiyDwRzFq7c4fsHmF6SjNFRtHVUXGDYKA3OSEMuEt3/8GbrrxRj7xyc9w7vw55hb2MZ26HVWHG+qLu94Uo19IVqWiXhs67TZ/9cDXCcIWFy+e44brb+Cul7+crQuKyeCiH8iNB7KVAVvRT6B9V7mCKAqJwplSpzJoLSUUUqheVfCBbILfz+h+lVW4UmcNxPjBLgIHSxTqGmalPau8ql8Us1kceaK0QocBohSDlWV++p++lR/4gTfzxBNP8tGPfoTtO/eSsoh4OR9mCvhSND9WfDpfyH+BY14Lu93ttjn5/HkeffIso9GILMu58+Uv5zvuehm91pTx2hkgIAxDtF9lut7gUQo6OVFUHWguXB5w4vwK48mUOHac/yRNyTJDnplSzsDkuT9bxmK8ynmZPVtVPpzcvTNxRgWIikBHoAuxpggJ2mQSkWSKcxdHxEnuVSEr0q3S2p16pDRKBxAEKB3QbncxVrG2fI5f+F9/jB//ibezfHmNX/vVX2UynrB11/UMJqkTfqIp/VPX5CuiIVEKdeTF90ldveMFCCYoDePhhH/+E/eRji/y0pfdSZpO+cQn/oqv/u3XuLw+ob2wh3Zvq9cOMv7IKN/miq0wFjRZnqOUyzUQ6/Sqla4JRzWPt5JaR/6G+mwp5l0cTFowu1XVWKHEVam0q+6Z3BGqdKEMpnRTN1UpgkCjw5DcCoPVVbYtBrznX72T+958LydPPs+//Jf/kvvv/xS33v5azq+FNMTQN8F/CgHB8m9HXnyfbHb036YToBz/24jln//4m7lw+mleetdd7N6xi/v/6nN87euPcur0BQbjHBVsIejOE0ahO8lIO2UQKc/3klIEsCj7Va1SVySnNNqFKoJ+TSm96MqU6vDNAnlpFN39sVMNmZ7yuD3lT3ly5w4kcUynZXj9a27np3/yH3Pd9dfzzW8+zi/8wrt54At/xa13fCdr00XSNCXQGjuTbKmZtL9hcdwE0BAR2pyW5x6BUqS5IQzhR9/6XayePc7Bw9fw8pe/jAsXz/PM08c4deYsp06fZ2V1yiTNyDJHfmk0LvuiTiERX5J85YVOKFXNwa6diFEKB9qK5iKe5ab9rmr4p1obaj3yKZqyg0ARRgHbl+a48/Ybue/e7+YlL76VOM35zKc/w3vf++84eeI4N932CvrJFuIkJgpCp3WqKsxrM8ZV46izugnajEk2uxpFhEBrUh8Gvv47bwWzgskS7rrrldxw/fVErYjBYMja6irj8ZhpkjKdJjW2mj/gwVjSLGUwGHD2zFmOHz/OufPnieMpJs9ru9JLqunAt8Bar+VsZ2DkGkyuXMgZBCHtVkS706HXm2euO0+73SaMIhSVrkWhgRGEAXPdHrt27uCqg/u56caj3PHSO5ibm+fhhx/mQx/6Yz7+8Y/TW1hg78Fb6MctTJ570nKd/ym1Do+KCszsmW1HXvz9Ig04VmY6RWQDcFZydQgYTcZcfXAnB7aHxMMVOnNtjhw5wtHrruPAgYMszi/QareJWi2iSPumBUfjyK0hy3LyzGmwxXFMlmelPJixBbpoywMfypMwaoPnXmOw1jt+qTk/X3XTWqNL8b5mslJxUTVaK8IwoN1uobVmOBzzzDNP88UvfpFHH/0acZKxZ/81BJ2djGMpYYWK5VKrIkpJoK0f6Nektxx58d+XWTq5Kg7zrAlVlExoLY3Kl1YQpymBwO6d82zpWUwyJo5HKKVpdTvMdbu0Wm1PjqVR1JHyvMgGDlZmjiJN7QmpnTtZHcDTJHo1uK1FIFygncUi1LU20tqh1NrTSMbTMf3BOv3VPqPRmCAI6S1sJYi2EOeazJoG17Xe1tokA89I19d5c1KcH+DhVy2mtKumYBBL/awWdxCD1I6cKpIhi+HYyRUkN3TaAb2WpRVCMByjA0MUBG4nRBGdTod2q+WdcwS61tpU2FCl0IQV1U/ZSlBKqB1jVae5s0GroWyXsjUHXewEMY2acO51jsbjCcPRiCROUCokai+SZnB5PQMuu8NLA+V3lu8lVkG5gxSBa2rRuUtElW72GtRmJXSnWzQOsq0o19KUMvPpru+QUZ4uAmINRiDUITZQxEnKeJSSZRNsFiM281lpZRakQehqNnyUnCKpb1hb66/SNS1pmWFsUHXx1JMxmqf30ahjNHErU9BulKYVtZ1Uf6tDSzmGtlUapdsE2k+AH/xKP0LVBl2XhebqWABd7vZQ1XsSaqW2sk4r2pNtVfWmYjtJxbFvBSGL83MsLsyhgEnsFBKd5G9xjoxFtJS7p0aeK82mrZmlsqBfHrpWMSqKQooVfx1S12rzy8kPiMw0RcgMy8P1NJga3FydKam1JQhdQ998t0urHTIaJ6wOpqRJWgqSqFmRDilgbcoMu1poVR4QzjBQPWm1TjxVNe6WKpnKgQ7QoaIbBWxb6rFv1xKLc236kwnDQUygW8z3uu5Ml4LmUjtcWeonFfkD20Sqg9NKv+ArTrmP5kuI2DOeRYKS21rvb1Cq1nZa43U2TtT2qxbfbGisV4ZUtQjMWnIjWNEYY+i2uuzftY00N5y7tM7a+phpnDhayixLXNcYHuV5l+Jkg/1YhAWeouqsMKQhu6JUUNqtUGt3oHErZKnXYv+uJQ7u3067FbK6PkSrgN5clzkcgGZqYtegq+M/bO1EiRolRBN4yFcQZcpT9QJPKVeCW/WemVBRHZVnYlTNFS6csA3AS2pSAsrTXqrko3i3w7W0hiDo0G4LYaiJgoAwCmm3A67av429u7fw/JllLlxapz9KiNPcn0tZ+ch666uq1Z2LkDQss8QrNNfX24V0oGmFIXOtFluWOhzYtcih/TuZm2uz1h+SGevCTGuIs5TEGCR3g2SsIMa1PlkM2NDh4WFQMqKd4xV02ODvubi/cP62wIH877bYQQrj1SxsjWpqFQS1cml53DmejqMLTQddNvEVx/hq7egrgRLakSaa66CDwEsSaPbv3kK3GxC1NMHFPoNhTBxnZFnmSGvIhrbdWS3RsEgUxFOCxN+E5xSjVQHrasIwpNOOWFrosm/XEocPbGNhqctoFDOeJEynOZNpwjSOSVODMZBL7g9VU259erJvFDiB7G6k0WisGIJAEShFoPEFktBPgJO2rI4npzzfMRMhz6vd5nYYWCfX6pFYx21Sqqh8WUQ50RHjT8lTM/R0FGgNioxAu9ovKkWFAUmumcQJC702u7duweYWyQ3Kul1oVYRk7tjEeoi9GcLQLEmqylUVLUVFyBaF2g1+r8PubV327Jhnfr5LlmYMRiMG4wmjyZTJJGUcp6SZm4DqyHLKuD0INLqtQUKUCgi0IhChFQhRS9EOlDtAR7l2QS2OKFw/VS83OXnujqvKM0tmLROD04oo0FEvs+YUHl2NuKKrC7kVh7hmpiQfUyu8FAK1gdYYEwCZk0EIA4atCb1ui1Y7YsfWRSaThDjxMpd56k5Y8n1lL9RnHM5We2Z58NrTRVpRxFy7xcJCm6WlORZ6c4gVxqOY4TBmOEkZT1Mm45RxlpHmmTc74k86lbIHIIoiTJhjsoBMB4j2tjhwZ691Q00rUEQhRDogVCFaGyeV7LWeM2NJUuu0IrQizl2SmCpFmkOG9TlD7b4Kv1E7Xh2vdlggr03YRVdSNL6sqIOUyVQz6cRMpjFzvRadVouti/P0F2NGcUySGXITNE5n3fjZbsz/b4YICBUfRARvAAAAAElFTkSuQmCC"};
  const icon49=n=>'<img class="mb-icon" alt="" draggable="false" src="'+ICONS49[n]+'">';
  const I18N = {
    ru: {
      title: 'ГРАВИ-БУМ!',
      subtitle: 'Башня четырех этажей',
      timeLabel: 'ВРЕМЯ',
      magicLabel: 'МАГИЯ',
      trapLabel: 'ЛОВУШКА',
      scoreLabel: 'ОЧКИ',
      comboLabel: 'КОМБО',
      btnShake: 'Тряхнуть',
      btnShake2: 'ТРЯХНУТЬ',
      btnCut: 'РЕЗАТЬ ТРОС',
      btnRestart: 'Заново',
      btnLang: 'RU',
      tiltL: '← наклон',
      tiltR: 'наклон →',
      legendRed: 'Красные шары: кластер у выхода площадки A — взорвите, чтобы открыть путь',
      legendBlue: 'Синие шары: приманки по краям воронки (путь не открывают)',
      legendYellow: 'Жёлтые шары: пробка в центре воронки — взорвите, чтобы провалиться',
      legendCore: 'Ядро щита (y = 0.5): разбейте шаром, иначе три тела отобьют его в ловушку',
      legendBtn: 'Красная кнопка на кронштейнах (y = −2.5) — цель спуска',
      legendStats: 'Шаров: {free} свободных / {mounted} примагничено / {charged} заряжено',
      hint: '<b>ЛКМ-тяга</b> — наклон стакана (вверх = от себя, вниз = к себе) · <b>клик или свайп по тросу</b> — разрезать (<span class="kbd">X</span>) · <b>ПКМ</b> — камера с инерцией · <b>колесо</b> — зум · <span class="kbd">Space</span> — встряска · <span class="kbd">R</span> — заново',
      statusRope: 'Трос цел: кликните по тросу или проведите поперёк него (либо нажмите X)',
      statusFallA: 'Этаж «Чаша»: заполняйте лунки шарами нужного цвета— запас рядом',
      statusFallB: 'Этаж «Труба»: толкните первый шар жёлоба, чтобы цепочка освободила красные',
      statusSocket: 'ЛУНКИ {a}/{b}: катите шары нужного цветав гнёзда с цифрами',
      statusCore: 'Шар ниже воронки: попадите в фиолетовое ядро щита, иначе три тела отобьют его',
      statusButton: 'Шар над кнопкой: держите его точно по центру',
      statusTrap: 'Шар в ловушке! Через {n} с — поражение',
      statusWin: 'ПОБЕДА: кнопка вдавлена',
      statusCharged: 'Магия заряжена: {n} шар(а), осталось {t} с — ищите третий того же цвета',
      menuTitle: 'ГРАВИ-БУМ!',
      menuSubtitle: 'БАШНЯ ЧЕТЫРЁХ ЭТАЖЕЙ · v' + VERSION + ' · 10 УРОВНЕЙ',
      menuS1: '<b>Разрежьте трос</b>: кликните по нему, проведите поперёк или нажмите <b>X</b> — белый шар сорвётся вниз.',
      menuS2: '<b>Наклоняйте стакан</b> (ЛКМ + движение: вверх — от себя, вниз — к себе) и <b>трясите</b> (Space), чтобы катить шар.',
      menuS3: '<b>Магия:</b> два шара одного цвета при касании заряжаются на 10 с; третий того же цвета — и все взрываются.',
      menuS4: '<b>Цель:</b> разбить ядро щита и упасть на красную кнопку. Сетка ловушки внизу — поражение.',
      menuStart: 'ИГРАТЬ',
      menuHelp: 'Справка',
      // v4.5: экраны «МАТ-БУМ! 3»
      menuPlay: 'ИГРАТЬ',
      menuTrain: 'ОБУЧЕНИЕ',
      menuHall: 'ЗАЛ СЛАВЫ',
      menuHelp2: 'СПРАВКА',
      ver: 'v' + VERSION,
      selTitle: 'Выбери уровень',
      selSub: 'Любой открытый уровень — в любом порядке',
      hallTitle: 'ЗАЛ СЛАВЫ',
      hallSub: 'Лучшие результаты по уровням',
      hallLevelT: 'УРОВНИ',
      hallYandexT: 'ОБЩИЕ РЕКОРДЫ',
      hallEmpty: 'Пока нет результатов — сыграйте первый уровень!',
      hallTotalLine: 'Всего звёзд: {s}/30 · Лучший счёт: {b}',
      hallYaNo: 'Общие рекорды пока недоступны. Ваши результаты сохраняются на устройстве.',
      helpScrTitle: 'СПРАВКА',
      helpScrSub: 'Башня четырёх этажей — как её пройти',
      helpFooter: 'Грави-Бум! v' + VERSION + ' Игорь Таланов 2026 г.',
      sideRecT: 'РЕКОРДЫ',
      sideProgT: 'ПРОГРЕСС',
      sideOpen: 'Открыто уровней: {n}/10',
      sideStars: 'Звёзды: {s}/30 · Челленджи: {c}',
      sideNoRec: 'Рекордов пока нет',
      tutTitle: 'ОБУЧЕНИЕ · ШАГ {n}/{m}',
      tut1: 'Разрежьте трос: клик по тросу, свайп поперёк или клавиша X',
      tut2: 'Наклоняйте стакан тягой ЛКМ (вверх — от себя) — шар покатится',
      tut3: 'Этаж 1 Чаша: заполните лунку шарами нужного цвета',
      tut4: 'Этаж 2 Труба: шары цвета мишени закати в мишень, другие — в боковой отвод',
      tut5: 'Этаж 3 Резонанс: ударьте в плиты с силой, близкой к их полосе',
      tut6: 'Этаж 4 Финал: докатите шар до бокового люка, разбейте ядро и попадите на кнопку',
      tutDone: 'Обучение пройдено! Дальше — «ЗАЛ СЛАВЫ» за звёздами.',
      btnAuto: 'АВТО',
      autoOn: 'АВТО: башня сама ведёт шары к решению этого этажа',
      autoOff: 'АВТО выключен — управление снова у вас',
      autoFloorDone: 'Этаж собран АВТО! Дальше — снова ваши руки',
      autoTimeout: 'АВТО не удалось довести этаж — попробуйте сами или ещё раз',
      autoBusy: 'АВТО доступен только во время игры',
      victoryTitle: 'ПОБЕДА!',
      victoryDesc: 'Шар вдавил кнопку на кронштейнах. Стакан пройден!',
      defeatTitle: 'ПОРАЖЕНИЕ',
      defeatDesc: 'Не получилось. Попробуй ещё разок!',
      statTime: 'Время',
      statMagic: 'Взрывов магии',
      statLost: 'Шаров в ловушке',
      statCuts: 'Разрезов троса',
      statScore: 'Очки',
      statPerfect: 'Идеальных срезов',
      statReason: 'Причина',
      victoryAgain: 'Играть снова',
      victoryMenu: 'В меню',
      nextLevel: 'Следующий уровень',
      newRecord: 'НОВЫЙ РЕКОРД!',
      defeatRetry: 'Начать заново',
      defeatMenu: 'В меню',
      pauseTitle: 'ПАУЗА',
      pauseDesc: 'Стакан замер. Продолжить спуск?',
      pauseResume: 'Продолжить',
      pauseRestart: 'Заново',
      pauseMenu: 'В меню',
      helpTitle: 'Как играть: «Грави-Бум! Вертикальный стакан»',
      toastCut: 'Трос разрезан!',
      toastCharge: 'Заряжено: ищите третий {c} шар ({t} с)',
      toastBoom: 'МАГИЯ! Взрыв: {n} шаров',
      toastExpired: 'Магия погасла — коснитесь снова',
      toastShake: 'Встряска!',
      toastCore: 'Ядро щита разбито! Путь к кнопке открыт',
      toastTrap: 'Игровой шар в ловушке…',
      toastReturned: 'Шар возвращён на трос',
      // v4.0: этажи
      floorNames: ['Этаж 1 Чаша', 'Этаж 2 Труба', 'Этаж 3 Резонанс', 'Этаж 4 Финал'],
      floorOf: '{name}',
      floorSolved: 'Загадка решена — люк открыт!',
      floorScore: 'Этаж пройден',
      floor0Hint: 'Заполните лунки: катите шары нужного цветав гнёзда с цифрами.',
      floor1Hint: 'Труба: толкните колонну белым шаром. Свои шары катятся в мишень, чужие уходят через цветную решётку в боковой отвод.',
      floor2Hint: 'Резонанс: ударьте каждую плиту сбоку с нужной скоростью — зелёная слабо, жёлтая средне, красная сильно. Чужие шары гасят активные плиты!',
      floor3Hint: 'Финал: докатите шар до бокового люка у стены, разбейте планеты и попадите на кнопку под ним!',
      taskSockets: 'ЛУНКИ {a}/{b}',
      taskChain: 'ЗМЕЙКА {a}/{b}',
      taskPlates: 'РЕЗОНАНС: ПЛИТЫ {a}/{b}',
      taskButton: 'ЦЕЛЬ: КНОПКА',
      taskChainPending: 'ЗМЕЙКА: СБЕЙТЕ ЦЕПОЧКУ',
      taskChainDone: 'ЗМЕЙКА ГОТОВА',
      socketFull: 'Лунка заполнена',
      socketWrong: 'Не тот цвет!',
      socketOverflow: 'Перебор — в лунке уже есть шар',
      socketPlayer: 'Игровой шар не входит в лунку',
      socketIn: '{n}/{b} — есть!',
      floorReset: 'Этаж сброшен — загадка заново',
      // v4.2: Труба / Резонанс
      pipeRoadDone: 'Дорога {r}: МИШЕНЬ ПОРАЖЕНА!',
      taskPipe: 'ТРУБА: МИШЕНИ {a}/{b}',
      plateOn: { weak: 'ЗЕЛЁНАЯ плита — АКТИВНА (полоса {v})', mid: 'ЖЁЛТАЯ плита — АКТИВНА (полоса {v})', strong: 'КРАСНАЯ плита — АКТИВНА (полоса {v})' },
      plateTooWeak: 'СЛАБО — нужна полоса {v}',
      plateTooStrong: 'СИЛЬНО — нужна полоса {v}',
      plateOff: 'Плита ПОГАШЕНА чужим шаром!',
      floorRestarted: 'Этаж начат заново',
      ffTitle: 'ЭТАЖ НЕ ПРОЙТИ',
      ffNoBalls: 'Недостаточно шаров для завершения уровня. Начать заново или перейти в меню?',
      ffPlate: 'Чужой шар погасил плиту — этаж придётся начинать заново',
      ffRestart: 'Начать заново',
      ffMenu: 'В меню',
      btnPipeReset: 'СБРОС ЭТАЖА',
      btnFloorRestart: 'ЭТАЖ ЗАНОВО',
      btnFloorsShow: 'ЭТАЖИ: ПОКАЗАТЬ',
      btnFloorsHide: 'ЭТАЖИ: СКРЫТЬ',
      totalBest: 'Рекорд: {n}',
      challengeLine: 'Челленджи: {n}/15',
      levelLocked: 'Сначала пройдите предыдущий уровень',
      advancedLevel: 'Продвинутый уровень',
      challengeDoneShort: 'Челлендж выполнен',
      challengeDone: 'ЧЕЛЛЕНДЖ ВЫПОЛНЕН: {n}',
      sandbox: 'Песочница',
      sandboxOn: 'ПЕСОЧНИЦА: все уровни открыты, результаты не записываются',
      sandboxOff: 'Обычный режим: уровни и рекорды как обычно',
      chainStall: 'Цепочка остановилась — на 2 с в исходное',
      chainSolved: 'Красные освобождены!',
      chainHit: 'ЗМЕЙКА: {a}/{b}',
      plateTooWeak: 'Слабо! Нужна скорость {v}',
      plateTooStrong: 'Сильно! Нужна скорость {v}',
      plateDone: 'Плита принята ({v} м/с)',
      plateStatus: 'ПЛИТЫ {a}/{b}',
      cascade: 'КАСКАД +{n}',
      toastRelease: 'Три тела освобождены',
      colorRed: 'красный',
      colorBlue: 'синий',
      colorYellow: 'жёлтый',
      reasonTrap: 'сетка ловушки',
      reasonMiss: 'мимо кнопки'
    },

    en: {
      title: 'GRAVI‑BOOM!',
      subtitle: 'Four‑story tower',
      timeLabel: 'TIME',
      magicLabel: 'MAGIC',
      trapLabel: 'TRAP',
      scoreLabel: 'SCORE',
      comboLabel: 'COMBO',
      btnShake: 'Shake',
      btnShake2: 'SHAKE',
      btnCut: 'CUT ROPE',
      btnRestart: 'Restart',
      btnLang: 'EN',
      tiltL: '← tilt',
      tiltR: 'tilt →',
      legendRed: 'Red balls: the cluster blocking platform A exit — blow them to open the way',
      legendBlue: 'Blue balls: decoys on the funnel edge (they do not open the way)',
      legendYellow: 'Yellow balls: the plug in the funnel centre — blow it to fall through',
      legendCore: 'Shield core (y = 0.5): break it with the ball, otherwise the three bodies deflect it into the trap',
      legendBtn: 'The red button on brackets (y = −2.5) is the goal',
      legendStats: 'Balls: {free} free / {mounted} magnetised / {charged} charged',
      hint: '<b>LMB drag</b> — tilt the glass (up = away from you, down = toward you) · <b>click or swipe the rope</b> — cut it (<span class="kbd">X</span>) · <b>RMB</b> — camera with inertia · <b>wheel</b> — zoom · <span class="kbd">Space</span> — shake · <span class="kbd">R</span> — restart',
      statusRope: 'The rope is intact: click it or swipe across (or press X)',
      statusFallA: 'Floor "Bowl": fill the sockets with balls of the matching colour — clips are nearby',
      statusFallB: 'Floor "Pipe": push the first trough ball so the chain frees the reds',
      statusSocket: 'SOCKETS {a}/{b}: roll matching balls into the numbered cups',
      statusCore: 'The ball is below the funnel: hit the purple shield core, otherwise the three bodies will deflect it',
      statusButton: 'The ball is above the button: keep it exactly centred',
      statusTrap: 'The ball is in the trap! Defeat in {n} s',
      statusWin: 'VICTORY: the button is pressed',
      statusCharged: 'Magic charged: {n} ball(s), {t} s left — find a third of the same colour',
      menuTitle: 'GRAVI-BOOM!',
      menuSubtitle: 'TOWER OF FOUR FLOORS · v' + VERSION + ' · 10 LEVELS',
      menuS1: '<b>Cut the rope</b>: click it, swipe across it or press <b>X</b> — the white ball will fall.',
      menuS2: '<b>Tilt the glass</b> (LMB + move: up = away from you, down = toward you) and <b>shake</b> it (Space) to roll the ball.',
      menuS3: '<b>Magic:</b> two same-colour balls touching charge for 10 s; a third one of that colour makes them all explode.',
      menuS4: '<b>Goal:</b> break the shield core and land on the red button. The trap net below means defeat.',
      menuStart: 'PLAY',
      menuHelp: 'Help',
      // v4.5: «МАТ-БУМ! 3» screens
      menuPlay: 'PLAY',
      menuTrain: 'TRAINING',
      menuHall: 'HALL OF FAME',
      menuHelp2: 'HELP',
      ver: 'v' + VERSION,
      selTitle: 'Choose a level',
      selSub: 'Any unlocked level — in any order',
      hallTitle: 'HALL OF FAME',
      hallSub: 'Best results per level',
      hallLevelT: 'LEVELS',
      hallYandexT: 'GLOBAL RECORDS',
      hallEmpty: 'No records yet — play the first level!',
      hallTotalLine: 'Total stars: {s}/30 · Best score: {b}',
      hallYaNo: 'Global records are currently unavailable. Your results are saved on this device.',
      helpScrTitle: 'HELP',
      helpScrSub: 'Tower of four floors — how to beat it',
      helpFooter: 'Gravi‑Boom! v' + VERSION + ' Igor Talanov 2026',
      sideRecT: 'RECORDS',
      sideProgT: 'PROGRESS',
      sideOpen: 'Levels unlocked: {n}/10',
      sideStars: 'Stars: {s}/30 · Challenges: {c}',
      sideNoRec: 'No records yet',
      tutTitle: 'TRAINING · STEP {n}/{m}',
      tut1: 'Cut the rope: click it, swipe across it, or press X',
      tut2: 'Tilt the glass with LMB drag (up = away) — the ball will roll',
      tut3: 'Floor 1 Bowl: fill the socket with balls of the matching color',
      tut4: 'Floor 2 Pipe: roll balls matching the target color into the target; send the others to the side outlet',
      tut5: 'Floor 3 Resonance: strike each plate with speed close to its band',
      tut6: 'Floor 4 Finale: roll to the side opening, break the core, then land on the button',
      tutDone: 'Training complete! Chase stars for the HALL OF FAME next.',
      btnAuto: 'AUTO',
      autoOn: 'AUTO: the tower herds the balls to solve this floor',
      autoOff: 'AUTO off — you have the controls again',
      autoFloorDone: 'Floor solved by AUTO! It is your hands again now',
      autoTimeout: 'AUTO could not finish the floor — try yourself or again',
      autoBusy: 'AUTO is available only during play',
      victoryTitle: 'VICTORY!',
      victoryDesc: 'The ball pressed the button on the brackets. The glass is complete!',
      defeatTitle: 'DEFEAT',
      defeatDesc: 'It didn\u2019t work out. Give it another try!',
      statTime: 'Time',
      statMagic: 'Magic blasts',
      statLost: 'Balls in trap',
      statCuts: 'Rope cuts',
      statScore: 'Score',
      statPerfect: 'Perfect cuts',
      statReason: 'Reason',
      victoryAgain: 'Play again',
      victoryMenu: 'Menu',
      nextLevel: 'Next level',
      newRecord: 'NEW RECORD!',
      defeatRetry: 'Start over',
      defeatMenu: 'Menu',
      pauseTitle: 'PAUSED',
      pauseDesc: 'The glass is frozen. Continue the descent?',
      pauseResume: 'Resume',
      pauseRestart: 'Restart',
      pauseMenu: 'Menu',
      helpTitle: 'How to play: Gravi-Boom! Vertical Glass',
      toastCut: 'Rope cut!',
      toastCharge: 'Charged: find a third {c} ball ({t} s)',
      toastBoom: 'MAGIC! Blast: {n} balls',
      toastExpired: 'The magic faded — touch again',
      toastShake: 'Shake!',
      toastCore: 'Shield core broken! The way to the button is open',
      toastTrap: 'The player ball is in the trap…',
      toastReturned: 'The ball returned to the rope',
      // v4.0: floors
      floorNames: ['Floor 1 Bowl', 'Floor 2 Pipe', 'Floor 3 Resonance', 'Floor 4 Finale'],
      floorOf: '{name}',
      floorSolved: 'Puzzle solved — hatch open!',
      floorScore: 'Floor cleared',
      floor0Hint: 'Fill the sockets: roll balls of the matching colour into the numbered cups. Knock the clips beside each socket.',
      floor1Hint: 'Pipe: push the column with the white ball. Matching balls reach the target; other colors fall through the side filter.',
      floor2Hint: 'Resonance: strike each plate from the side at the right speed — green weak, yellow medium, red strong. Foreign balls douse active plates!',
      floor3Hint: 'Finale: roll to the offset throat near the wall, break the planets and land on the button below!',
      taskSockets: 'SOCKETS {a}/{b}',
      taskChain: 'SNAKE {a}/{b}',
      taskPlates: 'RESONANCE: PLATES {a}/{b}',
      taskButton: 'GOAL: BUTTON',
      taskChainPending: 'SNAKE: TOPPLE THE CHAIN',
      taskChainDone: 'SNAKE DONE',
      socketFull: 'Socket full',
      socketWrong: 'Wrong colour!',
      socketOverflow: 'Overflow — the socket already has its ball',
      socketPlayer: 'The player ball does not fit',
      socketIn: '{n}/{b} — in!',
      floorReset: 'Floor reset — the puzzle anew',
      // v4.2: Pipe / Resonance
      pipeRoadDone: 'Road {r}: TARGET HIT!',
      taskPipe: 'PIPE: TARGETS {a}/{b}',
      plateOn: { weak: 'GREEN plate — ACTIVE (band {v})', mid: 'YELLOW plate — ACTIVE (band {v})', strong: 'RED plate — ACTIVE (band {v})' },
      plateTooWeak: 'TOO WEAK — band {v} needed',
      plateTooStrong: 'TOO STRONG — band {v} needed',
      plateOff: 'Plate DOUSED by a foreign ball!',
      floorRestarted: 'Floor restarted',
      ffTitle: 'FLOOR UNPASSABLE',
      ffNoBalls: 'Not enough balls to finish the level. Start over or go to the menu?',
      ffPlate: 'A foreign ball doused a plate — the floor must be restarted',
      ffRestart: 'Start over',
      ffMenu: 'To menu',
      btnPipeReset: 'RESET FLOOR',
      btnFloorRestart: 'RESTART FLOOR',
      btnFloorsShow: 'SHOW FLOORS',
      btnFloorsHide: 'HIDE FLOORS',
      totalBest: 'Best: {n}',
      challengeLine: 'Challenges: {n}/15',
      levelLocked: 'Complete the previous level first',
      advancedLevel: 'Advanced level',
      challengeDoneShort: 'Challenge done',
      challengeDone: 'CHALLENGE COMPLETE: {n}',
      sandbox: 'Sandbox',
      sandboxOn: 'SANDBOX: all levels open, results are not saved',
      sandboxOff: 'Normal mode: levels and records as usual',
      chainStall: 'The chain stalled — resetting for 2 s',
      chainSolved: 'Reds freed!',
      chainHit: 'SNAKE: {a}/{b}',
      plateTooWeak: 'Too weak! Speed {v} needed',
      plateTooStrong: 'Too strong! Speed {v} needed',
      plateDone: 'Plate accepted ({v} m/s)',
      plateStatus: 'PLATES {a}/{b}',
      cascade: 'CASCADE +{n}',
      toastRelease: 'The three bodies are free',
      colorRed: 'red',
      colorBlue: 'blue',
      colorYellow: 'yellow',
      reasonTrap: 'trap net',
      reasonMiss: 'missed the button'
    }
  };

  let curLang = 'ru';
  const D = () => I18N[curLang];

  // ===========================================================================
  // 4. ЗВУК (полностью синтезированный, без файлов)
  // ===========================================================================
  const Sound = {
    ctx: null,
    master: null,
    enabled: true,
    lastHit: 0,

    init() {
      if (this.ctx) return;
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.5;
        this.master.connect(this.ctx.destination);
      } catch (e) { this.ctx = null; }
    },

    setEnabled(on) {
      this.enabled = !!on;
      if (this.master) this.master.gain.value = on ? 0.5 : 0.0;
    },

    _now() { return this.ctx ? this.ctx.currentTime : 0; },

    _tone(freq, dur, type, vol, delay) {
      if (!this.ctx || !this.enabled) return;
      const t0 = this._now() + (delay || 0);
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq, t0);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(this.master);
      o.start(t0); o.stop(t0 + dur + 0.03);
    },

    _noise(dur, vol, filterFreq) {
      if (!this.ctx || !this.enabled) return;
      const n = Math.floor(this.ctx.sampleRate * dur);
      const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < n; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / n);
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const f = this.ctx.createBiquadFilter();
      f.type = 'bandpass';
      f.frequency.value = filterFreq || 900;
      const g = this.ctx.createGain();
      g.gain.value = vol;
      src.connect(f); f.connect(g); g.connect(this.master);
      src.start();
    },

    // Бильярдный клик
    hit(strength) {
      const now = performance.now();
      if (now - this.lastHit < 45) return;         // не чаще ~22 в секунду
      this.lastHit = now;
      const s = Math.max(0.05, Math.min(1, strength || 0.3));
      this._tone(520 + s * 900, 0.05 + s * 0.04, 'triangle', 0.05 + s * 0.16);
      this._noise(0.03, 0.03 + s * 0.06, 2200 + s * 2600);
    },

    roll(strength) {
      const s = Math.max(0, Math.min(1, strength || 0));
      if (s < 0.05) return;
      const now = performance.now();
      if (now - (this._lastRoll || 0) < 110) return;
      this._lastRoll = now;
      this._noise(0.09, 0.012 + s * 0.03, 420 + s * 500);
    },

    cut() {
      this._noise(0.22, 0.16, 3200);
      this._tone(1400, 0.12, 'sawtooth', 0.06);
      this._tone(700, 0.18, 'sine', 0.05, 0.05);
    },

    // Магия: заряд (короткий звон) и восходящее арпеджио C-E-G (+ нота за каждый сверх 3)
    charge() {
      this._tone(880, 0.14, 'sine', 0.07);
      this._tone(1320, 0.12, 'sine', 0.045, 0.04);
    },

    fade() {
      this._tone(420, 0.2, 'sine', 0.05);
      this._tone(300, 0.24, 'sine', 0.04, 0.06);
    },

    boom(extra, echo) {
      const up = echo ? 2 : 1, gv = echo ? 0.55 : 1;   // v4.0: эхо — октавой выше, приглушённо
      const base = [261.63, 329.63, 392.0];        // C E G
      const extraNotes = [523.25, 659.25, 783.99, 1046.5];
      const n = Math.max(0, Math.min(4, extra || 0));
      for (let i = 0; i < base.length; i++) this._tone(base[i] * up, 0.34, 'triangle', 0.16 * gv, i * 0.055);
      for (let i = 0; i < n; i++) this._tone(extraNotes[i] * up, 0.36, 'triangle', 0.14 * gv, (base.length + i) * 0.055);
      this._noise(0.3, 0.1 * gv, echo ? 1400 : 700);
      this._tone(90 * up, 0.4, 'sine', 0.16 * gv);
    },

    // v4.0: звуки этажей
    floorDone() {
      [392.0, 493.88, 587.33, 783.99].forEach((f, i) => this._tone(f, 0.3, 'triangle', 0.14, i * 0.07));
      this._noise(0.25, 0.08, 900);
    },
    socketIn() { this._tone(740, 0.16, 'sine', 0.14); this._tone(1108.7, 0.2, 'sine', 0.1, 0.06); },
    reject() { this._tone(196, 0.18, 'square', 0.07); this._tone(174.6, 0.2, 'square', 0.06, 0.09); },
    plateOk() { this._tone(880, 0.22, 'sine', 0.15); this._tone(1318.5, 0.3, 'sine', 0.11, 0.08); },
    plateBad() { this._tone(233, 0.16, 'triangle', 0.1); this._noise(0.14, 0.06, 500); },
    chainFail() { this._tone(147, 0.4, 'sawtooth', 0.1); this._tone(110, 0.5, 'sine', 0.12, 0.12); },

    shake() {
      this._noise(0.3, 0.12, 260);
      this._tone(120, 0.18, 'square', 0.05);
      for (let i = 0; i < 4; i++) this._tone(300 + Math.random() * 500, 0.05, 'triangle', 0.05, 0.04 * i);
    },

    fall() {
      this._tone(600, 0.25, 'sine', 0.06);
      this._tone(300, 0.3, 'sine', 0.05, 0.08);
      this._noise(0.2, 0.05, 500);
    },

    trap() {
      this._tone(220, 0.5, 'sawtooth', 0.09);
      this._tone(150, 0.7, 'sine', 0.11, 0.1);
      this._noise(0.5, 0.08, 300);
    },

    core() {
      this._tone(180, 0.5, 'square', 0.1);
      this._tone(900, 0.35, 'sine', 0.09, 0.04);
      this._noise(0.45, 0.14, 1400);
    },

    victory(finale) {
      const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
      // v3.5: финальный уровень — арпеджио-крещендо, три ноты сверху
      if (finale) notes.push(1567.98, 2093.0, 2637.0);
      notes.forEach((f, i) => this._tone(f, 0.5, 'triangle', 0.16, i * 0.11));
      this._tone(130.8, 1.1, 'sine', 0.12, 0.1);
    },

    defeat() {
      const notes = [392.0, 349.23, 293.66, 220.0];
      notes.forEach((f, i) => this._tone(f, 0.45, 'sine', 0.14, i * 0.16));
    },

    ui() { this._tone(660, 0.05, 'sine', 0.05); }
  };

  // ===========================================================================
  // 5. УТИЛИТЫ
  // ===========================================================================
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function fmtTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  }
  function angNorm(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  function angIn(az, from, to) {
    if (from === undefined) return true;
    if (from <= to) return az >= from && az <= to;
    return az >= from || az <= to;   // диапазон через 0
  }

  // ===========================================================================
  // 6. КОЛЛАЙДЕРЫ (поверхности вращения, цилиндры, сферы, капсулы)
  //    Вся физика ведётся в ЛОКАЛЬНОЙ системе стакана: наклон реализуется
  //    поворотом вектора гравитации, поэтому коллайдеры статичны.
  // ===========================================================================

  /**
   * Поверхность вращения: профиль — полилиния в меридианной плоскости (r, y),
   * обход ПРОТИВ часовой стрелки → внешняя нормаль = (dy, -dr)/len.
   * Для шара расстояние в 3D равно расстоянию в меридианной плоскости.
   */
  function makeRevolve(name, pts, opts) {
    opts = opts || {};
    const segs = [], verts = [];
    let yMin = Infinity, yMax = -Infinity, rMin = Infinity, rMax = -Infinity;
    for (let i = 0; i < pts.length; i++) {
      const r = pts[i][0], y = pts[i][1];
      yMin = Math.min(yMin, y); yMax = Math.max(yMax, y);
      rMin = Math.min(rMin, r); rMax = Math.max(rMax, r);
      // ВАЖНО: вершины у оси тоже нужны — иначе шар, летящий точно по оси,
      // проваливается в «дырку» между концом сегмента (t>1) и осью (кнопка, дно).
      verts.push({ r: r, y: y });
      if (i === pts.length - 1) continue;
      const r2 = pts[i + 1][0], y2 = pts[i + 1][1];
      const dr = r2 - r, dy = y2 - y;
      const len = Math.hypot(dr, dy);
      if (len < 1e-6) continue;
      if (r < 0.05 && r2 < 0.05) continue;          // осевой сегмент — нормаль вырождена
      segs.push({ r1: r, y1: y, dr: dr, dy: dy, l2: len * len, nr: dy / len, ny: -dr / len });
    }
    return {
      type: 'revolve', name: name, segs: segs, verts: verts,
      closed: Math.hypot(pts[0][0]-pts[pts.length-1][0],pts[0][1]-pts[pts.length-1][1])<1e-8,
      yMin: yMin, yMax: yMax, rMin: rMin, rMax: rMax,
      angFrom: opts.angFrom, angTo: opts.angTo,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      roll: opts.roll || 0,             // дополнительное гашение качения (чаша, воронка)
      group: opts.group || null,        // метка для «важных» объектов (затухание)
      onHit: opts.onHit || null
    };
  }

  /** Кольцо (тор) в меридианной плоскости: центр (cr, cy), радиус трубки tube. */
  function makeTorusR(name, cr, cy, tube, opts) {
    opts = opts || {};
    return {
      type: 'torusR', name: name, cr: cr, cy: cy, tube: tube,
      yMin: cy - tube, yMax: cy + tube, rMin: cr - tube, rMax: cr + tube,
      angFrom: opts.angFrom, angTo: opts.angTo,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      group: opts.group || null, onHit: opts.onHit || null
    };
  }

  /** Цилиндрическая стенка (шар удерживается ВНУТРИ r < wallR). */
  function makeCyl(name, wallR, yMin, yMax, opts) {
    opts = opts || {};
    return {
      type: 'cyl', name: name, wallR: wallR, yMin: yMin, yMax: yMax,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionWall : opts.e,
      angFrom: opts.angFrom, angTo: opts.angTo, group: opts.group || null, onHit: opts.onHit || null
    };
  }

  /** Сфера (ядро щита, тела-загадки). */
  function makeSphereCol(name, x, y, z, r, opts) {
    opts = opts || {};
    return {
      type: 'sphere', name: name, c: new THREE.Vector3(x, y, z), r: r,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      group: opts.group || null, onHit: opts.onHit || null, live: true
    };
  }

  /** Капсула (кронштейны кнопки, стойка троса). */
  function makeCapsule(name, a, b, r, opts) {
    opts = opts || {};
    return {
      type: 'capsule', name: name,
      a: new THREE.Vector3(a.x, a.y, a.z), b: new THREE.Vector3(b.x, b.y, b.z),
      ab: new THREE.Vector3(b.x - a.x, b.y - a.y, b.z - a.z), r: r,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      group: opts.group || null, onHit: opts.onHit || null
    };
  }

  const _n = new THREE.Vector3();

  /**
   * Разрешение контакта: выталкивание + упругое отражение + трение.
   * pen — глубина проникновения вдоль нормали n.
   */
  // Трение: при настоящем ударе — кулоновское (μ·(1+e)·|v_n|), при спокойном
  // контакте/качении — очень малое сопротивление качению. Иначе шары «залипают»
  // и не катятся даже под уклон 3° (бильярдного наката не получается).
  const ROLL_RESISTANCE = 0.18;   // 1/с
  const SLIDE_THRESHOLD = 0.4;    // м/с: граница «удар / качение»

  // v4.2: осевой бокс-коллайдер (плиты-стенки этажа «Резонанс»)
  function makeBox(name, cx, cy, cz, hx, hy, hz, opts) {
    const o = opts || {};
    return {
      type: 'box', name: name, group: o.group || '',
      c: { x: cx, y: cy, z: cz }, h: { x: hx, y: hy, z: hz },
      e: o.e !== undefined ? o.e : 0.5, fr: o.friction !== undefined ? o.friction : 0.05,
      live: true, floor: undefined, onHit: o.onHit || null
    };
  }

  function resolveContact(ball, nx, ny, nz, pen, e, friction, dt, surfVx, surfVy, surfVz, col) {
    if (pen <= 0) return false;
    ball.p.x += nx * pen; ball.p.y += ny * pen; ball.p.z += nz * pen;
    let vx = ball.v.x - (surfVx || 0), vy = ball.v.y - (surfVy || 0), vz = ball.v.z - (surfVz || 0);
    const vnIn = vx * nx + vy * ny + vz * nz;
    // бильярдная упругость сохраняется для настоящих ударов; на микро-скоростях
    // она гасится, иначе шар вечно прыгает в чаше и не катится
    const eEff = dt===0 ? 0 : (-vnIn < 1.55) ? e * clamp((-vnIn - 0.35) / 1.2, 0, 1) : e;
    if (vnIn < 0) {
      const j = -(1 + eEff) * vnIn;
      vx += nx * j; vy += ny * j; vz += nz * j;
      if (dt>0 && -vnIn > (ball.impact || 0)) ball.impact = -vnIn;
    }
    const vn2 = vx * nx + vy * ny + vz * nz;
    let tx = vx - vn2 * nx, ty = vy - vn2 * ny, tz = vz - vn2 * nz;
    const vtLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
    if (vtLen > 1e-9) {
      let k;
      if(dt===0){k=1;}else if (vnIn < -SLIDE_THRESHOLD) {
        const maxFt = friction * (1 + eEff) * (-vnIn);
        k = Math.max(0, 1 - maxFt / vtLen);
      } else {
        k = Math.exp(-(ROLL_RESISTANCE + (ball.rollExtra || 0))*dt);
      }
      tx *= k; ty *= k; tz *= k;
    }
    vx = vn2 * nx + tx; vy = vn2 * ny + ty; vz = vn2 * nz + tz;
    ball.v.x = vx + (surfVx || 0); ball.v.y = vy + (surfVy || 0); ball.v.z = vz + (surfVz || 0);
    ball.contact = true;
    ball.contactN.set(nx, ny, nz);
    if(col && col.group==='plate3' && vnIn<0) { ball.plateSpeeds=ball.plateSpeeds||{};ball.plateSpeeds[col.name]=Math.max(ball.plateSpeeds[col.name]||0,-vnIn); }
    if (col) {
      ball.touched[col.name] = true;
      if (col.group) ball.touched[col.group] = true;
    }
    return true;
  }

  function collideOne(ball, col, dt) {
    if (col.floor !== undefined && col.floor !== W.currentFloor) return;
    if(col.filterColor!==undefined && (ball.colorIdx!==col.filterColor || ball.pipeRoad!==col.filterRoad))return;
    if (col.live === false) return;   // v4.0: отключённые коллайдеры (открытые люки, полные лунки)
    const P = LEVEL_CONFIG.physics;
    const fr = P.surfaceFriction;
    const rollExtra = col.roll || 0;
    const p = ball.p;

    if(col.type==='pipeRamp'){rampContact50(ball,col,dt);return;}
    if(col.type==='offsetFunnel') {
      const dx=p.x-col.x,dz=p.z-col.z,r=Math.hypot(dx,dz);
      if(Math.hypot(p.x,p.z)>col.outerR+ball.r || p.y<col.y-.35)return;
      if(r>=col.hole){
        const surface=col.y+col.slope*(r-col.hole),n=Math.sqrt(1+col.slope*col.slope);
        const distance=(p.y-surface)/n;
        if(distance<ball.r && distance>-.3){
          ball.rollExtra=0;resolveContact(ball,-col.slope*dx/r/n,1/n,-col.slope*dz/r/n,ball.r-distance,col.e,fr,dt,0,0,0,col);
        }
      }else if(r>.001){
        const dr=r-col.hole,dy=p.y-col.y,d=Math.hypot(dr,dy);
        if(d<ball.r&&d>.0001)resolveContact(ball,dx/r*dr/d,dy/d,dz/r*dr/d,ball.r-d,col.e,fr,dt,0,0,0,col);
      }
      return;
    }
    if (col.type === 'box') {
      if (col.live === false) return;
      const bx = p.x - col.c.x, by = p.y - col.c.y, bz = p.z - col.c.z;
      if (Math.abs(bx) - col.h.x >= ball.r || Math.abs(by) - col.h.y >= ball.r || Math.abs(bz) - col.h.z >= ball.r) return;
      const qx = clamp(bx, -col.h.x, col.h.x), qy = clamp(by, -col.h.y, col.h.y), qz = clamp(bz, -col.h.z, col.h.z);
      const dx = bx - qx, dy = by - qy, dz = bz - qz;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (d2 > ball.r * ball.r) return;
      let nx, ny, nz, pen;
      if (d2 > 1e-9) {
        const d = Math.sqrt(d2);
        nx = dx / d; ny = dy / d; nz = dz / d; pen = ball.r - d;
      } else {
        const ex = col.h.x - Math.abs(bx), ey = col.h.y - Math.abs(by), ez = col.h.z - Math.abs(bz);
        if (ex <= ey && ex <= ez) { nx = bx >= 0 ? 1 : -1; ny = 0; nz = 0; pen = ball.r + ex; }
        else if (ey <= ez) { nx = 0; ny = by >= 0 ? 1 : -1; nz = 0; pen = ball.r + ey; }
        else { nx = 0; ny = 0; nz = bz >= 0 ? 1 : -1; pen = ball.r + ez; }
      }
      ball.rollExtra = rollExtra;
      resolveContact(ball, nx, ny, nz, pen, col.e, fr, dt, 0, 0, 0, col);
      if (col.onHit) col.onHit(ball, col);
      return;
    }

    if (col.type === 'cyl') {
      if (p.y < col.yMin - ball.r || p.y > col.yMax + ball.r) return;
      const r = Math.hypot(p.x, p.z);
      if (r + ball.r <= col.wallR) return;
      const az = Math.atan2(p.z, p.x);
      if (!angIn(az, col.angFrom, col.angTo)) return;
      const ux = r > 1e-6 ? p.x / r : 1, uz = r > 1e-6 ? p.z / r : 0;
      ball.rollExtra = rollExtra; resolveContact(ball, -ux, 0, -uz, r + ball.r - col.wallR, col.e, fr, dt, 0, 0, 0, col);
      return;
    }

    if (col.type === 'sphere') {
      if (col.live === false) return;
      const dx = p.x - col.c.x, dy = p.y - col.c.y, dz = p.z - col.c.z;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const rr = ball.r + col.r;
      if (d >= rr || d < 1e-9) return;
      ball.rollExtra = rollExtra;
      resolveContact(ball, dx / d, dy / d, dz / d, rr - d, col.e, fr, dt, 0, 0, 0, col);
      if (col.onHit) col.onHit(ball, col);
      return;
    }

    if (col.type === 'capsule') {
      const apx = p.x - col.a.x, apy = p.y - col.a.y, apz = p.z - col.a.z;
      const l2 = col.ab.lengthSq();
      let t = l2 > 1e-9 ? (apx * col.ab.x + apy * col.ab.y + apz * col.ab.z) / l2 : 0;
      t = clamp(t, 0, 1);
      const cx = col.a.x + col.ab.x * t, cy = col.a.y + col.ab.y * t, cz = col.a.z + col.ab.z * t;
      const dx = p.x - cx, dy = p.y - cy, dz = p.z - cz;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const rr = ball.r + col.r;
      if (d >= rr || d < 1e-9) return;
      ball.rollExtra = rollExtra;
      resolveContact(ball, dx / d, dy / d, dz / d, rr - d, col.e, fr, dt, 0, 0, 0, col);
      return;
    }

    if (col.type === 'torusR') {
      if (p.y < col.yMin - ball.r || p.y > col.yMax + ball.r) return;
      const r = Math.hypot(p.x, p.z);
      if (r < col.rMin - ball.r || r > col.rMax + ball.r) return;
      const az = Math.atan2(p.z, p.x);
      if (!angIn(az, col.angFrom, col.angTo)) return;
      const dr = r - col.cr, dy = p.y - col.cy;
      const d = Math.hypot(dr, dy);
      const rr = ball.r + col.tube;
      if (d >= rr || d < 1e-9) return;
      const ux = r > 1e-6 ? p.x / r : 1, uz = r > 1e-6 ? p.z / r : 0;
      ball.rollExtra = rollExtra;
      resolveContact(ball, (dr / d) * ux, dy / d, (dr / d) * uz, rr - d, col.e, fr, dt, 0, 0, 0, col);
      return;
    }

    if(col.type==='revolve'){revolveContact50(ball,col,dt);return;}
  }


  // ===========================================================================
  // 7. ШАР
  // ===========================================================================
  let BALL_SEQ = 0;

  class Ball {
    constructor(opts) {
      this.id = 'ball_' + (++BALL_SEQ) + '_' + (opts.name || '');
      this.name = opts.name || this.id;
      this.p = new THREE.Vector3(opts.x || 0, opts.y || 0, opts.z || 0);
      this.v = new THREE.Vector3(0, 0, 0);
      this.baseR = opts.r;
      this.r = opts.r * 1;
      this.m = opts.m === undefined ? (opts.r * opts.r * opts.r * 6.0) : opts.m;
      this.baseM = this.m;
      this.colorIdx = opts.colorIdx === undefined ? -1 : opts.colorIdx;   // -1 = бесцветный (белый)
      this.isPlayer = !!opts.isPlayer;
      this.isBody = !!opts.isBody;         // тело-загадка
      this.noMagic = !!opts.noMagic;
      this.mounted = !!opts.mounted;       // примагничен → кинематический
      this.mountPos = this.p.clone();
      this.mountQuat = null;
      this.kinematic = this.mounted;
      this.contact = false;
      this.contactN = new THREE.Vector3(0, 1, 0);
      this.touched = {};                 // имена коллайдеров, которых касались в этом кадре
      this.kinV = new THREE.Vector3();   // скорость кинематического тела
      this.rollExtra = 0;                // доп. гашение качения от зоны контакта
      this.impact = 0;
      this.chargeT = 0;                    // остаток заряда магии, с
      this.chargeArmed = true;             // можно заряжаться по фронту нового касания
      this.groupId = -1;                   // id заряженной цепочки
      this.onNet = false;
      this.onGlass = false;
      this.glassT = 0;                     // сколько лежит на стекле
      this.dissolving = 0;                 // >0 — растворяется
      this.restT = 0;                      // время покоя (для анти-застревания)
      this.assistCd = 0;
      this.spinAxis = new THREE.Vector3(0, 0, 1);
      this.spinRate = 0;
      this.alive = true;
      this.mesh = null;
      this.ring = null;
      this.glow = null;
      this.trail = null;
      this.flash = 0;
      this.lastSpeed = 0;
      if (this.isPlayer) { this.m = LEVEL_CONFIG.player.mass; this.baseM = this.m; }
    }

    get colorNum() {
      if (this.colorIdx < 0) return LEVEL_CONFIG.player.colorNum;
      return LEVEL_CONFIG.palette[this.colorIdx].colorNum;
    }

    demount(why) {
      if (!this.mounted || this.pipeLock) return;   // v4.5: К в кармане не выбить
      this.mounted = false;
      this.kinematic = false;
      this.v.set(0, 0, 0);
      // v4.5: касание = сдвиг с опоры В СТОРОНУ толчка (часть скорости толкателя):
      // иначе белый шар проходит сквозь ряд «призраком», ряд стоит, а возврат
      // сквозь стоящие шары расшвыряет их из жёлоба
      if (why && why.indexOf('touch:') === 0 && W && W.balls) {
        const pusher = W.balls.find(q => q.name === why.slice(6));
        if (pusher) {
          const s = Math.hypot(pusher.v.x, pusher.v.z);
          if (s > 0.05) {
            const k = Math.min(s * 0.55, 1.1) / s;
            this.v.x = pusher.v.x * k; this.v.z = pusher.v.z * k;
          }
        }
      }
      W.events.push({ t: W.time, type: 'demount', name: this.name, why: why || '' });
    }
  }

  // ===========================================================================
  // 8. МАТЕРИАЛЫ И МЕШИ
  // ===========================================================================
  const MAT = {};

  function initMaterials() {
    MAT.silver = new THREE.MeshStandardMaterial({
      color: 0x8899aa, metalness: 0.92, roughness: 0.28,
      transparent: true, opacity: 1.0, side: THREE.DoubleSide,
      emissive: 0x0a1420, emissiveIntensity: 0.5
    });
    MAT.silverDark = new THREE.MeshStandardMaterial({
      color: 0x556677, metalness: 0.9, roughness: 0.4,
      transparent: true, opacity: 1.0, side: THREE.DoubleSide
    });
    MAT.glass = new THREE.MeshPhysicalMaterial({
      color: 0x9fd8ff, metalness: 0.0, roughness: 0.06,
      transparent: true, opacity: 0.085, side: THREE.DoubleSide,
      depthWrite: false
    });
    MAT.glassFloor = new THREE.MeshPhysicalMaterial({
      color: 0xbfe6ff, metalness: 0.05, roughness: 0.12,
      transparent: true, opacity: 0.85, side: THREE.DoubleSide,
      emissive: 0x113344, emissiveIntensity: 0.35
    });
    MAT.net = new THREE.MeshStandardMaterial({
      color: 0x99aabb, metalness: 0.5, roughness: 0.6,
      transparent: true, opacity: 0.7, side: THREE.DoubleSide,
      map: makeNetTexture(), alphaMap: makeNetTexture(true)
    });
    MAT.rope = new THREE.MeshStandardMaterial({
      color: 0xd8c9a8, metalness: 0.1, roughness: 0.85, emissive: 0x221a08
    });
    MAT.button = new THREE.MeshStandardMaterial({
      color: 0xff2244, metalness: 0.3, roughness: 0.35,
      emissive: 0xff2244, emissiveIntensity: 1.1,
      transparent: true, opacity: 1.0, side: THREE.DoubleSide
    });
    MAT.core = new THREE.MeshStandardMaterial({
      color: 0xd946ef, metalness: 0.35, roughness: 0.25,
      emissive: 0xd946ef, emissiveIntensity: 1.5,
      transparent: true, opacity: 1.0
    });
    MAT.halo = new THREE.MeshBasicMaterial({
      color: 0xf0abfc, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false
    });
    MAT.player = new THREE.MeshStandardMaterial({
      color: 0xffffff, metalness: 0.15, roughness: 0.22,
      emissive: 0x88ddff, emissiveIntensity: 0.55
    });
    MAT.ring = new THREE.MeshBasicMaterial({
      color: 0x00ffaa, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false
    });
    MAT.glowSprite = new THREE.MeshBasicMaterial({
      color: 0xffffff, transparent: true, opacity: 0.22,
      side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending
    });
    MAT.palette = LEVEL_CONFIG.palette.map(c => new THREE.MeshStandardMaterial({
      color: c.colorNum, metalness: 0.25, roughness: 0.3,
      emissive: c.emissive, emissiveIntensity: 0.85
    }));
  }

  function makeNetTexture(asAlpha) {
    const S = 256;
    const cv = document.createElement('canvas');
    cv.width = S; cv.height = S;
    const g = cv.getContext('2d');
    if (asAlpha) {
      g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
      g.strokeStyle = '#fff'; g.lineWidth = 7;
      const step = S / 4;
      for (let i = 0; i <= 4; i++) {
        g.beginPath(); g.moveTo(i * step, 0); g.lineTo(i * step, S); g.stroke();
        g.beginPath(); g.moveTo(0, i * step); g.lineTo(S, i * step); g.stroke();
      }
    } else {
      g.fillStyle = '#7d8ea0'; g.fillRect(0, 0, S, S);
      g.strokeStyle = '#cfe4f5'; g.lineWidth = 7;
      const step = S / 4;
      for (let i = 0; i <= 4; i++) {
        g.beginPath(); g.moveTo(i * step, 0); g.lineTo(i * step, S); g.stroke();
        g.beginPath(); g.moveTo(0, i * step); g.lineTo(S, i * step); g.stroke();
      }
    }
    const tex = new THREE.CanvasTexture(cv);
    tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(14, 6);
    return tex;
  }

  function lathe(profile, segments, phiStart, phiLength) {
    const pts = profile.map(p => new THREE.Vector2(Math.max(0.001, p[0]), p[1]));
    const g = new THREE.LatheGeometry(pts, (MOBILE ? Math.min(48,segments||96) : segments||96), phiStart || 0, phiLength === undefined ? Math.PI * 2 : phiLength);
    g.computeVertexNormals();
    return g;
  }


  function ringMesh(r, tube, color, opacity) {
    const m = new THREE.Mesh(
      new THREE.TorusGeometry(r, tube, 8, 96),
      new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: opacity, depthWrite: false })
    );
    m.rotation.x = Math.PI / 2;
    return m;
  }

  // ===========================================================================
  // 9. СОСТОЯНИЕ МИРА
  // ===========================================================================
  const W = {
    scene: null, camera: null, renderer: null,
    glassGroup: null, fxGroup: null,
    colliders: [], balls: [], bodies: [], fadeables: [], important: [],
    player: null, core: null, coreAlive: true,
    buttonCol: null, netCol: null, buttonMesh: null, buttonGlow: null,
    coreMesh: null, halos: [], bodyOrbitT: 0,
    ropeMesh: null, ropeAnchorMesh: null, ropeCut: false, ropeLen: LEVEL_CONFIG.rope.length,
    events: [], contacts: [],
    time: 0, runTime: 0, state: 'menu',
    magicCount: 0, lostCount: 0, cutCount: 0, blastCount: 0,
    trapTimer: -1, winSeq: 0, loseSeq: 0,
    shakeCd: 0, shakeVisual: 0, shakeSeed: 0, orbitT: 0, ropeHover: false,
    slowmo: 0, slowmoScale: 1, screenShake: 0, screenShakeAmp: 0,
    tilt: { rotX: 0, rotZ: 0, tRotX: 0, tRotZ: 0, active: false },
    ffOpen: false, ffReason: null, floorsGhost: false, autoPull: null,
    cam: { theta: LEVEL_CONFIG.camera.defaultTheta, phi: LEVEL_CONFIG.camera.defaultPolar, dist: LEVEL_CONFIG.camera.defaultDist,
           tTheta: LEVEL_CONFIG.camera.defaultTheta, tPhi: LEVEL_CONFIG.camera.defaultPolar, tDist: LEVEL_CONFIG.camera.defaultDist,
           spinTheta: 0, spinPhi: 0 },
    camShake: new THREE.Vector3(),
    sparks: null, sparkData: [],
    fireworks: null, fwData: [],
    chargeGroups: [],
    fadeState: new Map(),
    glassOffset: new THREE.Vector3(),
    def: null,
    // --- v3.5: поток (re-wind), очки/комбо, интро, уровни, звёзды ---
    attempts: 0, failStreak: 0,
    rewind: { active: false, t: 0, from: new THREE.Vector3(), dur: 0.4 },
    intro: { active: false, t: 0, dur: 2.5 },
    introWasActive: false,
    cine: null, camTargetY: undefined,
    lowestY: 99, hintShownAt: 0,
    score: 0, bestScore: 0, combo: 1, lastEventTime: -999, perfectCuts: 0,
    progress: null, specials: null, sandbox: false, sandboxMenu: false, levelNameT: 0, // v4.1
    currentLevel: 0,
    flashT: 0, ropePulse: 0,
    visited: null,
    trail: null,
    // v4.0: этажи
    currentFloor: 0, floorGroup: null, floorState: null, floorSolvedFlag: false,
    floorGate: null, gateAnim: 0, floorEntry: null,
    floorTransition: null,      // { active, t, dur, to, toastShown }
    paletteNow: null, paletteTarget: 0, floorGlowRing: null,
    camTargetX: 0, camTargetZ: 0, camBreath: 0,
    echoQueue: null, lights: null
  };

  // ===========================================================================
  // 10. ПРОФИЛИ ПЛОЩАДОК
  // ===========================================================================
  // v4.1: диск этажа «Чаша» башни — юбка до стенки стакана, плоскость, чаша
  // с ЦЕНТРАЛЬНЫМ ЛЮКОМ вниз (дно чаши — горловина). Спуск — только через люк.
  function profilePlatformA() {
    const A = LEVEL_CONFIG.platformA;
    const R = LEVEL_CONFIG.glass.radius;
    const hole = LEVEL_CONFIG.floors.holeR * 1;
    const r0 = hole + 0.1;
    const pts = [[R, A.y], [A.bowlRadius, A.y]];
    const N = 12;
    for (let i = 1; i <= N; i++) {
      const r = A.bowlRadius - (A.bowlRadius - r0) * (i / N);
      const t = (r - r0) / (A.bowlRadius - r0);
      pts.push([r, A.y - A.bowlDepth * (1 - t * t)]);
    }
    pts.push([hole, A.y - A.bowlDepth - 0.06]);        // губа горловины люка
    pts.push([hole, A.y - A.bowlDepth - 0.5]);         // трубка люка вниз
    pts.push([hole + 0.22, A.y - A.bowlDepth - 0.55]);
    pts.push([A.bowlRadius + 0.4, A.y - A.bowlDepth - 0.75]);
    pts.push([R, A.y - A.bowlDepth - 1.15]);
    pts.push([R, A.y]);
    return pts;
  }

  // Всё, что обязано пропускать или удерживать шар, масштабируется вместе с ним:
  // горловина воронки, отверстие сетки, пробка, кнопка, ядро, орбита тел,
  // бортик площадки A и длина троса. Иначе на крупных шарах уровень
  // непроходим (шар не пролезает в горловину r=1.5), а на мелких
  // пробка перестаёт закрывать отверстие.


  // Площадка B: плоское кольцо тянется ДО СТЕНКИ стакана (иначе между краем
  // площадки и стеклом остаётся щель, в которую шар проваливается в ловушку,
  function profilePlatformB() {
    const B = LEVEL_CONFIG.platformB;
    const R = LEVEL_CONFIG.glass.radius;
    return [
      [R, B.y],                              // юбка у стенки стакана
      [B.funnelTopR + 0.3, B.y],             // плоское кольцо
      [B.funnelTopR + 0.15, B.funnelTopY - 0.05],
      [B.funnelTopR, B.funnelTopY],          // губа воронки (r=10, y=5.3)
      [(B.funnelBottomR * 1), B.funnelBottomY],    // конус к горловине (r=1.5, y=3.5)
      [(B.funnelBottomR * 1), B.funnelBottomY - 0.3],
      [B.funnelTopR, B.funnelTopY - 0.35],
      [B.funnelTopR + 0.3, B.y - B.thickness],
      [R, B.y - B.thickness - 0.3],
      [R, B.y]
    ];
  }

  // Зона воронки отдельно: гасящая поверхность (иначе шар играет в пинбол
  // и никогда не попадает в горловину r=1.5)
  function profileFunnelB() {
    const B = LEVEL_CONFIG.platformB;
    return [
      [B.funnelTopR, B.funnelTopY],
      [(B.funnelBottomR * 1), B.funnelBottomY],
      [(B.funnelBottomR * 1), B.funnelBottomY - 0.3],
      [B.funnelTopR, B.funnelTopY - 0.35]
    ];
  }

  // Чаша площадки A отдельно от плоского диска: чаша гасит прыжки,
  // диск остаётся строго бильярдным
  // v4.1: гасящая чаша — до горловины люка (центр открыт, крышка — отдельный коллайдер)
  function profileBowlA() {
    const A = LEVEL_CONFIG.platformA;
    const hole = LEVEL_CONFIG.floors.holeR * 1;
    const r0 = hole + 0.12;
    const pts = [[A.bowlRadius + 0.02, A.y]];
    const N = 12;
    for (let i = 1; i <= N; i++) {
      const r = A.bowlRadius - (A.bowlRadius - r0) * (i / N);
      const t = (r - r0) / (A.bowlRadius - r0);
      pts.push([r, A.y - A.bowlDepth * (1 - t * t)]);
    }
    pts.push([r0, A.y - A.bowlDepth - 0.25]);
    pts.push([A.bowlRadius + 0.02, A.y - A.bowlDepth - 0.25]);
    pts.push([A.bowlRadius + 0.02, A.y]);
    return pts;
  }

  function profileDiscA() {
    const A = LEVEL_CONFIG.platformA;
    const R = LEVEL_CONFIG.glass.radius;   // v4.1: диск до стенки — щелей нет
    return [[R, A.y], [A.bowlRadius, A.y], [A.bowlRadius, A.y - A.thickness],
      [R, A.y - A.thickness], [R, A.y]];
  }

  function profileNet() {
    const T = LEVEL_CONFIG.trap;
    const drop = Math.tan(T.netTilt) * (T.netRadius - (T.netHole * 1));
    return [
      [LEVEL_CONFIG.glass.radius, T.netY],
      [T.netRadius, T.netY],
      [(T.netHole * 1), T.netY - drop],
      [(T.netHole * 1), T.netY - drop - 0.3]
    ];
  }

  function profileButton() {
    const B = LEVEL_CONFIG.button, R = B.radius * 1;
    const top = B.y + B.thickness / 2, bot = B.y - B.thickness / 2;
    return [[R, top], [0.02, top], [0.02, bot], [R, bot], [R, top]];
  }

  // v4.0: плоский диск этажа «Труба»/«Резонанс»: кольцо до стенки стакана
  // + центральная трубка-горловина (люк вниз). Юбка вниз к стенке — как у
  // прежней площадки B, чтобы шар не проскальзывал между диском и стеклом.
  function profileFloorDisc(y) {
    const R = LEVEL_CONFIG.glass.radius, hole = (LEVEL_CONFIG.floors.holeR * 1);
    return [
      [R, y],                                  // юбка у стенки
      [hole + 0.3, y],                         // плоское кольцо
      [hole, y - 0.05],                        // губа горловины
      [hole, y - 0.45],                        // трубка люка вниз
      [hole + 0.2, y - 0.5],
      [R, y - 0.8],                            // нижняя юбка к стенке
      [R, y]
    ];
  }

  // v4.0: кольцо-балкон финального этажа: площадка вокруг провала, сквозь который
  // ныряют к смещённому ядру. Внизу трубки нет — нырок уходит в открытую полость.
  // Обход сверху справа налево (от большего r к меньшему), иначе нормаль вниз.
  function profileFinalRing(y) {
    const R = LEVEL_CONFIG.glass.radius, hole = (LEVEL_CONFIG.floors.holeR * 1);
    return [
      [R, y],                                  // юбка у стенки
      [hole + 0.3, y],                         // плоское кольцо-балкон
      [hole + 0.05, y - 0.06],
      [hole, y - 0.12],                        // скруглённая губа провала
      [hole + 0.25, y - 0.32],
      [R, y - 0.55],
      [R, y]
    ];
  }

  // v4.0: мини-профиль крышки люка (плоский диск по горловине).
  // Обход справа налево — иначе нормаль смотрит вниз и шар проваливается
  function profileGateLid(y) {
    const hole = (LEVEL_CONFIG.floors.holeR * 1);
    return [[hole + 0.08, y + 0.06], [0, y + 0.06], [0, y - 0.22], [hole + 0.08, y - 0.22], [hole + 0.08, y + 0.06]];
  }

  function funnelY(r) {
    const B = LEVEL_CONFIG.platformB;
    if (r >= B.funnelTopR) return B.y;
    if (r <= (B.funnelBottomR * 1)) return B.funnelBottomY;
    const t = (B.funnelTopR - r) / (B.funnelTopR - (B.funnelBottomR * 1));
    return B.funnelTopY + (B.funnelBottomY - B.funnelTopY) * t;
  }

  // ===========================================================================
  // 11. ПОСТРОЕНИЕ УРОВНЯ
  // ===========================================================================
  function protectedMats() {
    const set = new Set();
    Object.keys(MAT).forEach(k => {
      const v = MAT[k];
      if (Array.isArray(v)) v.forEach(m => set.add(m)); else if (v) set.add(v);
    });
    return set;
  }

  function disposeGroup(g) {
    if (!g) return;
    const prot = protectedMats();
    g.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        const mm = Array.isArray(o.material) ? o.material : [o.material];
        mm.forEach(m => {
          if (!m || prot.has(m)) return;
          if (m.map) m.map.dispose();
          if (m.alphaMap) m.alphaMap.dispose();
          m.dispose();
        });
      }
    });
    if (g.parent) g.parent.remove(g);
  }

  // v4.5: тонировка «цилиндров башни» (дисков этажей) цветом текущего уровня.
  // Диски создаются клонами MAT.silver — красим материал каждого меша,
  // коллайдеры и физику не трогаем.
  function applyLevelPalette() {
    const idx = clamp(W.currentLevel || 0, 0, LEVELS.length - 1);
    const pal = LEVEL_PALETTES[idx % LEVEL_PALETTES.length];
    const c = new THREE.Color(pal[1]);
    const e = new THREE.Color(pal[2]);
    const tint = (m) => {
      if (!m || !m.material || !m.material.color) return;
      m.material.color.copy(new THREE.Color(0.75, 0.8, 0.9)).lerp(c, 0.55);
      if (m.material.emissive) { m.material.emissive.copy(e).multiplyScalar(0.16); }
    };
    const walk = (root) => {
      if (!root) return;
      (root.children || []).forEach(ch => {
        if (ch && ch.name && /^(platformA|floorPipe|platformB)$/.test(ch.name)) tint(ch);
        if (ch && ch.children && ch.children.length) walk(ch);
      });
    };
    if (W.floorViz) W.floorViz.forEach(walk);
    W.levelPalette = pal;   // для UI-свотчей и тестов
  }

  function buildLevel() {
    const C = LEVEL_CONFIG;
    // v3.5: параметры текущего уровня
    applyLevel(W.currentLevel || 0);
    // --- очистка ---
    disposeGroup(W.glassGroup);
    W.glassGroup = new THREE.Group();
    W.glassGroup.name = 'glassGroup';
    W.scene.add(W.glassGroup);
    const G = W.glassGroup;
    W.colliders = []; W.balls = []; W.bodies = []; W.fadeables = []; W.important = [];
    W.events = []; W.contacts = []; W.chargeGroups = []; W.fadeState = new Map();
    W.halos = []; W.important = []; W.glassOffset.set(0, 0, 0);
    W.coreAlive = true; W.ropeCut = false; W.trapTimer = -1; W.winSeq = 0; W.loseSeq = 0;
    W.time = 0; W.runTime = 0; W.magicCount = 0; W.lostCount = 0; W.cutCount = 0; W.blastCount = 0;
    W.shakeCd = 0; W.shakeVisual = 0; W.slowmo = 0; W.slowmoScale = 1;
    W.screenShake = 0; W.screenShakeAmp = 0; W.cam.spinTheta = 0; W.cam.spinPhi = 0; W.ropeHover = false;
    W.bodyOrbitT = 0; W.orbitT = 0; W.tilt.rotX = W.tilt.rotZ = W.tilt.tRotX = W.tilt.tRotZ = 0;
    W.glassOffset.set(0, 0, 0);
    BALL_SEQ = 0;
    // v3.5: сброс потока, очков и вспомогательных состояний
    W.attempts = 0; W.failStreak = 0; W.rewind.active = false; W.rewind.t = 0;
    W.score = 0; W.combo = 1; W.lastEventTime = -999; W.perfectCuts = 0; W.lowestY = 99;
    W.cine = null; W.camTargetY = LEVEL_CONFIG.camera.targetY;
    W.flashT = 0; W.ropePulse = 0;
    W.visited = { A: false, B: false, core: false, button: false, trap: false, floors: [false, false, false, false] };
    // v4.1: сброс этажей (башню строит buildAllFloors)
    W.currentFloor = 0; W.floorGroup = null; W.floorState = null; W.floorSolvedFlag = false;
    W.floorStates = null; W.floorSolvedArr = null; W.floorGates = null;
    W.floorGate = null; W.gateAnim = 0; W.floorTransition = null; W.echoQueue = [];
    W.camTargetX = 0; W.camTargetZ = 0; W.camBreath = 0;
    applyFloorPalette(0, true);
    if (W.trail) {
      W.trail.head = 0; W.trail.fade = 0; W.trail.dirty = true;
      W.trail.colors.fill(0);
    }

    // --- СОЛОД / ЦВЕТ ФОНА (v4.0: из палитры этажей) ---
    const PAL0 = LEVEL_CONFIG.floorPalettes[0];
    W.scene.background = new THREE.Color(PAL0.bg);
    W.scene.fog = new THREE.Fog(PAL0.bg, 90, 260);
    applyFloorPalette(0, true);

    // ============================ СТАКАН ============================
    const gR = C.glass.radius, gB = C.glass.yBottom, gT = C.glass.yTop;
    const LV = LEVELS[W.currentLevel || 0];
    const PAL = LEVEL_PALETTES[(W.currentLevel || 0) % LEVEL_PALETTES.length];
    // v4.5: стекло стакана — цвета текущего уровня (клон материала, тон + подсветка)
    const wallMat = MOBILE ? new THREE.MeshBasicMaterial({color:0x4499bb,transparent:true,opacity:0.07,side:THREE.BackSide,depthWrite:false}) : MAT.glass.clone();
    try { wallMat.color.set(PAL[0]); wallMat.attenuationColor.set(PAL[0]); } catch (e) {}
    const wall = new THREE.Mesh(
      new THREE.CylinderGeometry(gR, gR, gT - gB, 96, 1, true),
      wallMat
    );
    wall.name = 'glassWallMesh';
    wall.position.y = (gT + gB) / 2;
    G.add(wall);

    // вертикальные швы и горизонтальные пояса стекла
    const seamMat = new THREE.LineBasicMaterial({ color: new THREE.Color(PAL[2]).getHex(), transparent: true, opacity: 0.42 });
    const seamPts = [];
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      seamPts.push(new THREE.Vector3(Math.cos(a) * gR, gB, Math.sin(a) * gR));
      seamPts.push(new THREE.Vector3(Math.cos(a) * gR, gT, Math.sin(a) * gR));
    }
    G.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(seamPts), seamMat));
    W.glassBelts = [];
    for (let y = gB; y <= gT + 0.01; y += 3.5) {
      const belt = ringMesh(gR, 0.045, new THREE.Color(PAL[2]).getHex(), 0.4);
      belt.position.y = y;
      G.add(belt);
      W.glassBelts.push(belt);
    }
    // верхний и нижний обод
    const rimTop = new THREE.Mesh(new THREE.TorusGeometry(gR, 0.28, 12, 120), MAT.silverDark.clone());
    rimTop.rotation.x = Math.PI / 2; rimTop.position.y = gT; G.add(rimTop);
    const rimBot = rimTop.clone(); rimBot.position.y = gB; G.add(rimBot);

    // стеклянное дно (ловушка, opacity 0.85)
    const floor = new THREE.Mesh(new THREE.CircleGeometry(gR, 96), MAT.glassFloor.clone());
    floor.rotation.x = -Math.PI / 2; floor.position.y = gB; G.add(floor);
    W.fadeables.push({ mesh: floor, base: 0.85, kind: 'floor' });

    // подсветка дна (v4.0: перекрашивается палитрой этажа; v4.5 — палитрой уровня)
    const floorGlow = ringMesh(gR * 0.72, 0.06, new THREE.Color(PAL[2]).getHex(), 0.5);
    floorGlow.position.y = gB + 0.02; G.add(floorGlow);
    W.floorGlowRing = floorGlow;

    // коллайдеры стакана
    W.colliders.push(makeCyl('glassWall', gR, gB, gT, { e: C.physics.restitutionWall, group: 'glass' }));
    W.colliders.push(makeRevolve('glassFloor', [[0.02, gB], [gR, gB]].reverse(), { e: 0.55, group: 'floor' }));
    W.colliders.push(makeRevolve('ceiling', [[0.02, gT + 1.0], [gR + 0.5, gT + 1.0]], { e: 0.35 }));

    // ============================ ЭТАЖИ (v4.1) ============================
    // Башня: все 4 этажа строятся сразу и сосуществуют до конца уровня.
    const A = C.platformA;
    W.runStats = { shakes: 0, plateFails: 0, roadResets: 0, echoBlasts: 0, socketFails: 0, dives: 0, cutMisses: 0 };
    buildAllFloors();
    applyLevelPalette();   // v4.5: диски этажей — цвет уровня

    // ============================ ЛОВУШКА: СЕТКА ============================
    const T = C.trap;
    const profN = profileNet();
    const meshN = new THREE.Mesh(lathe(profN, 128), MAT.net.clone());
    meshN.name = 'net';
    G.add(meshN);
    W.fadeables.push({ mesh: meshN, base: 0.7, kind: 'net', topY: T.netY });
    W.netCol = makeRevolve('net', profN, { e: 0.5, group: 'net' });
    W.colliders.push(W.netCol);
    const holeRing = ringMesh((T.netHole * 1), 0.07, 0xff3355, 0.9);
    holeRing.position.y = T.netY - Math.tan(T.netTilt) * (T.netRadius - (T.netHole * 1)) + 0.02;
    G.add(holeRing);
    W.trapHoleRing = holeRing;

    // ============================ КНОПКА + КРОНШТЕЙНЫ ============================
    const BT = C.button;
    const SH = C.shield;
    const btnGroup = new THREE.Group();
    btnGroup.position.set(SH.x, 0, SH.z);   // v4.0: кнопка под смещённым ядром
    G.add(btnGroup);
    W.buttonGroup = btnGroup;

    const btnTop = new THREE.Mesh(new THREE.CylinderGeometry((BT.radius * 1), (BT.radius * 1), BT.thickness, 48), MAT.button.clone());
    btnTop.position.y = BT.y;
    btnGroup.add(btnTop);
    W.buttonMesh = btnTop;

    const btnBase = new THREE.Mesh(new THREE.CylinderGeometry((BT.radius * 1) * 1.25, (BT.radius * 1) * 1.45, 0.22, 48), MAT.silverDark.clone());
    btnBase.position.y = BT.y - BT.thickness / 2 - 0.12;
    btnGroup.add(btnBase);

    const btnGlow = new THREE.Mesh(new THREE.CircleGeometry(BT.glowRadius, 48),
      new THREE.MeshBasicMaterial({ color: 0xff3355, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    btnGlow.rotation.x = -Math.PI / 2;
    btnGlow.position.y = BT.y - BT.thickness / 2 - 0.24;
    btnGroup.add(btnGlow);
    W.buttonGlow = btnGlow;

    // v4.0: кнопка вне оси стакана — вместо поверхности вращения капсула
    W.buttonCol = makeRevolve('button',profileButton(),{e:0.15,group:'button'});
    W.buttonCol.offsetX=SH.x;W.buttonCol.offsetZ=SH.z;
    W.colliders.push(W.buttonCol);

    BT.bracketAngles.forEach((a, i) => {
      const ax = Math.cos(a), az = Math.sin(a);
      const p1 = new THREE.Vector3(SH.x + ax * BT.bracketInner, BT.y, SH.z + az * BT.bracketInner);
      const p2 = new THREE.Vector3(ax * (gR - 0.2), BT.bracketWallY, az * (gR - 0.2));
      const dir = new THREE.Vector3().subVectors(p2, p1);
      const len = dir.length();
      const br = new THREE.Mesh(new THREE.CylinderGeometry(BT.bracketRadius, BT.bracketRadius * 1.25, len, 14), MAT.silverDark.clone());
      br.position.copy(p1).addScaledVector(dir, 0.5);
      br.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      br.name = 'bracket' + i;
      W.floorViz[3].add(br);
      W.fadeables.push({ mesh: br, base: 1.0, kind: 'bracket', topY: BT.y });
      const bc=makeCapsule('bracket'+i,p1,p2,BT.bracketRadius,{e:0.7});bc.floor=3;W.colliders.push(bc);
      // крепёжные узлы к стене
      const pad = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.1, 0.9), MAT.silver.clone());
      pad.position.copy(p2);
      pad.lookAt(0, p2.y, 0);
      W.floorViz[3].add(pad);
    });

    // ============================ ЯДРО ЩИТА ============================
    const S = C.shield;
    const coreGroup = new THREE.Group();
    coreGroup.position.set(S.x, S.y, S.z);   // v4.0: ядро смещено от оси
    G.add(coreGroup);
    W.coreGroup = coreGroup;

    const coreMesh = new THREE.Mesh(new THREE.IcosahedronGeometry((S.coreRadius * 1), 2), MAT.core.clone());
    coreGroup.add(coreMesh);
    W.coreMesh = coreMesh;

    const inner = new THREE.Mesh(new THREE.IcosahedronGeometry((S.coreRadius * 1) * 0.62, 1),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55 }));
    coreGroup.add(inner);
    W.coreInner = inner;

    for (let i = 0; i < 2; i++) {
      const h = new THREE.Mesh(new THREE.TorusGeometry((S.coreRadius * 1) * (1.5 + i * 0.42), 0.05, 8, 72), MAT.halo.clone());
      h.rotation.x = Math.PI / 2 + (i ? 0.5 : -0.35);
      h.rotation.y = i ? 0.6 : 0;
      coreGroup.add(h);
      W.halos.push(h);
    }

    W.coreCol = makeSphereCol('core', S.x, S.y, S.z, (S.coreRadius * 1), { e: 0.85, group: 'core' });
    W.colliders.push(W.coreCol);
    W.important.push({ obj: coreGroup, name: 'core' });

    // ============================ ТРОС ============================
    const anchor = new THREE.Vector3(C.rope.anchor.x, C.rope.anchor.y, C.rope.anchor.z);
    W.ropeAnchor = anchor;
    // длина троса = якорь − площадка A − радиус шара − зазор (при 1.00× это ровно 7.9)
    W.ropeLen = anchor.y - A.y - C.player.radius * 1 - 0.35;
    const anchorMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.62, 0.5, 20), MAT.silverDark.clone());
    anchorMesh.position.copy(anchor).add(new THREE.Vector3(0, 0.25, 0));
    G.add(anchorMesh);
    W.ropeAnchorMesh = anchorMesh;
    const anchorHook = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.07, 8, 24), MAT.silver.clone());
    anchorHook.position.copy(anchor);
    G.add(anchorHook);

    const ropeMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 1, 8), MAT.rope.clone());
    G.add(ropeMesh);
    W.ropeMesh = ropeMesh;

    // ============================ ШАРЫ ============================
    // Игровой шар (белый, r = 0.75)
    const hangY = anchor.y - W.ropeLen;
    W.player = makeBall({
      name: 'player', x: anchor.x, y: hangY, z: anchor.z,
      r: C.player.radius, isPlayer: true, colorIdx: -1, m: C.player.mass
    });
    W.important.push({ obj: W.player.mesh, name: 'player', ball: W.player });

    // Тела-загадки на орбите вокруг ядра (3, на уровне 10 — 4: «ядро усилено»)
    const nb = (LEVELS[W.currentLevel | 0] || LEVELS[0]).bodies;
    for (let i = 0; i < nb; i++) {
      const b = makeBall({
        name: 'body' + i, x: 0, y: S.y, z: 0,
        r: S.bodyRadius, colorIdx: i % 3, m: S.bodyMass, isBody: true, mounted: true
      });
      b.orbitPhase = (i / nb) * Math.PI * 2;
      b.orbit = true;
      W.bodies.push(b);
    }

    // «важные» объекты для авто-затухания площадок
    W.important.push({ obj: W.buttonGroup, name: 'button' });

    updateKinematic(0);
    updateRopeVisual();
    for(const o of [W.coreGroup,W.buttonGroup])if(o)W.floorViz[3].add(o);
    for(const b of W.bodies){b.floor=3;W.floorViz[3].add(b.mesh);W.floorViz[3].add(b.ring);}
    for(const col of [W.coreCol,W.buttonCol])if(col)col.floor=3;
    syncFloorViz();
    return W;
  }

  // ===========================================================================
  // 11a. ЭТАЖИ (v4.0): постройка, люки, палитры, загадки
  // ===========================================================================
  const PAL_C = { red: 0, blue: 1, yellow: 2 };

  // кластер примагниченных шаров по дуге (шаг раздвигается при крупном шаре)
  function magnetRing(prefix, count, radius, anglesDeg, colorIdx, rBall, y) {
    const R2 = rBall * 1;
    const need = 2 * Math.asin(Math.min(1, (R2 * 2 * 1.02) / (2 * radius))) * 180 / Math.PI;
    const spec = count > 1 ? (anglesDeg[count - 1] - anglesDeg[0]) / (count - 1) : 0;
    const step = Math.max(spec, need);
    const mid = (anglesDeg[0] + anglesDeg[count - 1]) / 2;
    for (let i = 0; i < count; i++) {
      const a = (mid + (i - (count - 1) / 2) * step) * Math.PI / 180;
      makeFloorBall({
        name: prefix + (i + 1), x: Math.cos(a) * radius, y: y, z: Math.sin(a) * radius,
        r: rBall, colorIdx: colorIdx, mounted: true
      });
    }
  }

  function addFloorCol(col) {
    col.floor = (W._buildFloor !== undefined && W._buildFloor >= 0) ? W._buildFloor : W.currentFloor;
    W.colliders.push(col);
    return col;
  }

  function makeFloorBall(opts) {
    const b = makeBall(opts);
    b.floor = (W._buildFloor !== undefined && W._buildFloor >= 0) ? W._buildFloor : W.currentFloor;
    // v4.2: «дом» шара — точка возврата, если шар ухнул в ловушку мимо загадки
    b.homePos = b.p.clone();
    b.homeMounted = !!opts.mounted;
    const vg = (W.floorViz && W.floorViz[b.floor]) || W.floorGroup;
    if (vg) {
      if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
      if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
      vg.add(b.mesh);
      vg.add(b.ring);
    }
    return b;
  }

  // v4.2: возврат «потерянного» шара этажа на его место (шары больше не исчезают)
  function respawnBallHome(b) {
    if (!b || !b.alive || !b.homePos) return;
    b.p.copy(b.homePos);
    b.v.set(0, 0, 0);
    b.mounted = b.homeMounted;
    b.kinematic = b.homeMounted;
    b.onNet = false; b.onGlass = false; b.glassT = 0; b.dissolving = 0;
    b.countedLost = false; b.inTrap = false;
    if (b.mesh) { b.mesh.scale.setScalar(1); b.mesh.position.copy(b.p); if (b.mesh.material) { b.mesh.material.opacity = 1; } }
    if (b.glow) b.glow.visible = true;
    if (b.pedestal) b.pedestal.visible = true;
    W.events.push({ t: W.time, type: 'ballRespawn', name: b.name });
    W.events.push({ t: W.time, type: 'zzH', name: b.name, x: +b.p.x.toFixed(1), z: +b.p.z.toFixed(1) });
  }

  // точка входа на этаж (для отката при проигрыше на этажах 1+)
  function entryPointOf(idx) {
    const C = LEVEL_CONFIG, ry = C.player.radius * 1 + 0.06;
    if (idx <= 0) return null;                                            // этаж 0 — откат на трос
    if (idx === 1) return new THREE.Vector3(11.2, LEVEL_CONFIG.floorPipeY + ry, 0);
    if (idx === 3) return new THREE.Vector3(0, finalFloorY(0,0) + ry, 0);   // финал: дальше от воронки (r 2.2K + шар)
    return new THREE.Vector3(0, LEVEL_CONFIG.platformB.y + ry, 2.6);      // «Резонанс»: у люка (крышка закрыта)
  }

  // ===========================================================================
  // ПАЛИТРЫ ЭТАЖЕЙ
  // ===========================================================================
  const _palCols = LEVEL_CONFIG.floorPalettes.map(P => ({
    bg: new THREE.Color(P.bg), fog: new THREE.Color(P.fog), key: new THREE.Color(P.key),
    hemi: new THREE.Color(P.hemi), hemiG: new THREE.Color(P.hemiG), glow: new THREE.Color(P.glow)
  }));
  const _palKeys = ['bg', 'fog', 'key', 'hemi', 'hemiG', 'glow'];

  // v4.1: тёмный режим (L10): множитель яркости палитры
  const _darkMul = () => (LV().dark ? 0.32 : 1.0);

  function applyFloorPalette(idx, instant) {
    W.paletteTarget = clamp(idx | 0, 0, 3);
    if (instant) {
      if (!W.paletteNow) W.paletteNow = {};
      const t = _palCols[W.paletteTarget];
      for (const k of _palKeys) {
        if (!W.paletteNow[k]) W.paletteNow[k] = t[k].clone().multiplyScalar(_darkMul());
        else W.paletteNow[k].copy(t[k]).multiplyScalar(_darkMul());
      }
      applyPaletteNow();
    }
  }

  function applyPaletteNow() {
    const p = W.paletteNow;
    if (!p || !W.scene) return;
    if (W.scene.background && W.scene.background.copy) W.scene.background.copy(p.bg);
    if (W.scene.fog) W.scene.fog.color.copy(p.fog);
    if (W.lights) {
      W.lights.key.color.copy(p.key);
      W.lights.hemi.color.copy(p.hemi);
      W.lights.hemi.groundColor.copy(p.hemiG);
      if (W.lights.p1) W.lights.p1.color.copy(p.glow);
    }
    if (W.floorGlowRing && W.floorGlowRing.material) W.floorGlowRing.material.color.copy(p.glow);
  }

  function updatePalette(dt) {
    if (!W.paletteNow) return;
    const t = _palCols[W.paletteTarget];
    if (!t) return;
    const rate = 1 - Math.exp(-dt / 0.35);
    const mul = _darkMul();
    let moved = false;
    for (const k of _palKeys) {
      const c = W.paletteNow[k];
      const tr = t[k].r * mul, tg = t[k].g * mul, tb = t[k].b * mul;
      if (Math.abs(c.r - tr) > 1e-3 || Math.abs(c.g - tg) > 1e-3 || Math.abs(c.b - tb) > 1e-3) moved = true;
      c.r += (tr - c.r) * rate; c.g += (tg - c.g) * rate; c.b += (tb - c.b) * rate;
    }
    if (moved) applyPaletteNow();
  }

  // ===========================================================================
  // ЛЮКИ (ворота этажей)
  // ===========================================================================
  function openFloorGate() {
    const g = W.floorGate;
    if (!g || g.opened || !W.floorSolvedArr[W.currentFloor]) return;
    g.opened = true;
    if (g.col) g.col.live = false;
    W.gateAnim = 0.001;
    Sound.floorDone();
  }

  // v4.1: закрыть крышку люка этажа (сброс загадки на уровнях 6-8)
  function closeGate(idx) {
    const g = W.floorGates && W.floorGates[idx];
    if (!g) return;
    g.opened = false;
    g.pulled = false;                // v4.2: сброс этажа возвращает магнитный поток
    if (g.col) g.col.live = true;
    if (g.lid) g.lid.material.opacity = 0.3;
    if (g.ringMesh) { g.ringMesh.material.color.setHex(0xff3355); g.ringMesh.material.opacity = 0.85; }
    if (g.arc) g.arc.material.opacity = 0.9;
    if (g.group) g.group.position.y = 0;
    W.gateAnim = 0;
  }

  // v4.1: полный сброс загадки этажа (модификатор Re-wind уровней 6-8)
  function resetFloorPuzzle(idx) {
    const st = W.floorStates && W.floorStates[idx];
    if (!st) return;
    if (idx === 0 && st.sockets) {
      for (const sk of st.sockets) {
        sk.count = 0; sk.full = false; sk.stack = 0;
        if (sk.collar) sk.collar.material.opacity = 0;
        if (sk.rim) sk.rim.material.color.setHex(LEVEL_CONFIG.palette[sk.color].colorNum);
        for (const c of sk.cols) c.live = true;
        drawSocketSprite(sk);
      }
      for (const b of W.balls) {
        if (!b.alive || b.isPlayer || b.floor !== 0 || !b.mountPos) continue;
        b.mounted = true; b.kinematic = true; b.orbit = false;
        b.p.copy(b.mountPos); b.v.set(0, 0, 0);
        if (b.mesh) b.mesh.position.copy(b.p);
      }
    } else if (idx === 1 && st.pipe) {
      W.pipeExit=null;AUTO.pipe=null;
      for (const r of st.pipe.roads) resetPipeRoad(r, 'floorReset');
    } else if (idx === 2 && st.plates) {
      for (const pl of st.plates) {
        pl.active = false; pl.cool = 0; pl.lastV = 0; pl.insideBy = {};
        if (pl.mesh) { pl.mesh.material.emissive.setHex(pl.kindColor); pl.mesh.material.emissiveIntensity = 0.55; }
        if (pl.ring) pl.ring.material.color.setHex(pl.kindColor);
        drawPlateBar(pl, -1);
      }
      for (const b of (st.hazards || [])) respawnBallHome(b);
      drawHatchSprite();
    }
    closeGate(idx);
    const wasCur = W.currentFloor;
    W.currentFloor = idx; W.floorState = st;
    setSolvedFlag(false);
    W.currentFloor = wasCur; W.floorState = W.floorStates[wasCur];
    W.floorSolvedFlag = W.floorSolvedArr[wasCur];
    toast(D().floorReset, 'warn');
    Sound.reject();
    W.events.push({ t: W.time, type: 'floorReset', floor: idx });
  }

  function updateGateVisual(dt) {
    if (!W.floorGate || !W.floorGate.opened || W.gateAnim <= 0) return;
    W.gateAnim += dt;
    const g = W.floorGate;
    const t = clamp(W.gateAnim / LEVEL_CONFIG.floors.gateOpenTime, 0, 1);
    if (g.lid) g.lid.material.opacity = lerp(0.3, 0.03, t);
    if (g.ringMesh) { g.ringMesh.material.color.setHex(0x00ffaa); g.ringMesh.material.opacity = lerp(0.85, 0.35, t); }
    if (g.arc) g.arc.material.opacity = lerp(0.9, 0.12, t);
    if (g.group) g.group.position.y = -0.5 * t * t;   // створка проседает
    if (t >= 1) W.gateAnim = 0;
  }

  // крышка центрального люка этажа (0 — в дне чаши, 1/2 — в дисках)
  function makeGateLid(y, fIdx) {
    const hole = LEVEL_CONFIG.floors.holeR * 1;
    const grp = new THREE.Group();
    const lid = new THREE.Mesh(new THREE.CircleGeometry(hole, 48),
      new THREE.MeshBasicMaterial({ color: 0xff3355, transparent: true, opacity: 0.3, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    lid.rotation.x = -Math.PI / 2;
    lid.position.y = y + 0.06;
    grp.add(lid);
    const ring = ringMesh(hole, 0.07, 0xff3355, 0.85);
    ring.position.y = y + 0.09;
    grp.add(ring);
    (W.floorViz && W.floorViz[fIdx] ? W.floorViz[fIdx] : W.floorGroup).add(grp);
    const col = addFloorCol(makeRevolve('gateLid' + fIdx, profileGateLid(y), { e: 0.35 }));
    W.floorGates[fIdx] = { col: col, group: grp, lid: lid, ringMesh: ring, opened: false, floor: fIdx, cx: 0, cz: 0, cy: y };
    if (fIdx === W.currentFloor) W.floorGate = W.floorGates[fIdx];
  }

  // ===========================================================================
  // ГЛАВНЫЙ СТРОИТЕЛЬ ЭТАЖА
  // ===========================================================================
  // v4.1: вход на этаж — БЕЗ пересборки: башня из 4 этажей построена целиком
  // и этажи сосуществуют. Меняются только указатели состояния/палитры.
  // (имя buildFloor сохранено как тест-хук)
  function buildFloor(idx) {
    idx = clamp(idx | 0, 0, 3);
    W.currentFloor = idx;
    if(idx!==1)W.pipeExit=null;
    if(idx===3)W.finalView=null;
    W.floorState = W.floorStates ? W.floorStates[idx] : null;
    W.floorSolvedFlag = W.floorSolvedArr ? W.floorSolvedArr[idx] : false;
    W.floorGate = (W.floorGates && W.floorGates[idx]) || null;
    W.floorEntry = entryPointOf(idx);
    // трос виден только на первом этаже
    if (W.ropeMesh) W.ropeMesh.visible = (idx === 0);
    if (W.ropeAnchorMesh) W.ropeAnchorMesh.visible = idx === 0;
    syncFloorViz();
  }

  // v4.1: БАШНЯ — все 4 этажа строятся одновременно (Чаша 11 / Труба 8 /
  // Резонанс 5 / Ядро внизу). Спуск между этажами — только через центральные
  // люки, крышки которых открывает решённая загадка этажа.
  function buildAllFloors() {
    W.pipeExit=null;W.finalView=null;
    if (W.floorGroup) disposeGroup(W.floorGroup);
    W.colliders = W.colliders.filter(c => c.floor === undefined);
    W.fadeables = W.fadeables.filter(f => f.floor === undefined);
    for (const b of W.balls) {
      if (b.floor !== undefined) {
        b.alive = false;
        if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
      }
    }
    W.floorGroup = new THREE.Group();
    W.floorGroup.name = 'floorGroup';
    W.glassGroup.add(W.floorGroup);
    // v4.2: отдельная визуальная группа на этаж — скрытие пройденных
    W.floorViz = [0, 1, 2, 3].map(i => {
      const g = new THREE.Group();
      g.name = 'floorViz' + i;
      W.floorGroup.add(g);
      return g;
    });
    W.floorStates = [
      { sockets: null, chain: null, plates: null, solved: false },
      { sockets: null, chain: null, plates: null, solved: false },
      { sockets: null, chain: null, plates: null, solved: false },
      { sockets: null, chain: null, plates: null, solved: false }
    ];
    W.floorSolvedArr = [false, false, false, false];
    W.floorGates = [null, null, null];
    W.gateAnim = 0;
    W.floorTransition = null;
    W.floorState = W.floorStates[0];
    W.floorSolvedFlag = false;
    W.floorGate = null;
    W._buildFloor = 0; buildFloorBowl();          // этаж 0 «ЧАША»
    W._buildFloor = 1; buildFloorPipe();          // этаж 1 «ТРУБА»
    W._buildFloor = 2; buildFloorResonance();     // этаж 2 «РЕЗОНАНС»
    W._buildFloor = 3; buildFloorCore();          // этаж 3 «ЯДРО»
    W._buildFloor = -1;
    buildFloor(0);
    syncFloorViz();                               // v4.2: скрыть/призрак пройденных
  }

  // ---------------------------------------------------------------------------
  // ЭТАЖ 0 «ЧАША»: существующая площадка A + числовые лунки
  // ---------------------------------------------------------------------------
  function buildFloorBowl() {
    const A = LEVEL_CONFIG.platformA;
    const F = W.floorViz[0];
    W.floorState = W.floorStates[0];

    const profA = profilePlatformA();
    const meshA = new THREE.Mesh(lathe(profA, 128), MAT.silver.clone());
    meshA.name = 'platformA';
    F.add(meshA);
    W.fadeables.push({ mesh: meshA, base: 1.0, kind: 'platform', topY: A.y, floor: 0 });
    addFloorCol(makeRevolve('platformA',profilePlatformA(),{group:'platformA',e:.72,roll:.55}));

    const bowlRing = ringMesh(A.bowlRadius, 0.05, 0x00ffaa, 0.65);
    bowlRing.position.y = A.y + 0.01; F.add(bowlRing);
    const bowlRing2 = ringMesh(A.bowlRadius * 0.55, 0.04, 0x00d4ff, 0.5);
    bowlRing2.position.y = A.y - A.bowlDepth * 0.72; F.add(bowlRing2);

    // v4.1: бортик — ПОЛНЫЙ круг у самой стенки: перила сомкнуты, за них
    // выкатиться нельзя; сход с этажа — только через центральный люк чаши.
    const rimY = A.y + (A.rimY - A.y) * 1;
    const rimTube = A.rimTube * 1;
    const rimGroup = new THREE.Group();
    rimGroup.position.y = rimY;
    rimGroup.name = 'rimA';
    F.add(rimGroup);
    const rimArc = new THREE.Mesh(
      new THREE.TorusGeometry(A.rimRadius, rimTube, 14, 128),
      MAT.silverDark.clone()
    );
    rimArc.rotation.x = Math.PI / 2;
    rimGroup.add(rimArc);
    W.rimGroup = rimGroup;
    W.fadeables.push({ mesh: rimArc, base: 1.0, kind: 'platform', topY: rimY, floor: 0 });
    addFloorCol(makeTorusR('rimA', A.rimRadius, rimY, rimTube, { group: 'platformA' }));

    // ЛЮК этажа 0 — в дне чаши: крышка открывается решённой загадкой лунок
    makeGateLid(A.y - A.bowlDepth + 0.02, 0);

    // ---------- ЛУНКИ ----------
    // Коллайдеры лунок — позиционированные примитивы (revolve всегда осевой!):
    // «забор» из 8 вертикальных капсул (вершина на 2 см НИЖЕ диска — шар
    // перекатывается сверху свободно) + сфера-дно + сфера-крышка для полных.
    const L = LEVELS[W.currentLevel];
    const spec = L.sockets;
    const angs = spec.length === 1 ? [115] :
      spec.length === 2 ? [115, 295] :
      spec.length === 3 ? [55, 175, 295] :
      spec.length === 4 ? [45, 135, 225, 315] : [90, 162, 234, 306, 18];
    const rS = 1.2 * 1;
    const sockR = 6.2;
    W.floorState.sockets = [];
    const colorRun = { 0: 0, 1: 0, 2: 0 };
    const pref = ['R-A', 'B-A', 'Y-A'];
    const rStd = 0.62;

    spec.forEach((sp, i) => {
      const az = angs[i] * Math.PI / 180;
      const sx = Math.cos(az) * sockR, sz = Math.sin(az) * sockR;
      const sk = {
        id: i, color: sp[0], target: sp[1], count: 0, full: false,
        x: sx, z: sz, baseY: A.y, stack: 0, cols: []
      };
      // визуал: блюдце-гнездо на диске (револь-коллайдеры осевые, «настоящую»
      // дырку в диске сделать нельзя — лунка это зона с низким бортиком)
      const cupProf = [[0.06, A.y], [rS - 0.5, A.y], [rS - 0.12, A.y + 0.05], [rS, A.y + 0.1], [rS - 0.12, A.y + 0.05]];
      const cup = new THREE.Mesh(lathe(cupProf, 48), MAT.silver.clone());
      cup.position.set(sx, 0, sz);
      F.add(cup);
      // низкий бортик-губа: шары запрыгивают на скорости, медленные откатываются
      for (let k = 0; k < 8; k++) {
        const fa = k * Math.PI / 4;
        const fx = sx + Math.cos(fa) * rS, fz = sz + Math.sin(fa) * rS;
        const col = addFloorCol(makeCapsule('skf' + i + '_' + k,
          { x: fx, y: A.y - 0.06, z: fz }, { x: fx, y: A.y + 0.03, z: fz },
          0.12 * 1, { e: 0.5, group: 'socket' }));
        sk.cols.push(col);
      }
      // подсветка кромки цветом лунки
      const rim = ringMesh(rS + 0.1, 0.05, LEVEL_CONFIG.palette[sk.color].colorNum, 0.9);
      rim.position.set(sx, A.y + 0.03, sz);
      F.add(rim);
      sk.rim = rim;
      // «воротничок» заполненной лунки
      const collar = ringMesh(rS + 0.28, 0.07, 0x00ffaa, 0.0);
      collar.position.set(sx, A.y + 0.06, sz);
      F.add(collar);
      sk.collar = collar;
      // спрайт с цифрой и пи́псами прогресса
      makeSocketSprite(sk);
      W.floorState.sockets.push(sk);
      // запас: (target+1) шаров нужного цветау лунки
      const rackN = sp[1] + 1;
      const rackR = 8.3;
      const need = 2 * Math.asin(Math.min(1, (rStd * 1 * 2 * 1.02) / (2 * rackR))) * 180 / Math.PI;
      const stepDeg = Math.max(13, need);
      for (let j = 0; j < rackN; j++) {
        const a = az + (j - (rackN - 1) / 2) * stepDeg * Math.PI / 180;
        makeFloorBall({
          name: pref[sp[0]] + (++colorRun[sp[0]]),
          x: Math.cos(a) * rackR, y: A.y + rStd * 1, z: Math.sin(a) * rackR,
          r: rStd, colorIdx: sp[0], mounted: true
        });
      }
    });

    // v4.1: нейтральные тройки — только цвета, НЕ занятые лунками («сырьё» магии)
    const usedCols = {};
    spec.forEach(sp => usedCols[sp[0]] = true);
    if (!usedCols[PAL_C.blue]) magnetRing('B-A', 3, 7.0, [65, 80, 95], PAL_C.blue, rStd, A.y + rStd * 1);
    if (!usedCols[PAL_C.yellow]) magnetRing('Y-A', 3, 7.0, [245, 260, 275], PAL_C.yellow, rStd, A.y + rStd * 1);
    (function () {
      const a1 = 200 * Math.PI / 180, r1 = 8.4, rb1 = 0.95;
      makeFloorBall({ name: 'Lone-A1', x: Math.cos(a1) * r1, y: A.y + rb1 * 1, z: Math.sin(a1) * r1, r: rb1, colorIdx: PAL_C.red, mounted: true });
      const a2 = 95 * Math.PI / 180, r2 = 5.3, rb2 = 0.45;
      makeFloorBall({ name: 'Lone-A2', x: Math.cos(a2) * r2, y: A.y + rb2 * 1, z: Math.sin(a2) * r2, r: rb2, colorIdx: PAL_C.blue, mounted: true });
    })();
  }

  // спрайт лунки: цифра-цель + пи́псы прогресса
  function makeSocketSprite(sk) {
    const cv = document.createElement('canvas');
    cv.width = 128; cv.height = 168;
    const tex = new THREE.CanvasTexture(cv);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
    sp.scale.set(1.7, 2.2, 1);
    sp.position.set(sk.x, sk.baseY + 2.15, sk.z);
    if (W.floorViz) W.floorViz[0].add(sp);
    sk.sprite = sp; sk.cv = cv; sk.tex = tex;
    drawSocketSprite(sk);
  }

  function drawSocketSprite(sk) {
    const g = sk.cv.getContext('2d');
    if (!g) return;
    const col = sk.full ? '#00ffaa' : ('#' + LEVEL_CONFIG.palette[sk.color].colorNum.toString(16).padStart(6, '0'));
    g.clearRect(0, 0, 128, 168);
    g.fillStyle = 'rgba(4,10,24,0.78)';
    g.fillRect(10, 10, 108, 116);
    g.strokeStyle = col; g.lineWidth = 4;
    g.strokeRect(10, 10, 108, 116);
    g.fillStyle = col;
    g.font = 'bold 74px Arial';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(sk.target), 64, 66);
    // пи́псы
    for (let i = 0; i < sk.target; i++) {
      const px = 64 + (i - (sk.target - 1) / 2) * 32;
      g.beginPath();
      g.arc(px, 140, 10, 0, Math.PI * 2);
      if (i < sk.count) { g.fillStyle = '#00ffaa'; g.fill(); }
      else { g.strokeStyle = 'rgba(255,255,255,0.4)'; g.lineWidth = 3; g.stroke(); }
    }
    if (sk.full) {
      g.strokeStyle = '#00ffaa'; g.lineWidth = 6;
      g.beginPath(); g.moveTo(24, 24); g.lineTo(44, 44); g.moveTo(44, 24); g.lineTo(24, 44); g.stroke();
    }
    sk.tex.needsUpdate = true;
  }

  // попытка вставить шар в лунку (зона: шар в круге rS на высоте диска)
  function socketTryInsert(ball, sk) {
    if (W.currentFloor !== 0 || inTransition() || !ball.alive) return;
    if (ball.socketCd > 0 || sk.full) return;
    const A = LEVEL_CONFIG.platformA;
    if (ball.p.y > A.y + 1.6 || ball.p.y < A.y - 0.2) return;   // только у диска
    const kick = () => {
      ball.socketCd = 0.6;
      const dx = ball.p.x - sk.x, dz = ball.p.z - sk.z;
      const d = Math.hypot(dx, dz) || 1;
      ball.v.y += 4.2;
      ball.v.x += (dx / d) * 1.3 + rnd(-0.3, 0.3);   // выброс наружу от лунки
      ball.v.z += (dz / d) * 1.3 + rnd(-0.3, 0.3);
    };
    if (ball.isPlayer) { kick(); toast(D().socketPlayer, 'warn'); W.events.push({ t: W.time, type: 'socketPlayer' }); return; }
    if (ball.colorIdx !== sk.color) { kick(); Sound.reject(); if (W.runStats) W.runStats.socketFails++; toast(D().socketWrong, 'bad'); W.events.push({ t: W.time, type: 'socketWrong', ball: ball.name }); return; }
    if (sk.count >= sk.target) { kick(); Sound.reject(); toast(D().socketOverflow, 'bad'); return; }
    // приём: шар примагничивается в центр лунки (башенкой)
    sk.count++;
    ball.socketCd = 0;
    ball.mounted = true;
    ball.kinematic = true;
    ball.orbit = false;
    ball.noMagic = true;                        // вставленный шар больше не участвует в магии
    ball.mountPos.set(sk.x, A.y + ball.r + (sk.count - 1) * ball.r * 1.9, sk.z);
    ball.p.copy(ball.mountPos);
    ball.v.set(0, 0, 0);
    ball.flash = 0.25;
    drawSocketSprite(sk);
    Sound.socketIn();
    addScore(100, curLang === 'ru' ? 'лунка' : 'socket');
    W.events.push({ t: W.time, type: 'socketIn', socket: sk.id, ball: ball.name, count: sk.count });
    if (sk.count >= sk.target) {
      sk.full = true;
      for (const c of sk.cols) c.live = false;   // бортик больше не мешает
      if (sk.collar) sk.collar.material.opacity = 0.85;
      drawSocketSprite(sk);
      toast(D().socketFull + ' · ' + (sk.count + '/' + sk.target), 'good');
    }
    const all = W.floorState.sockets;
    if (all && all.every(q => q.full)) onFloorSolved();
  }

  // ---------------------------------------------------------------------------
  // ЭТАЖ 1 «ТРУБА»: плоский диск, жёлоб, домино-змейка
  // ---------------------------------------------------------------------------
  // ===========================================================================
  // ЭТАЖ 1 «ТРУБА» v4.2 — две дороги-жёлоба со спусковыми люками и мишенями
  // (ТЗ v4.2 п.2: закатить белый шар в люк дороги → цепочка катится к мишени,
  //  мишень засчитывает только шары целевого цвета; обе дороги решены → люк на
  //  этаж «Резонанс» открывается и шар магнитным потоком уходит вниз)
  // ===========================================================================
  const PIPE_ROADS = [
    {id:0,letter:'A',zc:4.8,xIn:-9.8,xOut:9.0},
    {id:1,letter:'B',zc:-4.8,xIn:-9.8,xOut:9.0}
  ];
  function validateRoad(spec) {
    if(!spec) return null;
    const a=spec.layout;
    if(!Array.isArray(a)||a.length<2||a.some(x=>x!=='K'&&x!=='S')) throw Error('Invalid road layout');
    if(a[0]!=='K') { const i=a.indexOf('K'); if(i<0)throw Error('Road needs K'); [a[0],a[i]]=[a[i],a[0]]; }
    if(a[1]!=='S') { const i=a.indexOf('S',2); if(i<0)throw Error('Road needs S'); [a[1],a[i]]=[a[i],a[1]]; }
    if(a.some((x,i)=>i&&x==='K'&&a[i-1]==='K'))throw Error('Consecutive K');
    return spec;
  }
  function litFloorMaterial(base) {
    const m=base.clone();
    m.metalness=.36;m.roughness=.48;
    m.emissive.copy(m.color);m.emissiveIntensity=.28;
    return m;
  }
  function buildFloorPipe() {
    const y=LEVEL_CONFIG.floorPipeY, F=W.floorViz[1], L=LV();
    W.floorState=W.floorStates[1];
    const prof=profileFloorDisc(y), disc=new THREE.Mesh(lathe(prof,64),litFloorMaterial(MAT.silver));disc.name="pipeFloorSurface";
    F.add(disc); addFloorCol(makeRevolve('floorPipe',prof,{group:'floorPipe'})); makeGateLid(y,1);
    W.floorState.pipe={roads:[]};
    PIPE_ROADS.forEach((rd,i)=>{
      const spec=validateRoad(L.pipe.roads[i]);
      const st={id:rd.id,letter:rd.letter,def:rd,layout:spec&&spec.layout,color:L.pipe.color,balls:[],markers:[],hit:0,dropped:0,need:0,solved:false,gaps:[],gapSide:spec?spec.gapSide:1,deckY:y+0.85};
      W.floorState.pipe.roads.push(st); if(!spec)return;
      st.halfWidth=Math.max(1.25,LEVEL_CONFIG.player.radius*1+0.5);
      const radius=0.62*1, pitch=2*radius+0.035;
      // Compress only pitch by selecting a longer rail when scaling is extreme, never ball sizes.
      st.front=rd.xOut-0.75; st.pitch=pitch;
      const firstX=st.front-(st.layout.length-1)*pitch;
      st.startX=Math.min(rd.xIn,firstX-1.2);
      const gaps=Array.isArray(spec.gapAfter)?spec.gapAfter:[spec.gapAfter];
      st.gapAfter=spec.gapAfter;
      const gapWidth=2*radius+0.14;
      st.gaps=gaps.map(j=>({x:st.front-(j+0.5)*pitch,half:gapWidth/2}));
      const rampLen=2.8;
      const ramp=rampMesh50(st.startX-rampLen,st.startX,y,st.deckY,rd.zc,st.halfWidth*2);F.add(ramp);
      addFloorCol({type:'pipeRamp',halfWidth:st.halfWidth,name:'pipeRamp'+i,x0:st.startX-rampLen,x1:st.startX,z:rd.zc,y0:y,y1:st.deckY,live:true});
      st.exitEnd=rd.xOut+3;
      const exitRamp=rampMesh50(rd.xOut+1,st.exitEnd,st.deckY,y,rd.zc,st.halfWidth*2);F.add(exitRamp);
      addFloorCol({type:'pipeRamp',halfWidth:st.halfWidth,name:'pipeExitRamp'+i,x0:rd.xOut+1,x1:st.exitEnd,z:rd.zc,y0:st.deckY,y1:y,live:true});
      const material=new THREE.MeshStandardMaterial({color:LEVEL_CONFIG.palette[st.color].colorNum,emissive:LEVEL_CONFIG.palette[st.color].colorNum,emissiveIntensity:0.6,metalness:0.45,roughness:0.3});
      const deck=new THREE.Mesh(new THREE.BoxGeometry(rd.xOut+1-st.startX,0.18,st.halfWidth*2),litFloorMaterial(MAT.silverDark));
      deck.position.set((st.startX+rd.xOut+1)/2,st.deckY-0.09,rd.zc);F.add(deck);
      addFloorCol(makeBox('pipeDeck'+i,deck.position.x,deck.position.y,rd.zc,(rd.xOut+1-st.startX)/2,0.09,st.halfWidth,{group:'pipeDeck',e:0.25}));
      const rail=(a,b,side)=>{
        if(b<=a)return;
        const cy=st.deckY+0.45,z=rd.zc+side*st.halfWidth;
        addFloorCol(makeCapsule('pipeRail'+i+'_'+a+'_'+side,{x:a,y:cy,z},{x:b,y:cy,z},0.18,{group:'trough',e:0.25}));
        const m=new THREE.Mesh(new THREE.CylinderGeometry(0.18,0.18,b-a,8),MAT.silverDark.clone());m.rotation.z=Math.PI/2;m.position.set((a+b)/2,cy,z);F.add(m);
      };
      rail(st.startX,rd.xOut+1,-st.gapSide);
      let edge=st.startX;
      for(const gap of [...st.gaps].sort((a,b)=>a.x-b.x)) {
        rail(edge,gap.x-gap.half-0.16,st.gapSide);edge=gap.x+gap.half+0.16;
        const z=rd.zc+st.gapSide*st.halfWidth, cy=st.deckY+0.4;
        for(const sg of [-1,1]){
          addFloorCol(makeCapsule('gapEdge'+i+'_'+gap.x+'_'+sg,{x:gap.x+sg*(gap.half+0.16),y:st.deckY,z},{x:gap.x+sg*(gap.half+0.16),y:st.deckY+1.3*radius,z},0.07,{group:'pipeGap'}));
        }
        const filter=makeBox('colorFilter'+i+'_'+gap.x,gap.x,cy,z,gap.half,0.6,0.045,{group:'pipeFilter',e:0.15});filter.filterColor=st.color;filter.filterRoad=st.id;addFloorCol(filter);
        for(let k=0;k<4;k++){
          const grate=new THREE.Mesh(new THREE.BoxGeometry(0.045,1.3*radius,0.055),material);
          grate.position.set(gap.x-gap.half+(k+0.5)*gapWidth/4,cy,z);F.add(grate);
        }
        const chute=new THREE.Mesh(new THREE.BoxGeometry(gapWidth+0.2,0.12,2.4),MAT.silverDark.clone());
        chute.rotation.x=st.gapSide*0.36;chute.position.set(gap.x,st.deckY-0.3,z+st.gapSide*0.9);F.add(chute);
      }
      rail(edge,rd.xOut+1,st.gapSide);st.filterMat=material;
      const pocket=new THREE.Mesh(new THREE.CylinderGeometry(0.9,1.1,0.2,24),material.clone());
      pocket.position.set(rd.xOut+0.25,st.deckY,rd.zc);F.add(pocket);st.pocket=pocket;
      const hatch=ringMesh(0.8,0.04,LEVEL_CONFIG.palette[st.color].colorNum,0.8);hatch.position.set(st.startX,st.deckY+0.02,rd.zc);F.add(hatch);st.hatch=hatch;
      st.need=st.layout.filter(t=>t==='K').length;
      st.layout.forEach((t,j)=>{
        const b=makeFloorBall({name:'P'+rd.letter+(j+1),x:st.front-j*pitch,y:st.deckY+radius,z:rd.zc,r:0.62,colorIdx:t==='K'?st.color:(st.color+1+j%2)%3,mounted:true,noMagic:true});
        b.pipeType=t;b.pipeRoad=st.id;b.gapChecked=false;b.gapChecks={};b.pipeInitial=b.p.clone();
        b.reservePos=new THREE.Vector3(-9+j*1.35,y+radius,rd.zc+st.gapSide*3.1);
        st.balls.push(b);
        if(t==='K'){
          const marker=new THREE.Mesh(new THREE.SphereGeometry(0.12,8,6),new THREE.MeshBasicMaterial({color:LEVEL_CONFIG.palette[st.color].colorNum}));
          F.add(marker);st.markers.push({ball:b,mesh:marker});
        }
      });
      makeRoadBar(st);drawRoadBar(st);
    });
  }
  function makeRoadBar(st){
    const cv=document.createElement('canvas');cv.width=192;cv.height=128;
    const tex=new THREE.CanvasTexture(cv),sp=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,depthWrite:false}));
    sp.scale.set(2.2,1.47,1);sp.position.set(st.def.xOut+0.2,st.deckY+2.1,st.def.zc);W.floorViz[1].add(sp);
    Object.assign(st,{cv,tex,sprite:sp});
  }
  function drawRoadBar(st){
    const g=st.cv.getContext('2d');g.clearRect(0,0,192,128);g.fillStyle='#10182c';g.fillRect(3,3,186,122);
    const color=st.solved?'#44ff99':'#'+LEVEL_CONFIG.palette[st.color].colorNum.toString(16).padStart(6,'0');g.strokeStyle=color;g.lineWidth=4;g.strokeRect(3,3,186,122);
    g.textAlign='center';g.fillStyle=color;g.font='bold 48px system-ui';g.fillText(st.hit+' / '+st.need,96,63);
    g.fillStyle='#a3abba';g.font='24px system-ui';g.fillText('↓ S: '+st.dropped,96,105);st.tex.needsUpdate=true;
  }
  function resetPipeRoad(st,reason){
    if(AUTO.pipe&&AUTO.pipe.road===st.id)AUTO.pipe=null;
    if(!st.layout)return;st.hit=0;st.dropped=0;st.solved=false;
    for(const b of st.balls){
      b.alive=true;b.pipeDone=false;b.pipeLock=false;b.pipeEval=false;b.gapChecked=false;b.gapChecks={};b.gapFalling=false;b.gapT=0;b.prevPipeX=undefined;b.noMagic=true;
      b.homePos.copy(b.pipeInitial);b.homeMounted=true;b.mountPos.copy(b.pipeInitial);respawnBallHome(b);
      if(!W.balls.includes(b))W.balls.push(b);if(!b.mesh.parent)W.floorViz[1].add(b.mesh);if(!b.ring.parent)W.floorViz[1].add(b.ring);b.mesh.visible=true;
    }
    drawRoadBar(st);
  }
  function resetPipeRoads(reason){
    W.pipeExit=null;AUTO.pipe=null;
    if(W.currentFloor===1){setSolvedFlag(false);closeGate(1);}
    if(reason==='button'&&W.runStats)W.runStats.roadResets++;
    const ps=W.floorStates&&W.floorStates[1].pipe;if(!ps)return;
    for(const st of ps.roads)resetPipeRoad(st,reason);
  }
  function pipeDrop(st,b){
    if(b.gapFalling||b.pipeDone)return;
    b.gapChecked=true;b.gapFalling=true;b.mounted=false;b.kinematic=true;b.gapT=0;b.gapFrom=b.p.clone();
    b.v.z+=st.gapSide*2.2;b.v.y-=1;st.dropped++;
    Sound.reject();toast(D().pipeWrongDrop,'warn',1200);drawRoadBar(st);
  }
  function pipeArrive(st,b){
    if(b.isPlayer||b.pipeRoad!==st.id||b.pipeDone||b.gapFalling)return;
    if(b.colorIdx!==st.color){pipeDrop(st,b);return;}
    b.pipeDone=true;b.pipeLock=true;b.mounted=true;b.kinematic=true;b.v.set(0,0,0);st.hit++;
    // Separate display rack behind the side rail; never block the travelling column.
    b.p.set(8-(st.hit-1)*1.35,LEVEL_CONFIG.floorPipeY+b.r,st.def.zc-st.gapSide*2.7);b.mountPos.copy(b.p);
    st.solved=st.hit>=st.need;drawRoadBar(st);Sound.floorDone();
    if(st.solved)toast(D().pipeRoadDone.replace('{r}',st.letter),'good',1600);
  }
  function updatePipe(dt){
    const ps=W.floorState&&W.floorState.pipe;if(!ps||W.state!=='play'||inTransition())return;
    for(const st of ps.roads){
      if(!st.layout)continue;
      st.filterMat.emissiveIntensity=0.6+0.08*Math.sin(W.time*3);
      for(const b of st.balls){
        if(!b.alive||b.pipeDone)continue;
        if(b.gapFalling){
          b.gapT+=dt;const t=clamp(b.gapT/0.85,0,1);
          b.p.set(b.gapFrom.x,b.gapFrom.y-1.2*t*t,b.gapFrom.z+st.gapSide*2.4*t);
          if(t>=1){b.gapFalling=false;b.pipeDone=true;b.noMagic=false;b.homePos.copy(b.reservePos);b.homeMounted=true;b.mountPos.copy(b.reservePos);respawnBallHome(b);}
          continue;
        }
        for(let j=0;j<st.gaps.length;j++){
          const gap=st.gaps[j];
          const crosses=b.prevPipeX!==undefined&&b.prevPipeX<gap.x&&b.p.x>=gap.x;
          if(st.hit>0 && b.pipeInitial.x<gap.x && !b.gapChecks[j]&&!b.mounted&&Math.abs(b.p.z-st.def.zc)<1.25&&b.p.x>=gap.x-0.1){
            b.gapChecks[j]=true;b.gapChecked=true;
            if(b.colorIdx!==st.color)pipeDrop(st,b);else Sound.socketIn();
          }
        }
        b.prevPipeX=b.p.x;
        if(!b.gapFalling&&!b.mounted&&b.p.x>=st.def.xOut-0.1&&Math.abs(b.p.z-st.def.zc)<1.25)pipeArrive(st,b);
        if(!b.gapFalling&&!b.pipeDone&&b.p.y<st.deckY-0.25){
          if(b.colorIdx!==st.color)pipeDrop(st,b);
          else {b.p.copy(b.pipeInitial);b.v.set(0,0,0);b.mounted=true;b.kinematic=true;b.mountPos.copy(b.p);b.gapChecks={};b.gapChecked=false;}
        }
      }
      for(const mk of st.markers){mk.mesh.visible=mk.ball.alive&&!mk.ball.pipeDone;mk.mesh.position.copy(mk.ball.p);mk.mesh.position.y+=0.9;}
    }
    const roads=ps.roads.filter(s=>s.layout);
    if(roads.length&&roads.every(s=>s.solved)&&!W.floorSolvedFlag)onFloorSolved();
    const gate=W.floorGates[1];if(W.floorSolvedFlag&&gate.opened&&!gate.pulled&&!W.pipeExit)startPipeExit();
  }

  // ===========================================================================
  // v4.2: магнитный поток — решённый этаж сам уводит шар в центральный люк
  // ===========================================================================
  function startAutoPull(floorIdx) {
    if(floorIdx===1){startPipeExit();return;}
    const pl = W.player;
    if (!pl || !pl.alive) return;
    // один поток на решённый этаж: без флага триггер перезахватывал шар
    // сразу после отпускания, и шар зависал над люком
    const gg = W.floorGates && W.floorGates[floorIdx];
    if (gg) gg.pulled = true;
    W.autoPull = {
      active: true, t: 0, dur: 1.5, floor: floorIdx,
      from: { x: pl.p.x, z: pl.p.z }, y: pl.p.y
    };
    pl.kinematic = true;
    pl.v.set(0, 0, 0);
    Sound.ui();
    W.events.push({ t: W.time, type: 'autoPull', floor: floorIdx });
  }

  function updateAutoPull(dt) {
    const ap = W.autoPull;
    if (!ap || !ap.active) return;
    const pl = W.player;
    if (!pl || !pl.alive || W.state !== 'play') { W.autoPull = null; return; }
    W.tilt.active = false;
    W.tilt.tRotX = 0; W.tilt.tRotZ = 0;
    ap.t += dt;
    const k = clamp(ap.t / ap.dur, 0, 1);
    const e = k * k * (3 - 2 * k);
    const r = Math.hypot(pl.p.x, pl.p.z);
    const targetY = floorY(ap.floor) + pl.r + 0.05;
    pl.p.x = lerp(ap.from.x, 0, e);
    pl.p.z = lerp(ap.from.z, 0, e);
    pl.p.y = targetY + Math.max(0, (ap.y - targetY)) * (1 - e);
    if (pl.mesh) pl.mesh.position.copy(pl.p);
    if (k >= 1 || r < 0.35) {
      ap.active = false;
      W.autoPull = null; W.pipeExit=null;
      pl.kinematic = false;
      pl.mounted = false;
      pl.v.set(0, -0.8, 0);                     // отпуск в открытый люк
    }
  }

  // ===========================================================================
  // ЭТАЖ 2 «РЕЗОНАНС» v4.2 — три плиты-стенки: бей гранью с нужной скоростью
  // (ТЗ v4.2 п.3: зелёная слабо / жёлтая средне / красная сильно; чужой шар
  //  нужной силы ГАСИТ активную плиту — с 6-го уровня на полу шары-помехи)
  // ===========================================================================
  // Continuous containment, including CCD/ball-ball correction and high rebounds.
  function protectResonancePerimeter() {
    if(W.currentFloor!==2)return;
    for(const b of W.balls){
      if(!b.alive || b.returning || (!b.isPlayer&&b.floor!==2))continue;
      const r=Math.hypot(b.p.x,b.p.z),limit=Math.max(1,7.78-b.r);
      if(r<=limit)continue;
      const nx=b.p.x/r,nz=b.p.z/r;
      b.p.x=nx*limit;b.p.z=nz*limit;
      const outward=b.v.x*nx+b.v.z*nz;
      if(outward>0){b.v.x-=nx*outward*1.22;b.v.z-=nz*outward*1.22;}
      // The centre hatch is untouched; only an out-of-bounds perimeter crossing is repaired.
      if(b.p.y<LEVEL_CONFIG.platformB.y+b.r) {b.p.y=LEVEL_CONFIG.platformB.y+b.r;b.v.y=Math.max(0,b.v.y);}
    }
  }
  function buildFloorResonance() {
    const y = LEVEL_CONFIG.platformB.y;
    const L = LEVELS[W.currentLevel];
    const F = W.floorViz[2];
    W.floorState = W.floorStates[2];

    // v4.2: пол радиуса 8 (ТЗ) + сомкнутое перило по кромке — с этажа не сойти
    const R = 8.0, hole = LEVEL_CONFIG.floors.holeR * 1;
    const prof = [
      [R, y],
      [hole + 0.3, y],
      [hole, y - 0.05],
      [hole, y - 0.45],
      [hole + 0.2, y - 0.5],
      [R - 0.3, y - 0.6],
      [R, y]
    ];
    const meshD = new THREE.Mesh(lathe(prof, 96), MAT.silver.clone());
    meshD.name = 'platformB';
    F.add(meshD);
    W.fadeables.push({ mesh: meshD, base: 1.0, kind: 'platform', topY: y, floor: 2 });
    addFloorCol(makeRevolve('platformB', prof, { group: 'platformB' }));
    makeGateLid(y, 2);
    // перила этажа
    const railT = 0.32 * 1;
    const rim = new THREE.Mesh(new THREE.TorusGeometry(R - 0.28, railT, 12, 96), MAT.silverDark.clone());
    rim.rotation.x = Math.PI / 2;
    rim.position.y = y + 0.34;
    F.add(rim);
    addFloorCol(makeTorusR('rimB', R - 0.28, y + 0.34, railT, { group: 'platformB' }));

    // v4.6: tall continuous guardrail, matching the upper floors.
    const fenceR=7.88,fenceHeight=2.5;
    for(const h of [1.2,fenceHeight]){
      const rail=new THREE.Mesh(new THREE.TorusGeometry(fenceR,0.11,8,MOBILE?48:80),MAT.silverDark.clone());
      rail.rotation.x=Math.PI/2;rail.position.y=y+h;F.add(rail);
    }
    const posts=new THREE.InstancedMesh(new THREE.CylinderGeometry(0.07,0.09,fenceHeight,6),MAT.silverDark.clone(),12);
    const matrix=new THREE.Matrix4();
    for(let i=0;i<12;i++){const a=i*Math.PI/6;matrix.makeTranslation(Math.cos(a)*fenceR,y+fenceHeight/2,Math.sin(a)*fenceR);posts.setMatrixAt(i,matrix);}
    F.add(posts);
    const guard=new THREE.Mesh(new THREE.CylinderGeometry(fenceR,fenceR,fenceHeight,MOBILE?48:80,1,true),
      new THREE.MeshBasicMaterial({color:0x8bcfe8,transparent:true,opacity:0.085,side:THREE.DoubleSide,depthWrite:false}));
    guard.position.y=y+fenceHeight/2;F.add(guard);
    // Floor-scoped cylinder and substep safety boundary prevent jumping over a low torus.
    addFloorCol(makeCyl('resonanceFence',7.78,y-0.7,LEVEL_CONFIG.glass.yTop+6,{e:0.22,group:'resonanceFence'}));

    // ---------- ТРИ ПЛИТЫ-СТЕНКИ ----------
    // v4.2: тройка плит повернута на 30° (300°/60°/180°) — ось люка x=0 и z<0
    // свободна для нырка к ядру: плиты не перегораживают разгонный коридор
    const P3 = [
      { id: 0, kind: 'weak',   colHex: 0x00ff88, x: 3.35,  z: -5.80 },
      { id: 1, kind: 'mid',    colHex: 0xffcc00, x: 3.35,  z: 5.80 },
      { id: 2, kind: 'strong', colHex: 0xff3355, x: -6.7,  z: 0.0 }
    ];
    W.floorState.plates = [];
    for (const pd of P3) {
      const band = L.plate3[pd.kind];
      const plate = {
        id: pd.id, kind: pd.kind, x: pd.x, z: pd.z, band: { min: band[0], max: band[1] },
        active: false, cool: 0, lastV: 0, insideBy: {}, barT: 0,
        kindColor: pd.colHex
      };
      // плита-стенка: квадрат 1.2×1.2 «лицом» к центру, толщина 0.4
      const ang = Math.atan2(pd.z, pd.x) + Math.PI / 2;   // ориентация грани к центру
      const hgt = 1.2, thk = 0.4;
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.2, hgt, thk),
        new THREE.MeshStandardMaterial({ color: pd.colHex, metalness: 0.72, roughness: 0.18, emissive: pd.colHex, emissiveIntensity: 0.35 }));
      const rotY = -Math.atan2(pd.z, pd.x) + Math.PI / 2;
      mesh.position.set(pd.x, y + hgt / 2, pd.z);
      mesh.rotation.y = rotY;
      F.add(mesh);
      plate.mesh = mesh;
      plate.rotY = rotY;
      // Four bevel-like polished strips around the face, shared material.
      const trimMat=MAT.silver.clone();
      for(const q of [[0,0.66,1.42,0.10],[0,-0.66,1.42,0.10],[-0.66,0,0.10,1.22],[0.66,0,0.10,1.22]]){
        const trim=new THREE.Mesh(new THREE.BoxGeometry(q[2],q[3],0.48),trimMat);trim.position.set(q[0],q[1],0);mesh.add(trim);
      }
      const cv=document.createElement('canvas');cv.width=192;cv.height=96;
      const ctx=cv.getContext('2d'),count=pd.id+1;ctx.fillStyle='#0a1325';ctx.fillRect(4,4,184,88);
      ctx.strokeStyle='#'+pd.colHex.toString(16).padStart(6,'0');ctx.lineWidth=4;ctx.strokeRect(4,4,184,88);
      ctx.fillStyle=ctx.strokeStyle;
      for(let k=0;k<count;k++){const x=96-count*23+k*46;ctx.beginPath();ctx.moveTo(x+20,12);ctx.lineTo(x,49);ctx.lineTo(x+17,49);ctx.lineTo(x+6,84);ctx.lineTo(x+39,40);ctx.lineTo(x+23,40);ctx.fill();}
      const icon=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(cv),depthWrite:false}));icon.scale.set(1.9,0.95,1);icon.position.set(pd.x,y+2.55,pd.z);F.add(icon);plate.forceIcon=icon;

      // физика: две капсулы вдоль ширины плиты (грань к центру — любая ориентация)
      const wx = Math.cos(rotY), wz = -Math.sin(rotY);
      for (let hy = 0.35; hy <= 0.95; hy += 0.5) {
        addFloorCol(makeCapsule('plate3_' + pd.id + '_' + hy,
          { x: pd.x - 0.55 * wx, y: y + hy, z: pd.z - 0.55 * wz },
          { x: pd.x + 0.55 * wx, y: y + hy, z: pd.z + 0.55 * wz }, 0.21, { e: 0.55, group: 'plate3' }));
      }
      const glow = ringMesh(0.95, 0.06, pd.colHex, 0.85);
      glow.rotation.x = -Math.PI / 2;
      glow.position.set(pd.x, y + 0.06, pd.z);
      F.add(glow);
      plate.ring = glow;
      makePlateBar(plate);
      drawPlateBar(plate, -1);
      W.floorState.plates.push(plate);
    }

    // индикатор люка: три квадратика над заглушкой
    {
      const cv = document.createElement('canvas');
      cv.width = 160; cv.height = 56;
      const tex = new THREE.CanvasTexture(cv);
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0.95, depthWrite: false }));
      sp.scale.set(2.0, 0.7, 1);
      sp.position.set(0, y + 2.3, 0);
      F.add(sp);
      W.floorState.hatchSprite = { cv, tex, sprite: sp };
    }

    // ---------- шары-помехи (L6+) ----------
    W.floorState.hazards = [];
    const hz = L.hazards || 0;
    const spots = hz === 1 ? [[0, -6.1]] : [[4.4, -6.2], [-4.4, -6.2]];
    for (let i = 0; i < hz; i++) {
      const b = makeFloorBall({
        name: 'Hz' + (i + 1), x: spots[i][0], y: y + 0.62 * 1, z: spots[i][1],
        r: 0.62, colorIdx: (i + 1) % 3, mounted: false
      });
      b.hazard = true;
      W.floorState.hazards.push(b);
    }
    drawHatchSprite();
  }

  function drawHatchSprite() {
    const hs = W.floorStates[2] && W.floorStates[2].hatchSprite;
    if (!hs || !hs.cv.getContext) return;
    const g = hs.cv.getContext('2d');
    g.clearRect(0, 0, 160, 56);
    const plates = W.floorStates[2].plates || [];
    for (let i = 0; i < 3; i++) {
      g.fillStyle = (plates[i] && plates[i].active) ? '#00ff88' : 'rgba(255,255,255,0.16)';
      g.fillRect(28 + i * 36, 12, 26, 26);
      g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = 2;
      g.strokeRect(28 + i * 36, 12, 26, 26);
    }
    hs.tex.needsUpdate = true;
  }

  // термометр скорости над плитой (v<0 — пустой)
  function makePlateBar(plate) {
    const cv = document.createElement('canvas');
    cv.width = 64; cv.height = 160;
    const tex = new THREE.CanvasTexture(cv);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0, depthWrite: false }));
    sp.scale.set(0.75, 1.9, 1);
    sp.position.set(plate.x, LEVEL_CONFIG.platformB.y + 2.0, plate.z);
    if (W.floorViz && W.floorViz[2]) W.floorViz[2].add(sp);
    plate.cv = cv; plate.tex = tex; plate.sprite = sp;
    drawPlateBar(plate, -1);
  }

  function drawPlateBar(plate, v) {
    const g = plate.cv && plate.cv.getContext && plate.cv.getContext('2d');
    if (!g) return;
    g.clearRect(0, 0, 64, 160);
    g.fillStyle = 'rgba(4,10,24,0.75)';
    g.fillRect(18, 8, 28, 144);
    if (v >= 0) {
      const VMAX = 14;
      const hgt = clamp(v / VMAX, 0, 1) * 140;
      let col = '#ff5566';
      if (v >= plate.band.min && v <= plate.band.max) col = '#00ff88';
      else if (v > plate.band.max) col = '#ffcc00';
      g.fillStyle = col;
      g.fillRect(20, 150 - hgt, 24, hgt);
    }
    const yOf = w => 150 - clamp(w / 14, 0, 1) * 140;
    g.strokeStyle = 'rgba(255,255,255,0.75)'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(16, yOf(plate.band.min)); g.lineTo(48, yOf(plate.band.min)); g.stroke();
    g.beginPath(); g.moveTo(16, yOf(plate.band.max)); g.lineTo(48, yOf(plate.band.max)); g.stroke();
    plate.tex.needsUpdate = true;
  }

  // v4.2: удар в плиту-стенку. ball — игровой ИЛИ чужой свободный шар
  function plateImpact(ball, plate) {
    if (plate.cool > 0) return;
    const prefix='plate3_'+plate.id+'_';
    let v=0;
    for(const key in (ball.plateSpeeds||{}))if(key.startsWith(prefix))v=Math.max(v,ball.plateSpeeds[key]);
    if(!v)v=Math.abs(ball.v.x*Math.sin(plate.rotY)+ball.v.z*Math.cos(plate.rotY));
    plate.lastV = v;
    plate.cool = 0.45;
    plate.barT = 0.65;
    drawPlateBar(plate, v);
    if (plate.sprite) plate.sprite.material.opacity = 1;
    const inBand = v >= plate.band.min && v <= plate.band.max;
    const bandStr = plate.band.min.toFixed(1) + '–' + plate.band.max.toFixed(1);

    if (ball.isPlayer) {
      if (plate.active) return;                       // активную игрок не гасит
      if (inBand) {
        plate.active = true;
        if (plate.mesh) { plate.mesh.material.emissive.setHex(0x00ff88); plate.mesh.material.emissiveIntensity = 1.6; }
        if (plate.ring) plate.ring.material.color.setHex(0x00ffaa);
        Sound.plateOk();
        toast(D().plateOn[plate.kind].replace('{v}', bandStr), 'good', 1500);
        addScore(150, curLang === 'ru' ? 'плита' : 'plate');
        W.events.push({ t: W.time, type: 'plateOn', plate: plate.id, v: v, by: 'player' });
        drawHatchSprite();
        checkPlatesSolved();
      } else if (v < plate.band.min) {
        toast(D().plateTooWeak.replace('{v}', bandStr), 'warn', 1200);
        Sound.plateBad();
        ball.v.multiplyScalar(0.7);
        W.runStats.plateFails++;
        W.events.push({ t: W.time, type: 'plateMiss', plate: plate.id, v: v, why: 'weak' });
      } else {
        toast(D().plateTooStrong.replace('{v}', bandStr), 'warn', 1200);
        Sound.plateBad();
        ball.v.multiplyScalar(0.9);
        W.runStats.plateFails++;
        W.events.push({ t: W.time, type: 'plateMiss', plate: plate.id, v: v, why: 'strong' });
      }
      return;
    }

    // чужой свободный шар той же силой: активную ГАСИТ, неактивную — включает
    if (!inBand) return;
    if (plate.active) {
      plate.active = false;
      if (plate.mesh) { plate.mesh.material.emissive.setHex(plate.kindColor); plate.mesh.material.emissiveIntensity = 0.55; }
      if (plate.ring) plate.ring.material.color.setHex(plate.kindColor);
      Sound.defeat();
      doShake(true);
      drawHatchSprite();
      W.events.push({ t: W.time, type: 'plateOff', plate: plate.id, v: v, by: ball.name });
      const st2 = W.floorStates[2];
      if (st2 && !st2.deactShown) {
        st2.deactShown = true;
        askFloorFail('plate');
      } else {
        toast(D().plateOff, 'bad', 1800);
      }
    } else {
      plate.active = true;
      if (plate.mesh) { plate.mesh.material.emissive.setHex(0x00ff88); plate.mesh.material.emissiveIntensity = 1.6; }
      if (plate.ring) plate.ring.material.color.setHex(0x00ffaa);
      Sound.plateOk();
      drawHatchSprite();
      W.events.push({ t: W.time, type: 'plateOn', plate: plate.id, v: v, by: ball.name });
      checkPlatesSolved();
    }
  }

  function checkPlatesSolved() {
    const st = W.floorStates[2];
    if (!st || !st.plates || st.solved) return;
    if (st.plates.every(q => q.active)) onFloorSolved();
  }

  // ежекадровая логика плит: вход в расширенную зону плиты = удар
  function updatePlates(dt) {
    const plates = W.floorState && W.floorState.plates;
    if (!plates) return;
    const live = (W.state === 'play') && !inTransition();
    const st2 = W.floorStates[2];
    if (st2 && st2.plPulse > 0) {                        // v4.2: обучение — пульс плит
      st2.plPulse -= dt;
      const pk = 0.55 + 0.5 * (0.5 + 0.5 * Math.sin(W.time * 7));
      for (const p of plates) {
        if (!p.active && p.mesh && p.mesh.material) p.mesh.material.emissiveIntensity = pk;
      }
    }
    for (const p of plates) {
      if(!p.active && p.mesh) { p.mesh.material.emissiveIntensity=0.32+0.12*Math.sin(W.time*2+p.id);p.mesh.material.color.setHex(p.kindColor).offsetHSL(0.025*Math.sin(W.time+p.id),0,0); }
      if (p.cool > 0) p.cool -= dt;
      if (p.barT > 0) {
        p.barT -= dt;
        if (p.sprite) p.sprite.material.opacity = clamp(p.barT / 0.3, 0, 1);
      }
      if (!live) continue;
      const py = LEVEL_CONFIG.platformB.y;
      const ct = Math.cos(p.rotY || 0), sn = Math.sin(p.rotY || 0);
      for (const b of W.balls) {
        if (!b.alive || b.kinematic || b.inTrap) continue;
        if (!b.isPlayer && (b.floor !== 2 || b.pipeType)) continue;   // чужие — только шары этого этажа
        const dx = b.p.x - p.x, dz = b.p.z - p.z;
        const lx = dx * ct - dz * sn;                     // вдоль ширины плиты
        const lz = dx * sn + dz * ct;                     // вдоль толщины (нормаль грани)
        const mW = 0.6 + b.r + 0.07, mN = 0.2 + b.r + 0.07, mY = 0.6 + b.r + 0.07;
        const inside = Math.abs(lx) < mW && Math.abs(lz) < mN && Math.abs(b.p.y - (py + 0.6)) < mY;
        const key = b.isPlayer ? 'P' : b.name;
        if (inside && !p.insideBy[key] && Object.keys(b.plateSpeeds||{}).some(k=>k.startsWith('plate3_'+p.id+'_'))) {
          p.insideBy[key] = true;
          if (p.cool <= 0) plateImpact(b, p);
        } else if (!inside && p.insideBy[key]) {
          p.insideBy[key] = false;
        }
      }
    }
    // поток к люку после решения
    const st = W.floorStates[2];
    if (st && st.solved && W.currentFloor === 2) {
      const g = W.floorGates[2];
      const pl = W.player;
      if (g && g.opened && !g.pulled && !W.autoPull && pl && pl.alive && W.state === 'play' &&
          pl.p.y < LEVEL_CONFIG.platformB.y + 3 && pl.p.y > LEVEL_CONFIG.platformB.y - 0.5 && !inTransition()) {
        startAutoPull(2);
      }
    }
  }

  // v4.2: рестарт этажа «Резонанс» (кнопка/модалка)
  function restartResonanceFloor() {
    const st = W.floorStates[2];
    if (!st) return;
    for (const p of (st.plates || [])) {
      p.active = false; p.cool = 0; p.lastV = 0; p.insideBy = {};
      if (p.mesh) { p.mesh.material.emissive.setHex(p.kindColor); p.mesh.material.emissiveIntensity = 0.55; }
      if (p.ring) p.ring.material.color.setHex(p.kindColor);
      drawPlateBar(p, -1);
    }
    for (const b of (st.hazards || [])) respawnBallHome(b);
    drawHatchSprite();
    // люк закрывается, флаг решения снимается
    closeGate(2);
    setFloorSolvedFlag(2, false);
    // шар на точку входа этажа
    const pl = W.player;
    if (pl && W.floorEntry) {
      pl.p.copy(W.floorEntry);
      pl.v.set(0, 0, 0);
      pl.kinematic = false; pl.mounted = false;
      pl.returning = false; pl.idleT = 0;
      W.trapTimer = -1;
    }
    W.autoPull = null;
    toast(D().floorRestarted, 'good', 1600);
    Sound.ui();
    W.events.push({ t: W.time, type: 'floorRestart', floor: 2 });
  }

  // ===========================================================================
  // v4.2: НЕВЫПОЛНИМЫЙ ЭТАЖ — модалка «заново / в меню»
  // ===========================================================================
  function askFloorFail(reason) {
    if (W.ffOpen || W.state !== 'play') return;
    W.ffOpen = true;
    W.ffReason = reason;
    if (W.player) W.player.v.set(0, 0, 0);
    if (el.ff_title) el.ff_title.textContent = D().ffTitle;
    if (el.ff_desc) el.ff_desc.textContent = reason === 'final' ? D().ffFinal : (reason === 'plate') ? D().ffPlate : D().ffNoBalls;
    W.events.push({ t: W.time, type: 'floorFail', reason: reason });
    Sound.defeat();
    if (typeof App !== 'undefined' && App.syncModals) App.syncModals();
  }

  // v4.2: хватает ли на этаже 0 шаров, чтобы закрыть все лунки?
  // (шары стоят в запас примагниченными — они доступны; недоступны
  //  только растворённые/взорванные/утонувшие и тела-загадки ядра)
  function floor0Winnable() {
    const st = W.floorStates && W.floorStates[0];
    if (!st || !st.sockets) return true;
    const need = [0, 0, 0];
    let anyNeed = false;
    for (const sk of st.sockets) {
      if (!sk.full) { need[sk.color] += Math.max(0, (sk.target || 0) - (sk.count || 0)); anyNeed = true; }
    }
    if (!anyNeed) return true;
    const have = [0, 0, 0];
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer || b.dissolving || b.countedLost || b.inTrap) continue;
      if (b.colorIdx === null || b.colorIdx === undefined || b.colorIdx < 0) continue;
      if (W.bodies && W.bodies.indexOf(b) >= 0) continue;          // тела-загадки на орбите ядра
      if (b.floor !== undefined && b.floor !== null && b.floor !== 0) continue;
      have[b.colorIdx]++;
    }
    const inSocket = [0, 0, 0];
    for (const sk of st.sockets) inSocket[sk.color] += (sk.count || 0);   // уже стоят в лунках
    return need.every((n, c) => n <= have[c] - inSocket[c]);
  }

  // ===========================================================================
  // v4.2: видимость пройденных этажей — скрыть или «призрак» (кнопка ЭТАЖИ)
  // ===========================================================================
  function setGroupGhost(group, on) {
    if (!group) return;
    group.traverse(o => {
      if (!o.isMesh || !o.material) return;
      if (on) {
        if (o.userData._origMat) return;
        const src = o.material;
        const m = src.clone();
        m.transparent = true;
        m.opacity = (src.opacity !== undefined ? src.opacity : 1) * 0.3;
        if (m.emissiveIntensity !== undefined && src.emissiveIntensity !== undefined) m.emissiveIntensity = src.emissiveIntensity * 0.35;
        o.userData._origMat = src;
        o.material = m;
      } else {
        if (!o.userData._origMat) return;
        const m = o.material;
        o.material = o.userData._origMat;
        delete o.userData._origMat;
        if (m && m.dispose) m.dispose();
      }
    });
    group.userData._ghost = !!on;
  }

  function syncFloorViz() {
    if (!W.floorViz) return;
    for (let i = 0; i < 4; i++) {
      const g = W.floorViz[i];
      if (i > W.currentFloor) { g.visible=false; continue; }
      const passed = i < W.currentFloor;
      if (!passed) {
        if (g.userData._ghost) setGroupGhost(g, false);
        g.visible = true;
      } else if (W.floorsGhost) {
        g.visible = true;
        if (!g.userData._ghost) setGroupGhost(g, true);
      } else {
        if (g.userData._ghost) setGroupGhost(g, false);
        g.visible = false;
      }
    }
  }

  function setFloorSolvedFlag(idx, v) {
    if (!W.floorStates) return;
    const wasCur = W.currentFloor;
    W.currentFloor = idx; W.floorState = W.floorStates[idx];
    setSolvedFlag(v);
    W.currentFloor = wasCur; W.floorState = W.floorStates[wasCur];
    W.floorSolvedFlag = W.floorSolvedArr[wasCur];
  }

  // Floor 2 completion uses real rolling, not the legacy kinematic pull.
  function startPipeExit() {
    if(W.currentFloor!==1 || !W.floorSolvedFlag || W.pipeExit)return;
    const p=W.player,ps=W.floorStates[1].pipe;
    const st=ps.roads.find(r=>r.layout && Math.abs(p.p.z-r.def.zc)<r.halfWidth+p.r &&
      p.p.x>r.startX-3 && p.p.x<r.def.xOut+3.5 && p.p.y>LEVEL_CONFIG.floorPipeY+p.r+0.18);
    const route=[];
    if(st) route.push({x:st.def.xOut+3.35,z:st.def.zc,exit:true});
    else if(Math.abs(p.p.z)>2.2) {
      if(p.p.x<-12.4)route.push({x:-12.85,z:0});
      else route.push({x:12.35,z:clamp(p.p.z,-7.0,7.0),exit:true});
    }
    if(route.length && route[route.length-1].x>0)route.push({x:12.35,z:0});
    route.push({x:0,z:0});
    W.pipeExit={active:true,route,index:0,stall:0,best:Infinity,t:0,recover:0,road:st?st.id:null};
    W.floorGates[1].pulled=true;
    AUTO.active=true;AUTO.floor=1;autoUpdateBtn();
    W.events.push({t:W.time,type:'pipeExitStart',road:st?st.id:null});
    toast(D().pipeExitHint,'good',2200);
  }
  function updatePipeExit(dt) {
    const e=W.pipeExit,p=W.player;
    if(!e||!e.active||!p||W.state!=='play'||W.ffOpen)return;
    if(W.currentFloor!==1){W.pipeExit=null;return;}
    if(p.kinematic||W.rewind.active)return;
    e.t+=dt;
    const q=e.route[e.index];if(!q)return;
    const d=Math.hypot(p.p.x-q.x,p.p.z-q.z);
    if(e.recover>0){e.recover-=dt;autoTilt(e.rx,e.rz,.7);return;}
    // Keep the ball on the road centreline until its entire body clears the end.
    const cap=q.exit?2.0:2.5;
    pipeSteer(p,q.x,q.z,cap,null);
    if(d<0.28 && Math.hypot(p.v.x,p.v.z)<0.85 && (!q.exit || p.p.y<=LEVEL_CONFIG.floorPipeY+p.r+0.12)){
      if(e.index<e.route.length-1){e.index++;e.best=Infinity;e.stall=0;
        W.events.push({t:W.time,type:'pipeExitWaypoint',index:e.index,x:p.p.x,z:p.p.z});}
    }
    if(d<e.best-.12){e.best=d;e.stall=0;}else e.stall+=dt;
    if(e.stall>3.2 && d>.4){
      const dx=p.p.x-q.x,dz=p.p.z-q.z,len=Math.hypot(dx,dz)||1;
      e.rx=dx/len;e.rz=dz/len;e.recover=.8;e.stall=0;e.best=Infinity;
    }
  }

  function finalFloorY(x,z) {
    const F=LEVEL_CONFIG.finalFunnel;
    return F.throatY+F.slope*Math.max(0,Math.hypot(x-F.x,z-F.z)-F.holeR*1);
  }
  function buildFloorCore() {
    const group=W.floorViz[3],F=LEVEL_CONFIG.finalFunnel,R=LEVEL_CONFIG.glass.radius;
    W.floorState=W.floorStates[3];
    const hole=F.holeR*1,n=MOBILE?64:96,steps=6,pos=[],idx=[];
    // Conical floor centred on the offset throat and clipped to the round tower wall.
    for(let j=0;j<=steps;j++)for(let i=0;i<=n;i++){
      const a=i/n*Math.PI*2,ux=Math.cos(a),uz=Math.sin(a),dot=F.x*ux+F.z*uz;
      const edge=-dot+Math.sqrt(dot*dot+R*R-F.x*F.x-F.z*F.z);
      const r=hole+(edge-hole)*j/steps;
      pos.push(F.x+ux*r,F.throatY+F.slope*(r-hole),F.z+uz*r);
    }
    for(let j=0;j<steps;j++)for(let i=0;i<n;i++){
      const a=j*(n+1)+i,b=a+n+1;idx.push(a,a+1,b,a+1,b+1,b);
    }
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setIndex(idx);geo.computeVertexNormals();
    const mat=litFloorMaterial(MAT.silver);mat.transparent=true;mat.opacity=1;
    const mesh=new THREE.Mesh(geo,mat);mesh.name='offsetFinalFunnel';group.add(mesh);W.finalFunnelMesh=mesh;
    const lines=[];
    const line=(a,b)=>{for(const v of [a,b])lines.push(pos[v*3],pos[v*3+1]+.02,pos[v*3+2]);};
    for(let j=1;j<=steps;j++)for(let i=0;i<n;i++)line(j*(n+1)+i,j*(n+1)+i+1);
    for(let i=0;i<n;i+=4)for(let j=0;j<steps;j++)line(j*(n+1)+i,(j+1)*(n+1)+i);
    const gridGeo=new THREE.BufferGeometry();gridGeo.setAttribute('position',new THREE.Float32BufferAttribute(lines,3));
    W.finalFloorGrid=new THREE.LineSegments(gridGeo,new THREE.LineBasicMaterial({color:0x88ccee,transparent:true,opacity:.24,depthWrite:false}));group.add(W.finalFloorGrid);
    addFloorCol({type:'offsetFunnel',name:'finalFunnel',group:'finalFunnel',x:F.x,z:F.z,hole,outerR:R,y:F.throatY,slope:F.slope,e:.14,live:true});
    const rim=ringMesh(hole,.07,0x44eedd,.95);rim.position.set(F.x,F.throatY+.025,F.z);group.add(rim);
    // A short transparent lip makes the eccentric opening easy to locate.
    const lip=new THREE.Mesh(new THREE.CylinderGeometry(hole,hole,.28,MOBILE?32:48,1,true),new THREE.MeshBasicMaterial({color:0x42ddce,transparent:true,opacity:.28,side:THREE.DoubleSide,depthWrite:false}));
    lip.position.set(F.x,F.throatY-.14,F.z);group.add(lip);
    W.finalView=null;
  }
  function finalFlightActive() {
    return W.currentFloor===3 && W.player && (W.player.p.y<LEVEL_CONFIG.finalFunnel.throatY+.12 || !W.coreAlive);
  }
  function updateFinalView(dt) {
    if(W.currentFloor!==3 || !W.player || W.intro.active)return;
    const F=LEVEL_CONFIG.finalFunnel,p=W.player;
    const near=Math.hypot(p.p.x-F.x,p.p.z-F.z)<F.holeR*1+(W.finalView&&W.finalView.flight?2.7:1.7);
    // Show the planets before impact, not only after the core has already burst.
    const flight=finalFlightActive()||(near&&p.p.y<finalFloorY(p.p.x,p.p.z)+p.r+.4);
    if(!W.finalView || (!flight&&W.finalView.flight)){
      W.finalView={flight:false};W.cam.tTheta=Math.atan2(F.x,F.z)+.8;W.cam.tPhi=47*DEG;W.cam.tDist=MOBILE?42:38;
    }
    if(flight&&!W.finalView.flight){
      W.finalView.flight=true;
      W.cam.tTheta=Math.atan2(F.x,F.z);W.cam.tPhi=80*DEG;W.cam.tDist=MOBILE?26:23;
      W.cam.spinTheta=W.cam.spinPhi=0;
    }
    const k=1-Math.exp(-dt/.28);
    const tx=flight?F.x:F.x*.35,tz=flight?F.z:F.z*.35,ty=flight?-.25:2.0;
    W.camTargetX=lerp(W.camTargetX||0,tx,k);W.camTargetZ=lerp(W.camTargetZ||0,tz,k);
    W.camTargetY=lerp(W.camTargetY===undefined?4:W.camTargetY,ty,k);
    if(W.finalFunnelMesh){
      W.finalFunnelMesh.material.opacity=lerp(W.finalFunnelMesh.material.opacity,flight?.12:1,k);
      W.finalFunnelMesh.material.depthWrite=!flight;
      if(W.finalFloorGrid)W.finalFloorGrid.material.opacity=flight?.035:.24;
    }
  }
  function autoFloor3(dt) {
    const p=W.player,F=LEVEL_CONFIG.finalFunnel;if(!p||!p.alive||p.kinematic||W.ffOpen)return;
    const dx=p.p.x-F.x,dz=p.p.z-F.z,r=Math.hypot(dx,dz),hole=F.holeR*1;
    if(finalFlightActive()){
      // Level the tower before the visible slow descent; no forced landing or teleport.
      autoTilt(0,0,0);return;
    }
    let s=AUTO.final;
    if(!s){
      const len=r||1;s=AUTO.final={phase:r>hole+2.9?'roll':'approach',
        x:F.x+dx/len*(hole+2.4),z:F.z+dz/len*(hole+2.4)};
    }
    if(s.phase==='roll'){
      pipeSteer(p,s.x,s.z,2.0,null);
      if(Math.hypot(p.p.x-s.x,p.p.z-s.z)<.45&&Math.hypot(p.v.x,p.v.z)<1.1)s.phase='approach';
    }else pipeSteer(p,F.x,F.z,.85,null);
  }

  function restartFinalFloor(){
    autoStop('level');W.ffOpen=false;W.ffReason=null;W.state='play';W.trapTimer=-1;W.rewind.active=false;
    W.coreAlive=true;W.coreCol.live=true;W.coreGroup.visible=true;W.buttonPressed=false;
    W.autoPull=null;W.tilt.active=false;W.tilt.tRotX=W.tilt.tRotZ=0;
    if(W.buttonMesh)W.buttonMesh.position.y=LEVEL_CONFIG.button.y;
    for(const b of W.bodies){b.alive=true;b.orbit=true;b.mounted=true;b.kinematic=true;b.mesh.visible=true;b.v.set(0,0,0);}
    const p=W.player;p.alive=true;p.kinematic=false;p.mounted=false;p.returning=false;p.idleT=0;p.v.set(0,0,0);
    p.p.set(0,finalFloorY(0,0)+p.r+.04,0);W.ropeCut=true;buildFloor(3);W.floorTransition=null;App.syncModals();
  }
  const coreBursts=[];
  function coreBurst(x,y,z,color){
    const n=MOBILE?10:20,coords=new Float32Array(n*18),vel=[];
    for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,v=3+Math.random()*4;vel.push({x:Math.cos(a)*v,y:(Math.random()-0.25)*6,z:Math.sin(a)*v});}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(coords,3));
    const m=new THREE.LineBasicMaterial({color,transparent:true,opacity:1,blending:THREE.AdditiveBlending,depthWrite:false});
    const obj=new THREE.LineSegments(g,m);obj.frustumCulled=false;W.glassGroup.add(obj);
    coreBursts.push({obj,vel,x,y,z,t:0});spawnSparks(x,y,z,MOBILE?10:24,6,color);
  }
  function updateCoreBursts(dt){
    for(let i=coreBursts.length-1;i>=0;i--){const b=coreBursts[i];b.t+=dt;
      if(b.t>1.1){if(b.obj.parent)b.obj.parent.remove(b.obj);b.obj.geometry.dispose();b.obj.material.dispose();coreBursts.splice(i,1);continue;}
      const arr=b.obj.geometry.attributes.position.array;let k=0;
      for(const v of b.vel)for(let seg=0;seg<3;seg++)for(let end=0;end<2;end++){
        const t=Math.max(0,b.t-(seg+end)*0.045);arr[k++]=b.x+v.x*t;arr[k++]=b.y+v.y*t-2*t*t;arr[k++]=b.z+v.z*t;
      }
      b.obj.material.opacity=1-b.t/1.1;b.obj.geometry.attributes.position.needsUpdate=true;
    }
  }

  function inTransition() { return !!(W.floorTransition && W.floorTransition.active); }

  function setSolvedFlag(v) {
    W.floorSolvedFlag = v;
    if (W.floorSolvedArr) W.floorSolvedArr[W.currentFloor] = v;
    if (W.floorState) W.floorState.solved = v;
  }

  function onFloorSolved() {
    if (W.floorSolvedFlag || !W.floorState) return;
    setSolvedFlag(true);
    addScore(300, D().floorScore);
    openFloorGate();
    toast(D().floorSolved, 'good');
    W.events.push({ t: W.time, type: 'floorSolved', floor: W.currentFloor });
  }

  // ежекадровая логика этажей (из updateTriggers)
  function updateFloorState(dt) {
    if (!W.floorState) return;
    // кулдауны лунок/плит
    for (const b of W.balls) if (b.socketCd > 0) b.socketCd -= dt;
    // v4.0: зоны лунок — свободный шар в круге гнезда = попытка вставить
    if (W.currentFloor === 0 && W.floorState.sockets && !inTransition()) {
      const A = LEVEL_CONFIG.platformA;
      for (const sk of W.floorState.sockets) {
        if (sk.full) continue;
        const rr = (1.2 * 1) - 0.15;
        for (const b of W.balls) {
          if (!b.alive || b.kinematic || b.dissolving) continue;
          if (b.p.y > A.y + 1.6 || b.p.y < A.y - 0.2) continue;
          const dx = b.p.x - sk.x, dz = b.p.z - sk.z;
          if (dx * dx + dz * dz < rr * rr) socketTryInsert(b, sk);
        }
      }
    }
    // v4.2: этажи «Труба» и «Резонанс»
    if (W.currentFloor === 1 && W.floorState && W.floorState.pipe) updatePipe(dt);
    if (W.floorState && W.floorState.plates) updatePlates(dt);
    updateAutoPull(dt);
    // белый шар «проглочен» мишенью дороги → перемотка как из ловушки
    if (W.player && W.player._pipeTrapT > 0 && W.state === 'play' && !inTransition()) {
      W.player._pipeTrapT -= dt;
      if (W.player._pipeTrapT <= 0) {
        W.player._pipeTrapT = 0;
        if (W.player.p.y < LEVEL_CONFIG.floorPipeY + 1.2) {
          W.events.push({ t: W.time, type: 'pipeSwallowPlayer' });
          startRewind('pipe');
        }
      }
    }
    // шары-помехи, упавшие в открытый люк, исчезают без последствий
    if (W.floorStates && W.floorStates[2] && W.floorStates[2].hazards) {
      for (const b of W.floorStates[2].hazards) {
        if (b.alive && b.p.y < LEVEL_CONFIG.platformB.y - 1.2) {
          b.alive = false;
          if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
          if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
          W.events.push({ t: W.time, type: 'hazardGone', name: b.name });
        }
      }
    }
    // v4.2: не хватает шаров для лунок этажа 0 → вопрос игроку
    if (W.currentFloor === 0 && W.state === 'play' && !inTransition() && !W.floorSolvedFlag && !W.ffOpen) {
      W._noBallCheckT = (W._noBallCheckT || 0) + dt;
      if (W._noBallCheckT > 0.5) {
        W._noBallCheckT = 0;
        if (!floor0Winnable()) askFloorFail('noBalls');
      }
    }
    // переход: этаж решён и шар провалился ниже плоскости этажа
    if (W.state === 'play' && !inTransition() && W.floorSolvedFlag && W.currentFloor < 3) {
      const pl = W.player;
      if (pl && pl.alive && pl.p.y < floorY(W.currentFloor) - 0.9) {
        startFloorTransition(W.currentFloor + 1);
      }
    }
    if (W.floorTransition && W.floorTransition.active) {
      const tr = W.floorTransition;
      tr.t += dt;
      // «дыхание» камеры
      W.camBreath = Math.sin(Math.min(tr.t / tr.dur, 1) * Math.PI) * 10;
      if (tr.t >= tr.dur * 0.5 && !tr.toastShown) {
        tr.toastShown = true;
        const names = D().floorNames;
        toast(D().floorOf.replace('{n}', String(tr.to + 1)).replace('{name}', names[tr.to]), 'magic', 1800);
        // подсказка этажа — один раз за проход; v4.1: hints 0 — текстовые подсказки этажа выкл
        if (LV().hints >= 1 && W.visited && !W.visited.floors[tr.to]) {
          W.visited.floors[tr.to] = true;
          setTimeout(() => {
            if (W.state === 'play') toast(D()['floor' + tr.to + 'Hint'], 'magic', 3200);
          }, 900);
        }
      }
      if (tr.t >= tr.dur) {
        tr.active = false;
        W.camBreath = 0;
      }
    }
  }

  function startFloorTransition(to) {
    to = clamp(to | 0, 0, 3);
    W.events.push({ t: W.time, type: 'floorTransition', from: W.currentFloor, to: to });
    if (to === 3 && W.runStats) W.runStats.dives++;
    buildFloor(to);                               // v4.1: вход мгновенный, башня не пересобирается
    W.floorTransition = { active: true, t: 0, dur: LEVEL_CONFIG.floors.transitionDur, to: to, toastShown: false };
    applyFloorPalette(to);
    if (to > 0) W.ropeCut = true;                 // трос остался наверху
    // v4.2: подсветка-обучение при первом заходе на этаж
    if (to === 1 && W.floorStates[1] && W.floorStates[1].pipe) {
      const rdA = W.floorStates[1].pipe.roads[0];
      if (rdA && rdA.layout && rdA.hatch) rdA.pulseT = 3.4;
    }
    if (to === 2 && W.floorStates[2] && W.floorStates[2].plates) {
      W.floorStates[2].plPulse = 3.4;
    }
    syncFloorViz();                               // v4.2: пройденный этаж исчезает
  }

  function makeBall(opts) {
    const b = new Ball(opts);
    const mat = (b.isPlayer || b.colorIdx < 0) ? MAT.player.clone() : MAT.palette[b.colorIdx].clone();
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(b.baseR, MOBILE ? 16 : 28, MOBILE ? 12 : 20), mat);
    mesh.scale.setScalar(1);
    mesh.position.copy(b.p);
    mesh.name = b.name;
    W.glassGroup.add(mesh);
    b.mesh = mesh;

    // ореол
    const glow = new THREE.Mesh(new THREE.SphereGeometry(b.baseR * 1.28, 16, 12),
      new THREE.MeshBasicMaterial({
        color: b.isPlayer ? 0x88ddff : b.colorNum, transparent: true, opacity: b.isPlayer ? 0.2 : 0.12,
        depthWrite: false, blending: THREE.AdditiveBlending
      }));
    glow.scale.setScalar(1);
    if(!MOBILE) mesh.add(glow);
    b.glow = glow;

    // кольцо заряда магии
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.82, 1.0, 40), MAT.ring.clone());
    ring.visible = false;
    ring.renderOrder = 3;
    W.glassGroup.add(ring);
    b.ring = ring;

    W.balls.push(b);
    return b;
  }

  // ===========================================================================
  // 12. ФИЗИКА
  // ===========================================================================
  const _gLocal = new THREE.Vector3();
  const _qInv = new THREE.Quaternion();
  const _tv = new THREE.Vector3();
  const _tv2 = new THREE.Vector3();

  function freeBalls() { return W.balls.filter(b => b.alive && !b.kinematic); }
  function minBallRadius() {
    let m = 99;
    for (const b of W.balls) if (b.alive && b.r < m) m = b.r;
    return m === 99 ? 0.4 : m;
  }

  function updateKinematic(h) {
    const S = LEVEL_CONFIG.shield;
    for (const b of W.balls) {
      if (!b.alive || !b.kinematic || b.gapFalling) continue;
      if (b.orbit) {
        const a = b.orbitPhase + W.orbitT * S.orbitOmega;
        const ca = Math.cos(a), sa = Math.sin(a);
        // v4.0: орбита вокруг смещённого ядра (S.x, S.z)
        b.p.set(S.x + ca * (S.orbitRadius * 1), S.y, S.z + sa * (S.orbitRadius * 1));
        b.kinV.set(-sa * S.orbitOmega * (S.orbitRadius * 1), 0, ca * S.orbitOmega * (S.orbitRadius * 1));
        b.v.copy(b.kinV);
        if (b.mesh) b.mesh.position.copy(b.p);
      } else if (b.mounted) {
        b.p.copy(b.mountPos);
        b.v.set(0, 0, 0);
        b.kinV.set(0, 0, 0);
      }
    }
  }

  function collideBalls(a, c, dt) {
    const dx = c.p.x - a.p.x, dy = c.p.y - a.p.y, dz = c.p.z - a.p.z;
    const rr = a.r + c.r;
    const d2 = dx * dx + dy * dy + dz * dz;
    if (d2 >= rr * rr || d2 < 1e-10) return;
    const d = Math.sqrt(d2);
    const nx = dx / d, ny = dy / d, nz = dz / d;
    const overlap = rr - d;
    const wa = a.kinematic ? 0 : 1 / a.m;
    const wc = c.kinematic ? 0 : 1 / c.m;
    const wsum = wa + wc;
    if (wsum <= 0) { W.contacts.push([a, c]); return; }

    a.p.x -= nx * overlap * (wa / wsum); a.p.y -= ny * overlap * (wa / wsum); a.p.z -= nz * overlap * (wa / wsum);
    c.p.x += nx * overlap * (wc / wsum); c.p.y += ny * overlap * (wc / wsum); c.p.z += nz * overlap * (wc / wsum);

    const rvx = c.v.x - a.v.x, rvy = c.v.y - a.v.y, rvz = c.v.z - a.v.z;
    const vn = rvx * nx + rvy * ny + rvz * nz;
    if (vn < 0) {
      const e0 = LEVEL_CONFIG.physics.restitutionBall;
      const e = (-vn < 1.2) ? e0 * clamp((-vn - 0.2) / 1.0, 0, 1) : e0;
      const j = -(1 + e) * vn / wsum;
      a.v.x -= nx * j * wa; a.v.y -= ny * j * wa; a.v.z -= nz * j * wa;
      c.v.x += nx * j * wc; c.v.y += ny * j * wc; c.v.z += nz * j * wc;
      const imp = -vn;
      if (imp > (a.impact || 0)) a.impact = imp;
      if (imp > (c.impact || 0)) c.impact = imp;
    }
    if(W.currentFloor===1 && (a.isPlayer || c.isPlayer)) {
      const q=a.isPlayer?c:a, ps=W.floorState&&W.floorState.pipe;
      if(q.pipeRoad!==undefined && !q.pipeDone && ps) {
        const st=ps.roads.find(r=>r.id===q.pipeRoad);
        if(st)for(const b of st.balls)if(!b.pipeDone&&!b.gapFalling)b.demount('playerPush');
      }
    }
    if(W.currentFloor===3 && W.coreAlive && ((a.isPlayer && c.isBody)||(c.isPlayer && a.isBody)))breakCore(a.isPlayer?a:c);
    W.contacts.push([a, c]);
    a.touched[c.name] = true; c.touched[a.name] = true;

    // Примагниченный шар освобождается от касания любого свободного шара
    if (a.mounted && !c.mounted) a.demount('touch:' + c.name);
    if (c.mounted && !a.mounted) c.demount('touch:' + a.name);
  }


  function protectClosedFloor() {
    protectResonancePerimeter();
    const p=W.player,g=W.floorGates&&W.floorGates[W.currentFloor];
    if(!p||!p.alive||!g||g.opened||W.floorSolvedArr[W.currentFloor]||p.returning)return;
    const r=Math.hypot(p.p.x,p.p.z), top=g.cy+0.06;
    if(p.p.y<top+p.r && (r<LEVEL_CONFIG.floors.holeR*1+0.1 || p.p.y<top-0.05)) {
      p.p.y=top+p.r;if(p.v.y<0)p.v.y=0;
    }
  }

  function stepPhysics(dt) {
    const activeBalls=W.balls.filter(b=>b.alive && (b.floor===undefined || b.floor===W.currentFloor));
    const activeCols=W.colliders.filter(c=>c.live!==false && (c.floor===undefined || c.floor===W.currentFloor));
    const supportCols=activeCols.filter(c=>c.type==='pipeRamp'||c.type==='offsetFunnel'||['platformA','floorPipe','platformB','pipeDeck'].includes(c.group)||/^gateLid/.test(c.name));
    const P = LEVEL_CONFIG.physics;
    const maxV = P.maxSpeed * Math.max(1, 1);

    // гравитация в локальной системе стакана (наклон = поворот вектора g)
    _qInv.copy(W.glassGroup.quaternion).invert();
    _gLocal.set(0, -P.gravity, 0).applyQuaternion(_qInv);
    // v4.1: модификатор уровня — ускорение игрового шара (L10: ×1.1)
    const boost = LV().ballBoost || 1.0;

    // CCD: число подшагов так, чтобы перемещение за подшаг было << радиуса шара
    const mR = minBallRadius();
    const sub = clamp(Math.ceil(Math.max(dt*240,(maxV*dt)/(0.28*mR))),1,96);
    const h = dt / sub;

    for (const b of activeBalls) { if (b.alive) { b.touched = {}; b.plateSpeeds={}; } }
    W.contacts.length = 0;

    for (let s = 0; s < sub; s++) {
      W.orbitT += h;
      updateKinematic(h);

      for (const b of activeBalls) {
        if (!b.alive || b.kinematic || (b.floor!==undefined && b.floor!==W.currentFloor)) continue;
        b.contact = false;
        // интеграция
        const gk = (b.isPlayer && boost > 1) ? boost : 1;
        b.v.x += _gLocal.x * h * gk; b.v.y += _gLocal.y * h * gk; b.v.z += _gLocal.z * h * gk;
        if(b.isPlayer && W.currentFloor===3){
          const F=LEVEL_CONFIG.finalFunnel,r=Math.hypot(b.p.x-F.x,b.p.z-F.z),hole=F.holeR*1;
          if(r<hole+.65 && b.p.y>F.throatY-.3 && b.p.y<finalFloorY(b.p.x,b.p.z)+b.r+.4){
            const damp=Math.exp(-3*h);b.v.x*=damp;b.v.z*=damp;
          }
        }
        const dragK = Math.exp(-P.airDrag*h);
        b.v.multiplyScalar(dragK);
        const sp = b.v.length();
        const cap = b.isPlayer ? maxV * 1 : maxV;
        if (sp > cap) b.v.multiplyScalar(cap / sp);
        b.p.x += b.v.x * h; b.p.y += b.v.y * h; b.p.z += b.v.z * h;

        // коллайдеры уровня
        for (let i = 0; i < activeCols.length; i++) collideOne(b, activeCols[i], h);

        // аварийный возврат в стакан
        if (b.p.y > LEVEL_CONFIG.glass.yTop + 3) { b.p.y = LEVEL_CONFIG.glass.yTop + 3; if (b.v.y > 0) b.v.y = -b.v.y * 0.3; }
        const rr = Math.hypot(b.p.x, b.p.z);
        if (rr > LEVEL_CONFIG.glass.radius + 1) {
          const k = (LEVEL_CONFIG.glass.radius + 1) / rr;
          b.p.x *= k; b.p.z *= k;
          b.v.x *= -0.4; b.v.z *= -0.4;
        }
        if (b.p.y < LEVEL_CONFIG.glass.yBottom - 1) { b.p.y = LEVEL_CONFIG.glass.yBottom - 1; b.v.y = Math.abs(b.v.y) * 0.3; }
      }

      protectClosedFloor();
      // шар-шар
      const n = activeBalls.length;
      for (let i = 0; i < n; i++) {
        const a = activeBalls[i];
        if (!a.alive || (a.floor!==undefined && a.floor!==W.currentFloor)) continue;
        for (let j = i + 1; j < n; j++) {
          const c = activeBalls[j];
          if (!c.alive || (c.floor!==undefined && c.floor!==W.currentFloor)) continue;
          if (a.kinematic && c.kinematic) continue;
          const dx = c.p.x - a.p.x, dy = c.p.y - a.p.y, dz = c.p.z - a.p.z;
          const rr2 = a.r + c.r;
          if (dx * dx + dy * dy + dz * dz < rr2 * rr2) collideBalls(a, c, h);
        }
      }
      // Pair separation can push the lower sphere into a floor. Restore the
      // static support constraints before the substep can be rendered.
      for(let pass=0;pass<2;pass++)for(const b of activeBalls){
        if(!b.alive||b.kinematic)continue;
        for(const col of supportCols)collideOne(b,col,0);
      }
      protectResonancePerimeter();
    }

    protectClosedFloor();
    // вращение для визуала (качение)
    for (const b of activeBalls) {
      if (!b.alive) continue;
      const sp = b.v.length();
      if (b.contact && sp > 0.02) {
        _tv.copy(b.v).normalize();
        _tv2.crossVectors(b.contactN, _tv);
        if (_tv2.lengthSq() > 1e-8) { b.spinAxis.copy(_tv2).normalize(); b.spinRate = sp / Math.max(0.05, b.r); }
      } else {
        b.spinRate *= 0.94;
      }
      b.lastSpeed = sp;
    }
  }

  // ===========================================================================
  // 13. МАГИЯ: match-3 с таймером 10 с
  //     Правила ТЗ: два свободных шара одного цвета коснулись → оба заряжаются
  //     (кольцо сужается, зеленеет→краснеет). Если за 10 с их коснётся третий
  //     того же цвета — взрываются ВСЕ шары цвета в этой цепочке (3, 4, 5…).
  //     Не успели — магия гаснет. Примагниченные и белый игровой шар не участвуют.
  // ===========================================================================
  const Magic = {
    /** компоненты связности по касаниям среди свободных цветных шаров */
    components() {

      const pool = W.balls.filter(b => b.alive && !b.kinematic && b.colorIdx >= 0 && !b.dissolving && !b.noMagic);
      const seen = new Set();
      const comps = [];
      for (const b of pool) {
        if (seen.has(b.id)) continue;
        const stack = [b], comp = [];
        seen.add(b.id);
        while (stack.length) {
          const x = stack.pop();
          comp.push(x);
          for (const y of pool) {
            if (y === x || seen.has(y.id) || y.colorIdx !== x.colorIdx) continue;
            const dx = y.p.x - x.p.x, dy = y.p.y - x.p.y, dz = y.p.z - x.p.z;
            const rr = x.r + y.r + 0.06;               // небольшой допуск: касание
            if (dx * dx + dy * dy + dz * dz <= rr * rr) { seen.add(y.id); stack.push(y); }
          }
        }
        comps.push(comp);
      }
      return comps;
    },

    update(dt) {
      const MT = LV().magicTime;

      // v4.0: каскад — отложенные эхо-взрывы
      if (W.echoQueue && W.echoQueue.length) {
        for (let i = W.echoQueue.length - 1; i >= 0; i--) {
          const e = W.echoQueue[i];
          e.t -= dt;
          if (e.t <= 0) {
            W.echoQueue.splice(i, 1);
            const alive = e.balls.filter(b => b.alive && !b.kinematic && b.colorIdx === e.color && !b.noMagic && !b.dissolving);
            if (alive.length) this.explode(alive, true);
          }
        }
      }

      // таймеры заряда
      for (const b of W.balls) {
        if (!b.alive || b.chargeT <= 0) continue;
        b.chargeT -= dt;
        if (b.chargeT <= 0) {
          b.chargeT = 0;
          if (b.ring) b.ring.visible = false;
          W.magicFaded = true;
        }
      }

      const comps = this.components();

      // Шар, который сейчас НЕ входит в одноцветную пару, снова «вооружён»:
      // следующее касание зарядит его заново.
      const inGroup = new Set();
      for (const comp of comps) {
        if (comp.length < 2) continue;
        for (const b of comp) inGroup.add(b.id);
      }
      for (const b of W.balls) {
        if (b.alive && !inGroup.has(b.id)) b.chargeArmed = true;
      }

      for (const comp of comps) {
        if (comp.length >= 3) { this.explode(comp); continue; }
        if (comp.length === 2) {
          // Заряд — только ПО ФРОНТУ касания. Раньше условие «chargeT <= 0 → MT»
          // срабатывало каждый кадр, пока шары не разошлись: таймер истекал и
          // тут же перезапускался, то есть магия не гасла никогда. По ТЗ истёк
          // таймер — магия пропадает, и для нового заряда нужно касаться снова.
          let started = false;
          for (const b of comp) {
            if (!b.chargeArmed) continue;
            b.chargeT = MT;
            b.chargeArmed = false;
            started = true;
          }
          if (started) {
            Sound.charge();
            const cname = D()['color' + cap(LEVEL_CONFIG.palette[comp[0].colorIdx].id)];
            toast(D().toastCharge.replace('{c}', cname).replace('{t}', MT.toFixed(0)), 'magic');
            W.events.push({ t: W.time, type: 'charge', color: comp[0].colorIdx, names: comp.map(b => b.name) });
          }
        }
      }

      // визуал колец заряда
      for (const b of W.balls) {
        if (!b.alive || !b.ring) continue;
        if (b.chargeT > 0) {
          const k = clamp(b.chargeT / MT, 0, 1);
          b.ring.visible = true;
          const scale = b.r * (1.18 + 0.85 * k);
          b.ring.scale.setScalar(scale);
          const c = new THREE.Color(0xff2233).lerp(new THREE.Color(0x00ff88), k);
          b.ring.material.color.copy(c);
          b.ring.material.opacity = 0.55 + 0.35 * Math.sin(W.time * 11);
          if (b.mesh && b.mesh.material && b.mesh.material.emissive) {
            b.mesh.material.emissiveIntensity = 0.85 + 0.9 * (0.5 + 0.5 * Math.sin(W.time * 11));
          }
        } else {
          if (b.ring.visible) b.ring.visible = false;
          if (b.mesh && b.mesh.material && b.mesh.material.emissive && !b.isPlayer) {
            b.mesh.material.emissiveIntensity = 0.85;
          }
        }
      }

      if (W.magicFaded) {
        W.magicFaded = false;
        Sound.fade();
        toast(D().toastExpired, 'bad');
        W.events.push({ t: W.time, type: 'magicFade' });
      }
    },

    /** Взрыв цепочки: слоу-мо, вспышка, искры, арпеджио, тряска экрана */
    explode(comp, isEcho) {
      const colorIdx = comp[0].colorIdx;
      const colNum = LEVEL_CONFIG.palette[colorIdx].colorNum;
      const extra = comp.length - 3;
      W.blastCount++;
      W.magicCount = W.blastCount;
      if (isEcho) {
        // v4.0: каскад — очки без комбо
        const pts = 250 + extra * 60;
        W.score += pts;
        toast(D().cascade.replace('{n}', String(pts)), 'magic');
        W.events.push({ t: W.time, type: 'scoreEcho', amount: pts });
      } else {
        // v3.5: очки за магию (400 + 100 за каждый шар сверх трёх)
        addScore(400 + extra * 100, curLang === 'ru' ? 'магия' : 'magic');
      }

      W.slowmo = Math.max(W.slowmo, LEVEL_CONFIG.magic.slowmoTime);
      W.slowmoScale = LEVEL_CONFIG.magic.slowmoScale;
      W.screenShake = Math.max(W.screenShake, LEVEL_CONFIG.magic.screenShakeTime);
      W.screenShakeAmp = LEVEL_CONFIG.magic.screenShakeAmp;

      let cx = 0, cy = 0, cz = 0;
      for (const b of comp) { cx += b.p.x; cy += b.p.y; cz += b.p.z; }
      cx /= comp.length; cy /= comp.length; cz /= comp.length;

      // вспышка: шары белеют на 0.15 с и исчезают
      for (const b of comp) {
        b.flash = LEVEL_CONFIG.magic.flashTime;
        if (!isEcho) spawnShockwave(b.p.x, b.p.y, b.p.z, b.r * 2.4, colNum);
      }

      const k = 1 * (isEcho ? 0.6 : 1);
      for (const b of W.balls) {
        if (!b.alive || comp.indexOf(b) >= 0 || b.noMagic) continue;
        const dx = b.p.x - cx, dy = b.p.y - cy, dz = b.p.z - cz;
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > 7 || d < 1e-6) continue;
        const f = (1 - d / 7) * 4.2 * k * (b.isPlayer ? 1 : 1);
        if (b.kinematic) { b.demount('blast'); }
        b.v.x += (dx / d) * f; b.v.y += (dy / d) * f + 0.6 * k; b.v.z += (dz / d) * f;
      }

      if (isEcho) {
        // v4.0: эхо — компактнее и быстрее
        spawnSparks(cx, cy, cz, Math.round((LEVEL_CONFIG.magic.sparks + extra * 8) * 0.6), LEVEL_CONFIG.magic.sparkSpeed * k * 1.3, colNum);
        spawnShockwave(cx, cy, cz, 3.2, colNum);
        Sound.boom(extra, true);
      } else {
        spawnSparks(cx, cy, cz, LEVEL_CONFIG.magic.sparks + extra * 8, LEVEL_CONFIG.magic.sparkSpeed * k, colNum);
        Sound.boom(extra);
      }

      const names = comp.map(b => b.name);
      setTimeoutBalls(comp);
      if (!isEcho) toast(D().toastBoom.replace('{n}', String(comp.length)), 'magic');
      W.events.push({ t: W.time, type: 'blast', color: colorIdx, count: comp.length, names: names, x: cx, y: cy, z: cz, echo: !!isEcho });
      W.lastBlast = { x: cx, y: cy, z: cz, color: colorIdx, count: comp.length };
      // v4.1: эхо включается с уровня 4 (LV().echo)
      if (isEcho && W.runStats) W.runStats.echoBlasts++;
      if (!isEcho && LV().echo) {
        const R2 = 3.5;
        const cands = [];
        for (const b of W.balls) {
          if (!b.alive || b.kinematic || b.noMagic || b.dissolving || b.colorIdx !== colorIdx || comp.indexOf(b) >= 0) continue;
          let near = false;
          for (const c of comp) {
            const dx = b.p.x - c.p.x, dy = b.p.y - c.p.y, dz = b.p.z - c.p.z;
            if (dx * dx + dy * dy + dz * dz <= R2 * R2) { near = true; break; }
          }
          if (near) cands.push(b);
        }
        if (cands.length) W.echoQueue.push({ t: 0.25, balls: cands, color: colorIdx });
      }
    }
  };

  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  function setTimeoutBalls(comp) {
    for (const b of comp) {
      b.alive = false;
      b.chargeT = 0;
      b.chargeArmed = true;
      if (b.mesh) { b.mesh.visible = false; if (b.mesh.parent) b.mesh.parent.remove(b.mesh); }
      if (b.ring) { b.ring.visible = false; if (b.ring.parent) b.ring.parent.remove(b.ring); }
    }
    const i = W.balls.indexOf(comp[0]);
    W.balls = W.balls.filter(x => x.alive);
    W.bodies = W.bodies.filter(x => x.alive);
    void i;
  }

  // ===========================================================================
  // 14. ВСТРЯСКА СТАКАНА
  // ===========================================================================
  function playerResting() {
    const b = W.player;
    if (!b || !b.alive) return false;
    const onSurface = b.touched['platformA'] || b.touched['platformB'] || b.touched['floorPipe'] || b.touched['net'] || b.touched['glassFloor'] || b.touched['button'];
    return b.contact && onSurface && b.v.length() < 0.3;
  }

  function doShake(force) {
    if (W.state !== 'play') return false;
    if (!force && W.shakeCd > 0) return false;
    if (W.runStats) W.runStats.shakes++;
    W.shakeCd = LEVEL_CONFIG.shake.cooldown;
    W.shakeVisual = LEVEL_CONFIG.shake.visualTime;
    W.shakeSeed = Math.random() * 1000;
    const k = 1;
    let moved = 0;
    for (const b of W.balls) {
      if (!b.alive || b.kinematic) continue;
      if (b.isPlayer && playerResting()) continue;      // защита: покоящийся игровой шар не трясём
      const mag = rnd(LEVEL_CONFIG.shake.impulseMin, LEVEL_CONFIG.shake.impulseMax) * k;
      // направление: случайное, но НЕ вниз
      let x = rnd(-1, 1), y = rnd(0.1, 1), z = rnd(-1, 1);
      const l = Math.sqrt(x * x + y * y + z * z) || 1;
      const scale = b.isPlayer ? 1 : 1;
      b.v.x += (x / l) * mag * scale; b.v.y += (y / l) * mag * scale; b.v.z += (z / l) * mag * scale;
      moved++;
    }
    Sound.shake();
    W.screenShake = Math.max(W.screenShake, 0.18);
    W.screenShakeAmp = Math.max(W.screenShakeAmp, 0.12);
    toast(D().toastShake + ' (' + moved + ')', 'good');
    W.events.push({ t: W.time, type: 'shake', moved: moved });
    return true;
  }

  // ===========================================================================
  // 15. ЯДРО ЩИТА И ТРИ ТЕЛА
  // ===========================================================================
  function breakCore(byBall) {
    if (!W.coreAlive) return;
    W.coreAlive = false;
    W.coreCol.live = false;
    Sound.core();
    const S = LEVEL_CONFIG.shield;

    // осколки ядра
    spawnSparks(S.x, S.y, S.z, 40, 4.5 * 1, 0xd946ef);
    spawnShockwave(S.x, S.y, S.z, (S.coreRadius * 1) * 4, 0xd946ef);
    if (W.coreGroup) W.coreGroup.visible = false;
    W.screenShake = Math.max(W.screenShake, 0.4);
    W.screenShakeAmp = 0.3;
    W.slowmo = Math.max(W.slowmo, 0.35);
    W.slowmoScale = 0.45;
    W.flashT = 0.25;                       // v3.5: вспышка tone-mapping
    W.failStreak = 0;                      // продвижение — серия фейлов сброшена
    addScore(500, curLang === 'ru' ? 'ядро' : 'core');

    for(const b of W.bodies) {
      if(!b.alive)continue;
      coreBurst(b.p.x,b.p.y,b.p.z,b.colorNum);
      b.alive=false;b.orbit=false;b.mesh.visible=false;b.ring.visible=false;
    }
    coreBurst(S.x,S.y,S.z,0xd946ef);
    // шар, разбивший ядро, продолжает падение (§7.4). v4.0: ядро «гасит»
    // скорость нырка — иначе рикошет от сферы ядра отбрасывает шар от кнопки
    if (byBall && byBall.alive) {
      // v4.0: ядро полностью гасит снос и выносит шар на свою ось, НИЖЕ плоскости
      // орбиты тел — чистое короткое падение точно на кнопку (финал = нырок)
      byBall.v.y=Math.min(-2.5,byBall.v.y);
      byBall.v.x*=0.5;byBall.v.z*=0.5;
      byBall.flash = 0.18;
      byBall.restT = 0; byBall.idleT = 0;
    }

    toast(D().toastCore, 'good');
    W.events.push({ t: W.time, type: 'coreBroken', by: byBall ? byBall.name : '' });
  }

  // ===========================================================================
  // 16. ТРОС
  // ===========================================================================
  function ropeHangPos(out) {
    const A = LEVEL_CONFIG.rope.anchor;
    const t = W.time;
    const sw = W.ropeCut ? 0 : LEVEL_CONFIG.rope.swing;
    const ax = Math.sin(t * 1.15) * sw * 0.6;
    const az = Math.cos(t * 0.83) * sw * 0.45;
    const L = W.ropeLen;
    return (out || new THREE.Vector3()).set(
      A.x + Math.sin(ax) * L,
      A.y - Math.cos(ax) * Math.cos(az) * L,
      A.z + Math.sin(az) * L
    );
  }

  function hangPlayer() {
    const b = W.player;
    if (!b) return;
    b.kinematic = true;
    b.mounted = false;
    b.v.set(0, 0, 0);
    ropeHangPos(b.p);
    b.mountPos.copy(b.p);
    b.restT = 0;
    W.ropeCut = false;
    if (b.mesh) b.mesh.position.copy(b.p);
  }

  function cutRope() {
    if (W.ropeCut || W.state !== 'play' || !W.player) return false;
    if (W.currentFloor !== 0) return false;   // v4.0: трос есть только на первом этаже
    W.ropeCut = true;
    W.cutCount++;
    const b = W.player;
    b.kinematic = false;
    b.mounted = false;
    // v3.5: perfect cut — рез без предварительного наклона стакана
    const tiltMag = Math.hypot(W.tilt.rotX, W.tilt.rotZ);
    const perfect = tiltMag < 0.03;
    // v4.1: на L8+ идеальный рез обязателен — неидеальный замедляет шар на 10%
    const cutPenalty = (LV().perfectCut && !perfect) ? 0.9 : 1.0;
    if (LV().perfectCut && !perfect && W.runStats) W.runStats.cutMisses++;
    const push = 0.6 * 1 * cutPenalty;
    b.v.set(rnd(-0.25, 0.25), -push, rnd(-0.25, 0.25));
    b.restT = 0;
    Sound.cut();
    if (cutPenalty < 1) toast(curLang === 'ru' ? 'Срез кривой — шар медленнее (−10%)' : 'Crooked cut — the ball is slower (−10%)', 'warn');
    else toast(D().toastCut, 'good');
    if (perfect) {
      W.perfectCuts++;
      addScore(150, curLang === 'ru' ? 'идеальный срез' : 'perfect cut');
      spawnSparks(b.p.x, b.p.y + b.r, b.p.z, 20, 3.0, 0xffd700);
    }
    W.events.push({ t: W.time, type: 'cut', perfect: perfect, slow: cutPenalty < 1 });
    spawnSparks(b.p.x, b.p.y + b.r, b.p.z, 12, 2.2, 0xffeecc);
    return true;
  }

  // v3.5: досрочно завершить интро и вернуть камеру на дефолт
  function skipIntro() {
    if (!W.intro.active) return;
    W.intro.active = false;
    W.cam.theta = LEVEL_CONFIG.camera.defaultTheta;
    W.cam.phi = LEVEL_CONFIG.camera.defaultPolar;
    W.cam.dist = LEVEL_CONFIG.camera.defaultDist;
    W.cam.spinTheta = 0; W.cam.spinPhi = 0;
    W.introWasActive = false;
    pulseRope();
    if (W.state === 'play') toast(D().statusRope, 'good');
  }

  // v3.5: подсветка троса после интро — три вспышки за 1.5 с
  function pulseRope() { W.ropePulse = 1.5; }

  function updateRopeVisual() {
    if (!W.ropeMesh || !W.player) return;
    const b = W.player;
    const A = LEVEL_CONFIG.rope.anchor;
    if (!W.ropeCut && !b.returning) {
      const dx = b.p.x - A.x, dy = b.p.y - A.y, dz = b.p.z - A.z;
      const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
      W.ropeMesh.visible = true;
      W.ropeMesh.scale.set(1, Math.max(0.01, len), 1);
      W.ropeMesh.position.set(A.x + dx / 2, A.y + dy / 2, A.z + dz / 2);
      W.ropeMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0),
        new THREE.Vector3(dx, dy, dz).normalize());
    } else {
      // обрубок у анкера (v4.0: на этажах 1+ трос не показываем вовсе)
      W.ropeMesh.visible = (W.currentFloor === 0);
      W.ropeMesh.scale.set(1, 0.9, 1);
      W.ropeMesh.position.set(A.x, A.y - 0.45, A.z);
      W.ropeMesh.quaternion.identity();
    }
    // подсветка, когда курсор в зоне разреза; пульс после интро (v3.5)
    const rm = W.ropeMesh.material;
    if (rm && rm.emissive) {
      if (W.ropePulse > 0 && !W.ropeCut) {
        const ph = Math.sin(W.ropePulse * 12.6);          // ~3 вспышки за 1.5 с
        rm.emissive.setHex(ph > 0 ? 0x00ffcc : 0x1a4a3f);
        rm.emissiveIntensity = 1.2 + 1.3 * Math.abs(ph);
      } else if (W.ropeHover && !W.ropeCut) {
        rm.emissive.setHex(0xffcc44);
        rm.emissiveIntensity = 1.5 + 0.9 * Math.sin(W.time * 13);
      } else {
        rm.emissive.setHex(0x221a08);
        rm.emissiveIntensity = 1;
      }
    }
  }

  // ===========================================================================
  // 17. ЭФФЕКТЫ: искры, ударные волны, салют
  // ===========================================================================
  const SPARK_N = 1500;
  const TRAIL_N = 32;                 // v3.5: длина трейла игрового шара

  function initFX() {
    if (W.sparks) { if (W.sparks.parent) W.sparks.parent.remove(W.sparks); }
    const pos = new Float32Array(SPARK_N * 3);
    const col = new Float32Array(SPARK_N * 3);
    for (let i = 0; i < SPARK_N; i++) { pos[i * 3 + 1] = -9999; }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const m = new THREE.PointsMaterial({
      size: 0.3, vertexColors: true, transparent: true, opacity: 0.95,
      depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true
    });
    W.sparks = new THREE.Points(g, m);
    W.sparks.frustumCulled = false;
    W.sparks.renderOrder = 6;
    W.glassGroup.add(W.sparks);
    W.sparkData = [];
    for (let i = 0; i < SPARK_N; i++) W.sparkData.push({ life: 0, max: 1, vx: 0, vy: 0, vz: 0, c: new THREE.Color(), drag: 1.6 });
    W.sparkCursor = 0;
    // v3.5: трейл игрового шара — 32 точки, создаётся один раз и переиспользуется
    if (!W.trail) {
      const tpos = new Float32Array(TRAIL_N * 3), tcol = new Float32Array(TRAIL_N * 3);
      for (let i = 0; i < TRAIL_N; i++) tpos[i * 3 + 1] = -9999;
      const tg = new THREE.BufferGeometry();
      tg.setAttribute('position', new THREE.BufferAttribute(tpos, 3));
      tg.setAttribute('color', new THREE.BufferAttribute(tcol, 3));
      tg.setDrawRange(0, TRAIL_N);
      const tm = new THREE.PointsMaterial({ size: 7, vertexColors: true, transparent: true, opacity: 0.85,
        sizeAttenuation: false, depthWrite: false, blending: THREE.AdditiveBlending });
      W.trail = { positions: tpos, colors: tcol, head: 0, points: new THREE.Points(tg, tm), fade: 0, dirty: false };
      W.trail.points.frustumCulled = false;
      W.trail.points.renderOrder = 4;
    }
    // в сцену, не в стакан: трейл пишется в мировых координатах и не должен
    // ни вращаться вместе со стаканом, ни попадать под disposeGroup
    if (W.trail.points.parent !== W.scene) W.scene.add(W.trail.points);
    W.waves = [];
    for (let i = 0; i < 14; i++) {
      const mesh = new THREE.Mesh(new THREE.RingGeometry(0.72, 1.0, 44),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
      mesh.visible = false; mesh.renderOrder = 5;
      W.glassGroup.add(mesh);
      W.waves.push({ mesh: mesh, life: 0, max: 1, size: 1 });
    }
  }

  function spawnSparks(x, y, z, count, speed, colorNum) {
    if (!W.sparkData) return;
    const pos = W.sparks.geometry.attributes.position.array;
    const col = W.sparks.geometry.attributes.color.array;
    const c = new THREE.Color(colorNum);
    for (let i = 0; i < count; i++) {
      const idx = W.sparkCursor; W.sparkCursor = (W.sparkCursor + 1) % SPARK_N;
      const d = W.sparkData[idx];
      // случайное направление на сфере
      const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, s = Math.sqrt(1 - u * u);
      const sp = speed * rnd(0.45, 1.15);
      d.vx = Math.cos(th) * s * sp; d.vy = u * sp * 0.9 + 0.6; d.vz = Math.sin(th) * s * sp;
      d.max = d.life = LEVEL_CONFIG.magic.sparkLife * rnd(0.6, 1.5);
      d.c.copy(c).offsetHSL(rnd(-0.05, 0.05), 0, rnd(-0.05, 0.2));
      d.drag = rnd(1.1, 2.2);
      pos[idx * 3] = x; pos[idx * 3 + 1] = y; pos[idx * 3 + 2] = z;
      col[idx * 3] = d.c.r; col[idx * 3 + 1] = d.c.g; col[idx * 3 + 2] = d.c.b;
    }
    W.sparks.geometry.attributes.position.needsUpdate = true;
    W.sparks.geometry.attributes.color.needsUpdate = true;
  }

  function spawnShockwave(x, y, z, size, colorNum) {
    let slot = null;
    for (const w of W.waves) if (w.life <= 0) { slot = w; break; }
    if (!slot) slot = W.waves[0];
    slot.life = slot.max = 0.45;
    slot.size = size;
    slot.mesh.visible = true;
    slot.mesh.position.set(x, y, z);
    slot.mesh.material.color.set(colorNum);
    slot.mesh.scale.setScalar(size * 0.25);
  }

  function updateFX(dt) {
    if (W.sparks) {
      const pos = W.sparks.geometry.attributes.position.array;
      const col = W.sparks.geometry.attributes.color.array;
      let any = false;
      for (let i = 0; i < SPARK_N; i++) {
        const d = W.sparkData[i];
        if (d.life <= 0) continue;
        any = true;
        d.life -= dt;
        const k = Math.max(0, 1 - d.drag * dt);
        d.vx *= k; d.vy = d.vy * k - 6.0 * dt; d.vz *= k;
        pos[i * 3] += d.vx * dt; pos[i * 3 + 1] += d.vy * dt; pos[i * 3 + 2] += d.vz * dt;
        const f = Math.max(0, d.life / d.max);
        col[i * 3] = d.c.r * f; col[i * 3 + 1] = d.c.g * f; col[i * 3 + 2] = d.c.b * f;
        if (d.life <= 0) { pos[i * 3 + 1] = -9999; col[i * 3] = col[i * 3 + 1] = col[i * 3 + 2] = 0; }
      }
      if (any) {
        W.sparks.geometry.attributes.position.needsUpdate = true;
        W.sparks.geometry.attributes.color.needsUpdate = true;
      }
    }
    for (const w of W.waves) {
      if (w.life <= 0) { if (w.mesh.visible) w.mesh.visible = false; continue; }
      w.life -= dt;
      const t = 1 - Math.max(0, w.life / w.max);
      w.mesh.scale.setScalar(w.size * (0.25 + t * 1.9));
      w.mesh.material.opacity = 0.85 * (1 - t);
      billboard(w.mesh);
    }
    // v3.5: трейл гаснет сам (~0.92 за кадр)
    if (W.trail && W.trail.points) {
      if (W.trail.fade > 0) {
        W.trail.fade = Math.max(0, W.trail.fade - dt);
        const f = Math.pow(0.92, dt * 60);
        const tc = W.trail.colors;
        for (let i = 0; i < TRAIL_N; i++) {
          tc[i * 3] *= f; tc[i * 3 + 1] *= f; tc[i * 3 + 2] *= f;
        }
        if (W.trail.fade <= 0) W.trail.colors.fill(0);
        W.trail.dirty = true;
      }
      if (W.trail.dirty) {
        W.trail.points.geometry.attributes.position.needsUpdate = true;
        W.trail.points.geometry.attributes.color.needsUpdate = true;
        W.trail.dirty = false;
      }
    }
    if (W.fireworkT > 0) {
      W.fireworkT -= dt;
      W.fireworkAcc = (W.fireworkAcc || 0) + dt;
      if (W.fireworkAcc > 0.16) {
        W.fireworkAcc = 0;
        const a = Math.random() * Math.PI * 2, rr = rnd(2, 14);
        const y = rnd(-2, 12);
        const colors = [0xff3355, 0x00ffaa, 0xffcc00, 0x3d7bff, 0xd946ef, 0xffffff];
        spawnSparks(Math.cos(a) * rr, y, Math.sin(a) * rr, 34, rnd(4, 8), colors[(Math.random() * colors.length) | 0]);
        Sound.hit(0.5);
      }
    }
  }

  // v3.5: сквош-стретч — плоский «шлёп» после удара сильнее 5 м/с
  // v3.5: точка трейла игрового шара при скорости > 3 м/с
  function pushTrail() {
    if (MOBILE || !W.trail || !W.trail.points || !W.player || !W.player.alive) return;
    const pl = W.player;
    if (pl.v.length() <= 3.0) return;
    const i = W.trail.head;
    W.trail.positions[i * 3] = pl.p.x;
    W.trail.positions[i * 3 + 1] = pl.p.y;
    W.trail.positions[i * 3 + 2] = pl.p.z;
    W.trail.colors[i * 3] = 0.6; W.trail.colors[i * 3 + 1] = 0.9; W.trail.colors[i * 3 + 2] = 1.0;
    W.trail.head = (i + 1) % TRAIL_N;
    W.trail.fade = 1;
    W.trail.dirty = true;
  }

  const _bbQ = new THREE.Quaternion();
  function billboard(mesh) {
    if (!W.camera) return;
    _bbQ.copy(W.glassGroup.quaternion).invert().multiply(W.camera.quaternion);
    mesh.quaternion.copy(_bbQ);
  }

  // ===========================================================================
  // 18. ИГРОВАЯ ЛОГИКА: ядро, кнопка, ловушка, победа/поражение, авто-помощь
  // ===========================================================================
  const DEG = Math.PI / 180;


  // Финальная шахта: участок между горловиной воронки и кнопкой.
  // Поле щита гасит боковой снос игрового шара и слегка тянет его к оси,
  // и отбивается кронштейном кнопки на сетку — необъяснимое поражение.
  function shaftAssist(b, dt) {
    const C = LEVEL_CONFIG;
    if(W.currentFloor!==3)return;
    const yTop = C.finalFunnel.throatY + 0.05;          // низ горловины (3.2)
    const yBot = C.button.y + 0.3; // v4.0: выше купола кнопки — не мешаем скатиться к кольцу победы
    if (b.p.y > yTop || b.p.y < yBot) return;
    // v4.0: ось ствола — смещённое ядро, а не центр стакана
    const ax = C.shield.x, az = C.shield.z;
    const r = Math.hypot(b.p.x - ax, b.p.z - az);
    const k = Math.max(0, 1 - 0.9 * dt);                   // v4.0: мягче гасим разгон (нужен для нырка)
    b.v.x *= k; b.v.z *= k;
    if (r > 0.05) {                                        // тянем к оси ядра
      const f = 2.6 * dt;
      b.v.x -= ((b.p.x - ax) / r) * f;
      b.v.z -= ((b.p.z - az) / r) * f;
    }
  }

  function updateTriggers(dt) {
    const C = LEVEL_CONFIG, T = C.trap, BT = C.button;
    const pl = W.player;

    // v4.0: логика этажей (лунки, цепочка, плиты, переходы)
    updateFloorState(dt);

    // --- ядро щита: разбивается любым шаром ---
    if (W.currentFloor === 3 && W.coreAlive && pl && pl.alive && !pl.kinematic) {
      const rr = C.shield.coreRadius * 1;
      const dx = pl.p.x - C.shield.x, dy = pl.p.y - C.shield.y, dz = pl.p.z - C.shield.z;
      // Граница поля — внешнее гало-кольцо (coreRadius × 1.5), а не сам шар ядра:
      // иначе быстрый шар проскакивает в 5 см от ядра и финал срывается.
      // Поле действует только СВЕРХУ: шар, лежащий на кнопке (ниже ядра),
      // не должен разбивать его через весь уровень.
      const lim = rr * 1.5 + pl.r;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (pl.touched['core'] || (d2 < lim * lim && pl.p.y > C.shield.y - 0.1 && pl.p.y<C.finalFunnel.throatY+.12)) breakCore(pl);
    }

    // --- шары в ловушке ---
    let inTrap = 0;
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer) continue;
      const r = Math.hypot(b.p.x, b.p.z);
      const netY = T.netY - Math.tan(T.netTilt) * (T.netRadius - Math.min(r, T.netRadius));
      b.onNet = !!b.touched['net'];
      b.onGlass = !!b.touched['glassFloor'];
      if (b.p.y < netY + b.r + 0.2) { b.inTrap = true; inTrap++; } else b.inTrap = false;
      // v4.2: шары этажей не исчезают в ловушке — возвращаются на свои места
      if (b.floor !== undefined && b.floor !== null && !b.pipeFree &&
          (b.onGlass || b.p.y < T.netY - 0.9)) {
        if (!b._respawnT) b._respawnT = 0.55;
        b._respawnT -= dt;
        if (b._respawnT <= 0) { respawnBallHome(b); b._respawnT = 0; }
        continue;
      }
      if ((b.onGlass || b.p.y < T.netY - 0.9) && !b.countedLost) {
        b.countedLost = true; W.lostCount++; Sound.fall();
        W.events.push({ t: W.time, type: 'lost', name: b.name });
      }
      if (b.onGlass) {
        b.glassT += dt;
        if (b.glassT > T.dissolveAfter && !b.dissolving) { b.dissolving = T.dissolveTime; }
      } else b.glassT = 0;
    }
    W.trapBalls = inTrap;

    // --- растворение трофеев на стекле ---
    for (const b of W.balls) {
      if (!b.alive || !b.dissolving) continue;
      b.dissolving -= dt;
      const k = clamp(b.dissolving / C.trap.dissolveTime, 0, 1);
      if (b.mesh) { b.mesh.scale.setScalar(1 * k); if (b.mesh.material) b.mesh.material.opacity = k, b.mesh.material.transparent = true; }
      if (b.glow) b.glow.visible = k > 0.05;
      if (b.dissolving <= 0) {
        b.alive = false;
        if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
        if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
        W.events.push({ t: W.time, type: 'dissolve', name: b.name });
      }
    }

    // --- игровой шар ---
    if (!pl || !pl.alive) return;
    const plR = Math.hypot(pl.p.x, pl.p.z);
    const plRBtn = Math.hypot(pl.p.x - LEVEL_CONFIG.shield.x, pl.p.z - LEVEL_CONFIG.shield.z);   // v4.0: ось кнопки
    const netYpl = T.netY - Math.tan(T.netTilt) * (T.netRadius - Math.min(plR, T.netRadius));
    pl.onNet = !!pl.touched['net'];
    pl.onGlass = !!pl.touched['glassFloor'];
    const inTrapZone = pl.p.y < netYpl + pl.r + 0.25 || pl.onGlass;

    if(W.currentFloor===3 && W.state==='play' && pl.p.y < BT.y - 0.6) { askFloorFail('final'); return; }
    if (inTrapZone && W.state === 'play' && W.trapTimer < 0 && !W.rewind.active) {
      W.trapTimer = T.gameOverDelay;
      Sound.trap();
      toast(D().toastTrap, 'bad');
      W.events.push({ t: W.time, type: 'trapEnter' });
    }
    if (W.trapTimer > 0 && W.state === 'play' && !W.rewind.active) {
      W.trapTimer -= dt;
      if (!inTrapZone) W.trapTimer = -1;                 // выбрался — отбой
      else if (W.trapTimer <= 0) {
        // v3.5: откат шара на трос вместо поражения
        startRewind('trap');
      }
    }

    // v3.5: продвижение вниз сбрасывает серию фейлов
    if (W.state === 'play' && pl.p.y < W.lowestY - 2) {
      W.lowestY = Math.min(W.lowestY, pl.p.y);
      if (W.failStreak > 0) W.failStreak = 0;
    }

    // v4.0: подсказка первого этажа — один раз после разреза троса
    // (подсказки этажей 2-4 показываются при переходе, см. updateFloorState)
    if (W.state === 'play' && W.visited && !W.rewind.active) {
      if (LV().hints >= 1 && !W.visited.floors[0] && W.ropeCut && W.currentFloor === 0 &&
          pl.p.y < LEVEL_CONFIG.platformA.y + 1.5 && pl.p.y > LEVEL_CONFIG.platformA.y - 2.5) {
        W.visited.floors[0] = true;
        toast(D().floor0Hint, 'magic', 3200);
      }
    }

    // v4.2: автовозврат на трос УДАЛЁН — трос не «восстанавливается»,
    // срезавшийся шар больше не подвешивается обратно сам по себе
    if (false && W.ropeCut && !pl.returning && W.state === 'play' && (pl.idleT || 0) > C.physics.returnAfter && !inTrapZone) {
      pl.returning = true; pl.returnT = 0; pl.returnFrom = pl.p.clone();
      pl.kinematic = true; pl.v.set(0, 0, 0);
      Sound.ui(); toast(D().toastReturned, 'good');
      W.events.push({ t: W.time, type: 'return' });
    }
    if (pl.returning) {
      pl.returnT += dt / C.physics.returnDuration;
      const k = pl.returnT >= 1 ? 1 : (pl.returnT < 0.5 ? 2 * pl.returnT * pl.returnT : 1 - Math.pow(-2 * pl.returnT + 2, 2) / 2);
      if (W.currentFloor > 0 && W.floorEntry) {
        // v4.0: на этажах 1+ возврат — к площадке входа этажа
        pl.p.lerpVectors(pl.returnFrom, W.floorEntry, k);
        if (pl.returnT >= 1) { pl.returning = false; pl.idleT = 0; pl.kinematic = false; pl.v.set(0, 0, 0); }
      } else {
        ropeHangPos(_tv);
        pl.p.lerpVectors(pl.returnFrom, _tv, k);
        if (pl.returnT >= 1) { pl.returning = false; pl.idleT = 0; hangPlayer(); }
      }
    } else if (!W.ropeCut && !pl.returning) {
      pl.kinematic = true;
      ropeHangPos(pl.p);
    }

    // --- кнопка: победа ---
    // v4.0: кнопка — капсула-купол радиусом radius*K; шар может покоиться на макушке
    // (y ≈ BT.y+thick/2+radius*K+pl.r), поэтому верхняя граница окна учитывает купол
    const onBtnTop = pl.touched['button'] && plRBtn < (BT.radius * 1) + pl.r * 0.6 &&
      pl.p.y > BT.y - 0.6 && pl.p.y < BT.y + BT.thickness / 2 + (BT.radius * 1) + pl.r + 0.35;
    if (onBtnTop && W.state === 'play') {
      if (W.coreAlive) {
        if ((W.coreWarnT || 0) <= 0) { toast(D().statusCore, 'warn'); W.coreWarnT = 2.5; }
      } else {
        startWin();
      }
    }
    if (W.coreWarnT > 0) W.coreWarnT -= dt;
  }

  function startWin() {
    if (W.state !== 'play') return;
    if (W.currentFloor !== 3) return;   // v4.0: победа — только на четвёртом этаже
    W.state = 'winning';
    W.winT = 0;
    W.slowmo = 1.0; W.slowmoScale = 0.3;
    // v3.5: финальный уровень — шестисекундный салют
    const finale = W.currentLevel === LEVELS.length - 1;
    W.fireworkT = finale ? 6.0 : 3.0; W.fireworkAcc = 0;
    W.flashT = 0.25;                       // v3.5: вспышка tone-mapping
    Sound.victory(finale);
    // v3.5: очки за финиш, ×2 если быстрее 45 с
    const speedBonus = W.runTime < 45 ? 2 : 1;
    addScore(1000 * speedBonus, curLang === 'ru' ? 'финиш' : 'finish');
    // v3.5: кинематографичный финал — камера ныряет к кнопке
    W.cine = { active: true, t: 0, dur: 1.6, fromDist: W.cam.dist,
      fromY: (W.camTargetY === undefined ? LEVEL_CONFIG.camera.targetY : W.camTargetY) };
    W.cam.tDist = 22;
    W.camTargetY = -1.5;
    W.camTargetX = LEVEL_CONFIG.shield.x;   // v4.0: кино смотрит на смещённую кнопку
    W.camTargetZ = LEVEL_CONFIG.shield.z;
    W.events.push({ t: W.time, type: 'win' });
    if (W.player) W.player.v.multiplyScalar(0.25);
  }

  function startLose(reason) {
    if (W.state !== 'play') return;
    W.state = 'losing';
    W.loseT = 0;
    W.loseReason = reason || 'trap';
    W.slowmo = 0.8; W.slowmoScale = 0.35;
    Sound.defeat();
    W.events.push({ t: W.time, type: 'lose', reason: W.loseReason });
  }

  // v4.0: цель отката — трос на этаже 0, площадка входа на этажах 1+
  function rewindTargetPos(out) {
    if (W.currentFloor <= 0) { ropeHangPos(out); return false; }
    if (!W.floorEntry) { ropeHangPos(out); return false; }
    out.copy(W.floorEntry);
    return true;
  }

  // v3.5: re-wind вместо модалки поражения. Игровой шар откатывается на трос,
  // поток не прерывается. Ядро, освобождённые тела и взорванные шары НЕ
  // откатываются. Модалка поражения — только с 3 фейлов подряд.
  function startRewind(reason) {
    if(W.currentFloor===3){askFloorFail('final');return;}
    if (W.state !== 'play' || !W.player || !W.player.alive) return false;
    W.failStreak++;
    W.attempts++;
    W.loseReason = reason || 'trap';
    W.rewind.active = true;
    W.rewind.t = 0;
    W.rewind.from.copy(W.player.p);
    W.player.kinematic = true;
    W.player.v.set(0, 0, 0);
    W.player.returning = false;
    W.player.idleT = 0;
    W.trapTimer = -1;
    W.combo = 1;                               // фейл сбивает комбо
    // v4.2: неудачные дороги этажа «Труба» — пересборка (этаж 1)
    if (W.currentFloor === 1 && W.floorState && W.floorState.pipe) {
      for (const r of W.floorState.pipe.roads) {
        if (r.layout && !r.solved) resetPipeRoad(r, 'rewind');
      }
    }
    // v4.1: модификаторы Rewind по уровню (LEVELS[].rewind)
    const rw = LV().rewind || 'free';
    if (rw === 'pen50') { W.score = Math.max(0, W.score - 50); }
    else if (rw === 'pen100') { W.score = Math.max(0, W.score - 100); }
    else if (rw === 'pen200') { W.score = Math.max(0, W.score - 200); W.failStreak++; }
    else if (rw === 'reset') { resetFloorPuzzle(W.currentFloor); }
    Sound.fade();
    const rwMsg = {
      pen50:  curLang === 'ru' ? 'Откат: −50 очков' : 'Rewind: −50 points',
      pen100: curLang === 'ru' ? 'Откат: −100 очков' : 'Rewind: −100 points',
      pen200: curLang === 'ru' ? 'Откат: −200 очков и −1 попытка' : 'Rewind: −200 points and −1 attempt',
      reset:  curLang === 'ru' ? 'Откат: этаж сброшен' : 'Rewind: floor reset'
    };
    if (rwMsg[rw]) toast(rwMsg[rw], 'bad');
    else toast(curLang === 'ru' ? 'Ещё раз!' : 'Again!', 'warn');
    W.events.push({ t: W.time, type: 'rewind', reason: W.loseReason });
    // v3.5 (1.2): модалка поражения — только с 3-го фейла подряд.
    // Откат доиграет, затем 1.4 с паузы — и модалка.
    if (W.failStreak >= 3) {
      W.state = 'losing';
      W.loseT = 0;
      W.slowmo = 0.8; W.slowmoScale = 0.35;
      Sound.defeat();
    }
    return true;
  }

  function updateSequences(dt) {
    // v3.5: откат игрового шара на трос (0.4 с, ease-in-out)
    if (W.rewind.active) {
      W.rewind.t += dt;
      const k = clamp(W.rewind.t / W.rewind.dur, 0, 1);
      const ease = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      const toEntry = rewindTargetPos(_tv);
      W.player.p.lerpVectors(W.rewind.from, _tv, ease);
      if (W.player.mesh) W.player.mesh.position.copy(W.player.p);
      if (k >= 1) {
        W.rewind.active = false;
        if (toEntry) {
          W.player.kinematic = false;
          W.player.v.set(0, 0, 0);
        } else {
          hangPlayer();
        }
        if (W.player.mesh && W.player.mesh.material && W.player.mesh.material.emissive) {
          W.player.mesh.material.emissive.setHex(0x88ddff);
          W.player.mesh.material.emissiveIntensity = 0.55;
        }
        // откат доиграл: при 3+ фейлах дальше пойдёт пауза поражения
      } else {
        return;                                 // пока шар летит на трос — ничего не считаем
      }
    }
    if (W.state === 'winning') {
      W.winT += dt;
      const BT = LEVEL_CONFIG.button;
      const press = clamp(W.winT / 0.25, 0, 1) * BT.pressDepth;
      if (W.buttonMesh) W.buttonMesh.position.y = BT.y - press;
      if (W.buttonGlow) W.buttonGlow.material.opacity = 0.16 + 0.4 * Math.abs(Math.sin(W.winT * 6));
      if (W.winT > 1.0) { W.slowmoScale = lerp(W.slowmoScale, 1, dt * 2); }
      // v3.5: конец кино-наездa камеры — вернуться на дефолт
      if (W.cine && W.cine.active) {
        W.cine.t += dt;
        if (W.cine.t > W.cine.dur) {
          W.cine.active = false;
          W.cam.tDist = LEVEL_CONFIG.camera.defaultDist;
          W.camTargetY = LEVEL_CONFIG.camera.targetY;
          W.camTargetX = 0; W.camTargetZ = 0;
        }
      }
      if (W.winT > 4.4) { W.state = 'win'; if (window.GB_AUTO && window.GB_AUTO.active) autoStop('end'); App.showVictory(); }
    } else if (W.state === 'losing') {
      W.loseT += dt;
      // v3.5: модалка поражения — только при 3+ фейлах подряд
      if (W.loseT > 1.4) {
        if (W.failStreak >= 3) { W.state = 'lose'; App.showDefeat(); }
        else { W.state = 'play'; }
      }
    }
  }

  // ===========================================================================
  // 19. НАКЛОН СТАКАНА, ВИЗУАЛ, ЗАТУХАНИЕ ПЛОЩАДОК, КАМЕРА
  // ===========================================================================
  const _e = new THREE.Euler();
  const _ray = null;                    // создаётся лениво (Raycaster)
  let _raycaster = null;
  const _vWorld = new THREE.Vector3();
  const _vCam = new THREE.Vector3();

  function applyTilt(dt) {
    const T = LEVEL_CONFIG.tilt;
    if (!W.tilt.active) { W.tilt.tRotX = 0; W.tilt.tRotZ = 0; }
    // ограничение суммарного наклона
    const tmag = Math.hypot(W.tilt.tRotX, W.tilt.tRotZ);
    if (tmag > T.max) { const s = T.max / tmag; W.tilt.tRotX *= s; W.tilt.tRotZ *= s; }
    const tau = (W.tilt.active ? T.lerpIn : T.lerpOut) / 3;
    const k = 1 - Math.exp(-dt / Math.max(0.001, tau));
    W.tilt.rotX += (W.tilt.tRotX - W.tilt.rotX) * k;
    W.tilt.rotZ += (W.tilt.tRotZ - W.tilt.rotZ) * k;
    if (!W.tilt.active) {
      // экспоненциальное сглаживание никогда не достигает нуля само:
      // фиксируем точный ноль, чтобы стакан гарантированно выравнивался
      if (Math.abs(W.tilt.rotX) < 1e-4) W.tilt.rotX = 0;
      if (Math.abs(W.tilt.rotZ) < 1e-4) W.tilt.rotZ = 0;
    }
    _e.set(W.tilt.rotX, 0, W.tilt.rotZ, 'XYZ');
    W.glassGroup.quaternion.setFromEuler(_e);

    // визуальная тряска стакана (±0.15 м, 0.3 с)
    const SV = LEVEL_CONFIG.shake;
    if (W.shakeVisual > 0) {
      W.shakeVisual -= dt;
      const a = SV.visualAmp * clamp(W.shakeVisual / SV.visualTime, 0, 1);
      const s = W.shakeSeed;
      W.glassGroup.position.set(
        Math.sin(W.time * 63 + s) * a,
        Math.sin(W.time * 51 + s * 1.7) * a * 0.3,
        Math.cos(W.time * 57 + s * 0.6) * a
      );
    } else if (W.glassGroup.position.lengthSq() > 0) {
      W.glassGroup.position.set(0, 0, 0);
    }
  }

  function updateVisuals(dt) {
    const C = LEVEL_CONFIG;
    // шары
    for (const b of W.balls) {
      if (!b.alive || !b.mesh) continue;
      b.mesh.position.copy(b.p);
      if (Math.abs(b.spinRate) > 0.001) {
        _qInv.setFromAxisAngle(b.spinAxis, b.spinRate * dt);
        b.mesh.quaternion.premultiply(_qInv);
      }
      const mat = b.mesh.material;
      if (b.flash > 0) {
        b.flash -= dt;
        if (mat.emissive) { mat.emissive.setHex(0xffffff); mat.emissiveIntensity = 3.2; }
        if (b.glow) b.glow.material.opacity = 0.7;
      } else if (mat.emissive && b.chargeT <= 0) {
        if (b.isPlayer) { mat.emissive.setHex(0x88ddff); mat.emissiveIntensity = 0.55; }
        else if (b.colorIdx >= 0) { mat.emissive.setHex(C.palette[b.colorIdx].emissive); mat.emissiveIntensity = 0.85; }
        if (b.glow) b.glow.material.opacity = b.isPlayer ? 0.2 : 0.12;
      }
      // кольца заряда
      if (b.ring && b.ring.visible) { b.ring.position.copy(b.p); billboard(b.ring); }
    }

    // ядро щита
    if (W.currentFloor === 3 && W.coreAlive && W.coreMesh) {
      W.coreMesh.rotation.y += dt * 0.8;
      W.coreMesh.rotation.x += dt * 0.35;
      const pulse = 1.15 + 0.45 * Math.sin(W.time * 3.1);
      W.coreMesh.material.emissiveIntensity = pulse;
      if (W.coreInner) { W.coreInner.rotation.y -= dt * 1.4; W.coreInner.scale.setScalar(0.9 + 0.12 * Math.sin(W.time * 4.4)); }
      for (let i = 0; i < W.halos.length; i++) {
        const h = W.halos[i];
        h.rotation.z += dt * (i ? -0.9 : 0.6);
        h.rotation.y += dt * (i ? 0.4 : -0.3);
        h.material.opacity = 0.35 + 0.25 * Math.sin(W.time * 2.4 + i);
      }
    }

    // кнопка
    if (W.buttonMesh && W.state !== 'winning' && W.state !== 'win') {
      const ready = !W.coreAlive;
      W.buttonMesh.material.emissiveIntensity = ready ? 1.5 + 0.8 * Math.sin(W.time * 4.5) : 0.55 + 0.2 * Math.sin(W.time * 2);
      if (W.buttonGlow) W.buttonGlow.material.opacity = ready ? 0.2 + 0.12 * Math.sin(W.time * 4.5) : 0.08;
    }
    if (W.trapHoleRing) {
      W.trapHoleRing.material.opacity = 0.6 + 0.35 * Math.sin(W.time * 3.3);
    }

    if (W.ropePulse > 0) W.ropePulse = Math.max(0, W.ropePulse - dt);
    updateRopeVisual();
    applyTilt(dt);
    updateFade(dt);
    updatePalette(dt);        // v4.0: плавная смена палитры этажей
    updateGateVisual(dt);     // v4.0: анимация открывания люка
  }

  function updateFade(dt) {
    if (!W.camera || !W.fadeables.length) return;
    if (!_raycaster) _raycaster = new THREE.Raycaster();
    W.scene.updateMatrixWorld();

    const meshes = W.fadeables.map(f => f.mesh).filter(Boolean);
    const blocked = new Set();

    // лучи от камеры к важным объектам
    const targets = [];
    if (W.player && W.player.alive) targets.push(W.player);
    // кнопка и ядро — цели финальной зоны: учитываем, когда шар уже ниже воронки
    // или ядро разбито (иначе площадки гасли бы при любом взгляде сверху)
    const finale = (W.player && W.player.p.y < LEVEL_CONFIG.platformB.y - 1) || !W.coreAlive;
    if (finale) {
      if (W.currentFloor === 3 && W.coreAlive && W.coreGroup) targets.push(W.coreGroup.position);
      if (W.buttonGroup) targets.push(W.buttonGroup.position);
    }

    _vCam.copy(W.camera.position);
    for (const t of targets) {
      _vWorld.copy(t.p !== undefined ? t.p : t);
      W.glassGroup.localToWorld(_vWorld);
      const dir = _vWorld.clone().sub(_vCam);
      const dist = dir.length();
      if (dist < 0.5) continue;
      dir.normalize();
      _raycaster.set(_vCam, dir);
      // запас: не считать перекрытием поверхность, на которой объект лежит
      _raycaster.far = dist - (t.p !== undefined ? (t.r + 0.3) : 0.45);
      if (_raycaster.far < 0.6) continue;
      const hits = _raycaster.intersectObjects(meshes, false);
      for (const h of hits) blocked.add(h.object);
    }
    _raycaster.far = Infinity;

    const rate = 1 - Math.exp(-dt / 0.07);        // ~0.2 с на полное затухание
    for (const f of W.fadeables) {
      const mat = f.mesh && f.mesh.material;
      if (!mat) continue;
      // камера сверху или снизу площадки
      let base = f.base;
      if (f.kind === 'platform' || f.kind === 'bracket' || f.kind === 'net') {
        const topY = f.topY === undefined ? 0 : f.topY;
        _vWorld.set(0, topY, 0);
        W.glassGroup.localToWorld(_vWorld);
        base = (W.camera.position.y > _vWorld.y) ? f.base : (f.kind === 'net' ? f.base * 0.7 : 0.25);
      }
      const target = blocked.has(f.mesh) ? Math.min(0.1, base * 0.35) : base;
      mat.opacity = lerp(mat.opacity === undefined ? target : mat.opacity, target, rate);
      mat.transparent = true;
      mat.depthWrite = mat.opacity > 0.65;
    }
  }

  function updateCamera(dt) {
    const C = LEVEL_CONFIG.camera;
    const k = 1 - Math.exp(-dt / 0.085);
    // v3.5: интро-полёт камеры (2.5 с, скипается любым тапом)
    if (W.intro.active) {
      W.intro.t += dt;
      const kk = clamp(W.intro.t / W.intro.dur, 0, 1);
      const ease = 1 - Math.pow(1 - kk, 3);
      W.cam.theta = lerp(-0.8 * Math.PI, C.defaultTheta, ease);
      W.cam.phi = lerp(1.35, C.defaultPolar, ease);
      W.cam.dist = lerp(78, C.defaultDist, ease);
      if (kk >= 1) W.intro.active = false;
    }
    // инерция вращения камеры после отпускания ПКМ (см. bindInput)
    if (W.cam.spinTheta !== 0 || W.cam.spinPhi !== 0) {
      W.cam.tTheta += W.cam.spinTheta * dt;
      W.cam.tPhi += W.cam.spinPhi * dt;
      const damp = Math.exp(-dt / 0.26);
      W.cam.spinTheta *= damp; W.cam.spinPhi *= damp;
      if (Math.abs(W.cam.spinTheta) < 0.004) W.cam.spinTheta = 0;
      if (Math.abs(W.cam.spinPhi) < 0.004) W.cam.spinPhi = 0;
    }
    W.cam.tPhi = clamp(W.cam.tPhi, C.minPolar, C.maxPolar);
    W.cam.tDist = clamp(W.cam.tDist, C.minDist, C.maxDist);
    if (!W.intro.active) {
      W.cam.theta += (W.cam.tTheta - W.cam.theta) * k;
      W.cam.phi += (W.cam.tPhi - W.cam.phi) * k;
      W.cam.dist += (W.cam.tDist - W.cam.dist) * k;
      if (Math.abs(W.cam.tTheta - W.cam.theta) < 1e-6) W.cam.theta = W.cam.tTheta;
      if (Math.abs(W.cam.tPhi - W.cam.phi) < 1e-6) W.cam.phi = W.cam.tPhi;
      if (Math.abs(W.cam.tDist - W.cam.dist) < 1e-6) W.cam.dist = W.cam.tDist;
    }

    const sp = Math.sin(W.cam.phi), cp = Math.cos(W.cam.phi);
    const tx = (W.camTargetX || 0), ty = (W.camTargetY === undefined ? C.targetY : W.camTargetY), tz = (W.camTargetZ || 0);
    const dist = W.cam.dist + (W.camBreath || 0);   // v4.0: «дыхание» при переходе этажей
    W.camera.position.set(
      tx + dist * sp * Math.sin(W.cam.theta),
      ty + dist * cp,
      tz + dist * sp * Math.cos(W.cam.theta)
    );
    // тряска экрана ОБЯЗАНА затухать до нуля: раньше W.screenShake только
    // устанавливался и никогда не уменьшался — после первой встряски/взрыва
    // камера дрожала всю оставшуюся игру
    if (W.screenShake > 0) {
      W.screenShake = Math.max(0, W.screenShake - dt);
      if (W.screenShake <= 0) W.screenShakeAmp = 0;
    }
    if (W.screenShake > 0) {
      const f = clamp(W.screenShake / 0.25, 0, 1);
      const a = W.screenShakeAmp * f * f;               // квадратичное затухание
      W.camera.position.x += Math.sin(W.time * 77) * a;
      W.camera.position.y += Math.sin(W.time * 91.7) * a * 0.8;
      W.camera.position.z += Math.cos(W.time * 83.3) * a;
    }
    W.camera.lookAt(tx, ty, tz);
    W.camera.updateMatrixWorld();
  }

  // ===========================================================================
  // ===========================================================================
  // ===========================================================================
  // 21. DOM / ЛОКАЛИЗАЦИЯ / HUD
  // ===========================================================================
  function $(id) { return document.getElementById(id); }
  const el = {};
  const EL_IDS = ['scene', 'txt-title', 'txt-subtitle', 'txt-time-label', 'time-val', 'txt-magic-label', 'magic-val',
    'txt-trap-label', 'trap-val', 'txt-btn-shake', 'txt-btn-shake2', 'btn-shake', 'btn-shake-top', 'shake-fill', 'btn-cut', 'txt-btn-cut',
      'lang-text', 'btn-lang', 'audio-ico', 'btn-audio',  'btn-help',
    'txt-btn-restart', 'btn-restart', 'txt-tilt-l', 'txt-tilt-r', 'tilt-deg', 'tilt-fill',
    'txt-status-line', 'status-row', 'txt-legend-red', 'txt-legend-blue', 'txt-legend-yellow', 'txt-legend-core',
    'txt-legend-btn', 'txt-legend-stats', 'txt-hint', 'toasts',  
         
        
          
         
    'modal-menu', 'txt-menu-title', 'txt-menu-subtitle', 'txt-menu-s1', 'txt-menu-s2', 'txt-menu-s3', 'txt-menu-s4',
    'btn-start', 'txt-menu-start', 'btn-menu-help', 'txt-menu-help',
    'modal-victory', 'txt-victory-title', 'txt-victory-desc', 'txt-stat-time', 'stat-time', 'txt-stat-magic',
    'stat-magic', 'txt-stat-lost', 'stat-lost', 'txt-stat-cuts', 'stat-cuts', 'btn-again', 'txt-victory-again',
      'btn-victory-menu', 'txt-victory-menu',
    'modal-defeat', 'txt-defeat-title', 'txt-defeat-desc', 'txt-dstat-time', 'dstat-time', 'txt-dstat-magic',
    'dstat-magic', 'txt-dstat-reason', 'dstat-reason', 'btn-retry', 'txt-defeat-retry', 
     'btn-defeat-menu', 'txt-defeat-menu',
    'modal-help', 'txt-help-title', 'txt-help-body', 'btn-close-help', 'txt-help-close',
    'modal-pause', 'txt-pause-title', 'txt-pause-desc', 'btn-resume', 'txt-pause-resume',
    'btn-pause-restart', 'txt-pause-restart', 'btn-pause-menu', 'txt-pause-menu',
    'pill-magic', 'pill-trap', 'pill-score', 'txt-score-label', 'score-val',
    'pill-combo', 'combo-val', 'level-strip', 'win-stars', 'btn-next', 'txt-next',
    'lvl-total', 'btn-sandbox', 'txt-sandbox', 'txt-level-name',
    'stat-score', 'txt-stat-score', 'stat-perfect', 'txt-stat-perfect',
    'floor-ind', 'floor-task',
    'btn-pipe-reset', 'txt-pipe-reset', 'btn-floor-restart', 'txt-floor-restart',
    'btn-floors', 'txt-floors',
    'modal-floorfail', 'ff-title', 'ff-desc', 'btn-ff-restart', 'txt-ff-restart', 'btn-ff-menu', 'txt-ff-menu',
       
       
    // v4.5: архитектура «МАТ-БУМ! 3» — экраны, верхняя панель, боковые панели
    'scr-start', 'scr-select', 'scr-hall', 'scr-help', 'scr-game',
    'btn-back', 'btn-theme', 'theme-ico', 'btn-user',
    'b-play', 'txt-menu-play', 'b-train', 'txt-menu-train', 'b-hall', 'txt-menu-hall', 'b-help', 'txt-menu-help2',
    'txt-ver', 'side-recs', 'txt-side-rec-t', 'txt-side-open', 'side-prog', 'txt-side-prog-t', 'txt-side-stars',
    'txt-sel-title', 'txt-sel-sub', 'txt-hall-title', 'txt-hall-sub', 'hall-list', 'hall-total', 'hall-ya',
    'txt-help-scr-title', 'txt-help-scr-sub', 'txt-help-body2', 'txt-help-footer',
    'train-plate', 'tut-step', 'tut-text',
    'btn-auto', 'txt-btn-auto'];

  function cacheDom() {
    for (const id of EL_IDS) {
      const node = $(id);
      if (node) el[id.replace(/-/g, '_')] = node;
    }
  }

  // v3.5: очки с комбо. События реже 3 с подряд наращивают множитель ×2→×4.
  function addScore(amount, label) {
    if (W.time - W.lastEventTime < 3) W.combo = Math.min(4, W.combo * 2);
    else W.combo = 1;
    W.lastEventTime = W.time;
    const total = Math.round(amount * W.combo);
    W.score += total;
    toast('+' + total + (W.combo > 1 ? ' ×' + W.combo : '') + (label ? ' · ' + label : ''), 'good');
    W.events.push({ t: W.time, type: 'score', amount: total, combo: W.combo });
  }

  function toast(text, cls, duration) {
    const box = el.toasts;
    if (!box) return;
    while (box.children.length > 3) box.removeChild(box.firstChild);
    const d = document.createElement('div');
    d.className = 'toast' + (cls ? ' ' + cls : '');
    d.innerHTML = text;
    box.appendChild(d);
    setTimeout(() => { if (d.parentNode) d.parentNode.removeChild(d); }, duration || 2600);
  }

  // ===========================================================================
  // v4.1: ПРОГРЕСС, ЧЕЛЛЕНДЖИ, ПЕСОЧНИЦА
  // ===========================================================================
  const PROGRESS_KEY = 'graviboom_v4_levels';       // JSON: 10 × {time, score, stars, challenge}
  const BEST_KEY = 'graviboom_v4_bestScore';        // общий рекорд очков
  const SPECIALS_KEY = 'graviboom_v4_challenges';   // 5 спец-челленджей (bool × 5)

  function freshProgress() {
    return LEVELS.map(() => ({ time: 0, score: 0, stars: 0, challenge: false, fairScore:0, autoScore:0 }));
  }
  function loadProgress() {
    try {
      const a = JSON.parse(window.localStorage.getItem(PROGRESS_KEY) || 'null');
      if (Array.isArray(a) && a.length === LEVELS.length) {
        const f = freshProgress();
        for (let i = 0; i < a.length; i++) {
          if (a[i] && typeof a[i] === 'object') {
            f[i].fairScore=score49(a[i].fairScore);f[i].autoScore=score49(a[i].autoScore);
            f[i].time = +a[i].time || 0; f[i].score = +a[i].score || 0;
            f[i].stars = Math.min(3, Math.max(0, a[i].stars | 0)); f[i].challenge = !!a[i].challenge;
          }
        }
        return f;
      }
    } catch (e) {}
    return freshProgress();
  }
  function saveProgress() {
    try { window.localStorage.setItem(PROGRESS_KEY, JSON.stringify(W.progress)); } catch (e) {}
  }
  function loadSpecials() {
    try {
      const a = JSON.parse(window.localStorage.getItem(SPECIALS_KEY) || 'null');
      if (Array.isArray(a) && a.length === 5) return a.map(Boolean);
    } catch (e) {}
    return [false, false, false, false, false];
  }
  function saveSpecials() {
    try { window.localStorage.setItem(SPECIALS_KEY, JSON.stringify(W.specials)); } catch (e) {}
  }
  // v4.1: 1–5 открыты сразу; 6–10 открываются прохождением предыдущего
  function levelUnlocked(i) {
    if (W.sandboxMenu) return true;
    if (i < 5) return true;
    return !!(W.progress && W.progress[i - 1] && W.progress[i - 1].stars > 0);
  }
  function sandboxUnlocked() {
    return !!(W.progress && W.progress[LEVELS.length - 1] && W.progress[LEVELS.length - 1].stars > 0);
  }
  function challengeCount() {
    let n = 0;
    for (const p of W.progress) if (p.challenge) n++;
    for (const sp of W.specials) if (sp) n++;
    return n;
  }

  // 15 челленджей: 10 по уровням (после 3 звёзд) + 5 специальных.
  // test(rs) получает срез runStats; спец-челленджи проверяются на победе.
  const CHALLENGES = [
    { lvl: 0,  name: ['Без магии', 'No Magic'],           test: () => W.blastCount === 0 },
    { lvl: 1,  name: ['Скорострел', 'Sharpshooter'],      test: () => W.runTime < 90 },
    { lvl: 2,  name: ['Без сброса дорог', 'No Road Resets'],      test: (rs) => rs.roadResets === 0 },
    { lvl: 3,  name: ['Эхоман', 'Echo Man'],              test: (rs) => rs.echoBlasts >= 3 },
    { lvl: 4,  name: ['Без штрафов', 'Penalty-Free'],     test: () => W.attempts === 0 },
    { lvl: 5,  name: ['Полный фокус', 'Full Focus'],      test: (rs) => rs.plateFails === 0 && rs.roadResets === 0 },
    { lvl: 6,  name: ['Ровная линия', 'Straight Line'],   test: (rs) => rs.roadResets === 0 && rs.socketFails === 0 },
    { lvl: 7,  name: ['Только идеальные', 'Perfect Only'],test: () => W.perfectCuts >= 1 && (W.runStats ? W.runStats.cutMisses : 0) === 0 },
    { lvl: 8,  name: ['В такт', 'In Rhythm'],             test: (rs) => rs.plateFails === 0 },
    { lvl: 9,  name: ['Без единого сбоя', 'Flawless'],    test: () => W.attempts === 0 },
    { sp: 0, name: ['Звёздное небо', 'Starry Sky'],       test: () => W.progress.every(p => p.stars >= 3) },
    { sp: 1, name: ['Быстрее света', 'Faster Than Light'],test: () => W.runTime < 45 },
    { sp: 2, name: ['Пацифист', 'Pacifist'],              test: (rs) => W.blastCount === 0 && rs.shakes === 0 },
    { sp: 3, name: ['Коллекционер', 'Collector'],         test: () => W.bestScore >= 5000 },
    { sp: 4, name: ['Архитектор', 'Architect'],           test: () => W.progress.every(p => p.stars >= 1) }
  ];

  // v4.1: полоса уровней в меню — 10 кнопок с замками/звёздами/рекордами
  function renderLevelStrip() {
    const box = el.level_strip;
    if (!box) return;
    box.innerHTML = '';
    while (box.children.length) box.removeChild(box.firstChild);
    // v4.1: сверху — общий счётчик ★ N/30, общий рекорд и челленджи
    let total = 0;
    for (const p of W.progress) total += (p.stars | 0);
    if (el.lvl_total) {
      el.lvl_total.innerHTML =
        '<span>★ <b>' + total + '</b>/30</span>' +
        '<span>' + D().totalBest.replace('{n}', '<b>' + (W.bestScore | 0) + '</b>') + '</span>' +
        '<span>' + D().challengeLine.replace('{n}', String(challengeCount())) + '</span>';
    }
    for (let i = 0; i < LEVELS.length; i++) {
      const locked = !levelUnlocked(i);
      const pr = W.progress[i] || { time: 0, score: 0, stars: 0, challenge: false };
      const nm = LEVELS[i].name[curLang === 'ru' ? 0 : 1];
      const d = document.createElement('button');
      d.className = 'colcard' + (i === W.currentLevel && !W.sandboxMenu ? ' cur' : '') + (locked ? ' locked' : '');
      // v4.5: карточка уровня в стиле МБ3 — номер, свотчи цвета башни, имя, звёзды, рекорд
      const sw = '<span class="sw"><i style="background:' + LEVEL_PALETTES[i][0] + '"></i>' +
                 '<i style="background:' + LEVEL_PALETTES[i][1] + '"></i>' +
                 '<i style="background:' + LEVEL_PALETTES[i][2] + '"></i></span>';
      d.innerHTML =
        (locked ? '<span class="lock">🔒</span>' : (pr.challenge ? '<span class="ch" title="' + D().challengeDoneShort + '">✓</span>' : '')) +
        '<span class="num">' + (i + 1) + '</span>' +
        sw +
        '<span class="nm">' + nm + '</span>' +
        '<span class="stars">' + (pr.stars > 0 ? '★'.repeat(pr.stars) : '·') + '</span>' +
        '<span class="bst">' + (pr.score > 0 ? pr.score : '') + '</span>';
      d.title = (curLang === 'ru' ? 'Уровень ' : 'Level ') + (i + 1) + ' · ' + nm +
        (pr.stars > 0 ? ' · ' + '★'.repeat(pr.stars) : '') +
        (pr.score > 0 ? ' · ' + D().totalBest.replace('{n}', pr.score) : '') +
        (locked ? ' · ' + D().levelLocked : '');
      d.addEventListener('click', () => {
        if (locked) { toast(D().levelLocked, 'warn'); Sound.reject(); return; }
        App.start(i, W.sandboxMenu);
      });
      box.appendChild(d);
    }
    if (el.btn_sandbox) {
      el.btn_sandbox.classList.toggle('hidden', !sandboxUnlocked());
      el.btn_sandbox.classList.toggle('primary', W.sandboxMenu);
    }
  }

  function applyTexts() {
    
    const d = D();
    const T = (key, id) => { if (el[id]) el[id].textContent = d[key]; };
    const H = (key, id) => { if (el[id]) el[id].innerHTML = d[key]; };
    T('title', 'txt_title'); T('subtitle', 'txt_subtitle');
    T('timeLabel', 'txt_time_label'); T('magicLabel', 'txt_magic_label'); T('trapLabel', 'txt_trap_label');
    T('scoreLabel', 'txt_score_label'); T('comboLabel', 'txt_combo_label');
    T('btnShake', 'txt_btn_shake'); T('btnShake2', 'txt_btn_shake2'); T('btnCut', 'txt_btn_cut'); T('btnPipeReset', 'txt_pipe_reset'); T('btnFloorRestart', 'txt_floor_restart'); T('btnFloorsShow', 'txt_floors');
    T('ffTitle', 'ff_title'); T('ffRestart', 'txt_ff_restart'); T('ffMenu', 'txt_ff_menu');
    T('btnRestart', 'txt_btn_restart'); T('btnLang', 'lang_text');
    T('tiltL', 'txt_tilt_l'); T('tiltR', 'txt_tilt_r');
    T('legendRed', 'txt_legend_red'); T('legendBlue', 'txt_legend_blue'); T('legendYellow', 'txt_legend_yellow');
    T('legendCore', 'txt_legend_core'); T('legendBtn', 'txt_legend_btn');
    H('hint', 'txt_hint');
    T('menuTitle', 'txt_menu_title'); T('menuSubtitle', 'txt_menu_subtitle');
    H('menuS1', 'txt_menu_s1'); H('menuS2', 'txt_menu_s2'); H('menuS3', 'txt_menu_s3'); H('menuS4', 'txt_menu_s4');
    T('menuStart', 'txt_menu_start'); T('menuHelp', 'txt_menu_help');
    // v4.5: экраны МБ3
    T('menuPlay', 'txt_menu_play'); T('menuTrain', 'txt_menu_train');
    T('menuHall', 'txt_menu_hall'); T('menuHelp2', 'txt_menu_help2');
    T('ver', 'txt_ver'); T('selTitle', 'txt_sel_title'); T('selSub', 'txt_sel_sub');
    T('hallTitle', 'txt_hall_title'); T('hallSub', 'txt_hall_sub');
    T('helpScrTitle', 'txt_help_scr_title'); T('helpScrSub', 'txt_help_scr_sub');
    T('helpFooter', 'txt_help_footer');
    T('sideRecT', 'txt_side_rec_t'); T('sideProgT', 'txt_side_prog_t'); T('btnAuto', 'txt_btn_auto');
    T('victoryTitle', 'txt_victory_title'); T('victoryDesc', 'txt_victory_desc');
    T('statTime', 'txt_stat_time'); T('statMagic', 'txt_stat_magic'); T('statLost', 'txt_stat_lost'); T('statCuts', 'txt_stat_cuts');
    T('statScore', 'txt_stat_score'); T('statPerfect', 'txt_stat_perfect');
    T('victoryAgain', 'txt_victory_again'); T('victoryMenu', 'txt_victory_menu'); T('nextLevel', 'txt_next');
    T('defeatTitle', 'txt_defeat_title'); T('defeatDesc', 'txt_defeat_desc');
    T('statTime', 'txt_dstat_time'); T('statMagic', 'txt_dstat_magic'); T('statReason', 'txt_dstat_reason');
    T('defeatRetry', 'txt_defeat_retry'); T('defeatMenu', 'txt_defeat_menu');
    T('helpTitle', 'txt_help_title'); if(el.txt_help_body)el.txt_help_body.innerHTML=helpCards49(D().helpBody); T('helpClose', 'txt_help_close');
    T('pauseTitle', 'txt_pause_title'); T('pauseDesc', 'txt_pause_desc');
    T('pauseResume', 'txt_pause_resume'); T('pauseRestart', 'txt_pause_restart'); T('pauseMenu', 'txt_pause_menu');
    if (document.documentElement) document.documentElement.lang = curLang;
    renderLevelStrip();
    updateHud(0.1, true);
    renderSidePanels();      // v4.5: колонки рекордов/прогресса в главном меню
    renderHall();            // v4.5: зал славы
    renderHelpScreen();      // v4.5: экран справки
    refreshIcons49();
    const footer=document.getElementById("help-modal-footer");if(footer)footer.textContent=D().helpFooter;
    renderTrainPlate();      // v4.5: плашка обучения
  }

  function setLanguage(lang) {
    curLang = (lang === 'en') ? 'en' : 'ru';
    try { window.localStorage.setItem('graviboom_lang_v300', curLang); } catch (e) {}
    applyTexts();
  }

  function updateHud(dt, force) {
    W.hudAcc = (W.hudAcc || 0) + dt;
    if (!force && W.hudAcc < 0.1) return;
    const hudDt = W.hudAcc;                       // v4.1: реальный накопленный интервал
    W.hudAcc = 0;
    const d = D();

    if (el.time_val) el.time_val.textContent = fmtTime(W.runTime);

    // заряженные шары
    let charged = 0, mounted = 0, free = 0;
    for (const b of W.balls) {
      if (!b.alive) continue;
      if (b.chargeT > 0) charged++;
      if (b.kinematic) mounted++; else free++;
    }
    if (el.magic_val) el.magic_val.textContent = String(charged);
    if (el.trap_val) el.trap_val.textContent = String(W.trapBalls || 0);
    // v3.5 (4.2): легенда удалена, статистику шаров больше не показываем
    // v3.5 (2.3): таблетки видны только когда есть что показывать
    if (el.pill_magic) el.pill_magic.style.display = charged > 0 ? '' : 'none';
    if (el.pill_trap) el.pill_trap.style.display = (W.trapBalls || 0) > 0 ? '' : 'none';
    // v3.5 (1.4): очки и комбо
    if (el.score_val) el.score_val.textContent = String(W.score);
    if (el.combo_val) el.combo_val.textContent = '×' + W.combo;
    if (el.pill_combo) el.pill_combo.style.opacity = W.combo > 1 ? '1' : '0.35';
    // v3.5 (2.4): пульс HUD по BPM — тем чаще, чем глубже шар
    const hudTop = document.querySelector('.hud-top');
    if (W.state === 'play' && W.player && hudTop) {
      const depth = clamp(1 - (W.player.p.y - LEVEL_CONFIG.glass.yBottom) /
        (LEVEL_CONFIG.glass.yTop - LEVEL_CONFIG.glass.yBottom), 0, 1);
      const bpm = (70 + 60 * depth) / 60;
      if (hudTop.style && hudTop.style.setProperty) hudTop.style.setProperty('--bpm', bpm.toFixed(2) + 's');
      if (!hudTop.classList.contains('pulsing')) hudTop.classList.add('pulsing');
    } else if (hudTop) {
      hudTop.classList.remove('pulsing');
    }
    // v4.1: плашка названия уровня тает к концу прогона первых секунд
    if (el.txt_level_name) {
      if (W.levelNameT > 0 && W.state === 'play') {
        W.levelNameT -= hudDt;
        el.txt_level_name.classList.remove('hidden');
        el.txt_level_name.classList.toggle('fading', W.levelNameT < 0.9);
      } else if (!el.txt_level_name.classList.contains('hidden')) {
        el.txt_level_name.classList.add('hidden');
      }
    }
    // v3.5 (2.3): подсказка внизу гаснет через 5 с игры, возвращается в меню/паузе
    // v4.1: hints<=1 — нижняя подсказка выключена совсем (уровни 6-8 и 9-10)
    if (el.txt_hint) {
      if (LV().hints < 2) el.txt_hint.style.opacity = '0';
      else if (W.state === 'play' && W.time - W.hintShownAt > 5) el.txt_hint.style.opacity = '0';
      else el.txt_hint.style.opacity = '1';
      el.txt_hint.style.transition = 'opacity 0.8s';
    }

    // строка состояния
    if (el.txt_status_line) {
      let txt = d.statusRope, cls = '';
      const pl = W.player;
      if (W.state === 'win' || W.state === 'winning') { txt = d.statusWin; cls = ''; }
      else if (W.state === 'lose' || W.state === 'losing') { txt = d.statusTrap.replace('{n}', String(Math.max(0, Math.ceil(W.trapTimer)))); cls = 'bad'; }
      else if (W.trapTimer > 0) { txt = d.statusTrap.replace('{n}', String(Math.ceil(W.trapTimer))); cls = 'bad'; }
      else if (pl) {
        const y = pl.p.y;
        const f = W.currentFloor || 0;
        if (!W.ropeCut && f === 0) txt = d.statusRope;
        else if (f === 0) {
          const sks = W.floorState && W.floorState.sockets;
          const a = sks ? sks.filter(q => q.full).length : 0, b = sks ? sks.length : 0;
          txt = d.statusSocket.replace('{a}', String(a)).replace('{b}', String(b));
        } else if (f === 1) {
          const pp = W.floorState && W.floorState.pipe;
          if (W.floorSolvedFlag) txt = d.floorSolved;
          else if (pp) {
            const rds = pp.roads.filter(q => q.layout);
            const a = rds.reduce((sum, q) => sum + (q.hit || 0), 0);
            const b = rds.reduce((sum, q) => sum + (q.need || 0), 0);
            txt = d.taskPipe.replace('{a}', String(a)).replace('{b}', String(b));
          } else txt = d.taskPipe;
        } else if (f === 2) {
          const ps = W.floorState && W.floorState.plates;
          const a = ps ? ps.filter(q => q.active).length : 0, b = ps ? ps.length : 0;
          txt = d.plateStatus.replace('{a}', String(a)).replace('{b}', String(b));
        } else if (f === 3) {
          if (y >= -1.6) txt = d.statusCore;
          else txt = d.statusButton;
        } else { txt = d.statusRope; }
        if (charged > 0 && cls !== 'bad') {
          let tmin = 99;
          for (const b of W.balls) if (b.alive && b.chargeT > 0 && b.chargeT < tmin) tmin = b.chargeT;
          txt = d.statusCharged.replace('{n}', String(charged)).replace('{t}', tmin.toFixed(1));
          cls = 'warn';
        }
      }
      if (el.txt_status_line.textContent !== txt) el.txt_status_line.textContent = txt;
      el.txt_status_line.className = cls;
    }

    // v4.0: индикатор этажа (4 точки + n/4 + название)
    if (el.floor_ind) {
      if (!W._floorDots) {
        W._floorDots = [];
        for (let i = 0; i < 4; i++) {
          const dot = document.createElement('i');
          el.floor_ind.appendChild(dot);
          W._floorDots.push(dot);
        }
        const num = document.createElement('span');
        num.className = 'fnum';
        el.floor_ind.appendChild(num);
        W._floorNum = num;
        const nm = document.createElement('span');
        nm.className = 'fname';
        el.floor_ind.appendChild(nm);
        W._floorName = nm;
      }
      const f = clamp(W.currentFloor || 0, 0, 3);
      for (let i = 0; i < 4; i++) {
        W._floorDots[i].className = i < f ? 'done' : (i === f ? 'cur' : '');
      }
      if (W._floorNum.textContent !== undefined) W._floorNum.textContent = (f + 1) + '/4';
      if (W._floorName.textContent !== undefined) W._floorName.textContent = D().floorNames[f];
    }

    // v4.0: строка задания этажа
    if (el.floor_task) {
      const f = clamp(W.currentFloor || 0, 0, 3);
      const d2 = D();
      let task = '';
      if (f === 0) {
        const sks = W.floorState && W.floorState.sockets;
        if (W.floorSolvedFlag) task = d2.floorSolved;
        else if (sks) task = d2.taskSockets.replace('{a}', String(sks.filter(q => q.full).length)).replace('{b}', String(sks.length));
      } else if (f === 1) {
        const pp = W.floorState && W.floorState.pipe;
        if (W.floorSolvedFlag) task = d2.floorSolved;
        else if (pp) {
          const rds = pp.roads.filter(q => q.layout);
          const a = rds.reduce((sum, q) => sum + (q.hit || 0), 0);
          const b = rds.reduce((sum, q) => sum + (q.need || 0), 0);
          task = d2.taskPipe.replace('{a}', String(a)).replace('{b}', String(b));
        }
      } else if (f === 2) {
        const ps = W.floorState && W.floorState.plates;
        if (W.floorSolvedFlag) task = d2.floorSolved;
        else if (ps) task = d2.taskPlates.replace('{a}', String(ps.filter(q => q.active).length)).replace('{b}', String(ps.length));
      } else {
        task = d2.taskButton;
      }
      el.floor_task.title=task;
      el.floor_task.setAttribute('aria-label',task);
      if(matchMedia('(max-width:480px) and (orientation:portrait)').matches){const ratio=task.match(/\d+\s*\/\s*\d+/);task=['◉','⇢','ϟ','◎'][f]+' '+(ratio?ratio[0]:(W.floorSolvedFlag?'✓':(f+1)+'/4'));}
      if (el.floor_task.textContent !== task) el.floor_task.textContent = task;
    }

    // v4.2: кнопки этажных действий (видимость зависит от этажа)
    const fBtn = clamp(W.currentFloor || 0, 0, 3);
    if(el.btn_pipe_reset)el.btn_pipe_reset.style.display=(W.state==='play'&&!W.ffOpen&&!inTransition())?'':'none';
    if(el.btn_floor_restart)el.btn_floor_restart.style.display='none';
    if (el.btn_floors) {
      const anySolved = W.floorSolvedArr && W.floorSolvedArr.some(v => v);
      el.btn_floors.style.display = (W.state === 'play' && anySolved) ? '' : 'none';
      const lbl = W.floorsGhost ? D().btnFloorsHide : D().btnFloorsShow;
      if (el.txt_floors && el.txt_floors.textContent !== lbl) el.txt_floors.textContent = lbl;
    }

    // наклон
    const tmag = Math.hypot(W.tilt.rotX, W.tilt.rotZ) / LEVEL_CONFIG.tilt.max;
    if (el.tilt_fill) {
      const side = Math.abs(W.tilt.rotZ) > Math.abs(W.tilt.rotX) ? (W.tilt.rotZ < 0 ? 1 : -1) : (W.tilt.rotX > 0 ? 1 : -1);
      const w = clamp(tmag, 0, 1) * 50;
      el.tilt_fill.style.width = w.toFixed(1) + '%';
      el.tilt_fill.style.left = (side > 0 ? 50 : 50 - w).toFixed(1) + '%';
      el.tilt_fill.style.background = tmag > 0.55
        ? 'linear-gradient(90deg,#ffcc00,#ff3355)'
        : 'linear-gradient(90deg,#00d4ff,#00ffaa)';
    }
    if (el.tilt_deg) el.tilt_deg.textContent = (Math.hypot(W.tilt.rotX, W.tilt.rotZ) / DEG).toFixed(0) + '°';

    // кулдаун встряски
    const cd = clamp(W.shakeCd / LEVEL_CONFIG.shake.cooldown, 0, 1);
    if (el.shake_fill) el.shake_fill.style.transform = 'scaleX(' + (1 - cd).toFixed(3) + ')';
    if (el.btn_cut) el.btn_cut.classList.toggle('hidden', !(!W.ropeCut && W.state === 'play' && W.currentFloor === 0));
    if (el.btn_shake) el.btn_shake.classList.toggle('cooling', cd > 0);
    if (el.btn_shake_top) el.btn_shake_top.classList.toggle('cooling', cd > 0);
  }

  // ===========================================================================
  // 22. ПРИЛОЖЕНИЕ
  // ===========================================================================
  const App = {
    renderer: null,
    canvas: null,
    running: false,
    audioOn: true,
    helpOpen: false,

    init() {
      cacheDom();
      this.canvas = el.scene;
      if (!this.canvas) throw new Error('canvas #scene не найден');

      // --- рендерер ---
      this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: !MOBILE, alpha: false, powerPreference: 'high-performance' });
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, MOBILE ? 1 : 2));
      this.renderer.setSize(window.innerWidth, window.innerHeight, false);
      try { if ('outputColorSpace' in this.renderer && THREE.SRGBColorSpace) this.renderer.outputColorSpace = THREE.SRGBColorSpace; } catch (e) {}
      try { this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.08; } catch (e) {}
      W.renderer = this.renderer;

      // --- сцена и камера ---
      W.scene = new THREE.Scene();
      W.scene.background = new THREE.Color(0x04060f);
      W.scene.fog = new THREE.Fog(0x04060f, 110, 300);
      const C = LEVEL_CONFIG.camera;
      W.camera = new THREE.PerspectiveCamera(C.fov, window.innerWidth / Math.max(1, window.innerHeight), C.near, C.far);
      W.camera.position.set(0, 20, 46);

      this.buildBackdrop();
      this.buildLights();

      // --- уровень ---
      initMaterials();
      // v4.1: прогресс 10 уровней + общий рекорд из localStorage
      try { W.bestScore = parseInt(window.localStorage.getItem(BEST_KEY) || '0', 10) || 0; } catch (e) { W.bestScore = 0; }
      W.progress = loadProgress();
      W.specials = loadSpecials();
      buildLevel();
      initFX();
      hangPlayer();

      this.bindUi();
      this.bindInput();

      try {
        const savedLang = window.localStorage.getItem('graviboom_lang_v300');
        curLang = (savedLang === 'en') ? 'en' : 'ru';
      } catch (e) {}
      applyTexts();
      applyTheme(getTheme());          // v4.5: тема из localStorage
      bindPlatformGuards();            // v4.5: contextmenu off
      showScreen('scr-start');         // v4.5: главный экран-меню

      window.addEventListener('resize', () => this.onResize());
      window.addEventListener('blur', () => { if (W.state === 'play') this.pause(); Sound.setEnabled(false); });
      window.addEventListener('focus', () => { if (!document.hidden && !PLAT.adMuted) Sound.setEnabled(this.audioOn !== false); });
      document.addEventListener('visibilitychange', () => {
        // v4.5 (требование 1.3): при потере фокуса — пауза И глушение звука
        if (document.hidden) {
          if (W.state === 'play') this.pause();
          Sound.setEnabled(false);
        } else {
          Sound.setEnabled(this.audioOn !== false && !PLAT.adMuted);
        }
      });

      W.state = 'menu';
      this.syncModals();
      updateCamera(0.016);

      this.running = true;
      this.lastT = (window.performance && performance.now) ? performance.now() : Date.now();
      requestAnimationFrame(t => this.frame(t));
    },

    buildBackdrop() {
      // звёзды
      const N = 1400;
      const pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
      for (let i = 0; i < N; i++) {
        const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, s = Math.sqrt(1 - u * u);
        const rr = rnd(120, 260);
        pos[i * 3] = Math.cos(th) * s * rr; pos[i * 3 + 1] = u * rr * 0.8; pos[i * 3 + 2] = Math.sin(th) * s * rr;
        const t = Math.random();
        col[i * 3] = 0.55 + t * 0.45; col[i * 3 + 1] = 0.7 + t * 0.3; col[i * 3 + 2] = 1.0;
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      const stars = new THREE.Points(g, new THREE.PointsMaterial({
        size: 1.1, vertexColors: true, transparent: true, opacity: 0.85,
        depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true
      }));
      stars.frustumCulled = false;
      W.scene.add(stars);
      W.stars = stars; stars.visible = !MOBILE;

      // дальнее свечение под стаканом
      const cv = document.createElement('canvas'); cv.width = cv.height = 256;
      const ctx = cv.getContext('2d');
      const grd = ctx.createRadialGradient(128, 128, 8, 128, 128, 126);
      grd.addColorStop(0, 'rgba(0,180,255,0.55)');
      grd.addColorStop(0.5, 'rgba(0,90,160,0.18)');
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd; ctx.fillRect(0, 0, 256, 256);
      const tex = new THREE.CanvasTexture(cv);
      const glow = new THREE.Mesh(new THREE.PlaneGeometry(220, 220),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
      glow.rotation.x = -Math.PI / 2;
      glow.position.y = -42;
      W.scene.add(glow);
    },

    buildLights() {
      const hemi = new THREE.HemisphereLight(0x9fd8ff, 0x0a1224, 1.15);
      W.scene.add(hemi);
      const key = new THREE.DirectionalLight(0xffffff, 2.6);
      key.position.set(22, 34, 26);
      W.scene.add(key);
      const fill = new THREE.DirectionalLight(0x66aaff, 1.1);
      fill.position.set(-24, 10, -18);
      W.scene.add(fill);
      const rim = new THREE.DirectionalLight(0xff88aa, 0.7);
      rim.position.set(0, -18, -22);
      W.scene.add(rim);
      const p1 = new THREE.PointLight(0x00d4ff, 260, 60, 2);
      p1.position.set(0, 8, 0);
      W.scene.add(p1);
      const p2 = new THREE.PointLight(0xff3355, 180, 34, 2);
      p2.position.set(0, -2.5, 0);
      W.scene.add(p2);
      const p3 = new THREE.PointLight(0xd946ef, 200, 30, 2);
      p3.position.set(0, 1.2, 0);
      W.scene.add(p3);
      W.lights = { hemi: hemi, key: key, fill: fill, rim: rim, p1: p1, p2: p2, p3: p3 };
    },

    onResize() {
      if (!this.renderer || !W.camera) return;
      const w = window.innerWidth, h = Math.max(1, window.innerHeight);
      this.renderer.setSize(w, h, false);
      W.camera.aspect = w / h;
      W.camera.updateProjectionMatrix();
    },

    // ---------------- СОСТОЯНИЯ ----------------
    start(levelIdx, sandbox) {
      W.runUsedAuto=false;
      autoStop('level');                   // v4.5: АВТО не переживает рестарт
      Sound.init();
      if (levelIdx !== undefined && levelIdx !== null) {
        W.currentLevel = clamp(levelIdx | 0, 0, LEVELS.length - 1);
      }
      W.sandbox = !!sandbox;                       // v4.1: песочница — без записи результатов
      W.ffOpen = false; W.ffReason = null; W.autoPull = null;   // v4.2
      buildLevel();
      initFX();
      hangPlayer();
      W.state = 'play';
      W.runTime = 0;
      // v3.5: интро-полёт камеры 2.5 с (скипается любым тапом)
      W.intro.active = true;
      W.intro.t = 0;
      W.cam.theta = -0.8 * Math.PI;
      W.cam.phi = 1.35;
      W.cam.dist = 78;
      W.cam.tTheta = LEVEL_CONFIG.camera.defaultTheta;
      W.cam.tPhi = LEVEL_CONFIG.camera.defaultPolar;
      W.cam.tDist = LEVEL_CONFIG.camera.defaultDist;
      W.cam.spinTheta = 0; W.cam.spinPhi = 0;
      W.introWasActive = true;
      W.hintShownAt = W.time;
      // v4.1: название уровня в HUD (тает через ~4.5 с)
      W.levelNameT = 4.5;
      if (el.txt_level_name) {
        el.txt_level_name.innerHTML =
          (W.sandbox ? '🧪 ' : '') +
          (curLang === 'ru' ? 'УРОВЕНЬ ' : 'LEVEL ') + (W.currentLevel + 1) + ' · ' +
          LEVELS[W.currentLevel].name[curLang === 'ru' ? 0 : 1];
        el.txt_level_name.classList.remove('hidden', 'fading');
      }
      showScreen('scr-game');           // v4.5: игровой экран
      if (tut.active) renderTrainPlate(true);   // v4.5: плашка обучения на месте
      this.syncModals();
      updateHud(0.1, true);
    },

    restart() { this.start(); },
    // разрез троса по кнопке HUD / горячее клавише X (жест мышью — отдельно)
    tryCut() {
      if (W.state !== 'play' || W.ropeCut) return false;
      const ok = cutRope();
      if (ok) { W.ropeHover = false; if (this.canvas) this.canvas.style.cursor = 'grab'; }
      return ok;
    },

    pause() {
      if (W.state !== 'play') return;
      W.state = 'pause';
      this.syncModals();
      Sound.ui();
    },

    resume() {
      if (W.state !== 'pause' || PLAT.adMuted || document.hidden) return;
      W.state = 'play';
      this.syncModals();
      Sound.ui();
    },

    toMenu() {
      autoStop('level');                   // v4.5: выход — АВТО прочь
      W.state = 'menu';
      W.slowmo = 0; W.slowmoScale = 1; W.fireworkT = 0;
      stopTraining();                  // v4.5: выход из обучения
      showScreen('scr-start');         // v4.5: экран главного меню
      this.syncModals();
      Sound.ui();
      maybeAd();                       // v4.5: реклама в естественной паузе (≥180 с)
    },

    togglePause() {
      if (W.state === 'play') this.pause();
      else if (W.state === 'pause') this.resume();
    },

    showVictory() {
      // v4.1: рекорд очков — общий (graviboom_v4_bestScore)
      const isRecord = W.score > (W.bestScore || 0);
      if (isRecord) {
        W.bestScore = W.score;
        try { window.localStorage.setItem(BEST_KEY, String(W.bestScore)); } catch (e) {}
      }
      // v3.5: звёзды 1–3: победа / время < 60 с / ни одной ошибки
      let stars = 1;
      if (W.runTime < 60) stars++;
      if (W.failStreak === 0 && W.attempts === 0) stars++;
      // v4.1: запись прогресса уровня + челленджи (в песочнице не сохраняется)
      if (!W.sandbox && W.progress) {
        const pr = W.progress[W.currentLevel];
        const rankKey=W.runUsedAuto?"autoScore":"fairScore";pr[rankKey]=Math.max(score49(pr[rankKey]),score49(W.score));
        pr.score = Math.max(pr.score, W.score);
        pr.stars = Math.max(pr.stars, stars);
        pr.time = (pr.time > 0) ? Math.min(pr.time, W.runTime) : W.runTime;
        saveProgress();        // челленджи: 10 по уровням (доступ после 3 звёзд) + 5 спец
        const rs = W.runStats || { shakes: 0, plateFails: 0, roadResets: 0, echoBlasts: 0, socketFails: 0, dives: 0, cutMisses: 0 };
        const li = curLang === 'ru' ? 0 : 1;
        const doneNames = [];
        for (const ch of CHALLENGES) {
          let ok = false;
          try { ok = ch.test(rs); } catch (e) { ok = false; }
          if (!ok) continue;
          if (ch.lvl !== undefined) {
            if (ch.lvl === W.currentLevel && pr.stars >= 3 && !pr.challenge) { pr.challenge = true; doneNames.push(ch.name[li]); }
          } else if (!W.specials[ch.sp]) {
            W.specials[ch.sp] = true; doneNames.push(ch.name[li]);
          }
        }
        if (doneNames.length) {
          saveProgress(); saveSpecials();
          setTimeout(() => { toast(D().challengeDone.replace('{n}', doneNames.join(' · ')), 'magic', 4000); }, 700);
          Sound.floorDone();
        }
        // v4.5: облако + лидерборд Яндекса (гостевой режим — тихо пропускается)
        cloudSave();
        lbSubmit(W.bestScore || 0);
      }
      if (el.stat_time) el.stat_time.textContent = fmtTime(W.runTime);
      if (el.stat_magic) el.stat_magic.textContent = String(W.blastCount);
      if (el.stat_lost) el.stat_lost.textContent = String(W.lostCount);
      if (el.stat_cuts) el.stat_cuts.textContent = String(W.cutCount);
      if (el.stat_score) el.stat_score.textContent = String(W.score);
      if (el.stat_perfect) el.stat_perfect.textContent = String(W.perfectCuts);
      if (el.txt_victory_title) el.txt_victory_title.textContent = D().victoryTitle + (isRecord ? ' · ' + D().newRecord : '');
      if (el.win_stars) {
        let sh = '';
        for (let i = 0; i < 3; i++) sh += '<span class="' + (i < stars ? 'on' : 'off') + '">★</span>';
        el.win_stars.innerHTML = sh;
      }
      // v3.5: «Следующий уровень» на всех уровнях, кроме последнего
      if (el.btn_next) el.btn_next.classList.toggle('hidden', W.currentLevel >= LEVELS.length - 1);
      // финальный уровень: салют продолжается и за модалкой
      W.fireworkT = (W.currentLevel === LEVELS.length - 1) ? Math.max(W.fireworkT, 1.7) : 0;
      this.syncModals();
    },

    showDefeat() {
      if (el.dstat_time) el.dstat_time.textContent = fmtTime(W.runTime);
      if (el.dstat_magic) el.dstat_magic.textContent = String(W.blastCount);
      if (el.dstat_reason) el.dstat_reason.textContent = W.loseReason === 'trap' ? D().reasonTrap : D().reasonMiss;
      this.syncModals();
    },

    syncModals() {
      const s = W.state;
      const show = (node, on) => { if (node) node.classList.toggle('hidden', !on); };
      show(el.modal_victory, s === 'win' && !this.helpOpen && !W.ffOpen);
      show(el.modal_defeat, s === 'lose' && !this.helpOpen && !W.ffOpen);
      show(el.modal_pause, s === 'pause' && !this.helpOpen && !W.ffOpen);
      show(el.modal_help, this.helpOpen && !W.ffOpen);
      
      show(el.modal_floorfail, !!W.ffOpen);
      if (s === 'menu') { renderLevelStrip(); renderSidePanels(); }   // v4.5: свежие данные меню
      // v4.5: геймплейная разметка для платформы (1.19.3)
      const inPlay = (s === 'play') && curScreen === 'scr-game' && !this.helpOpen && !W.ffOpen;
      if (inPlay) gameplayStart(); else gameplayStop();
    },

    openHelp() {
      this.helpOpen = true;
      if (W.state === 'play') W.state = 'pause';
      this.syncModals();
      Sound.ui();
    },

    // v4.2: закрыть модалку невыполнимого этажа
    closeFf(action) {
      const reason = W.ffReason;
      W.ffOpen = false;
      W.ffReason = null;
      this.syncModals();
      if (action === 'restart') {
        if (reason === 'final') restartFinalFloor();
        else if (reason === 'plate') restartResonanceFloor();
        else this.start();
      } else if (action === 'menu') {
        this.toMenu();
      }
    },

    closeHelp() {
      this.helpOpen = false;
      this.syncModals();
      Sound.ui();
    },

    toggleLang() { setLanguage(curLang === 'ru' ? 'en' : 'ru'); Sound.ui(); },

    toggleAudio() {
      this.audioOn = !this.audioOn;
      Sound.init();
      Sound.setEnabled(this.audioOn && !PLAT.adMuted && !document.hidden);
      refreshIcons49();
    },

    // ---------------- ВВОД ----------------
    bindUi() {
      const on = (node, ev, fn) => { if (node) node.addEventListener(ev, fn); };
      on(el.btn_start, 'click', () => this.start());
      on(el.btn_sandbox, 'click', () => {
        W.sandboxMenu = !W.sandboxMenu;
        toast(W.sandboxMenu ? D().sandboxOn : D().sandboxOff, W.sandboxMenu ? 'magic' : 'warn', 3000);
        Sound.ui();
        renderLevelStrip();
      });
      on(el.btn_menu_help, 'click', () => this.openHelp());
      on(el.btn_help, 'click', () => this.openHelp());
      on(el.btn_close_help, 'click', () => this.closeHelp());
      on(el.btn_resume, 'click', () => this.resume());
      on(el.btn_pipe_reset, 'click', () => restartCurrentFloor());
      on(el.btn_floor_restart, 'click', () => {
        if (W.state !== 'play' || W.ffOpen || W.currentFloor !== 2 || inTransition()) return;
        restartResonanceFloor();
      });
      on(el.btn_floors, 'click', () => {
        W.floorsGhost = !W.floorsGhost;
        syncFloorViz();
        Sound.ui();
      });
      on(el.btn_victory_menu, 'click', () => this.toMenu());
      on(el.btn_defeat_menu, 'click', () => this.toMenu());
      on(el.btn_cut, 'click', () => this.tryCut());
      on(el.btn_shake, 'click', () => doShake());
      on(el.btn_shake_top, 'click', () => doShake());
      on(el.btn_lang, 'click', () => this.toggleLang());
      on(el.btn_audio, 'click', () => this.toggleAudio());

      // ---------------- v4.5: экраны «МАТ-БУМ! 3» ----------------
      on(el.b_play, 'click', () => { Sound.ui(); showScreen('scr-select'); });
      on(el.b_train, 'click', () => { Sound.ui(); startTraining(); });
      on(el.b_hall, 'click', () => { Sound.ui(); showScreen('scr-hall'); });
      on(el.b_help, 'click', () => { Sound.ui(); showScreen('scr-help'); });
      on(el.btn_theme, 'click', () => toggleTheme());
      on(el.btn_auto, 'click', () => autoToggle());   // v4.5: автосборка этажа
      on(el.btn_back, 'click', () => {
        Sound.ui();
        if (curScreen === 'scr-game') this.toMenu();
        else if (W.state === 'menu') showScreen('scr-start');
      });
      // реклама в естественных паузах: «ещё раз», «следующий», рестарты (≥180 с)
      on(el.btn_again, 'click', () => maybeAd(() => this.start()));
      on(el.btn_next, 'click', () => maybeAd(() => this.start(W.currentLevel + 1)));
      on(el.btn_retry, 'click', () => maybeAd(() => this.start()));
      on(el.btn_restart, 'click', () => maybeAd(() => this.start()));
      on(el.btn_pause_restart, 'click', () => maybeAd(() => this.start()));
      on(el.btn_ff_restart, 'click', () => maybeAd(() => this.closeFf('restart')));
      on(el.btn_pause_menu, 'click', () => this.toMenu());
      on(el.btn_ff_menu, 'click', () => this.closeFf('menu'));

      window.addEventListener('keydown', e => {
        if (PLAT.adMuted || document.hidden) return;
        const k = e.code && /^Key[A-Z]$/.test(e.code) ? e.code.slice(3).toLowerCase() : (e.key || '').toLowerCase();
        if (W.ffOpen) { e.preventDefault(); return; }   // v4.2: модалка этажа блокирует клавиши
        if (k === ' ' || e.code === 'Space') { e.preventDefault(); Sound.init(); doShake(); }
        else if (k === 'r') { this.start(); }
        else if (k === 'l') { this.toggleLang(); }
        else if (k === 'h' || k === '?') { this.helpOpen ? this.closeHelp() : this.openHelp(); }
        else if (k === 'escape') {
          if (this.helpOpen) this.closeHelp();
          else this.togglePause();
        }
        else if (k === 'x' || k === 'с') { this.tryCut(); }
        else if (k === 'a' || k === 'ф') { autoToggle(); }   // v4.5: АВТО
        else if (k === 'm') { this.toggleAudio(); }
      });
    },

    bindInput() {
      const cv = this.canvas;
      const pointers = new Map();
      const inputAllowed = () => curScreen === 'scr-game' && W.state === 'play' && !W.ffOpen && !self.helpOpen && !PLAT.adMuted;
      const resetInput = () => { pointers.clear(); mode = null; W.tilt.active = false; W.tilt.tRotX = W.tilt.tRotZ = 0; W.ropeHover = false; };
      this.resetInput = resetInput;
      window.addEventListener('blur', resetInput);
      document.addEventListener('visibilitychange', resetInput);
      cv.addEventListener('lostpointercapture', e => { if (pointers.has(e.pointerId)) resetInput(); });
      this.hasPointerInput = () => pointers.size > 0;

      let mode = null;                  // 'tilt' | 'cam' | 'cam2' | 'cut'
      let lastX = 0, lastY = 0, dragDX = 0, dragDY = 0, pinch0 = 0, dist0 = 0;
      let cutTravel = 0, cutDone = false;
      let camVelT = 0, camVelP = 0, lastMoveMs = 0;
      const self = this;
      const GRAB_PX = 36;               // зона захвата троса на экране, px
      const nowMs = () => (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();

      cv.addEventListener('contextmenu', e => e.preventDefault());

      function screenOf(v) {
        const p = v.clone().project(W.camera);
        return { x: (p.x * 0.5 + 0.5) * cv.clientWidth, y: (-p.y * 0.5 + 0.5) * cv.clientHeight };
      }

      function segHit(p1, p2, p3, p4) {
        const d1x = p2.x - p1.x, d1y = p2.y - p1.y;
        const d2x = p4.x - p3.x, d2y = p4.y - p3.y;
        const den = d1x * d2y - d1y * d2x;
        if (Math.abs(den) < 1e-9) return false;
        const t = ((p3.x - p1.x) * d2y - (p3.y - p1.y) * d2x) / den;
        const u = ((p3.x - p1.x) * d1y - (p3.y - p1.y) * d1x) / den;
        return t >= 0 && t <= 1 && u >= 0 && u <= 1;
      }

      function ropeSegment() {
        if (!W.player || !W.ropeAnchor || W.ropeCut) return null;
        const a = W.glassGroup.localToWorld(W.ropeAnchor.clone());
        const b = W.glassGroup.localToWorld(W.player.p.clone());
        return [screenOf(a), screenOf(b)];
      }

      function distPointSeg(px, py, a, b) {
        const vx = b.x - a.x, vy = b.y - a.y;
        const L2 = vx * vx + vy * vy;
        let t = L2 > 1e-9 ? ((px - a.x) * vx + (py - a.y) * vy) / L2 : 0;
        t = clamp(t, 0, 1);
        return Math.hypot(px - (a.x + vx * t), py - (a.y + vy * t));
      }

      function ropeGrabbable() { return !W.ropeCut && W.state === 'play'; }

      function nearRope(x, y) {
        if (!ropeGrabbable()) return false;
        const rs = ropeSegment();
        return !!rs && distPointSeg(x, y, rs[0], rs[1]) < GRAB_PX;
      }

      function setCursor() {
        cv.style.cursor = mode === 'cam' || mode === 'cam2' ? 'move'
          : (mode === 'cut' || W.ropeHover) ? 'crosshair'
          : (mode === 'tilt' ? 'grabbing' : 'grab');
      }

      // Наклон стакана. Экранное направление перетаскивания переводится в
      // мировое через базис камеры: вправо — по вектору «право» камеры,
      // ВВЕРХ — «от игрока» (вектор взгляда камеры), ВНИЗ — «к игроку».
      // Так верх стакана наклоняется ровно туда, куда тянет мышь.
      function applyTiltDrag() {
        const T = LEVEL_CONFIG.tilt;
        const len = Math.hypot(dragDX, dragDY);
        if (len < 1) { W.tilt.tRotX = 0; W.tilt.tRotZ = 0; return; }
        const fwd = new THREE.Vector3();
        W.camera.getWorldDirection(fwd);
        const right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0));
        if (right.lengthSq() < 1e-8) right.set(1, 0, 0);
        right.normalize();
        const fwdXZ = new THREE.Vector3(fwd.x, 0, fwd.z);
        if (fwdXZ.lengthSq() < 1e-8) fwdXZ.set(0, 0, -1);
        fwdXZ.normalize();
        // экранное «вверх» (dragDY < 0) — это направление ОТ игрока, fwdXZ
        const dxw = right.x * dragDX - fwdXZ.x * dragDY;
        const dzw = right.z * dragDX - fwdXZ.z * dragDY;
        const dl = Math.hypot(dxw, dzw) || 1;
        const mag = Math.min(T.max, len * T.sensitivity);
        // наклон верха стакана в сторону (dxw, dzw): rotX = +Lz, rotZ = −Lx
        W.tilt.tRotZ = -(dxw / dl) * mag;
        W.tilt.tRotX = (dzw / dl) * mag;
      }

      cv.addEventListener('pointerdown', e => {
        if (!inputAllowed()) return;
        e.preventDefault();
        Sound.init();
        pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (W.intro.active) skipIntro();               // v3.5: тап скипает интро
        try { cv.setPointerCapture(e.pointerId); } catch (err) {}
        if (pointers.size === 1) {
          lastX = e.clientX; lastY = e.clientY;
          dragDX = 0; dragDY = 0;
          cutTravel = 0; cutDone = false;
          camVelT = 0; camVelP = 0; lastMoveMs = nowMs();
          W.cam.spinTheta = 0; W.cam.spinPhi = 0;      // взяли камеру — инерция сброшена
          if (e.button === 2 || e.ctrlKey) mode = 'cam';
          else if (nearRope(e.clientX, e.clientY)) {
            // жест разреза: наклон стакана в этом жесте НЕ участвует
            mode = 'cut';
            W.ropeHover = true;
          } else mode = 'tilt';
          W.tilt.active = (mode === 'tilt');
        } else if (pointers.size === 2) {
          mode = 'cam2';
          W.tilt.active = false;
          W.ropeHover = false;
          const pts = Array.from(pointers.values());
          pinch0 = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
          dist0 = W.cam.tDist;
          lastX = (pts[0].x + pts[1].x) / 2; lastY = (pts[0].y + pts[1].y) / 2;
        }
        setCursor();
      });

      window.addEventListener('pointermove', e => {
        if (!inputAllowed()) { resetInput(); return; }
        if (!pointers.has(e.pointerId)) {
          // просто наведение: подсвечиваем трос, если курсор рядом
          const was = W.ropeHover;
          W.ropeHover = nearRope(e.clientX, e.clientY);
          if (was !== W.ropeHover || !mode) setCursor();
          return;
        }
        pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        const dx = e.clientX - lastX, dy = e.clientY - lastY;

        if (mode === 'cam2' && pointers.size >= 2) {
          const pts = Array.from(pointers.values());
          const mid = { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 };
          const d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
          W.cam.tTheta -= (mid.x - lastX) * 0.006;
          W.cam.tPhi = clamp(W.cam.tPhi - (mid.y - lastY) * 0.005, LEVEL_CONFIG.camera.minPolar, LEVEL_CONFIG.camera.maxPolar);
          if (pinch0 > 4) W.cam.tDist = clamp(dist0 * (pinch0 / Math.max(4, d)), LEVEL_CONFIG.camera.minDist, LEVEL_CONFIG.camera.maxDist);
          lastX = mid.x; lastY = mid.y;
        } else if (mode === 'cam') {
          const t1 = nowMs();
          const dtm = Math.min(0.12, Math.max(0.008, (t1 - lastMoveMs) / 1000 || 0.016));
          lastMoveMs = t1;
          W.cam.tTheta -= dx * 0.006;
          W.cam.tPhi = clamp(W.cam.tPhi - dy * 0.005, LEVEL_CONFIG.camera.minPolar, LEVEL_CONFIG.camera.maxPolar);

          camVelT = camVelT * 0.4 + ((-dx * 0.006) / dtm) * 0.6;
          camVelP = camVelP * 0.4 + ((-dy * 0.005) / dtm) * 0.6;
          lastX = e.clientX; lastY = e.clientY;
        } else if (mode === 'cut') {
          cutTravel += Math.hypot(dx, dy);
          if (!cutDone && ropeGrabbable()) {
            const rs = ropeSegment();
            if (rs && segHit({ x: lastX, y: lastY }, { x: e.clientX, y: e.clientY }, rs[0], rs[1])) {
              cutDone = true;
              self.tryCut();
            }
          }
          lastX = e.clientX; lastY = e.clientY;
        } else if (mode === 'tilt') {
          dragDX += dx; dragDY += dy;
          applyTiltDrag();
          lastX = e.clientX; lastY = e.clientY;
        }
      });

      function endPointer(e) {
        if (!pointers.has(e.pointerId)) return;
        if (e.type === 'pointercancel' || !inputAllowed()) { resetInput(); return; }
        pointers.delete(e.pointerId);
        if (pointers.size === 0) {
          if (mode === 'tilt') W.tilt.active = false;
          if (mode === 'cam') {
            // небольшая инерция: стакан докручивается и плавно останавливается
            W.cam.spinTheta = clamp(camVelT, -12, 12) * 0.055;
            W.cam.spinPhi = clamp(camVelP, -12, 12) * 0.032;
            camVelT = 0; camVelP = 0;
          }
          if (mode === 'cut' && !cutDone && cutTravel < 14) self.tryCut();  // тап по тросу
          mode = null;
          W.ropeHover = false;
          setCursor();
        } else if (pointers.size === 1) {
          mode = 'tilt';
          const p = Array.from(pointers.values())[0];
          lastX = p.x; lastY = p.y;
          dragDX = 0; dragDY = 0;
          W.tilt.active = true;
          setCursor();
        }
      }
      window.addEventListener('pointerup', endPointer);
      window.addEventListener('pointercancel', endPointer);
      cv.addEventListener('pointerleave', () => { if (!mode) { W.ropeHover = false; setCursor(); } });

      cv.addEventListener('wheel', e => {
        if (!inputAllowed()) return;
        e.preventDefault();
        const C = LEVEL_CONFIG.camera;
        W.cam.tDist = clamp(W.cam.tDist * Math.exp((e.deltaY || 0) * 0.0011), C.minDist, C.maxDist);
      }, { passive: false });

      setCursor();
      void self;
    },

    // ---------------- ГЛАВНЫЙ ЦИКЛ ----------------
    frame(now) {
      requestAnimationFrame(t => this.frame(t));
      if (!this.running) return;
      let dtReal = (now - this.lastT) / 1000;
      this.lastT = now;
      if (!isFinite(dtReal) || dtReal <= 0) dtReal = 1 / 60;
      dtReal = Math.min(dtReal, 0.1);

      const live = !PLAT.adMuted && !document.hidden && (W.state === 'play' || W.state === 'winning' || W.state === 'losing') && !W.ffOpen;
      let dt = 0;

      if (live) {
        if (W.slowmo > 0) { W.slowmo -= dtReal; dt = dtReal * clamp(W.slowmoScale, 0.05, 1); }
        else { W.slowmoScale = 1; dt = dtReal; }
        if(W.state==='play'&&finalFlightActive())dt*=0.35;
        W.time += dt; W.runTime += dt;
        
        autoUpdate(dt);                     // v4.5: автопилот наклона (до физики)
        stepPhysics(dt);
        autoAssist(dt);
        Magic.update(dt);
        updateTriggers(dt);
        updateSequences(dt);
        pushTrail();                            // v3.5: точка трейла
        if (W.shakeCd > 0) W.shakeCd = Math.max(0, W.shakeCd - dtReal);
        // звуки качения/ударов
        playContactSounds();

      } else if (!W.ffOpen) {
        W.time += dtReal * (this.helpOpen || W.state === 'pause' ? 0.15 : 0.6);
      }

      // v3.5: интро закончилось само — подсветить трос и подсказать разрез
      if (W.introWasActive && !W.intro.active) {
        W.introWasActive = false;
        pulseRope();
        if (W.state === 'play') toast(D().statusRope, 'good');
      }
      // v3.5: вспышка tone-mapping (ядро/победа)
      if (W.flashT > 0) {
        W.flashT -= dtReal;
        const fk = clamp(W.flashT / 0.25, 0, 1);
        if (this.renderer) this.renderer.toneMappingExposure = 1.08 + fk * 0.35;
      } else if (this.renderer && this.renderer.toneMappingExposure !== 1.08) {
        this.renderer.toneMappingExposure = 1.08;
      }

      const vdt = live ? dt : dtReal;
      updateVisuals(vdt);
      updateCoreBursts(dtReal);
      updateFX(dtReal * (live && W.slowmoScale < 1 ? Math.max(W.slowmoScale, 0.4) : 1));
      updateFinalView(dtReal);
      updateCamera(dtReal);
      updateHud(dtReal);
      updateTraining();               // v4.5: шаги обучения по фактическим событиям
      if (W.stars) W.stars.rotation.y += dtReal * 0.0035;

      this.renderer.render(W.scene, W.camera);
    }
  };

  function playContactSounds() {
    let maxImp = 0, rollMax = 0;
    for (const b of W.balls) {
      if (!b.alive) continue;
      if (b.impact > maxImp) maxImp = b.impact;
      if (b.contact) { const sp = b.v.length(); if (sp > rollMax) rollMax = sp; }
      b.impact = 0;
    }
    if (maxImp > 0.45) Sound.hit(clamp(maxImp / 9, 0.06, 1));
    if (rollMax > 0.6) Sound.roll(clamp(rollMax / 12, 0, 1));
  }

  // ===========================================================================
  // 22b. v4.5: ПЛАТФОРМА ЯНДЕКС ИГР (адаптер по схеме «МАТ-БУМ! 3» 5.0.3)
  // Одиночный файл: SDK грузится динамически с '/sdk.js' только на платформе;
  // локально/в песочнице молча деградирует в гостевой офлайн-режим.
  // Требования: LoadingAPI.ready при готовности, GameplayAPI start/stop по
  // фактам геймплея, реклама только в естественных паузах и не чаще 180 с,
  // язык из environment.i18n.lang (до getPlayer), облачные сейвы, пауза/звук
  // на game_api_pause / hidden, контекстное меню и выделение выключены.
  // ===========================================================================
  const PLAT = {
    ysdk: null, player: null, lang: null, ready: false, adMuted: false, lastAdT: -1e9, inGameplay: false
  };
  window.PLAT = PLAT;

  function plIsHttps() {
    try { return (typeof location !== 'undefined') && /^https?:$/.test(location.protocol); } catch (e) { return false; }
  }
  function plLoadScript(src, ms) {
    return new Promise(resolve => {
      let done = false;
      const finish = (ok) => { if (!done) { done = true; resolve(ok); } };
      try {
        if (typeof document === 'undefined' || !document.createElement || !document.head ||
            typeof window === 'undefined') { finish(false); return; }
        const s = document.createElement('script');
        s.src = src; s.async = true;
        s.onload = () => finish(true);
        s.onerror = () => finish(false);
        document.head.appendChild(s);
        window.setTimeout(() => finish(false), ms || 6000);
      } catch (e) { finish(false); }
    });
  }
  function plSafe(fn) { try { return fn(); } catch (e) { return undefined; } }

  async function initPlatform() {
    if (window.GRAVI_SOLO || !plIsHttps()) return PLAT;             // file:// / vm-песочница — гостевой режим
    const ok = await plLoadScript('/sdk.js', 6000);
    if (!ok || typeof window.YaGames === 'undefined') return PLAT;
    const ysdk = await new Promise(resolve => {
      let done = false;
      try {
        window.YaGames.init().then(y => { if (!done) { done = true; resolve(y); } })
          .catch(() => { if (!done) { done = true; resolve(null); } });
        window.setTimeout(() => { if (!done) { done = true; resolve(null); } }, 8000);
      } catch (e) { resolve(null); }
    });
    if (!ysdk) return PLAT;
    PLAT.ysdk = ysdk;
    // 1.7: автоязык — читаем сразу после init, ДО getPlayer/облака
    PLAT.lang = plSafe(() => (ysdk.environment && ysdk.environment.i18n && ysdk.environment.i18n.lang) || null);
    // game_api_pause / game_api_resume (1.19.4): пауза + глушение звука
    plSafe(() => ysdk.on('game_api_pause', () => {
      PLAT.adMuted = true;
      plSafe(() => Sound.setEnabled(false));
      if (W.state === 'play') App.pause();
    }));
    plSafe(() => ysdk.on('game_api_resume', () => {
      if (document.getElementById('app').inert) return;
      PLAT.adMuted = false;
      plSafe(() => Sound.setEnabled(App.audioOn !== false && !document.hidden));
    }));
    // игрок: авторизация ТОЛЬКО по добровольному жесту (требование 1.2)
    // — здесь мы лишь проверяем уже существующую сессию, окно логина не открываем
    await plSafe(async () => {
      const p = await ysdk.getPlayer({ scopes: false }).catch(() => null);
      if (p) {
        PLAT.player = p;
      }
    });
    return PLAT;
  }
  function gameReady() {
    if (PLAT.ready) return;
    PLAT.ready = true;
    plSafe(() => PLAT.ysdk && PLAT.ysdk.features && PLAT.ysdk.features.LoadingAPI && PLAT.ysdk.features.LoadingAPI.ready());
  }
  function gameplayStart() {
    if (PLAT.inGameplay) return;
    PLAT.inGameplay = true;
    plSafe(() => PLAT.ysdk && PLAT.ysdk.features && PLAT.ysdk.features.GameplayAPI && PLAT.ysdk.features.GameplayAPI.start());
  }
  function gameplayStop() {
    if (!PLAT.inGameplay) return;
    PLAT.inGameplay = false;
    plSafe(() => PLAT.ysdk && PLAT.ysdk.features.GameplayAPI && PLAT.ysdk.features.GameplayAPI.stop());
  }
  function showInterstitial(after) {
    if (!PLAT.ysdk || !PLAT.ysdk.adv) { if (after) after(); return; }
    if (PLAT.adMuted) return;
    if (W.state === 'play') App.pause();
    gameplayStop();
    PLAT.adMuted = true;
    if (App.resetInput) App.resetInput();
    Sound.setEnabled(false);
    const root = document.getElementById('app');
    root.inert = true;
    const running = App.running; App.running = false;
    let finished = false;
    const finish = () => {
      if (finished) return; finished = true;
      PLAT.adMuted = false; root.inert = false;
      App.running = running; App.lastT = performance.now();
      Sound.setEnabled(App.audioOn !== false && !document.hidden);
      if (after) after();
      if (document.hidden && W.state === 'play') App.pause();
    };
    try { PLAT.ysdk.adv.showFullscreenAdv({ callbacks: {
      onOpen: () => { PLAT.adMuted = true; Sound.setEnabled(false); },
      onClose: finish, onError: finish, onOffline: finish
    }}); } catch (e) { finish(); }
  }
  // Реклама только в естественной паузе и не чаще раза в 180 с (рекомендация платформы)
  function maybeAd(after) {
    const t = (window.performance && performance.now) ? performance.now() : Date.now();
    if (t - PLAT.lastAdT < 180000) { if (after) after(); return; }
    PLAT.lastAdT = t;
    showInterstitial(after);
  }
  async function cloudSave() {
    if (!PLAT.player) return;
    const payload = {
      progress: W.progress, best: W.bestScore, specials: W.specials,
      theme: getTheme(), lang: curLang, v: VERSION
    };
    plSafe(() => PLAT.player.setData({ graviboom: payload }, true).catch(() => {}));
  }
  async function cloudLoad() {
    if (!PLAT.player) return null;
    return plSafe(async () => {
      const d = await PLAT.player.getData(['graviboom']).catch(() => null);
      return (d && d.graviboom) ? d.graviboom : null;
    });
  }
  // Слияние облачного прогресса с локальным (берем лучшие результаты)
  function mergeCloudProgress(cloud) {
    if (!cloud || typeof cloud !== 'object') return;
    try {
      if (Array.isArray(cloud.progress) && cloud.progress.length === LEVELS.length) {
        let changed = false;
        for (let i = 0; i < LEVELS.length; i++) {
          const c = cloud.progress[i] || {}; const p = W.progress[i];
          for(const key of ["fairScore","autoScore"]){const best=Math.max(score49(p[key]),score49(c[key]));if(best!==p[key]){p[key]=best;changed=true;}}
          if ((c.stars | 0) > p.stars) { p.stars = c.stars | 0; changed = true; }
          if ((c.score | 0) > p.score) { p.score = c.score | 0; changed = true; }
          if (c.time > 0 && (p.time === 0 || c.time < p.time)) { p.time = c.time; changed = true; }
          if (c.challenge && !p.challenge) { p.challenge = true; changed = true; }
        }
        if (changed) saveProgress();
      }
      if ((cloud.best | 0) > (W.bestScore | 0)) { W.bestScore = cloud.best | 0; try { window.localStorage.setItem(BEST_KEY, String(W.bestScore)); } catch (e) {} }
      if (cloud.specials && typeof cloud.specials === 'object') {
        for (const k of Object.keys(cloud.specials)) if (cloud.specials[k] && !W.specials[k]) { W.specials[k] = true; }
        saveSpecials();
      }
    } catch (e) {}
  }
  async function lbSubmit(score) {
    if (!PLAT.ysdk) return;
    const n = Math.max(0, score | 0);
    if (n <= 0) return;
    plSafe(() => PLAT.ysdk.leaderboards && PLAT.ysdk.leaderboards.setLeaderboardScore('main', n).catch(() => {}));
  }
  async function lbTop(n) {
    if (!PLAT.ysdk) return null;
    return plSafe(async () => {
      const r = await PLAT.ysdk.leaderboards.getLeaderboardEntries('main', { quantityTop: n || 5, includeUser: true, quantityAround: 2 }).catch(() => null);
      return r;
    });
  }

  // -------------------------------------------------------------------------
  // v4.5: ТЕМЫ (тёмная/светлая, как в МБ3; 3D-сцена остаётся космосом в обеих)
  // -------------------------------------------------------------------------
  const THEME_KEY = 'gb_theme';
  function getTheme() {
    try { return (window.localStorage.getItem(THEME_KEY) === 'light') ? 'light' : 'dark'; } catch (e) { return 'dark'; }
  }
  function applyTheme(t) {
    try { window.localStorage.setItem(THEME_KEY, t); } catch (e) {}
    try {
      document.documentElement.setAttribute('data-theme', t);
    } catch (e) {}
    refreshIcons49();
  }
  function toggleTheme() {
    applyTheme(getTheme() === 'light' ? 'dark' : 'light');
    Sound.ui();
  }

  // -------------------------------------------------------------------------
  // v4.5: ЭКРАНЫ (show как в МБ3) + геймплейная разметка для платформы
  // -------------------------------------------------------------------------
  const SCR_IDS = ['scr-start', 'scr-select', 'scr-hall', 'scr-help', 'scr-game'];
  let curScreen = 'scr-start';
  function showScreen(id) {
    if (SCR_IDS.indexOf(id) < 0) return;
    curScreen = id;
    document.getElementById('chrome').classList.toggle('playing', id === 'scr-game');
    document.getElementById('chrome').classList.toggle('home',id==='scr-start');
    for (const s of SCR_IDS) {
      const n = el[s.replace(/-/g, '_')];
      if (n) n.classList.toggle('on', s === id);
    }
    if (el.btn_back) el.btn_back.hidden = (id === 'scr-start');   // 1.8: без «выхода» из меню
    if (id === 'scr-select') renderLevelStrip();
    if (id === 'scr-hall') renderHall();
    if (id === 'scr-help') renderHelpScreen();
    if (id === 'scr-start') renderSidePanels();
    if (id !== 'scr-game' && W.state !== 'play' && W.state !== 'pause') gameplayStop();
  }

  // -------------------------------------------------------------------------
  // v4.5: боковые колонки главного меню (десктоп ≥1080px — видны, телефон — нет)
  // -------------------------------------------------------------------------
  function renderSidePanels() {
    if (!el.side_recs && !el.side_prog) return;
    const li = curLang === 'ru' ? 0 : 1;
    // рекорды: топ-5 уровней по счёту
    if (el.side_recs) {
      const rows = [];
      for (let i = 0; i < LEVELS.length; i++) {
        const pr = W.progress[i] || {};
        if ((pr.score | 0) > 0) rows.push({ i, score: pr.score | 0, stars: pr.stars | 0, nm: LEVELS[i].name[li] });
      }
      rows.sort((a, b) => b.score - a.score);
      let opened = 0;
      for (let i = 0; i < LEVELS.length; i++) if (levelUnlocked(i)) opened++;
      el.side_recs.innerHTML = rows.length
        ? rows.slice(0, 5).map(r =>
            '<div class="hall-row"><span class="nm">' + (r.i + 1) + '. ' + r.nm + '</span>' +
            '<span class="st">' + '★'.repeat(r.stars) + '</span><span class="sc">' + r.score + '</span></div>').join('')
        : '<div class="hall-empty">' + D().sideNoRec + '</div>';
      if (el.txt_side_open) el.txt_side_open.textContent = D().sideOpen.replace('{n}', String(opened));
    }
    // прогресс: все 10 уровней по порядку
    if (el.side_prog) {
      let totalStars = 0;
      for (let i = 0; i < LEVELS.length; i++) totalStars += ((W.progress[i] || {}).stars | 0);
      el.side_prog.innerHTML = LEVELS.map((L, i) => {
        const pr = W.progress[i] || {};
        const st = pr.stars | 0;
        const col = LEVEL_PALETTES[i][2];
        return '<div class="prog-row"><span class="nm" style="display:flex;align-items:center;gap:6px">' +
          '<i style="width:10px;height:10px;border-radius:50%;background:' + col + ';display:inline-block;flex:none"></i>' +
          (i + 1) + '. ' + L.name[li] + '</span>' +
          '<span class="sc">' + ((pr.score | 0) > 0 ? pr.score : '·') + '</span>' +
          '<span class="st">' + (st > 0 ? '★'.repeat(st) : '·') + '</span></div>';
      }).join('');
      if (el.txt_side_stars) el.txt_side_stars.textContent =
        D().sideStars.replace('{s}', String(totalStars)).replace('{c}', String(challengeCount()));
    }
  }

  // -------------------------------------------------------------------------
  // v4.5: ЗАЛ СЛАВЫ — локальные таблицы + таблица Яндекса (на платформе)
  // -------------------------------------------------------------------------
  let hallYaRendered = false;
  function renderHall(){renderHall49();}

  // -------------------------------------------------------------------------
  // v4.5: экран СПРАВКА (тот же текст, что в игровой модалке)
  // -------------------------------------------------------------------------
  function renderHelpScreen() {
    
    if (el.txt_help_body2) el.txt_help_body2.innerHTML = helpCards49(D().helpBody);
    if (el.txt_help_footer) el.txt_help_footer.textContent = D().helpFooter;
  }

  // -------------------------------------------------------------------------
  // v4.5: ОБУЧЕНИЕ — уровень 1 с плашкой шагов (как в МБ3, без карточек/музея)
  // -------------------------------------------------------------------------
  let tut = { active: false, step: 0 };
  const TUT_KEYS = ['tut1', 'tut2', 'tut3', 'tut4', 'tut5', 'tut6'];
  function startTraining() {
    tut.active = true; tut.step = 0;
    App.start(0);
    renderTrainPlate(true);
    toast(D().tutTitle.replace('{n}', '1').replace('{m}', String(TUT_KEYS.length)), 'magic', 2600);
  }
  function renderTrainPlate(reset) {
    if (!el.train_plate) return;
    if (!tut.active) { el.train_plate.classList.add('hidden'); return; }
    el.train_plate.classList.remove('hidden');
    if (el.tut_step) el.tut_step.textContent = D().tutTitle.replace('{n}', String(tut.step + 1)).replace('{m}', String(TUT_KEYS.length));
    if (el.tut_text) el.tut_text.textContent = D()[TUT_KEYS[tut.step]] || '';
  }
  // продвижение шагов по фактическим событиям игры; вызывается из кадра
  function updateTraining() {
    if (!tut.active) return;
    const fs = W.floorSolvedArr || [false, false, false, false];
    const stepDone = [
      W.cutCount > 0,                        // 1: трос разрезан
      W.cutCount > 0 && W.lowestY < 16.5,    // 2: шар катится по чаше
      fs[0] === true,                        // 3: ЧАША решена
      fs[1] === true,                        // 4: ТРУБА решена
      fs[2] === true,                        // 5: РЕЗОНАНС решена
      W.state === 'win' || W.state === 'winning'
    ][tut.step];
    if (stepDone) {
      tut.step++;
      if (tut.step >= TUT_KEYS.length) {
        tut.active = false;
        renderTrainPlate();
        toast(D().tutDone, 'good', 4200);
        Sound.floorDone();
      } else {
        renderTrainPlate();
        Sound.ui();
      }
    }
  }
  function stopTraining() {
    if (!tut.active) return;
    tut.active = false;
    renderTrainPlate();
  }

  // -------------------------------------------------------------------------
  // v4.5: КНОПКА «АВТО» (как в МАТ-БУМ! 3): автосборка ТЕКУЩЕГО этажа.
  // Башня сама наклоняется и лёгкие ассист-толчки (как у авто-помощи игрока)
  // ведут шары к решению головоломки — все срабатывания (лунки, дороги, плиты,
  // ядро, кнопка) идут через обычную физику, без прямых изменений состояния.
  // Когда этаж решён и шар уходит к следующему — АВТО отключается,
  // управление снова у игрока.
  // -------------------------------------------------------------------------
  const AUTO = { active: false, floor: -1, t: 0, deadline: 110, retreatT: 0, dive: false, plateSt: null, runOn: false, wp2: false, shakeT: 0, stuckP: null };
  window.GB_AUTO = AUTO;

  function autoUpdateBtn() {
    if (el.btn_auto) el.btn_auto.classList.toggle('on', AUTO.active);
  }
  function autoStart() {
    if (W.state !== 'play' || W.ffOpen || inTransition()) { toast(D().autoBusy, 'warn'); return; }
    W.runUsedAuto=true;
    AUTO.active = true; AUTO.final=null; AUTO.pipe=null;
    if(W.pipeExit)W.pipeExit.active=true; AUTO.deadline=W.currentFloor===1?240:110;
    AUTO.floor = W.currentFloor;
    AUTO.t = 0; AUTO.retreatT = 0; AUTO.dive = false; AUTO.plateSt = null; AUTO.runOn = false; AUTO.wp2 = false; AUTO.shakeT = 0; AUTO.stuckP = null; AUTO.stuckB = null; AUTO.f1Tries = 0; AUTO.shakeN = 0; AUTO.pullT = 0;
    autoUpdateBtn();
    toast(D().autoOn, 'magic', 2200);
    Sound.ui();
  }
  function autoStop(reason) {
    if(reason==='manual' && W.pipeExit)W.pipeExit.active=false;
    if (!AUTO.active) return;
    AUTO.active = false; AUTO.pipe=null;
    W.tilt.active = false; W.tilt.tRotX = 0; W.tilt.tRotZ = 0;
    autoUpdateBtn();
    if (reason === 'floorDone') toast(D().autoFloorDone, 'good', 2800);
    else if (reason === 'timeout') toast(D().autoTimeout, 'warn', 3200);
    else if (reason === 'manual') toast(D().autoOff, 'warn');
  }
  function autoToggle() { AUTO.active ? autoStop('manual') : autoStart(); }

  // наклон верха стакана в мировом направлении (dx, dz): как applyTiltDrag
  function autoTilt(dx, dz, mag01) {
    const T = LEVEL_CONFIG.tilt;
    const dl = Math.hypot(dx, dz);
    W.tilt.active = true;
    if (dl < 1e-6) { W.tilt.tRotX = 0; W.tilt.tRotZ = 0; return; }
    const mag = clamp(mag01 === undefined ? 1 : mag01, 0.05, 1) * T.max;
    W.tilt.tRotZ = -(dx / dl) * mag;
    W.tilt.tRotX = (dz / dl) * mag;
  }
  // мягкий ассист-толчок фокус-шара к цели (разумный «магнитный» доводчик);
  // wantCap — целевая скорость ассиста (по умолчанию 3.4, для разгона выше)
  function autoNudge(b, tx, tz, aMax, dt, wantCap) {
    if (!b || !b.alive || b.kinematic || b.mounted) return;
    const dx = tx - b.p.x, dz = tz - b.p.z;
    const d = Math.hypot(dx, dz);
    if (d < 1e-6) return;
    const vAlong = (b.v.x * dx + b.v.z * dz) / d;
    const want = (wantCap !== undefined) ? Math.min(wantCap, 15)
      : Math.min(3.4, Math.sqrt(0.9 * d) + 0.35);
    const add = clamp((want - vAlong) * 1.7, 0, aMax);
    if (add <= 0.01) return;
    b.v.x += (dx / d) * add * dt;
    b.v.z += (dz / d) * add * dt;
  }
  // ПД-наведение игрока на точку: наклон = ошибка скорости (тянет и тормозит)
  function autoSeek(pl, tx, tz, dt, cap) {
    const cx = tx - pl.p.x, cz = tz - pl.p.z;
    const d = Math.hypot(cx, cz);
    const sp = Math.min(cap || 3.2, Math.sqrt(1.1 * Math.max(d, 0)));
    const wx = (d > 1e-6 ? cx / d : 0) * sp;
    const wz = (d > 1e-6 ? cz / d : 0) * sp;
    const ex = wx - pl.v.x, ez = wz - pl.v.z;
    const em = Math.hypot(ex, ez);
    if (em < 0.05) { autoTilt(ex + 0.01, ez, 0.08); return; }
    autoTilt(ex, ez, clamp(0.15 + em * 0.28, 0.1, 0.95));
    autoNudge(pl, tx, tz, 1.8, dt);
  }

  // детектор застревания: шар почти не сместился за 3с — круговая тряска наклоном
  function autoStuckShake(b, dt) {
    if (!b || !b.alive) return false;
    if (AUTO.stuckB !== b) { AUTO.stuckB = b; AUTO.stuckP = { x: b.p.x, z: b.p.z, t: 0 }; }
    if (!AUTO.stuckP) AUTO.stuckP = { x: b.p.x, z: b.p.z, t: 0 };
    AUTO.stuckP.t += dt;
    if (AUTO.stuckP.t >= 3) {
      const disp = Math.hypot(b.p.x - AUTO.stuckP.x, b.p.z - AUTO.stuckP.z);
      const spd = Math.hypot(b.v.x, b.v.z);
      if (disp < 0.8 && spd < 0.3) {                     // медленно ползёт (вдоль стенки) — НЕ застревание
        AUTO.shakeN = (AUTO.shakeN || 0) + 1;
        if (AUTO.shakeN % 4 !== 0) AUTO.shakeT = 1.6;   // пауза каждую 4-ю: пусть ведёт обычная ветка
      }
      AUTO.stuckP = { x: b.p.x, z: b.p.z, t: 0 };
    }
    if (AUTO.shakeT > 0) {
      AUTO.shakeT -= dt;
      const an = W.time * 4;
      autoTilt(Math.cos(an), Math.sin(an), 0.95);
      return true;
    }
    return false;
  }

  // --- ЭТАЖ 0 «ЧАША»: разрезать трос → освободить запас → катить в лунку
  function autoFloor0(dt) {
    const A = LEVEL_CONFIG.platformA;
    const pl = W.player;
    if (!pl || !pl.alive) return;
    if (!W.ropeCut) {                                    // фаза 1: трос
      if (AUTO.t > 0.5) { cutRope(); } else autoTilt(0, 0, 0.15);
      return;
    }
    const socks = W.floorState && W.floorState.sockets;
    if (!socks) return;
    const open = socks.filter(s => !s.full);
    if (!open.length) {                                  // решено: ведём шар к люку чаши
      autoTilt(-pl.p.x, -pl.p.z, 0.7);
      autoNudge(pl, 0, 0, 1.2, dt);
      return;
    }
    const sk = open[0];
    // фаза 3: свободный шар нужного цвета→ катим в лунку
    let free = null, fd = 1e9;
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer || b.mounted || b.kinematic || b.noMagic) continue;
      if (b.colorIdx !== sk.color || b.floor !== 0) continue;
      if (b.p.y < A.y - 1 || b.p.y > A.y + 3) continue;
      const d = Math.hypot(b.p.x - sk.x, b.p.z - sk.z);
      if (d < fd) { fd = d; free = b; }
    }
    if (free) {
      if (autoStuckShake(free, dt)) return;              // свободный шар в клине — тряска
      pipeSteer(free,sk.x,sk.z,2.0,null);
      // игрок не должен торчать у лунки (его отскакивает)
      if (Math.hypot(pl.p.x - sk.x, pl.p.z - sk.z) < 1.7) {
        autoNudge(pl, sk.x * 2 + 0.01, sk.z * 2, 1.0, dt);
      }
      return;
    }
    // фаза 2: освобождаем запас — катим игрока в ближайший шар нужного цвета
    if (pl.p.y > A.y + 1.6 && pl.p.y < A.y + 4.5) {      // v4.5: насест на запас — скатываемся к чаше
      autoTilt(-pl.p.x, -pl.p.z, 0.8);
      return;
    }
    if (autoStuckShake(pl, dt)) return;                  // игрок в клине — тряска
    let rack = null, rd2 = 1e9;
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer || !b.mounted || b.noMagic) continue;
      if (b.colorIdx !== sk.color || b.floor !== 0) continue;
      const d = Math.hypot(b.p.x - pl.p.x, b.p.z - pl.p.z);
      if (d < rd2) { rd2 = d; rack = b; }
    }
    if (rack) {
      autoTilt(rack.p.x - pl.p.x, rack.p.z - pl.p.z, 0.85);
      autoNudge(pl, rack.p.x, rack.p.z, 1.8, dt);
    }
  }

  // --- ЭТАЖ 1 «ТРУБА»: завести игрока в жёлоб и толкнуть цепочку к мишени
  // v4.6 Pipe autopilot: route -> align -> climb -> push. Gravity only.
  // No player teleports, direct velocity edits, column release or score edits.
  function pipeSteer(pl, tx, tz, cap, ramp) {
    const dx=tx-pl.p.x, dz=tz-pl.p.z, d=Math.hypot(dx,dz);
    const speed=Math.min(cap,Math.sqrt(3.2*d));
    let vx=d>0.001?dx/d*speed:0, vz=d>0.001?dz/d*speed:0;
    // Strong cross-track damping while entering a narrow channel.
    if(ramp) { vx=Math.min(cap,Math.max(0.35,dx*1.4)); vz=clamp(dz*2.0,-0.9,0.9); }
    let ax=(vx-pl.v.x)*2.5, az=(vz-pl.v.z)*2.5;
    // A ramp needs a sustained uphill component, not an artificial impulse.
    if(ramp && pl.p.x<ramp.startX+0.2 && pl.p.x>ramp.startX-3.2) ax+=3.05;
    const a=Math.hypot(ax,az);
    if(a<0.04){W.tilt.active=true;W.tilt.tRotX=W.tilt.tRotZ=0;return;}
    autoTilt(ax,az,clamp(a/4.05,0.05,1));
  }
  function pipeOnDeck(pl, st) {
    return pl.p.y>st.deckY+pl.r-0.24 && pl.p.x>st.startX-0.15 && pl.p.x<st.def.xOut+1.25 && Math.abs(pl.p.z-st.def.zc)<st.halfWidth-0.12;
  }
  function pipeAutoPhase(s,phase) {
    s.phase=phase;s.phaseT=0;s.stallT=0;s.best=Infinity;s.watchT=0;
    s.watchX=W.player.p.x;s.watchZ=W.player.p.z;
  }
  function pipeAutoPlan(s,st,ps,pl) {
    const tail=st.balls.filter(b=>b.alive&&!b.pipeDone&&!b.gapFalling).sort((a,b)=>a.p.x-b.p.x)[0];
    s.route=[];
    const west=st.startX-3.05;
    if(pipeOnDeck(pl,st)) {
      if(tail && pl.p.x>tail.p.x-pl.r-tail.r+0.1) {
        // Do not try to overtake the column by driving backwards through it.
        s.route=[{x:11.6,z:st.def.zc},{x:11.6,z:0},{x:west,z:0},{x:west,z:st.def.zc}];
        pipeAutoPhase(s,'route');
      } else pipeAutoPhase(s,'push');
      return;
    }
    const inMiddle=Math.abs(pl.p.z)<2.5;
    const alreadyWest=pl.p.x<st.startX-0.65;
    if(!inMiddle&&!alreadyWest) {
      // Go around the east end, never try to cross a side rail or the color filter.
      s.route.push({x:11.6,z:clamp(pl.p.z,-7.6,7.6)},{x:11.6,z:0});
    }
    if(!alreadyWest) s.route.push({x:west,z:0});
    s.route.push({x:west,z:st.def.zc});
    pipeAutoPhase(s,'route');
  }
  function autoFloor1(dt) {
    const ps=W.floorState&&W.floorState.pipe,pl=W.player;
    if(!ps||!pl||!pl.alive||pl.kinematic||W.rewind.active||inTransition())return;
    const st=ps.roads.find(r=>r.layout&&!r.solved);if(!st)return;
    let s=AUTO.pipe;
    if(!s||s.road!==st.id){
      s=AUTO.pipe={road:st.id,retries:0,hit:st.hit,dropped:st.dropped};
      pipeAutoPlan(s,st,ps,pl);
    }
    s.phaseT+=dt;
    if(st.hit!==s.hit||st.dropped!==s.dropped){s.hit=st.hit;s.dropped=st.dropped;s.stallT=0;s.best=Infinity;}
    if(s.phase==='unstick') {
      // Reverse first. A rail pinch also gets a small alternating side component.
      if(s.recoverTrack) {
        const dz=st.def.zc-pl.p.z;
        autoTilt(-1,clamp(dz*2-pl.v.z,-0.3,0.3),0.82);
      } else {
        const side=s.phaseT>0.65 ? (s.retries%2?0.45:-0.45) : 0;
        autoTilt(s.reverseX-s.reverseZ*side,s.reverseZ+s.reverseX*side,0.85);
      }
      if(s.phaseT>1.35){pipeAutoPlan(s,st,ps,pl);}
      return;
    }
    let tx,tz,cap=3.1,ramp=null;
    if(s.phase==='route') {
      const q=s.route[0];if(!q){pipeAutoPhase(s,'align');return;}
      tx=q.x;tz=q.z;
      if(Math.hypot(tx-pl.p.x,tz-pl.p.z)<0.28 && Math.hypot(pl.v.x,pl.v.z)<0.8){s.route.shift();s.best=Infinity;s.stallT=0;return;}
    } else if(s.phase==='align') {
      tx=st.startX-2.95;tz=st.def.zc;cap=1.4;
      if(Math.abs(pl.p.z-tz)<0.1 && Math.abs(pl.v.z)<0.18 && Math.abs(pl.p.x-tx)<0.3){pipeAutoPhase(s,'enter');return;}
    } else if(s.phase==='enter') {
      tx=st.startX+1.15;tz=st.def.zc;cap=1.9;ramp=st;
      if(pipeOnDeck(pl,st)&&pl.p.x>st.startX+0.35){pipeAutoPhase(s,'push');return;}
    } else {
      tx=st.def.xOut+1.4;tz=st.def.zc;cap=2.8;
      if(!pipeOnDeck(pl,st) && (Math.abs(pl.p.z-tz)>st.halfWidth || pl.p.y<st.deckY+pl.r-0.5)){
        pipeAutoPlan(s,st,ps,pl);return;
      }
    }
    pipeSteer(pl,tx,tz,cap,ramp);
    s.targetX=tx;s.targetZ=tz;
    const dist=Math.hypot(tx-pl.p.x,tz-pl.p.z);
    // Watch improvement, not just speed: oscillating against an obstacle is also stuck.
    if(dist<s.best-0.16){s.best=dist;s.stallT=0;}else s.stallT+=dt;
    if(s.stallT>2.6 || s.phaseT>32){
      s.retries++;
      s.recoverTrack=pipeOnDeck(pl,st)||s.phase==='enter';
      let dx=pl.p.x-tx,dz=pl.p.z-tz;
      // At the outer wall, reverse towards the centre rather than wedging harder.
      if(Math.hypot(pl.p.x,pl.p.z)>13.8){dx=-pl.p.x;dz=-pl.p.z;}
      const len=Math.hypot(dx,dz)||1;s.reverseX=dx/len;s.reverseZ=dz/len;
      pipeAutoPhase(s,'unstick');
      toast(D().autoPipeRecover,'warn',1200);
      W.events.push({t:W.time,type:'autoPipeRecover',road:st.id,retry:s.retries});
    }
  }

  function autoFloor2(dt) {
    const plates = W.floorState && W.floorState.plates;
    if (!plates) return;
    const pl = W.player;
    if (!pl || !pl.alive) return;
    const plate = plates.find(p => !p.active);
    if (!plate) {                                        // все плиты горят: к люку (автопоток)
      AUTO.plateSt = null;
      autoTilt(-pl.p.x, -pl.p.z, 0.55);
      autoNudge(pl, 0, 0, 0.8, dt);
      return;
    }
    if (AUTO.plateSt !== plate) {                        // новая плита — новая подготовка
      AUTO.plateSt = plate;
      AUTO.retreatT = 0;
      AUTO.runOn = false;
    }
    const band = plate.band;
    const vT = band.min + (band.max - band.min) * 0.55;  // цель — середина полосы (запас на кромку люка)
    const rp = Math.hypot(plate.x, plate.z) || 1;
    // разгонная точка на противоположной стороне диска: прогон идёт через центр
    const runD = clamp(0.85 * vT * vT / 4.4 + 1.6, 3.2, 7.4);
    const sx = -(plate.x / rp) * runD, sz = -(plate.z / rp) * runD;
    const dSt = Math.hypot(pl.p.x - sx, pl.p.z - sz);
    const dirX = plate.x - pl.p.x, dirZ = plate.z - pl.p.z;
    const dist = Math.hypot(dirX, dirZ) || 1;
    const vAlong = (pl.v.x * dirX + pl.v.z * dirZ) / dist;
    const speed = pl.v.length();
    if (AUTO.retreatT > 0) {                             // короткий откат на 3 м от плиты
      AUTO.retreatT -= dt;
      AUTO.runOn = false;
      const ux = sx - plate.x, uz = sz - plate.z;
      const ul = Math.hypot(ux, uz) || 1;
      autoSeek(pl, plate.x + ux / ul * 3.2, plate.z + uz / ul * 3.2, dt, 2.6);
      return;
    }
    // фиксация фазы: пока плита та же, прогон не сбрасывается
    if (!AUTO.runOn && dSt <= 1.25 && vAlong > -0.3) AUTO.runOn = true;
    if (!AUTO.runOn) {
      // этап «подготовка»: встать на разгонную линию напротив плиты (ПД-наведение)
      autoSeek(pl, sx, sz, dt, 3.4);
      return;
    }
    // этап «прогон»: скорость вдоль ПРЯМОЙ линии стенд→плита (удар меряет полную
    // скорость — гасим боковую составляющую, чтобы вход в зону был в полосе)
    const rlx = plate.x - sx, rlz = plate.z - sz;
    const rll = Math.hypot(rlx, rlz) || 1;
    const ux = rlx / rll, uz = rlz / rll;                // направление разгона
    const nx = -uz, nz = ux;                             // нормаль линии
    const off = (pl.p.x - sx) * nx + (pl.p.z - sz) * nz; // смещение от линии
    const vRun = pl.v.x * ux + pl.v.z * uz;              // скорость вдоль линии
    const err = vT - Math.max(vRun, 0);
    // контроллер скорости ведёт до самой плиты: вход в зону ровно на vT,
    // боковая составляющая погашена, смещение с линии плавно убирается
    const wx = ux * vT - nx * clamp(off, -2.5, 2.5) * 0.7;
    const wz = uz * vT - nz * clamp(off, -2.5, 2.5) * 0.7;
    const exv = wx - pl.v.x, ezv = wz - pl.v.z;
    const em = Math.hypot(exv, ezv);
    autoTilt(exv, ezv, clamp(0.15 + em * 0.25, 0.12, 1));
    if (err > 0.3) autoNudge(pl, pl.p.x + wx * 0.5, pl.p.z + wz * 0.5, Math.min(err * 1.4, 2.6), dt, vT + 1.4);
    // отскок от плиты/кромки — откат для нового захода
    if (vAlong < -1.3 && dist < 3.2) AUTO.retreatT = 0.8;
  }

  // --- ЭТАЖ 3 «ЯДРО»: разгон с противоположной стороны диска, нырок через люк
  // к ядру (схема «робота» §31.9: заход по линии z, наведение по времени падения),
  // затем — на кнопку (ось кнопки = ось ядра, v4.0).
  function autoUpdate(dt) {
    if(W.pipeExit&&W.pipeExit.active){updatePipeExit(dt);return;}
    if (!AUTO.active) return;
    if (W.state === 'lose' || W.state === 'win') { autoStop(W.state === 'win' ? 'floorDone' : 'end'); return; }
    if (W.state !== 'play' || W.ffOpen) return;          // пауза/модалка — стоим, не сдаёмся
    if (W.currentFloor !== AUTO.floor) { autoStop('floorDone'); return; }
    AUTO.t += dt;
    if (AUTO.t > AUTO.deadline) { autoStop('timeout'); return; }
    if (W.autoPull && W.autoPull.active) { W.tilt.active = false; W.tilt.tRotX = 0; W.tilt.tRotZ = 0; return; }
    if (W.currentFloor === 0) autoFloor0(dt);
    else if (W.currentFloor === 1) autoFloor1(dt);
    else if (W.currentFloor === 2) autoFloor2(dt);
    else autoFloor3(dt);
  }

  // -------------------------------------------------------------------------
  // v4.5: контекстное меню и выделение выключены (требование Яндекс Игр)
  // -------------------------------------------------------------------------
  function bindPlatformGuards() {
    try {
      document.addEventListener('contextmenu', e => e.preventDefault());
    } catch (e) {}
  }

  // ===========================================================================
  // 23. СТАРТ
  // ===========================================================================


  I18N.ru.helpBody += '<br><b>Плиты:</b> одна молния — слабый удар от ближнего края центрального люка; две — средний от дальнего края; три — сильный от противоположного борта. Наклоняйте в сторону плиты. Четвёртый этаж: воронка ведёт к открытому люку, разбейте объекты и попадите на кнопку под боковым люком.';
  I18N.en.helpBody += '<br><b>Plates:</b> one bolt means a short run from the near hatch edge; two mean a run from the far hatch edge; three mean a run from the opposite outer edge. Tilt toward the plate. Floor 4: the funnel guides you through an open throat; break the objects and land on the button below the offset throat.';
  I18N.ru.pipeWrongDrop='Чужой сброшен!'; I18N.en.pipeWrongDrop='Wrong one dropped!';
  I18N.ru.ffFinal='Шар не попал на финальную кнопку. Начать заново 4-й этаж или вернуться в меню?';
  I18N.en.ffFinal='The ball missed the final button. Restart floor 4 or return to the menu?';
  Sound.socketIn=()=>Sound.ui();
  Sound.reject=()=>Sound.plateBad();
  I18N.ru.helpBody = '<b>Цель:</b> проведите белый шар через четыре этажа и нажмите им красную финальную кнопку. Этажи открываются последовательно. Десять уровней, звёзды и рекорды сохраняются.<br><br>' +
    '<b>Компьютер:</b> тяните с зажатой левой кнопкой мыши, чтобы наклонять башню; правая кнопка вращает камеру, колесо меняет масштаб. Клик или свайп по тросу разрезает его. Кнопка «Резать трос» и X делают то же самое. Space — встряска, R — заново, Esc — пауза, A — авто-помощь.<br><br>' +
    '<b>Телефон и планшет:</b> один палец — наклон башни; два пальца — вращение камеры; щипок — масштаб. Все игровые действия доступны кнопками. Для разрезания троса нажмите «Резать трос» или проведите пальцем поперёк него.<br><br>' +
    '<b>Этаж 1 Чаша:</b> заполните цветные лунки нужным количеством шаров того же цвета. Закрытый центральный люк удерживает белый шар до решения этажа.<br><br>' +
    '<b>Этаж 2 Труба:</b> коснитесь белым шаром колонны, затем наклоняйте башню в сторону мишени. Первый шар целевого цвета стоит ближе всех к мишени. Цветная решётка на щели в борту удерживает свои шары на дороге, а чужие отправляет через боковой лоток в боковой отвод. Счётчик показывает принятые шары, ниже — число сброшенных. «Сброс этажа» перезапускает текущий этаж и возвращает белый шар на его начало.<br><br>' +
    '<b>Этаж 3 Резонанс:</b> ударяйте в лицевую сторону плит. Одна молния — слабый удар с разгона от ближнего края центрального люка; две — средний от дальнего края; три — сильный от противоположного борта. Удерживайте наклон в сторону плиты. Плита принимает диапазон скоростей, а не одну точную скорость. На поздних уровнях чужие шары могут погасить активную плиту.<br><br>' +
    '<b>Этаж 4 Финал:</b> докатите шар по пологой воронке до смещённого к стене люка. Над кнопкой находятся объекты щита: касание вызывает взрыв с осколками. Выровняйте башню, чтобы попасть на кнопку. При промахе можно повторить только четвёртый этаж или вернуться в меню.<br><br>' +
    '<b>Магия:</b> два свободных шара одного цвета заряжаются, третий запускает взрыв. Сброшенные из жёлоба шары можно использовать для магии. Кнопка «Авто» помогает пройти текущий этаж, глаз показывает только уже пройденные этажи. Пауза, потеря фокуса и реклама ставят игровой процесс на паузу.';
  I18N.en.helpBody = '<b>Goal:</b> guide the white ball through four floors and land on the red final button. Floors unlock in sequence. Ten levels, stars and records are saved.<br><br>' +
    '<b>Desktop:</b> left-drag tilts the tower; right-drag rotates the camera; the wheel zooms. Click or swipe the rope, tap Cut rope, or press X to release the ball. Space shakes, R restarts, Esc pauses and A toggles automatic help.<br><br>' +
    '<b>Phone and tablet:</b> drag one finger to tilt the tower; use two fingers to rotate the camera and pinch to zoom. All game actions have buttons. Tap Cut rope or swipe across the rope to release the ball.<br><br>' +
    '<b>Floor 1 Bowl:</b> fill each colored socket with the requested number of matching balls. The closed hatch holds the white ball until the puzzle is solved.<br><br>' +
    '<b>Floor 2 Pipe:</b> touch the column with the white ball and tilt toward the target. The first matching ball is nearest to the target. A colored grate at a gap in the side rail keeps matching balls on track and diverts other colors through a chute into the reserve. The main counter counts accepted balls; the smaller counter counts diverted ones. Reset floor restarts the current floor and returns the white ball to its entrance.<br><br>' +
    '<b>Floor 3 Resonance:</b> strike the front of each plate. One bolt: short run from the near edge of the central hatch. Two bolts: run from the far hatch edge. Three bolts: run from the opposite outer edge. Hold the tilt toward the plate. Speed ranges have tolerance. On later levels, other balls can deactivate plates.<br><br>' +
    '<b>Floor 4 Finale:</b> roll across the shallow funnel to its always-open throat near the wall. Hitting a shield object creates an explosion with fragment trails. Level the tower to land on the button below the offset throat. A miss offers a restart of floor four only, or a return to the menu.<br><br>' +
    '<b>Magic:</b> two free matching balls charge; a third triggers an explosion. Diverted balls can be used for magic. Auto helps with the current floor; the eye reveals only completed floors. Pause, loss of focus and advertisements pause gameplay.';
  I18N.ru.autoPipeRecover='Авто: освобождаю шар и повторяю заход';
  I18N.en.autoPipeRecover='Auto: freeing the ball and trying the entrance again';
  I18N.ru.pipeExitHint='Этаж решён: выкатываемся из жёлоба и едем к люку';
  I18N.en.pipeExitHint='Floor solved: rolling out of the trough toward the hatch';
  function refreshIcons49(){
    if(el.audio_ico)el.audio_ico.innerHTML=icon49('ui-sound');
    if(el.btn_audio){el.btn_audio.classList.toggle('off',!App.audioOn);el.btn_audio.setAttribute('aria-pressed',String(App.audioOn));el.btn_audio.title=curLang==='ru'?'Звук':'Sound';}
    if(el.theme_ico)el.theme_ico.innerHTML=icon49(getTheme()==='light'?'ui-sun':'ui-moon');
    if(el.btn_theme)el.btn_theme.title=curLang==='ru'?'Тема':'Theme';
    if(el.btn_back)el.btn_back.title=curLang==='ru'?'Назад':'Back';
  }
  function score49(n){n=Number(n);return Number.isFinite(n)?Math.max(0,Math.min(1e9,Math.floor(n))):0;}
  function renderHall49(){
    if(!el.hall_list)return;
    const ru=curLang==='ru',li=ru?0:1;
    const table=(key,title)=>{
      const rows=LEVELS.map((L,i)=>({name:L.name[li],level:i+1,score:score49((W.progress[i]||{})[key])})).filter(r=>r.score>0).sort((a,b)=>b.score-a.score||a.level-b.level);
      return '<section class="rank-section" data-ranking="'+key+'"><h3 class="rank-title">'+title+'</h3>'+ (rows.length?rows.map((r,i)=>'<div class="hallrow"><div class="rk">'+(i+1)+'</div><div class="nm">'+r.level+'. '+r.name+'</div><div class="sc">'+r.score+'</div></div>').join(''):'<p class="rank-empty">'+(ru?'Пока нет результатов':'No results yet')+'</p>')+'</section>';
    };
    el.hall_list.innerHTML=table('fairScore',ru?'ЧЕСТНО · БЕЗ АВТО':'FAIR PLAY · NO AUTO')+table('autoScore',ru?'С ПОМОЩЬЮ АВТО':'WITH AUTOPILOT');
    const old=W.progress.some(p=>score49(p.score)>Math.max(score49(p.fairScore),score49(p.autoScore)));
    if(el.hall_total)el.hall_total.textContent=old?(ru?'Результаты старых версий сохранены в прогрессе. Они не распределены по этим рейтингам: использование Авто тогда не записывалось.':'Older results remain in your progress. They are not classified here because Auto usage was not recorded.'): (ru?'Включение Авто хотя бы один раз относит весь проход к нижнему рейтингу.':'Using Auto even once places the entire run in the lower ranking.');
    if(el.hall_ya)el.hall_ya.innerHTML='';
  }
  function helpCards49(html){
    return html.split(/<br>\s*<br>/).filter(Boolean).map(p=>{
      const m=p.match(/^<b>(.*?)<\/b>\s*([\s\S]*)$/);
      return '<article class="help-card">'+(m?'<h2>'+m[1].replace(/:$/,'')+'</h2><p>'+m[2]+'</p>':'<p>'+p+'</p>')+'</article>';
    }).join('');
  }
  function restartCurrentFloor(){
    if(W.state!=='play'||W.ffOpen||inTransition())return;
    const f=W.currentFloor;
    if(f===0){App.start(W.currentLevel,W.sandbox);return;}
    autoStop('level');W.pipeExit=null;W.autoPull=null;W.rewind.active=false;W.trapTimer=-1;
    W.tilt.active=false;W.tilt.rotX=W.tilt.rotZ=W.tilt.tRotX=W.tilt.tRotZ=0;
    W.glassGroup.rotation.set(0,0,0);W.glassGroup.updateMatrixWorld(true);
    if(f===3)restartFinalFloor();
    else if(f===2)restartResonanceFloor();
    else{
      resetPipeRoads('button');
      const p=W.player;p.alive=true;p.kinematic=false;p.mounted=false;p.returning=false;p.idleT=0;p._pipeTrapT=0;
      p.pipeFree=false;p.gapFalling=false;p.inTrap=false;p.onNet=false;p.onGlass=false;p.glassT=0;
      p.p.copy(entryPointOf(1));p.v.set(0,0,0);p.mesh.visible=true;
      W.ropeCut=true;W.floorTransition=null;buildFloor(1);
      toast(D().floorRestarted,'good',1600);Sound.ui();
    }
    // Floor retries never erase the run-wide Auto classification.
    updateHud(.1,true);App.syncModals();
  }

  // Exact closest feature in the meridian plane. A closed profile is a solid,
  // not a collection of competing independent faces and vertex contacts.
  function revolveContact50(ball,col,dt){
    const p=ball.p,px=p.x-(col.offsetX||0),pz=p.z-(col.offsetZ||0),r=Math.hypot(px,pz);
    if(p.y<col.yMin-ball.r||p.y>col.yMax+ball.r||r<col.rMin-ball.r-.05||r>col.rMax+ball.r)return;
    if(!angIn(Math.atan2(pz,px),col.angFrom,col.angTo))return;
    let best=Infinity,cr=0,cy=0,nr=0,ny=1;
    for(const sg of col.segs){
      const t=clamp(((r-sg.r1)*sg.dr+(p.y-sg.y1)*sg.dy)/sg.l2,0,1);
      const qr=sg.r1+sg.dr*t,qy=sg.y1+sg.dy*t,d2=(r-qr)**2+(p.y-qy)**2;
      if(d2<best){best=d2;cr=qr;cy=qy;nr=sg.nr;ny=sg.ny;}
    }
    if(!isFinite(best))return;
    let inside=false;
    if(col.closed){
      const vs=col.verts;
      for(let i=0,j=vs.length-1;i<vs.length;j=i++){
        const a=vs[i],b=vs[j];
        if((a.y>p.y)!==(b.y>p.y)&&r<(b.r-a.r)*(p.y-a.y)/(b.y-a.y)+a.r)inside=!inside;
      }
    }
    const d=Math.sqrt(best);
    if(!inside&&d>=ball.r)return;
    if(d>1e-10){const sign=inside?-1:1;nr=sign*(r-cr)/d;ny=sign*(p.y-cy)/d;}
    const ux=r>1e-10?px/r:1,uz=r>1e-10?pz/r:0;
    ball.rollExtra=col.group==='platformA'&&r>=LEVEL_CONFIG.platformA.bowlRadius?0:(col.roll||0);
    const hitE=col.group==='platformA'&&r>=LEVEL_CONFIG.platformA.bowlRadius?LEVEL_CONFIG.physics.restitutionSurface:col.e;
    resolveContact(ball,nr*ux,ny,nr*uz,inside?ball.r+d:ball.r-d,hitE,LEVEL_CONFIG.physics.surfaceFriction,dt,0,0,0,col);
    if(dt>0&&col.onHit)col.onHit(ball,col);
  }
  function rampContact50(ball,col,dt){
    const p=ball.p,dx=col.x1-col.x0,dy=col.y1-col.y0,len2=dx*dx+dy*dy,len=Math.sqrt(len2);
    if(p.x<col.x0-ball.r||p.x>col.x1+ball.r||Math.abs(p.z-col.z)>col.halfWidth+ball.r)return;
    const signed=(-dy*(p.x-col.x0)+dx*(p.y-col.y0))/len;
    if(signed<-.12)return;
    const t=clamp(((p.x-col.x0)*dx+(p.y-col.y0)*dy)/len2,0,1);
    const qx=col.x0+t*dx,qy=col.y0+t*dy,qz=clamp(p.z,col.z-col.halfWidth,col.z+col.halfWidth);
    const vx=p.x-qx,vy=p.y-qy,vz=p.z-qz,d=Math.hypot(vx,vy,vz);
    if(d>=ball.r)return;
    let nx,ny,nz,pen;
    if(signed>=0&&d>1e-10){nx=vx/d;ny=vy/d;nz=vz/d;pen=ball.r-d;}
    else{nx=-dy/len;ny=dx/len;nz=0;pen=ball.r-signed;}
    ball.rollExtra=0;resolveContact(ball,nx,ny,nz,pen,.15,LEVEL_CONFIG.physics.surfaceFriction,dt,0,0,0,col);
  }
  function rampMesh50(x0,x1,y0,y1,z,width){
    const dx=x1-x0,dy=y1-y0,len=Math.hypot(dx,dy);
    const m=new THREE.Mesh(new THREE.BoxGeometry(len,.12,width),litFloorMaterial(MAT.silverDark));
    m.rotation.z=Math.atan2(dy,dx);
    // The visible top, not the box centre, coincides with the contact segment.
    m.position.set((x0+x1)/2+dy/len*.06,(y0+y1)/2-dx/len*.06,z);
    return m;
  }
  function autoAssist(dt){
    for(const b of W.balls){
      if(!b.alive||b.kinematic||(b.floor!==undefined&&b.floor!==W.currentFloor))continue;
      b.assistCd=Math.max(0,b.assistCd-dt);
      if(b.isPlayer&&W.state==='play')shaftAssist(b,dt);
      if(b.isPlayer){
        if(b.v.length()<.5){b.idleT=(b.idleT||0)+dt;if(!b.idlePos)b.idlePos=b.p.clone();else if(b.p.distanceTo(b.idlePos)>1.5){b.idleT=0;b.idlePos.copy(b.p);}}
        else{b.idleT=0;if(!b.idlePos)b.idlePos=b.p.clone();else b.idlePos.copy(b.p);}
      }
    }
  }
  // Responsive layout for pointer/touch input.
  function initInputLayout50(){
    const toolbar=document.getElementById('hud-side'),game=document.getElementById('scr-game'),chrome=document.getElementById('chrome');
    toolbar.appendChild(document.getElementById('btn-floors'));
    document.getElementById('hud').appendChild(document.getElementById('floor-task'));
    const meter=document.querySelector('.tilt-meter');meter.id='tilt-top';game.appendChild(meter);
    const layout=()=>{const compact=matchMedia('(max-width:1079px), (pointer:coarse)').matches;(compact?chrome:game).appendChild(toolbar);};
    window.addEventListener('resize',layout);layout();
  }

  function boot() {
    App.init();
    initInputLayout50();
    window.GB = { collideOne, collideBalls, makeBall, profilePlatformA, profileFloorDisc, restartCurrentFloor, renderHall, renderHelpScreen, saveProgress, loadProgress, mergeCloudProgress, cloudSave, startPipeExit, updatePipeExit, finalFloorY, finalFlightActive, updateFinalView, updateCamera, updateVisuals, autoFloor3, autoStart, autoStop, autoUpdate, autoFloor1, applyTilt, protectResonancePerimeter, autoAssist, updateTriggers, updateFloorState, updateKinematic, validateRoad, updatePipe, pipeArrive, resetPipeRoads, updatePlates, plateImpact, restartFinalFloor, protectClosedFloor, syncFloorViz, W: W, VERSION: VERSION, LEVEL_CONFIG: LEVEL_CONFIG, LEVELS: LEVELS, App: App, Magic: Magic, 
      Sound: Sound, I18N: I18N, doShake: doShake, cutRope: cutRope, breakCore: breakCore, stepPhysics: stepPhysics,
      buildLevel: buildLevel, buildFloor: buildFloor, buildAllFloors: buildAllFloors, setLanguage: setLanguage, fmtTime: fmtTime, skipIntro: skipIntro, addScore: addScore,
      PLAT: PLAT, LEVEL_PALETTES: LEVEL_PALETTES, showScreen: showScreen, startTraining: startTraining, getTheme: getTheme, applyTheme: applyTheme };   // v4.5
    // v4.5: платформа Яндекс Игр — SDK грузится только на платформе;
    // локально/в песочнице тихий гостевой режим, LoadingAPI.ready всё равно вызывается.
    initPlatform().then(() => {
      try {
        // 1.7 автоязык: платформа задаёт язык, только если игрок не выбирал сам
        let hadChoice = null;
        try { hadChoice = window.localStorage.getItem('graviboom_lang_v300'); } catch (e) {}
        if (PLAT.lang && !hadChoice) setLanguage(/^(be|kk|ru|uk|uz)$/i.test(PLAT.lang) ? 'ru' : 'en');
      } catch (e) {}
      cloudLoad().then(cloud => {
        if (cloud) {
          mergeCloudProgress(cloud);
          renderSidePanels();
        }
        gameReady();          // 1.19.2 LoadingAPI.ready: меню готово — можно играть
      }).catch(() => gameReady());
    }).catch(() => gameReady());
  }

  if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', boot);
  else boot();

})();

  