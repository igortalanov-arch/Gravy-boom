const{chromium}=require('playwright'),fs=require('fs');
(async()=>{const browser=await chromium.launch({args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});let results=[];const repeats=Number(process.argv[2]||1);const file=process.argv[3]||'campaign53-pilot.json';
for(const level of (process.env.LEVEL===undefined?Array.from({length:10},(_,i)=>i):[Number(process.env.LEVEL)]))for(const run of (process.env.RUN===undefined?Array.from({length:repeats},(_,i)=>i):[Number(process.env.RUN)])){
 const page=await browser.newPage();let errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(process.env.GAME_URL||'http://127.0.0.1:8087/gravi-boom-v5.3-single.html',{timeout:90000});await page.waitForFunction(()=>window.GB);
 const result=await page.evaluate(({level,run})=>{
  // Seed is for reproducible initial generation and in-game random effects, not forced outcomes.
  let seed=530000+level*1000+run*97;Math.random=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
  const W=GB.W;GB.App.start(level);GB.App.running=false;GB.skipIntro();GB.Sound.setEnabled(false);
  const visits=[0],retries=[0,0,0,0],incidents=[];let lastFloor=0,lastProgress=0,lastSignature='',ticks=0,reason='time-limit';
  for(;ticks<60*900;ticks++){
   if(W.state==='win'){reason='win';break;}
   if(W.state==='lose'){reason='lose';break;}
   if(!W.player.p.toArray().concat(W.player.v.toArray()).every(Number.isFinite)){reason='nonfinite';break;}
   if(W.ffOpen){const f=W.currentFloor;incidents.push({time:ticks/60,floor:f,reason:W.ffReason,events:W.events.slice(-6)});if(retries[f]++>=2){reason='retry-limit';break;}GB.App.closeFf('restart');lastProgress=ticks;}
   if(W.currentFloor!==lastFloor){lastFloor=W.currentFloor;visits.push(lastFloor);lastProgress=ticks;}
   if(W.state==='play'&&!W.floorTransition?.active&&!GB_AUTO.active){GB.autoStart();}
   const state=GB.advanceSimulation53(1/60);GB.applyTilt(state.live?state.dt:1/60);
   const sig=JSON.stringify([W.currentFloor,W.floorSolvedArr,W.floorStates[0].sockets.map(s=>s.count),W.floorStates[1].pipe.roads.map(r=>r.hit),W.floorStates[2].plates.map(p=>p.active),W.coreAlive,W.state]);
   if(sig!==lastSignature){lastSignature=sig;lastProgress=ticks;}
   if(ticks-lastProgress>180*60){reason='stalled';break;}
  }
  return{level:level+1,run:run+1,seed:530000+level*1000+run*97,reason,seconds:+(ticks/60).toFixed(2),visits,retries,incidents,floor:W.currentFloor,solved:W.floorSolvedArr,state:W.state,position:W.player.p.toArray(),events:W.events.slice(-15),classifiedAuto:W.runUsedAuto};
 },{level,run});result.errors=errors;results.push(result);fs.writeFileSync(file,JSON.stringify(results,null,2));console.log(JSON.stringify({level:result.level,run:result.run,result:result.reason,time:result.seconds,floor:result.floor,retries:result.retries}));await page.close();
}await browser.close();console.log('TOTAL',results.length,'WIN',results.filter(r=>r.reason==='win').length)})();
