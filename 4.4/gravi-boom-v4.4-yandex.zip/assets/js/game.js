
/* =============================================================================
   ГРАВИ-БУМ! v4.1 — «Башня четырёх этажей»
   Один файл, без зависимостей кроме встроенного Three.js. Работает по file://.

   Архитектура:
     1.  LEVEL_CONFIG — геометрия стакана, физика, палитра
     2.  SETTINGS     — панель настроек баланса (localStorage)
     3.  I18N         — RU / EN
     4.  Sound        — синтез WebAudio (без файлов)
     5.  Collider     — поверхности вращения, цилиндрические стенки, капсулы
     6.  Ball         — тело шара (примагниченный / свободный / заряженный)
     7.  GlassWorld   — физика: гравитация, CCD, столкновения, ловушка, кнопка
     8.  Magic        — match-3 с таймером 10 с, цепочки, взрывы
     9.  FX           — искры, слоу-мо, тряска экрана
     10. Rope         — трос и его разрезание свайпом
     11. Replay       — запись и повтор спуска
     12. App          — ввод, камера, HUD, модальные окна, главный цикл
   ============================================================================= */
(function () {
  'use strict';

  // ===========================================================================
  // 1. КОНФИГУРАЦИЯ УРОВНЯ
  // ===========================================================================
  const LEVEL_CONFIG = {
    // Стакан: ось Y, радиус 15, от стеклянного дна (y = -6.5) до верха (y = +22)
    glass: {
      radius: 15.0,
      yBottom: -6.5,
      yTop: 22.0,
      wallThickness: 0.35
    },

    physics: {
      gravity: 9.8,
      restitutionBall: 0.92,     // шар — шар (бильярд)
      restitutionSurface: 0.88,  // шар — площадка
      restitutionWall: 0.90,     // шар — стенка стакана
      airDrag: 0.02,             // линейное трение о воздух, 1/с
      surfaceFriction: 0.05,     // трение о поверхность
      angularFriction: 0.08,
      maxSpeed: 16.0,
      substeps: 6,               // подшагов на кадр (CCD для тонких плит)
      magneticAssistTilt: 12 * Math.PI / 180,   // ° наклона стакана для ассиста
      magneticAssistImpulse: 0.4,
      stuckSpeed: 0.1,
      stuckTime: 2.0,
      stuckImpulse: 0.5,
      returnAfter: 3.0,          // шар стоит > 3 с → возврат на трос
      returnDuration: 1.0
    },

    // Наклон стакана
    tilt: {
      max: 25 * Math.PI / 180,
      lerpIn: 0.3,               // сек на выход на целевой наклон
      lerpOut: 0.8,              // сек на возврат
      sensitivity: 0.0022        // рад на пиксель движения мыши
    },

    // Встряска
    shake: {
      impulseMin: 0.6,
      impulseMax: 1.2,
      visualAmp: 0.15,
      visualTime: 0.3,
      cooldown: 1.2
    },

    // Трос
    rope: {
      anchor: { x: 0, y: 20, z: 0 },
      length: 7.9,               // шар висит на y = 12.1 — над чашей площадки A
      swing: 0.12                // лёгкое покачивание до разреза
    },

    // Площадка A «Чаша» (y = 11)
    platformA: {
      y: 11.0,
      // толщина больше глубины чаши (0.8), иначе чаша прорезает диск насквозь
      thickness: 1.1,
      radius: 11.0,
      bowlRadius: 4.0,
      bowlDepth: 0.8,
      rimRadius: 14.2,        // v4.1: перила сомкнуты и прижаты к стенке — зазора-выхода нет
      rimTube: 0.4,
      rimY: 12.1,
      exitAngle: 0,              // (не используется с v4.1: выход только через центральный люк)
      exitHalfWidth: 22 * Math.PI / 180
    },

    // Площадка B «Воронка» (y = 5)
    platformB: {
      y: 5.0,
      thickness: 0.6,
      radius: 13.0,
      funnelTopR: 10.0,
      funnelTopY: 5.3,
      funnelBottomR: 1.5,
      funnelBottomY: 3.5,
      holeRadius: 1.5
    },

    // Ядро щита и три тела (y = 0.5). v4.0: зона смещена от оси — шар, падающий
    // из люка этажа 3 по центру, НЕ должен автоматически разбивать ядро
    shield: {
      y: 0.5,
      x: 0, z: 4.2,
      coreRadius: 1.2,
      orbitRadius: 3.0,
      orbitOmega: 1.2,           // рад/с
      bodyRadius: 0.84,
      bodyMass: 1.73,
      releaseSpeed: 3.0          // касательная скорость после освобождения
    },

    // Финальная кнопка (y = -2.5)
    button: {
      y: -2.5,
      radius: 1.6,
      thickness: 0.4,
      pressDepth: 0.15,
      // v4.0: кронштейны развёрнуты — не ловят шар, ныряющий к смещённому ядру
    bracketAngles: [90, 210, 330].map(a => a * Math.PI / 180),
      bracketWallY: -2.0,
      bracketRadius: 0.2,
      bracketInner: 1.4,
      glowRadius: 4.0
    },

    // Ловушка (сетка y = -4.5, стекло y = -6.5)
    trap: {
      netY: -4.5,
      netRadius: 14.0,
      netHole: 1.6,
      netTilt: 3 * Math.PI / 180,   // уклон к центру
      cellSize: 0.5,
      glassY: -6.5,
      glassRadius: 15.0,
      gameOverDelay: 2.0,           // драматическая пауза
      dissolveAfter: 30.0,          // шары на стекле растворяются
      dissolveTime: 3.0
    },

    // Магия match-3
    magic: {
      chargeTime: 10.0,
      ringRadiusK: 1.9,
      slowmoTime: 0.35,
      slowmoScale: 0.35,
      flashTime: 0.15,
      sparks: 24,
      sparkSpeed: 5.0,
      sparkLife: 0.5,
      screenShakeTime: 0.25,
      screenShakeAmp: 0.2
    },

    // Игровой шар
    player: {
      radius: 0.75,
      mass: 1.0,
      colorNum: 0xffffff
    },

    palette: [
      { id: 'red',    colorNum: 0xff3355, emissive: 0x551122 },
      { id: 'blue',   colorNum: 0x3d7bff, emissive: 0x112255 },
      { id: 'yellow', colorNum: 0xffcc00, emissive: 0x554400 }
    ],

    // Камера
    camera: {
      minPolar: 20 * Math.PI / 180,   // от вертикали
      maxPolar: 85 * Math.PI / 180,
      minDist: 18,
      maxDist: 78,
      defaultDist: 46,
      defaultTheta: 0.6,
      defaultPolar: 62 * Math.PI / 180,
      targetY: 4.0,
      fov: 46,
      near: 0.1,
      far: 400
    },

    gameplay: {
      maxTimeText: true
    },

    // v4.0: четыре этажа
    floors: {
      holeR: 2.0,                 // радиус центрального люка (ТЗ v4.2: 2.0)
      gateOpenTime: 0.6,          // анимация открывания люка, с
      transitionDur: 1.2          // переход между этажами, с
    },

    // v4.0: резонансные плиты — полосы скорости шара в момент касания
    resonance: {
      weak:   { min: 0.4, max: 1.2 },
      mid:    { min: 2.0, max: 4.5 },
      strong: { min: 6.5, max: 12.0 }
    },

    // v4.0: палитры этажей
    floorPalettes: [
      { name: 'bowl',       bg: 0x040a18, fog: 0x0a1830, key: 0x9fd8ff, hemi: 0x9fd8ff, hemiG: 0x0a1830, glow: 0x00d4ff },
      { name: 'pipe',       bg: 0x100804, fog: 0x2a0e04, key: 0xffd9a8, hemi: 0xffd9a8, hemiG: 0x180a04, glow: 0xff8800 },
      { name: 'resonance',  bg: 0x0a0418, fog: 0x1e0838, key: 0xd8b8ff, hemi: 0xd8b8ff, hemiG: 0x0e0420, glow: 0xd946ef },
      { name: 'core',       bg: 0x180408, fog: 0x380810, key: 0xffa0a8, hemi: 0xffa0a8, hemiG: 0x180408, glow: 0xff3355 }
    ]
  };

  // ===========================================================================
  // 1b. ДЕСЯТЬ УРОВНЕЙ (v4.1, ТЗ «Этап 4»): башня из 4 этажей одинаковой
  // геометрии; сложность растёт плотностью правил, а не числом загадок.
  // Поля: sockets [[цвет, цель]...] · chain {n, reds, mines, jitter, flip} ·
  // plates [{kind, min, max}...] · magicTime · echo · rewind ('free'|'pen50'|
  // 'reset'|'pen100'|'pen200') · perfectCut · hints (2 все/1 без нижней/0 нет) ·
  // blink (плиты мигают) · bodies (3|4) · ballBoost · dark · name [RU, EN]
  // ===========================================================================
  const VERSION = '4.4';
  // v4.4: палитры 10 уровней — «цилиндры башни своего цвета» (как в МАТ-БУМ! 3):
  // pal[0] — тон стекла стакана, pal[1] — тон дисков этажей, pal[2] — акцент (пояса, свечение).
  const LEVEL_PALETTES = [
    ['#37c8f0', '#3a97c9', '#37c8f0'],   // 1 — небесно-голубой
    ['#4f8cff', '#4668d8', '#6f9dff'],   // 2 — синий
    ['#8d5bff', '#7a4fd0', '#a97dff'],   // 3 — фиолетовый
    ['#ff5fa8', '#d84f92', '#ff7fbf'],   // 4 — розовый
    ['#ff7a3c', '#d86a34', '#ff9a5c'],   // 5 — оранжевый
    ['#ffc93c', '#d8a832', '#ffd97a'],   // 6 — золотой
    ['#5ce65c', '#48c95a', '#8af07a'],   // 7 — зелёный
    ['#2fd8c8', '#2ab5ad', '#5ff0e0'],   // 8 — бирюзовый
    ['#ff4f6d', '#d8445f', '#ff7a92'],   // 9 — алый
    ['#c9d6f0', '#8f9fc4', '#e8f0ff']    // 10 — ледяной белый (тёмный уровень)
  ];
  const LEVELS = [
    // pipe: { color, roads: [массив 'K'|'S'|'M' дороги A, null|массив дороги B] } — ТЗ v4.2 п.2.11
    // plate3: { weak/mid/strong: [min,max] } — пороги м/с по ТЗ v4.2 п.3.13; hazards — шары-помехи
    { id: 1, name: ['Первое знакомство', 'First Steps'],
      sockets: [[0, 1]],
      pipe: { color: 0, roads: [['K', 'S', 'K'], null] },
      plate3: { weak: [0.4, 2.0], mid: [2.5, 5.0], strong: [6.5, 10.0] }, hazards: 0,
      magicTime: 10, echo: false, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 2, name: ['Повторение', 'Repetition'],
      sockets: [[0, 1], [1, 2]],
      pipe: { color: 0, roads: [['M', 'S', 'K', 'K'], null] },
      plate3: { weak: [0.4, 2.0], mid: [2.5, 5.0], strong: [6.5, 10.0] }, hazards: 0,
      magicTime: 10, echo: false, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 3, name: ['Первый выбор', 'First Choice'],
      sockets: [[0, 2], [2, 2]],
      pipe: { color: 2, roads: [['K', 'S', 'M', 'K', 'S', 'K'], ['K', 'M', 'S', 'K']] },
      plate3: { weak: [0.4, 2.0], mid: [2.5, 5.0], strong: [6.5, 10.0] }, hazards: 0,
      magicTime: 10, echo: false, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 4, name: ['Плотность', 'Density'],
      sockets: [[0, 1], [1, 2], [2, 3]],
      pipe: { color: 0, roads: [['K', 'S', 'K', 'M', 'S', 'K'], ['K', 'S', 'M', 'K']] },
      plate3: { weak: [0.6, 1.6], mid: [2.5, 4.8], strong: [6.5, 10.0] }, hazards: 0,
      magicTime: 9, echo: true, rewind: 'free', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 5, name: ['Первый вызов', 'First Challenge'],
      sockets: [[0, 2], [0, 3], [1, 3]],
      pipe: { color: 1, roads: [['K', 'S', 'K', 'S', 'M', 'K'], ['K', 'M', 'S', 'S', 'K']] },
      plate3: { weak: [0.8, 1.4], mid: [2.5, 4.5], strong: [6.5, 9.5] }, hazards: 0,
      magicTime: 8, echo: true, rewind: 'pen50', perfectCut: false, hints: 2, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 6, name: ['Время', 'Time'],
      sockets: [[0, 3], [1, 3], [2, 4]],
      pipe: { color: 2, roads: [['K', 'S', 'K', 'M', 'S', 'K', 'S', 'K'], ['K', 'S', 'K', 'S', 'M', 'S', 'K']] },
      plate3: { weak: [0.9, 1.3], mid: [2.8, 4.2], strong: [6.8, 9.2] }, hazards: 1,
      magicTime: 7, echo: true, rewind: 'reset', perfectCut: false, hints: 1, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 7, name: ['Ровная линия', 'Straight Line'],
      sockets: [[0, 3], [1, 4], [2, 4]],
      pipe: { color: 0, roads: [['K', 'S', 'K', 'S', 'M', 'K', 'S', 'K'], ['K', 'S', 'M', 'K', 'S', 'S', 'K']] },
      plate3: { weak: [1.0, 1.3], mid: [2.9, 4.0], strong: [7.0, 9.0] }, hazards: 1,
      magicTime: 6, echo: true, rewind: 'reset', perfectCut: false, hints: 1, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 8, name: ['Идеальный срез', 'Perfect Cut'],
      sockets: [[0, 4], [1, 4], [2, 4]],
      pipe: { color: 1, roads: [['K', 'S', 'K', 'M', 'S', 'K', 'S'], ['K', 'M', 'S', 'K', 'S', 'K']] },
      plate3: { weak: [1.1, 1.3], mid: [3.0, 3.8], strong: [7.2, 8.8] }, hazards: 1,
      magicTime: 5, echo: true, rewind: 'reset', perfectCut: true, hints: 1, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 9, name: ['Светофор', 'Traffic Light'],
      sockets: [[0, 4], [1, 5], [2, 5]],
      pipe: { color: 1, roads: [['K', 'S', 'K', 'S', 'M', 'K', 'S', 'K'], ['K', 'S', 'M', 'K', 'S', 'S', 'K']] },
      plate3: { weak: [1.15, 1.25], mid: [3.1, 3.7], strong: [7.4, 8.6] }, hazards: 2,
      magicTime: 4, echo: true, rewind: 'pen100', perfectCut: true, hints: 0, bodies: 3, ballBoost: 1.0, dark: false },
    { id: 10, name: ['Мастер', 'The Master'],
      sockets: [[0, 2], [1, 3], [2, 3], [0, 4], [2, 5]],
      pipe: { color: 0, roads: [['K', 'S', 'K', 'M', 'S', 'K', 'S', 'K'], ['K', 'M', 'S', 'K', 'S', 'K']], jitter: 0.15 },
      plate3: { weak: [1.15, 1.25], mid: [3.2, 3.6], strong: [7.6, 8.4] }, hazards: 2,
      magicTime: 3, echo: true, rewind: 'pen200', perfectCut: true, hints: 0, bodies: 4, ballBoost: 1.1, dark: true }
  ];

  // v4.1: параметры текущего уровня (модификаторы)
  function LV() { return LEVELS[clamp(W.currentLevel | 0, 0, LEVELS.length - 1)]; }

  // Применяет параметры уровня к LEVEL_CONFIG перед постройкой.
  // v4.1: башня фиксированной геометрии (11/8/5/0.5) — меняются только правила.
  function applyLevel(idx) {
    const L = LEVELS[clamp(idx | 0, 0, LEVELS.length - 1)];
    LEVEL_CONFIG.platformA.y = 11;
    LEVEL_CONFIG.platformA.rimY = 11 + 1.1;
    LEVEL_CONFIG.platformA.bowlDepth = 0.8;
    LEVEL_CONFIG.platformB.y = 5;
    LEVEL_CONFIG.platformB.funnelTopY = 5;            // уровень диска «Резонанс»
    LEVEL_CONFIG.platformB.funnelBottomY = 5 - 0.45;  // низ трубки люка
    LEVEL_CONFIG.floorPipeY = 8;                      // этаж «Труба» — посередине
    LEVEL_CONFIG.shield.y = 0.5;
    LEVEL_CONFIG.rope.anchor.y = 20;
    LEVEL_CONFIG.tilt.max = 25 * Math.PI / 180;
    // «Время магии» — ручная настройка игрока: дефолт уровня ставим только
    // если игрок не трогал слайдер в этом сеансе
    if (!W.magicTouched) SETTINGS.magicTime = L.magicTime;
    return L;
  }

  // Высота плоскости этажа (для проверки «шар провалился ниже этажа»)
  function floorY(idx) {
    if (idx <= 0) return LEVEL_CONFIG.platformA.y;
    if (idx === 1) return LEVEL_CONFIG.floorPipeY;
    if (idx === 2) return LEVEL_CONFIG.platformB.y;
    return LEVEL_CONFIG.shield.y + 2.0;
  }

  // ===========================================================================
  // 2. НАСТРОЙКИ БАЛАНСА
  // ===========================================================================
  const SETTINGS_DEFAULTS = {
    ballSpeed: 1.0,     // 1) Скорость шара
    impactForce: 1.0,   // 2) Сила ударов (было scatter)
    ballSize: 1.0,      // 3) Размер шаров
    magicTime: 10.0,    // 4) Время магии, сек
    echoRadius: 3.5,    // 5) v4.0: радиус эхо-взрыва, м
    echoWindow: 0.25    // 6) v4.0: задержка эхо-взрыва, с
  };

  const SETTINGS_LIMITS = {
    ballSpeed:   { min: 0.3, max: 3.0, step: 0.05 },
    impactForce: { min: 0.2, max: 3.0, step: 0.05 },
    ballSize:    { min: 0.7, max: 1.3, step: 0.05 },
    magicTime:   { min: 3.0, max: 25.0, step: 0.5 },
    echoRadius:  { min: 2.0, max: 6.0, step: 0.1 },
    echoWindow:  { min: 0.1, max: 0.6, step: 0.05 }
  };

  const SETTINGS = Object.assign({}, SETTINGS_DEFAULTS);
  const SETTINGS_KEY = 'graviboom_glass_v300';

  function loadSettings() {
    try {
      const raw = window.localStorage.getItem(SETTINGS_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      Object.keys(SETTINGS_DEFAULTS).forEach(k => {
        const v = parseFloat(data[k]);
        if (isFinite(v)) {
          const L = SETTINGS_LIMITS[k];
          SETTINGS[k] = Math.max(L.min, Math.min(L.max, v));
        }
      });
    } catch (e) { /* file:// или приватный режим */ }
  }

  function saveSettings() {
    try { window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(SETTINGS)); } catch (e) {}
  }

  function resetSettings() {
    Object.keys(SETTINGS_DEFAULTS).forEach(k => { SETTINGS[k] = SETTINGS_DEFAULTS[k]; });
    W.magicTouched = false;               // v3.5: снова применяем дефолты уровней
    saveSettings();
  }

  // ===========================================================================
  // 3. ЛОКАЛИЗАЦИЯ
  // ===========================================================================
  const I18N = {
    ru: {
      title: 'ГРАВИ-БУМ! v' + VERSION,
      subtitle: 'Башня четырёх этажей · v' + VERSION,
      timeLabel: 'ВРЕМЯ',
      magicLabel: 'МАГИЯ',
      trapLabel: 'ЛОВУШКА',
      scoreLabel: 'ОЧКИ',
      comboLabel: 'КОМБО',
      btnShake: 'Тряхнуть',
      btnShake2: 'ТРЯХНУТЬ',
      btnCut: 'РЕЗАТЬ ТРОС',
      btnReplay: 'Повтор',
      btnRestart: 'Заново',
      btnLang: 'RU',
      tiltL: '← наклон',
      tiltR: 'наклон →',
      legendRed: 'Красные шары: кластер у выхода площадки A — взорвите, чтобы открыть путь',
      legendBlue: 'Синие шары: приманки по краям воронки (путь не открывают)',
      legendYellow: 'Жёлтые шары: пробка в центре воронки — взорвите, чтобы провалиться',
      legendCore: 'Ядро щита (y = 0.5): разбейте шаром, иначе три тела отобьют его в ловушку',
      legendBtn: 'Красная кнопка на кронштейнах (y = −2.5) — цель спуска',
      legendStats: 'Шаров: {free} свободных / {mounted} примагничено / {charged} заряжено',
      hint: '<b>ЛКМ-тяга</b> — наклон стакана (вверх = от себя, вниз = к себе) · <b>клик или свайп по тросу</b> — разрезать (<span class="kbd">X</span>) · <b>ПКМ</b> — камера с инерцией · <b>колесо</b> — зум · <span class="kbd">Space</span> — встряска · <span class="kbd">R</span> — заново · <span class="kbd">T</span> — повтор · <span class="kbd">S</span> — настройки',
      statusRope: 'Трос цел: кликните по тросу или проведите поперёк него (либо нажмите X)',
      statusFallA: 'Этаж «Чаша»: заполняйте лунки шарами нужного цвета — патронта́жи рядом',
      statusFallB: 'Этаж «Труба»: толкните первый шар жёлоба, чтобы цепочка освободила красные',
      statusSocket: 'ЛУНКИ {a}/{b}: катите шары нужного цвета в гнёзда с цифрами',
      statusCore: 'Шар ниже воронки: попадите в фиолетовое ядро щита, иначе три тела отобьют его',
      statusButton: 'Шар над кнопкой: держите его точно по центру',
      statusTrap: 'Шар в ловушке! Через {n} с — поражение',
      statusWin: 'ПОБЕДА: кнопка вдавлена',
      statusCharged: 'Магия заряжена: {n} шар(а), осталось {t} с — ищите третий того же цвета',
      menuTitle: 'ГРАВИ-БУМ!',
      menuSubtitle: 'БАШНЯ ЧЕТЫРЁХ ЭТАЖЕЙ · v' + VERSION + ' · 10 УРОВНЕЙ',
      menuS1: '<b>Разрежьте трос</b>: кликните по нему, проведите поперёк или нажмите <b>X</b> — белый шар сорвётся вниз.',
      menuS2: '<b>Наклоняйте стакан</b> (ЛКМ + движение: вверх — от себя, вниз — к себе) и <b>трясите</b> (Space), чтобы катить шар.',
      menuS3: '<b>Магия:</b> два шара одного цвета при касании заряжаются на 10 с; третий того же цвета — и все взрываются.',
      menuS4: '<b>Цель:</b> разбить ядро щита и упасть на красную кнопку. Сетка ловушки внизу — поражение.',
      menuStart: 'ИГРАТЬ',
      menuHelp: 'Справка',
      // v4.4: экраны «МАТ-БУМ! 3»
      menuPlay: 'ИГРАТЬ',
      menuTrain: 'ОБУЧЕНИЕ',
      menuHall: 'ЗАЛ СЛАВЫ',
      menuHelp2: 'СПРАВКА',
      ver: 'v' + VERSION + ' · одиночный файл · без сети',
      selTitle: 'Выбери уровень',
      selSub: 'Любой открытый уровень — в любом порядке',
      hallTitle: 'ЗАЛ СЛАВЫ',
      hallSub: 'Лучшие результаты по уровням',
      hallLevelT: 'УРОВНИ',
      hallYandexT: 'ТАБЛИЦА ЯНДЕКСА',
      hallEmpty: 'Пока нет результатов — сыграйте первый уровень!',
      hallTotalLine: 'Всего звёзд: {s}/30 · Лучший счёт: {b}',
      hallYaNo: 'Таблица Яндекса появится на платформе Яндекс Игр',
      helpScrTitle: 'СПРАВКА',
      helpScrSub: 'Башня четырёх этажей — как её пройти',
      helpFooter: 'ГРАВИ-БУМ! v' + VERSION + ' · Яндекс Игры · RU/EN · светлая/тёмная тема',
      sideRecT: 'РЕКОРДЫ',
      sideProgT: 'ПРОГРЕСС',
      sideOpen: 'Открыто уровней: {n}/10',
      sideStars: 'Звёзды: {s}/30 · Челленджи: {c}',
      sideNoRec: 'Рекордов пока нет',
      tutTitle: 'ОБУЧЕНИЕ · ШАГ {n}/{m}',
      tut1: 'Разрежьте трос: клик по тросу, свайп поперёк или клавиша X',
      tut2: 'Наклоняйте стакан тягой ЛКМ (вверх — от себя) — шар покатится',
      tut3: 'Этаж «ЧАША»: заполните лунку шарами нужного цвета с патронташей',
      tut4: 'Этаж «ТРУБА»: толкните первый шар жёлоба — цепочка освободит красные',
      tut5: 'Этаж «РЕЗОНАНС»: ударьте в плиты с силой, близкой к их полосе',
      tut6: 'Нырните через люк и разбейте фиолетовое ядро, затем упадите на кнопку',
      tutDone: 'Обучение пройдено! Дальше — «ЗАЛ СЛАВЫ» за звёздами.',
      btnAuto: 'АВТО',
      autoOn: 'АВТО: башня сама ведёт шары к решению этого этажа',
      autoOff: 'АВТО выключен — управление снова у вас',
      autoFloorDone: 'Этаж собран АВТО! Дальше — снова ваши руки',
      autoTimeout: 'АВТО не удалось довести этаж — попробуйте сами или ещё раз',
      autoBusy: 'АВТО доступен только во время игры',
      victoryTitle: 'ПОБЕДА!',
      victoryDesc: 'Шар вдавил кнопку на кронштейнах. Стакан пройден!',
      defeatTitle: 'ПОРАЖЕНИЕ',
      defeatDesc: 'Не получилось. Попробуй ещё разок!',
      statTime: 'Время',
      statMagic: 'Взрывов магии',
      statLost: 'Шаров в ловушке',
      statCuts: 'Разрезов троса',
      statScore: 'Очки',
      statPerfect: 'Идеальных срезов',
      statReason: 'Причина',
      victoryAgain: 'Играть снова',
      victoryReplay: 'Реплей',
      victoryMenu: 'В меню',
      nextLevel: 'Следующий уровень',
      newRecord: 'НОВЫЙ РЕКОРД!',
      defeatRetry: 'Начать заново',
      defeatReplay: 'Реплей',
      defeatMenu: 'В меню',
      pauseTitle: 'ПАУЗА',
      pauseDesc: 'Стакан замер. Продолжить спуск?',
      pauseResume: 'Продолжить',
      pauseRestart: 'Заново',
      pauseMenu: 'В меню',
      helpTitle: 'Как играть: «Грави-Бум! Вертикальный стакан»',
      helpBody:
        '<b>Цель:</b> провести белый игровой шар с троса на самом верху стакана вниз, на красную кнопку на трёх кронштейнах. Всё, что внизу кнопки, — ловушка: сетка с отверстием и стеклянное дно.<br><br>' +
        '<b>Управление:</b>' +
        '<table><tr><th>Действие</th><th>ПК</th><th>Мобильные</th></tr>' +
        '<tr><td>Наклон стакана (до 25°)</td><td>ЛКМ + движение мыши: вверх — от себя, вниз — к себе</td><td>свайп одним пальцем</td></tr>' +
        '<tr><td>Разрезать трос</td><td>клик или свайп поперёк троса, клавиша X, кнопка «Резать трос»</td><td>тап или свайп по тросу</td></tr>' +
        '<tr><td>Камера (с инерцией)</td><td>ПКМ + движение</td><td>свайп двумя пальцами</td></tr>' +
        '<tr><td>Зум</td><td>колесо</td><td>пинч</td></tr>' +
        '<tr><td>Встряска стакана</td><td>Space</td><td>кнопка «Тряхнуть»</td></tr>' +
        '<tr><td>Пауза / рестарт / повтор / язык / настройки</td><td>Esc, R, T, L, S</td><td>кнопки сверху</td></tr>' +
        '<tr><td>АВТО — автосборка этажа</td><td>клавиша A, кнопка «АВТО»</td><td>кнопка «АВТО»</td></tr></table>' +
        '<b>АВТО (как в «МАТ-БУМ! 3»):</b> кнопка «АВТО» (клавиша A) включает автосборку <b>текущего этажа</b>: стакан сам наклоняется так, чтобы шары максимально оптимально катились в нужные места и решали головоломку этажа — лунки заполняются, дороги доезжают до мишеней, плиты получают свои удары, ядро разбивается, шар садится на кнопку. Все срабатывания идут честной физикой. Как только этаж решён и открыт переход вниз, АВТО отключается — дальше всё снова в ваших руках. На каждом следующем этаже АВТО можно включить заново.<br><br>' +
        '<b>Физика бильярда:</b> гравитация 9.8, упругость шар-шар 0.92, шар-площадка 0.88, шар-стенка 0.90, трение почти нулевое, предел скорости 16 м/с. Шары катятся легко и отскакивают резко.<br><br>' +
        '<b>Магия (match-3 с таймером):</b> два свободных шара одного цвета коснулись — оба <b>заряжаются</b>: вокруг каждого появляется кольцо, которое сужается и краснеет. Если в течение <b>10 секунд</b> (настраивается) их коснётся третий шар того же цвета — взрываются <b>все</b> шары одного цвета в этой цепочке (3, 4, 5…). Не успели — кольца гаснут, магия пропадает, нужно касаться снова. Примагниченные шары в магии не участвуют, пока их не тронут; белый игровой шар — никогда.<br><br>' +
        '<b>Встряска:</b> все свободные шары получают случайный импульс 0.6–1.2 м/с (не вниз), стакан трясётся 0.3 с, кулдаун 1.2 с. Игровой шар не встряхивается, если он покоится на площадке, — защита от случайного падения. Встряска может организовать нужное касание цветов.<br><br>' +
        '<b>Авто-помощь:</b> магнитный ассист (при наклоне стакана > 12° слабый шар получает толчок 0.4 м/с), анти-застревание (стоит 2 с → толчок 0.5 м/с по уклону), возврат игрового шара на трос, если он простоял 3 с без прогресса.<br><br>' +
        '<b>Башня (v4.1):</b> четыре этажа один под другим — <b>Чаша → Труба → Резонанс → Ядро</b>. Перила каждого этажа сомкнуты до самой стенки: скатиться вниз нельзя, единственный путь — центральный люк, который открывает решённая загадка этажа, и проваливается только белый шар.<br><br>' +
        '<b>Этаж 1 «Чаша»:</b> лунки-сокеты под цвета — заполните каждую нужным числом шаров. Этаж 2 «Труба»: два жёлоба-дороги со спуском — толкайте шары к мишеням; точка над шаром — мишень (зачёт), крест — мина (дорога пересоберётся), белые нейтралы проваливаются. Этаж 3 «Резонанс»: три плиты-стенки — ударьте каждую сбоку с её скоростью; чужие шары гасят активные плиты. Этаж 4 «Ядро»: разбейте ядро щита и вдавите кнопку.<br><br>' +
        '<b>Финал этажа «Ядро»:</b> над кнопкой висит фиолетовое <b>ядро щита</b> (y = 0.5) с телами-загадками на орбите. Шар, попавший в ядро, разбивает его и падает на кнопку; шар, пролетевший мимо, отбивается телами в сторону и падает на сетку — поражение. Кнопка (y = −2.5, r = 1.6) на трёх диагональных кронштейнах к стенам.<br><br>' +
        '<b>Ловушка:</b> сетка (y = −4.5) с уклоном 3° к центру и отверстием r = 1.6. Свободные шары скатываются в отверстие и падают на стеклянное дно (y = −6.5), где лежат как трофеи и через 30 с растворяются. На сетке магия продолжает работать — ловушку можно «подчистить» встряской. Игровой шар на сетке = поражение через 2 с.<br><br>' +
        '<b>Поток и очки:</b> ловушка не заканчивает игру — шар откатывается (re-wind), и можно сразу пробовать снова; модалка поражения появляется только после трёх ошибок подряд, уровень тогда начинается с первого этажа. За идеальный срез троса (+150), решённый этаж, разбитое ядро (+500), взрыв магии (+400 и больше за каждый лишний шар) и финиш (+1000, ×2 если быстрее 45 с) начисляются очки; события одно за другим наращивают комбо ×2…×4.<br><br>' +
        '<b>Уровни и модификаторы (v4.1):</b> 10 уровней — 1–5 обычные, 6–10 продвинутые (открываются прохождением предыдущего). С 4-го появляется эхо-каскад взрывов; на 5-м откат −50 очков; на 6–8 откат сбрасывает этаж и отключает подсказки; с 8-го идеальный срез троса обязателен (кривой рез — шар медленнее); с 6-го на «Резонансе» появляются чужие шары-помехи (гасят активные плиты), «Труба» удлиняется, полосы плит сужаются; на 10-м — 4 тела на орбите, шар быстрее, палитра темнее, дороги варьируются, откат −200 очков и −1 попытка. Звёзды (1–3: победа / быстрее 60 с / без ошибок), рекорды и 15 челленджей сохраняются; после 10-го уровня открывается <b>Песочница</b> — любой уровень с любыми настройками.<br><br>' +
        '<b>Читаемость:</b> площадки непрозрачные сверху и прозрачные снизу; если площадка закрывает вид на игровой шар, кнопку или ядро — она плавно становится почти невидимой (камера при этом не опускается ниже 85° от вертикали).',
      helpClose: 'Понятно',
      replayBadge: 'ПОВТОР СПУСКА',
      settingsTitle: '⚙ НАСТРОЙКИ БАЛАНСА',
      setSpeed: '1) Скорость шара',
      setSpeedNote: 'Множитель скорости игрового шара: стартовый толчок после разреза троса и предел скорости.',
      setImpact: '2) Сила ударов',
      setImpactNote: 'Импульсы столкновений, взрывов магии и встряски: насколько резко разлетаются шары.',
      setSize: '3) Размер шаров',
      setSizeNote: 'Множитель радиусов всех шаров. Больше — легче касаться и собирать тройки.',
      setMagic: '4) Время магии',
      setMagicNote: 'Сколько секунд заряженные шары ждут третий, прежде чем магия погаснет.',
      setReset: 'Сбросить',
      setApply: 'Применить + заново',
      setHint: 'По умолчанию все параметры = 1.00× (время магии 10 с). Всё применяется мгновенно, «Применить + заново» restarting уровень.',
      toastCut: 'Трос разрезан!',
      toastCharge: 'Заряжено: ищите третий {c} шар ({t} с)',
      toastBoom: 'МАГИЯ! Взрыв: {n} шаров',
      toastExpired: 'Магия погасла — коснитесь снова',
      toastShake: 'Встряска!',
      toastCore: 'Ядро щита разбито! Путь к кнопке открыт',
      toastTrap: 'Игровой шар в ловушке…',
      toastReturned: 'Шар возвращён на трос',
      toastSize: 'Размер шаров применён — уровень пересобран',
      // v4.0: этажи
      floorNames: ['ЧАША', 'ТРУБА', 'РЕЗОНАНС', 'ЯДРО'],
      floorOf: 'ЭТАЖ {n}/4 · {name}',
      floorSolved: 'Загадка решена — люк открыт!',
      floorScore: 'Этаж пройден',
      floor0Hint: 'Заполните лунки: катите шары нужного цвета в гнёзда с цифрами. Сбивайте патронта́жи у лунок.',
      floor1Hint: 'Труба: толкните первый шар в жёлоб — он покатится по уклону к мишени. Точка над шаром — мишень (зачёт), крест — мина (дорога пересоберётся). Поразьте мишени обеих дорог.',
      floor2Hint: 'Резонанс: ударьте каждую плиту сбоку с нужной скоростью — зелёная слабо, жёлтая средне, красная сильно. Чужие шары гасят активные плиты!',
      floor3Hint: 'Финал: ныряйте из люка с разгоном в сторону ядра — по центру оно не совпадёт с падением!',
      taskSockets: 'ЛУНКИ {a}/{b}',
      taskChain: 'ЗМЕЙКА {a}/{b}',
      taskPlates: 'РЕЗОНАНС: ПЛИТЫ {a}/{b}',
      taskButton: 'ЦЕЛЬ: КНОПКА',
      taskChainPending: 'ЗМЕЙКА: СБЕЙТЕ ЦЕПОЧКУ',
      taskChainDone: 'ЗМЕЙКА ГОТОВА',
      socketFull: 'Лунка заполнена',
      socketWrong: 'Не тот цвет!',
      socketOverflow: 'Перебор — в лунке уже есть шар',
      socketPlayer: 'Игровой шар не входит в лунку',
      socketIn: '{n}/{b} — есть!',
      chainMine: 'Мина сбита! Цепочка на 2 с в исходное',
      floorReset: 'Этаж сброшен — загадка заново',
      // v4.2: Труба / Резонанс
      pipeMine: 'МИНА! Дорога пересобирается, счёт — ноль',
      pipeRoadDone: 'Дорога {r}: МИШЕНЬ ПОРАЖЕНА!',
      taskPipe: 'ТРУБА: МИШЕНИ {a}/{b}',
      plateOn: { weak: 'ЗЕЛЁНАЯ плита — АКТИВНА (полоса {v})', mid: 'ЖЁЛТАЯ плита — АКТИВНА (полоса {v})', strong: 'КРАСНАЯ плита — АКТИВНА (полоса {v})' },
      plateTooWeak: 'СЛАБО — нужна полоса {v}',
      plateTooStrong: 'СИЛЬНО — нужна полоса {v}',
      plateOff: 'Плита ПОГАШЕНА чужим шаром!',
      floorRestarted: 'Этаж начат заново',
      ffTitle: 'ЭТАЖ НЕ ПРОЙТИ',
      ffNoBalls: 'Недостаточно шаров для завершения уровня. Начать заново или перейти в меню?',
      ffPlate: 'Чужой шар погасил плиту — этаж придётся начинать заново',
      ffRestart: 'Начать заново',
      ffMenu: 'В меню',
      btnPipeReset: 'СБРОС ДОРОГ',
      btnFloorRestart: 'ЭТАЖ ЗАНОВО',
      btnFloorsShow: 'ЭТАЖИ: ПОКАЗАТЬ',
      btnFloorsHide: 'ЭТАЖИ: СКРЫТЬ',
      totalBest: 'Рекорд: {n}',
      challengeLine: 'Челленджи: {n}/15',
      levelLocked: 'Сначала пройдите предыдущий уровень',
      advancedLevel: 'Продвинутый уровень',
      challengeDoneShort: 'Челлендж выполнен',
      challengeDone: 'ЧЕЛЛЕНДЖ ВЫПОЛНЕН: {n}',
      sandbox: 'Песочница',
      sandboxOn: 'ПЕСОЧНИЦА: все уровни открыты, результаты не записываются',
      sandboxOff: 'Обычный режим: уровни и рекорды как обычно',
      chainStall: 'Цепочка остановилась — на 2 с в исходное',
      chainSolved: 'Красные освобождены!',
      chainHit: 'ЗМЕЙКА: {a}/{b}',
      plateTooWeak: 'Слабо! Нужна скорость {v}',
      plateTooStrong: 'Сильно! Нужна скорость {v}',
      plateDone: 'Плита принята ({v} м/с)',
      plateStatus: 'ПЛИТЫ {a}/{b}',
      cascade: 'КАСКАД +{n}',
      setEchoR: 'Радиус каскада',
      setEchoRNote: 'Эхо-взрыв подхватывает одноцветные шары в радиусе {v} м от взрыва (уровни 2+)',
      setEchoW: 'Задержка каскада',
      setEchoWNote: 'Пауза перед эхо-взрывом: {v} с',
      toastRelease: 'Три тела освобождены',
      colorRed: 'красный',
      colorBlue: 'синий',
      colorYellow: 'жёлтый',
      reasonTrap: 'сетка ловушки',
      reasonMiss: 'мимо кнопки'
    },

    en: {
      title: 'GRAVI-BOOM! v' + VERSION,
      subtitle: 'Tower of Four Floors · v' + VERSION,
      timeLabel: 'TIME',
      magicLabel: 'MAGIC',
      trapLabel: 'TRAP',
      scoreLabel: 'SCORE',
      comboLabel: 'COMBO',
      btnShake: 'Shake',
      btnShake2: 'SHAKE',
      btnCut: 'CUT ROPE',
      btnReplay: 'Replay',
      btnRestart: 'Restart',
      btnLang: 'EN',
      tiltL: '← tilt',
      tiltR: 'tilt →',
      legendRed: 'Red balls: the cluster blocking platform A exit — blow them to open the way',
      legendBlue: 'Blue balls: decoys on the funnel edge (they do not open the way)',
      legendYellow: 'Yellow balls: the plug in the funnel centre — blow it to fall through',
      legendCore: 'Shield core (y = 0.5): break it with the ball, otherwise the three bodies deflect it into the trap',
      legendBtn: 'The red button on brackets (y = −2.5) is the goal',
      legendStats: 'Balls: {free} free / {mounted} magnetised / {charged} charged',
      hint: '<b>LMB drag</b> — tilt the glass (up = away from you, down = toward you) · <b>click or swipe the rope</b> — cut it (<span class="kbd">X</span>) · <b>RMB</b> — camera with inertia · <b>wheel</b> — zoom · <span class="kbd">Space</span> — shake · <span class="kbd">R</span> — restart · <span class="kbd">T</span> — replay · <span class="kbd">S</span> — settings',
      statusRope: 'The rope is intact: click it or swipe across (or press X)',
      statusFallA: 'Floor "Bowl": fill the sockets with balls of the matching colour — clips are nearby',
      statusFallB: 'Floor "Pipe": push the first trough ball so the chain frees the reds',
      statusSocket: 'SOCKETS {a}/{b}: roll matching balls into the numbered cups',
      statusCore: 'The ball is below the funnel: hit the purple shield core, otherwise the three bodies will deflect it',
      statusButton: 'The ball is above the button: keep it exactly centred',
      statusTrap: 'The ball is in the trap! Defeat in {n} s',
      statusWin: 'VICTORY: the button is pressed',
      statusCharged: 'Magic charged: {n} ball(s), {t} s left — find a third of the same colour',
      menuTitle: 'GRAVI-BOOM!',
      menuSubtitle: 'TOWER OF FOUR FLOORS · v' + VERSION + ' · 10 LEVELS',
      menuS1: '<b>Cut the rope</b>: click it, swipe across it or press <b>X</b> — the white ball will fall.',
      menuS2: '<b>Tilt the glass</b> (LMB + move: up = away from you, down = toward you) and <b>shake</b> it (Space) to roll the ball.',
      menuS3: '<b>Magic:</b> two same-colour balls touching charge for 10 s; a third one of that colour makes them all explode.',
      menuS4: '<b>Goal:</b> break the shield core and land on the red button. The trap net below means defeat.',
      menuStart: 'PLAY',
      menuHelp: 'Help',
      // v4.4: «МАТ-БУМ! 3» screens
      menuPlay: 'PLAY',
      menuTrain: 'TRAINING',
      menuHall: 'HALL OF FAME',
      menuHelp2: 'HELP',
      ver: 'v' + VERSION + ' · single file · no network',
      selTitle: 'Choose a level',
      selSub: 'Any unlocked level — in any order',
      hallTitle: 'HALL OF FAME',
      hallSub: 'Best results per level',
      hallLevelT: 'LEVELS',
      hallYandexT: 'YANDEX LEADERBOARD',
      hallEmpty: 'No records yet — play the first level!',
      hallTotalLine: 'Total stars: {s}/30 · Best score: {b}',
      hallYaNo: 'The Yandex table appears on the Yandex Games platform',
      helpScrTitle: 'HELP',
      helpScrSub: 'Tower of four floors — how to beat it',
      helpFooter: 'GRAVI-BOOM! v' + VERSION + ' · Yandex Games · RU/EN · light/dark theme',
      sideRecT: 'RECORDS',
      sideProgT: 'PROGRESS',
      sideOpen: 'Levels unlocked: {n}/10',
      sideStars: 'Stars: {s}/30 · Challenges: {c}',
      sideNoRec: 'No records yet',
      tutTitle: 'TRAINING · STEP {n}/{m}',
      tut1: 'Cut the rope: click it, swipe across it, or press X',
      tut2: 'Tilt the glass with LMB drag (up = away) — the ball will roll',
      tut3: 'BOWL floor: fill the socket with balls of the matching color from the racks',
      tut4: 'PIPE floor: push the first tray ball — the chain frees the red ones',
      tut5: 'RESONANCE floor: strike each plate with speed close to its band',
      tut6: 'Dive through the hatch, break the violet core, then land on the button',
      tutDone: 'Training complete! Chase stars for the HALL OF FAME next.',
      btnAuto: 'AUTO',
      autoOn: 'AUTO: the tower herds the balls to solve this floor',
      autoOff: 'AUTO off — you have the controls again',
      autoFloorDone: 'Floor solved by AUTO! It is your hands again now',
      autoTimeout: 'AUTO could not finish the floor — try yourself or again',
      autoBusy: 'AUTO is available only during play',
      victoryTitle: 'VICTORY!',
      victoryDesc: 'The ball pressed the button on the brackets. The glass is complete!',
      defeatTitle: 'DEFEAT',
      defeatDesc: 'It didn\u2019t work out. Give it another try!',
      statTime: 'Time',
      statMagic: 'Magic blasts',
      statLost: 'Balls in trap',
      statCuts: 'Rope cuts',
      statScore: 'Score',
      statPerfect: 'Perfect cuts',
      statReason: 'Reason',
      victoryAgain: 'Play again',
      victoryReplay: 'Replay',
      victoryMenu: 'Menu',
      nextLevel: 'Next level',
      newRecord: 'NEW RECORD!',
      defeatRetry: 'Start over',
      defeatReplay: 'Replay',
      defeatMenu: 'Menu',
      pauseTitle: 'PAUSED',
      pauseDesc: 'The glass is frozen. Continue the descent?',
      pauseResume: 'Resume',
      pauseRestart: 'Restart',
      pauseMenu: 'Menu',
      helpTitle: 'How to play: Gravi-Boom! Vertical Glass',
      helpBody:
        '<b>Goal:</b> guide the white player ball from the rope at the top of the glass down onto the red button held by three brackets. Everything below the button is a trap: a net with a hole and a glass floor.<br><br>' +
        '<b>Controls:</b>' +
        '<table><tr><th>Action</th><th>Desktop</th><th>Mobile</th></tr>' +
        '<tr><td>Tilt the glass (up to 25°)</td><td>LMB + move: up = away, down = toward you</td><td>one-finger swipe</td></tr>' +
        '<tr><td>Cut the rope</td><td>click or swipe across the rope, key X, “Cut rope” button</td><td>tap or swipe the rope</td></tr>' +
        '<tr><td>Camera</td><td>RMB + move</td><td>two-finger swipe</td></tr>' +
        '<tr><td>Zoom</td><td>wheel</td><td>pinch</td></tr>' +
        '<tr><td>Shake the glass</td><td>Space</td><td>“Shake” button</td></tr>' +
        '<tr><td>Pause / restart / replay / language / settings</td><td>Esc, R, T, L, S</td><td>top buttons</td></tr>' +
        '<tr><td>AUTO — auto-solve the floor</td><td>key A, “AUTO” button</td><td>“AUTO” button</td></tr></table>' +
        '<b>AUTO (as in “MATH-BOOM! 3”):</b> the “AUTO” button (key A) starts auto-solving the <b>current floor</b>: the tower tilts by itself so the balls roll into the right places in the most optimal way and the floor puzzle gets solved — sockets filled, roads reach their targets, plates take their strikes, the core breaks, the ball lands on the button. Everything happens by honest physics. Once the floor is solved and the way down opens, AUTO switches off — the controls are yours again. On every next floor AUTO can be enabled anew.<br><br>' +
        '<b>Billiard physics:</b> gravity 9.8, restitution ball-ball 0.92, ball-platform 0.88, ball-wall 0.90, almost no friction, speed limit 16 m/s. Balls roll easily and bounce sharply.<br><br>' +
        '<b>Magic (match-3 with a timer):</b> when two free balls of the same colour touch, both become <b>charged</b>: a ring appears around each and shrinks while turning red. If a third ball of that colour touches them within <b>10 seconds</b> (adjustable), <b>all</b> same-colour balls in that chain explode (3, 4, 5…). Miss the window and the rings fade — touch them again. Magnetised balls do not take part until something touches them; the white player ball never does.<br><br>' +
        '<b>Shake:</b> all free balls get a random impulse of 0.6–1.2 m/s (never downward), the glass shakes for 0.3 s, cooldown 1.2 s. The player ball is not shaken while it rests on a platform — protection from an accidental fall. A shake can create the colour contact you need.<br><br>' +
        '<b>Auto-assist:</b> magnetic assist (with the glass tilted over 12° a slow ball gets a 0.4 m/s nudge), anti-stuck (still for 2 s → a 0.5 m/s push along the slope), and the player ball returns to the rope if it stands still for 3 s without progress.<br><br>' +
        '<b>The tower (v4.1):</b> four floors stacked one below another — <b>Bowl → Pipe → Resonance → Core</b>. Each floor\'s railing runs all the way to the wall: you cannot roll down — the only way is the central hatch opened by solving that floor\'s puzzle, and only the white ball falls through.<br><br>' +
        '<b>Floor 1 "Bowl":</b> colour sockets — fill each with the right number of balls. Floor 2 "Pipe": two trough roads with a downhill — push balls to the targets; a dot above a ball marks a target (counts), a cross marks a mine (the road rebuilds), white neutrals fall through. Floor 3 "Resonance": wall plates — strike each from the side at its speed; foreign balls douse active plates. Floor 4 "Core": break the shield core and press the button.<br><br>' +
        '<b>The "Core" finale:</b> above the button hangs the purple <b>shield core</b> (y = 0.5) with puzzle bodies in orbit. A ball that hits the core breaks it and falls onto the button; a ball that misses is deflected by the bodies and lands on the net — defeat. The button (y = −2.5, r = 1.6) sits on three diagonal brackets attached to the walls.<br><br>' +
        '<b>Trap:</b> the net (y = −4.5) slopes 3° toward the centre with a hole of r = 1.6. Free balls roll into the hole and fall onto the glass floor (y = −6.5), where they lie as trophies and dissolve after 30 s. Magic still works on the net — you can clean the trap with a shake. The player ball on the net means defeat in 2 s.<br><br>' +
        '<b>Flow and score:</b> the trap does not end the run — the ball rewinds and you can try again immediately; the defeat modal only appears after three misses in a row, and the level then restarts from floor 1. You earn points for a perfect rope cut (+150), a solved floor, breaking the core (+500), magic blasts (+400 and more for each extra ball) and the finish (+1000, ×2 if under 45 s); back-to-back events build a ×2…×4 combo.<br><br>' +
        '<b>Levels and modifiers (v4.1):</b> 10 levels — 1–5 normal, 6–10 advanced (unlocked by beating the previous one). Echo blast cascades from level 4; level 5 rewind costs −50 points; on 6–8 a rewind resets the floor and hints are off; from level 8 a perfect rope cut is required (a crooked cut slows the ball); from level 6 Resonance gets foreign hazard balls (they douse active plates), the Pipe grows longer and the plate bands narrower; on level 10 — 4 orbiting bodies, a faster ball, a darker palette, varied roads, and a rewind costs −200 points and −1 attempt. Stars (1–3: win / under 60 s / no mistakes), records and 15 challenges persist; after level 10 the <b>Sandbox</b> opens — any level with any settings.<br><br>' +
        '<b>Readability:</b> platforms are opaque from above and transparent from below; if a platform hides the view of the player ball, the button or the core, it smoothly fades to almost invisible (and the camera never goes below 85° from the vertical).',
      helpClose: 'Got it',
      replayBadge: 'DESCENT REPLAY',
      settingsTitle: '⚙ BALANCE SETTINGS',
      setSpeed: '1) Ball speed',
      setSpeedNote: 'Player ball speed multiplier: the initial push after cutting the rope and the speed limit.',
      setImpact: '2) Impact force',
      setImpactNote: 'Impulses of collisions, magic explosions and shakes: how sharply balls fly apart.',
      setSize: '3) Ball size',
      setSizeNote: 'Radius multiplier for all balls. Bigger balls are easier to touch and match.',
      setMagic: '4) Magic time',
      setMagicNote: 'How many seconds the charged balls wait for a third one before the magic fades.',
      setReset: 'Reset',
      setApply: 'Apply + restart',
      setHint: 'All parameters default to 1.00× (magic time 10 s). Everything applies instantly; “Apply + restart” rebuilds the level.',
      toastCut: 'Rope cut!',
      toastCharge: 'Charged: find a third {c} ball ({t} s)',
      toastBoom: 'MAGIC! Blast: {n} balls',
      toastExpired: 'The magic faded — touch again',
      toastShake: 'Shake!',
      toastCore: 'Shield core broken! The way to the button is open',
      toastTrap: 'The player ball is in the trap…',
      toastReturned: 'The ball returned to the rope',
      toastSize: 'Ball size applied — level rebuilt',
      // v4.0: floors
      floorNames: ['BOWL', 'PIPE', 'RESONANCE', 'CORE'],
      floorOf: 'FLOOR {n}/4 · {name}',
      floorSolved: 'Puzzle solved — hatch open!',
      floorScore: 'Floor cleared',
      floor0Hint: 'Fill the sockets: roll balls of the matching colour into the numbered cups. Knock the clips beside each socket.',
      floor1Hint: 'Pipe: push the first ball into the trough — it rolls downhill to the target. A dot above a ball marks a target (counts), a cross marks a mine (the road rebuilds). Hit the targets of both roads.',
      floor2Hint: 'Resonance: strike each plate from the side at the right speed — green weak, yellow medium, red strong. Foreign balls douse active plates!',
      floor3Hint: 'Finale: dive out of the hatch with speed toward the core — a dead-centre fall will miss it!',
      taskSockets: 'SOCKETS {a}/{b}',
      taskChain: 'SNAKE {a}/{b}',
      taskPlates: 'RESONANCE: PLATES {a}/{b}',
      taskButton: 'GOAL: BUTTON',
      taskChainPending: 'SNAKE: TOPPLE THE CHAIN',
      taskChainDone: 'SNAKE DONE',
      socketFull: 'Socket full',
      socketWrong: 'Wrong colour!',
      socketOverflow: 'Overflow — the socket already has its ball',
      socketPlayer: 'The player ball does not fit',
      socketIn: '{n}/{b} — in!',
      chainMine: 'Mine hit! Chain resets for 2 s',
      floorReset: 'Floor reset — the puzzle anew',
      // v4.2: Pipe / Resonance
      pipeMine: 'MINE! The road rebuilds, the counter is zero',
      pipeRoadDone: 'Road {r}: TARGET HIT!',
      taskPipe: 'PIPE: TARGETS {a}/{b}',
      plateOn: { weak: 'GREEN plate — ACTIVE (band {v})', mid: 'YELLOW plate — ACTIVE (band {v})', strong: 'RED plate — ACTIVE (band {v})' },
      plateTooWeak: 'TOO WEAK — band {v} needed',
      plateTooStrong: 'TOO STRONG — band {v} needed',
      plateOff: 'Plate DOUSED by a foreign ball!',
      floorRestarted: 'Floor restarted',
      ffTitle: 'FLOOR UNPASSABLE',
      ffNoBalls: 'Not enough balls to finish the level. Start over or go to the menu?',
      ffPlate: 'A foreign ball doused a plate — the floor must be restarted',
      ffRestart: 'Start over',
      ffMenu: 'To menu',
      btnPipeReset: 'RESET ROADS',
      btnFloorRestart: 'RESTART FLOOR',
      btnFloorsShow: 'SHOW FLOORS',
      btnFloorsHide: 'HIDE FLOORS',
      totalBest: 'Best: {n}',
      challengeLine: 'Challenges: {n}/15',
      levelLocked: 'Complete the previous level first',
      advancedLevel: 'Advanced level',
      challengeDoneShort: 'Challenge done',
      challengeDone: 'CHALLENGE COMPLETE: {n}',
      sandbox: 'Sandbox',
      sandboxOn: 'SANDBOX: all levels open, results are not saved',
      sandboxOff: 'Normal mode: levels and records as usual',
      chainStall: 'The chain stalled — resetting for 2 s',
      chainSolved: 'Reds freed!',
      chainHit: 'SNAKE: {a}/{b}',
      plateTooWeak: 'Too weak! Speed {v} needed',
      plateTooStrong: 'Too strong! Speed {v} needed',
      plateDone: 'Plate accepted ({v} m/s)',
      plateStatus: 'PLATES {a}/{b}',
      cascade: 'CASCADE +{n}',
      setEchoR: 'Cascade radius',
      setEchoRNote: 'The echo blast sweeps same-colour balls within {v} m of the explosion (levels 2+)',
      setEchoW: 'Cascade delay',
      setEchoWNote: 'Pause before the echo blast: {v} s',
      toastRelease: 'The three bodies are free',
      colorRed: 'red',
      colorBlue: 'blue',
      colorYellow: 'yellow',
      reasonTrap: 'trap net',
      reasonMiss: 'missed the button'
    }
  };

  let curLang = 'ru';
  const D = () => I18N[curLang];

  // ===========================================================================
  // 4. ЗВУК (полностью синтезированный, без файлов)
  // ===========================================================================
  const Sound = {
    ctx: null,
    master: null,
    enabled: true,
    lastHit: 0,

    init() {
      if (this.ctx) return;
      try {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = 0.5;
        this.master.connect(this.ctx.destination);
      } catch (e) { this.ctx = null; }
    },

    setEnabled(on) {
      this.enabled = !!on;
      if (this.master) this.master.gain.value = on ? 0.5 : 0.0;
    },

    _now() { return this.ctx ? this.ctx.currentTime : 0; },

    _tone(freq, dur, type, vol, delay) {
      if (!this.ctx || !this.enabled) return;
      const t0 = this._now() + (delay || 0);
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq, t0);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(this.master);
      o.start(t0); o.stop(t0 + dur + 0.03);
    },

    _noise(dur, vol, filterFreq) {
      if (!this.ctx || !this.enabled) return;
      const n = Math.floor(this.ctx.sampleRate * dur);
      const buf = this.ctx.createBuffer(1, n, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < n; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / n);
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const f = this.ctx.createBiquadFilter();
      f.type = 'bandpass';
      f.frequency.value = filterFreq || 900;
      const g = this.ctx.createGain();
      g.gain.value = vol;
      src.connect(f); f.connect(g); g.connect(this.master);
      src.start();
    },

    // Бильярдный клик
    hit(strength) {
      const now = performance.now();
      if (now - this.lastHit < 45) return;         // не чаще ~22 в секунду
      this.lastHit = now;
      const s = Math.max(0.05, Math.min(1, strength || 0.3));
      this._tone(520 + s * 900, 0.05 + s * 0.04, 'triangle', 0.05 + s * 0.16);
      this._noise(0.03, 0.03 + s * 0.06, 2200 + s * 2600);
    },

    roll(strength) {
      const s = Math.max(0, Math.min(1, strength || 0));
      if (s < 0.05) return;
      const now = performance.now();
      if (now - (this._lastRoll || 0) < 110) return;
      this._lastRoll = now;
      this._noise(0.09, 0.012 + s * 0.03, 420 + s * 500);
    },

    cut() {
      this._noise(0.22, 0.16, 3200);
      this._tone(1400, 0.12, 'sawtooth', 0.06);
      this._tone(700, 0.18, 'sine', 0.05, 0.05);
    },

    // Магия: заряд (короткий звон) и восходящее арпеджио C-E-G (+ нота за каждый сверх 3)
    charge() {
      this._tone(880, 0.14, 'sine', 0.07);
      this._tone(1320, 0.12, 'sine', 0.045, 0.04);
    },

    fade() {
      this._tone(420, 0.2, 'sine', 0.05);
      this._tone(300, 0.24, 'sine', 0.04, 0.06);
    },

    boom(extra, echo) {
      const up = echo ? 2 : 1, gv = echo ? 0.55 : 1;   // v4.0: эхо — октавой выше, приглушённо
      const base = [261.63, 329.63, 392.0];        // C E G
      const extraNotes = [523.25, 659.25, 783.99, 1046.5];
      const n = Math.max(0, Math.min(4, extra || 0));
      for (let i = 0; i < base.length; i++) this._tone(base[i] * up, 0.34, 'triangle', 0.16 * gv, i * 0.055);
      for (let i = 0; i < n; i++) this._tone(extraNotes[i] * up, 0.36, 'triangle', 0.14 * gv, (base.length + i) * 0.055);
      this._noise(0.3, 0.1 * gv, echo ? 1400 : 700);
      this._tone(90 * up, 0.4, 'sine', 0.16 * gv);
    },

    // v4.0: звуки этажей
    floorDone() {
      [392.0, 493.88, 587.33, 783.99].forEach((f, i) => this._tone(f, 0.3, 'triangle', 0.14, i * 0.07));
      this._noise(0.25, 0.08, 900);
    },
    socketIn() { this._tone(740, 0.16, 'sine', 0.14); this._tone(1108.7, 0.2, 'sine', 0.1, 0.06); },
    reject() { this._tone(196, 0.18, 'square', 0.07); this._tone(174.6, 0.2, 'square', 0.06, 0.09); },
    plateOk() { this._tone(880, 0.22, 'sine', 0.15); this._tone(1318.5, 0.3, 'sine', 0.11, 0.08); },
    plateBad() { this._tone(233, 0.16, 'triangle', 0.1); this._noise(0.14, 0.06, 500); },
    chainFail() { this._tone(147, 0.4, 'sawtooth', 0.1); this._tone(110, 0.5, 'sine', 0.12, 0.12); },

    shake() {
      this._noise(0.3, 0.12, 260);
      this._tone(120, 0.18, 'square', 0.05);
      for (let i = 0; i < 4; i++) this._tone(300 + Math.random() * 500, 0.05, 'triangle', 0.05, 0.04 * i);
    },

    fall() {
      this._tone(600, 0.25, 'sine', 0.06);
      this._tone(300, 0.3, 'sine', 0.05, 0.08);
      this._noise(0.2, 0.05, 500);
    },

    trap() {
      this._tone(220, 0.5, 'sawtooth', 0.09);
      this._tone(150, 0.7, 'sine', 0.11, 0.1);
      this._noise(0.5, 0.08, 300);
    },

    core() {
      this._tone(180, 0.5, 'square', 0.1);
      this._tone(900, 0.35, 'sine', 0.09, 0.04);
      this._noise(0.45, 0.14, 1400);
    },

    victory(finale) {
      const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
      // v3.5: финальный уровень — арпеджио-крещендо, три ноты сверху
      if (finale) notes.push(1567.98, 2093.0, 2637.0);
      notes.forEach((f, i) => this._tone(f, 0.5, 'triangle', 0.16, i * 0.11));
      this._tone(130.8, 1.1, 'sine', 0.12, 0.1);
    },

    defeat() {
      const notes = [392.0, 349.23, 293.66, 220.0];
      notes.forEach((f, i) => this._tone(f, 0.45, 'sine', 0.14, i * 0.16));
    },

    ui() { this._tone(660, 0.05, 'sine', 0.05); }
  };

  // ===========================================================================
  // 5. УТИЛИТЫ
  // ===========================================================================
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function fmtTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
    return m + ':' + (s < 10 ? '0' : '') + s;
  }
  function angNorm(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  function angIn(az, from, to) {
    if (from === undefined) return true;
    if (from <= to) return az >= from && az <= to;
    return az >= from || az <= to;   // диапазон через 0
  }

  // ===========================================================================
  // 6. КОЛЛАЙДЕРЫ (поверхности вращения, цилиндры, сферы, капсулы)
  //    Вся физика ведётся в ЛОКАЛЬНОЙ системе стакана: наклон реализуется
  //    поворотом вектора гравитации, поэтому коллайдеры статичны.
  // ===========================================================================

  /**
   * Поверхность вращения: профиль — полилиния в меридианной плоскости (r, y),
   * обход ПРОТИВ часовой стрелки → внешняя нормаль = (dy, -dr)/len.
   * Для шара расстояние в 3D равно расстоянию в меридианной плоскости.
   */
  function makeRevolve(name, pts, opts) {
    opts = opts || {};
    const segs = [], verts = [];
    let yMin = Infinity, yMax = -Infinity, rMin = Infinity, rMax = -Infinity;
    for (let i = 0; i < pts.length; i++) {
      const r = pts[i][0], y = pts[i][1];
      yMin = Math.min(yMin, y); yMax = Math.max(yMax, y);
      rMin = Math.min(rMin, r); rMax = Math.max(rMax, r);
      // ВАЖНО: вершины у оси тоже нужны — иначе шар, летящий точно по оси,
      // проваливается в «дырку» между концом сегмента (t>1) и осью (кнопка, дно).
      verts.push({ r: r, y: y });
      if (i === pts.length - 1) continue;
      const r2 = pts[i + 1][0], y2 = pts[i + 1][1];
      const dr = r2 - r, dy = y2 - y;
      const len = Math.hypot(dr, dy);
      if (len < 1e-6) continue;
      if (r < 0.05 && r2 < 0.05) continue;          // осевой сегмент — нормаль вырождена
      segs.push({ r1: r, y1: y, dr: dr, dy: dy, l2: len * len, nr: dy / len, ny: -dr / len });
    }
    return {
      type: 'revolve', name: name, segs: segs, verts: verts,
      yMin: yMin, yMax: yMax, rMin: rMin, rMax: rMax,
      angFrom: opts.angFrom, angTo: opts.angTo,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      roll: opts.roll || 0,             // дополнительное гашение качения (чаша, воронка)
      group: opts.group || null,        // метка для «важных» объектов (затухание)
      onHit: opts.onHit || null
    };
  }

  /** Кольцо (тор) в меридианной плоскости: центр (cr, cy), радиус трубки tube. */
  function makeTorusR(name, cr, cy, tube, opts) {
    opts = opts || {};
    return {
      type: 'torusR', name: name, cr: cr, cy: cy, tube: tube,
      yMin: cy - tube, yMax: cy + tube, rMin: cr - tube, rMax: cr + tube,
      angFrom: opts.angFrom, angTo: opts.angTo,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      group: opts.group || null, onHit: opts.onHit || null
    };
  }

  /** Цилиндрическая стенка (шар удерживается ВНУТРИ r < wallR). */
  function makeCyl(name, wallR, yMin, yMax, opts) {
    opts = opts || {};
    return {
      type: 'cyl', name: name, wallR: wallR, yMin: yMin, yMax: yMax,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionWall : opts.e,
      angFrom: opts.angFrom, angTo: opts.angTo, group: opts.group || null, onHit: opts.onHit || null
    };
  }

  /** Сфера (ядро щита, тела-загадки). */
  function makeSphereCol(name, x, y, z, r, opts) {
    opts = opts || {};
    return {
      type: 'sphere', name: name, c: new THREE.Vector3(x, y, z), r: r,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      group: opts.group || null, onHit: opts.onHit || null, live: true
    };
  }

  /** Капсула (кронштейны кнопки, стойка троса). */
  function makeCapsule(name, a, b, r, opts) {
    opts = opts || {};
    return {
      type: 'capsule', name: name,
      a: new THREE.Vector3(a.x, a.y, a.z), b: new THREE.Vector3(b.x, b.y, b.z),
      ab: new THREE.Vector3(b.x - a.x, b.y - a.y, b.z - a.z), r: r,
      e: opts.e === undefined ? LEVEL_CONFIG.physics.restitutionSurface : opts.e,
      group: opts.group || null, onHit: opts.onHit || null
    };
  }

  const _n = new THREE.Vector3();

  /**
   * Разрешение контакта: выталкивание + упругое отражение + трение.
   * pen — глубина проникновения вдоль нормали n.
   */
  // Трение: при настоящем ударе — кулоновское (μ·(1+e)·|v_n|), при спокойном
  // контакте/качении — очень малое сопротивление качению. Иначе шары «залипают»
  // и не катятся даже под уклон 3° (бильярдного наката не получается).
  const ROLL_RESISTANCE = 0.18;   // 1/с
  const SLIDE_THRESHOLD = 0.4;    // м/с: граница «удар / качение»

  // v4.2: осевой бокс-коллайдер (плиты-стенки этажа «Резонанс»)
  function makeBox(name, cx, cy, cz, hx, hy, hz, opts) {
    const o = opts || {};
    return {
      type: 'box', name: name, group: o.group || '',
      c: { x: cx, y: cy, z: cz }, h: { x: hx, y: hy, z: hz },
      e: o.e !== undefined ? o.e : 0.5, fr: o.friction !== undefined ? o.friction : 0.05,
      live: true, floor: undefined, onHit: o.onHit || null
    };
  }

  function resolveContact(ball, nx, ny, nz, pen, e, friction, dt, surfVx, surfVy, surfVz, col) {
    if (pen <= 0) return false;
    ball.p.x += nx * pen; ball.p.y += ny * pen; ball.p.z += nz * pen;
    let vx = ball.v.x - (surfVx || 0), vy = ball.v.y - (surfVy || 0), vz = ball.v.z - (surfVz || 0);
    const vnIn = vx * nx + vy * ny + vz * nz;
    // бильярдная упругость сохраняется для настоящих ударов; на микро-скоростях
    // она гасится, иначе шар вечно прыгает в чаше и не катится
    const eEff = (-vnIn < 1.55) ? e * clamp((-vnIn - 0.35) / 1.2, 0, 1) : e;
    if (vnIn < 0) {
      const j = -(1 + eEff) * vnIn;
      vx += nx * j; vy += ny * j; vz += nz * j;
      if (-vnIn > (ball.impact || 0)) ball.impact = -vnIn;
    }
    const vn2 = vx * nx + vy * ny + vz * nz;
    let tx = vx - vn2 * nx, ty = vy - vn2 * ny, tz = vz - vn2 * nz;
    const vtLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
    if (vtLen > 1e-9) {
      let k;
      if (vnIn < -SLIDE_THRESHOLD) {
        const maxFt = friction * (1 + eEff) * (-vnIn);
        k = Math.max(0, 1 - maxFt / vtLen);
      } else {
        k = Math.max(0, 1 - (ROLL_RESISTANCE + (ball.rollExtra || 0)) * dt);
      }
      tx *= k; ty *= k; tz *= k;
    }
    vx = vn2 * nx + tx; vy = vn2 * ny + ty; vz = vn2 * nz + tz;
    ball.v.x = vx + (surfVx || 0); ball.v.y = vy + (surfVy || 0); ball.v.z = vz + (surfVz || 0);
    ball.contact = true;
    ball.contactN.set(nx, ny, nz);
    if (col) {
      ball.touched[col.name] = true;
      if (col.group) ball.touched[col.group] = true;
    }
    return true;
  }

  function collideOne(ball, col, dt) {
    if (col.live === false) return;   // v4.0: отключённые коллайдеры (открытые люки, полные лунки)
    const P = LEVEL_CONFIG.physics;
    const fr = P.surfaceFriction;
    const rollExtra = col.roll || 0;
    const p = ball.p;

    if (col.type === 'box') {
      if (col.live === false) return;
      const bx = p.x - col.c.x, by = p.y - col.c.y, bz = p.z - col.c.z;
      if (Math.abs(bx) - col.h.x >= ball.r || Math.abs(by) - col.h.y >= ball.r || Math.abs(bz) - col.h.z >= ball.r) return;
      const qx = clamp(bx, -col.h.x, col.h.x), qy = clamp(by, -col.h.y, col.h.y), qz = clamp(bz, -col.h.z, col.h.z);
      const dx = bx - qx, dy = by - qy, dz = bz - qz;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (d2 > ball.r * ball.r) return;
      let nx, ny, nz, pen;
      if (d2 > 1e-9) {
        const d = Math.sqrt(d2);
        nx = dx / d; ny = dy / d; nz = dz / d; pen = ball.r - d;
      } else {
        const ex = col.h.x - Math.abs(bx), ey = col.h.y - Math.abs(by), ez = col.h.z - Math.abs(bz);
        if (ex <= ey && ex <= ez) { nx = bx >= 0 ? 1 : -1; ny = 0; nz = 0; pen = ball.r + ex; }
        else if (ey <= ez) { nx = 0; ny = by >= 0 ? 1 : -1; nz = 0; pen = ball.r + ey; }
        else { nx = 0; ny = 0; nz = bz >= 0 ? 1 : -1; pen = ball.r + ez; }
      }
      ball.rollExtra = rollExtra;
      resolveContact(ball, nx, ny, nz, pen, col.e, fr, dt, 0, 0, 0, col);
      if (col.onHit) col.onHit(ball, col);
      return;
    }

    if (col.type === 'cyl') {
      if (p.y < col.yMin - ball.r || p.y > col.yMax + ball.r) return;
      const r = Math.hypot(p.x, p.z);
      if (r + ball.r <= col.wallR) return;
      const az = Math.atan2(p.z, p.x);
      if (!angIn(az, col.angFrom, col.angTo)) return;
      const ux = r > 1e-6 ? p.x / r : 1, uz = r > 1e-6 ? p.z / r : 0;
      ball.rollExtra = rollExtra; resolveContact(ball, -ux, 0, -uz, r + ball.r - col.wallR, col.e, fr, dt, 0, 0, 0, col);
      return;
    }

    if (col.type === 'sphere') {
      if (col.live === false) return;
      const dx = p.x - col.c.x, dy = p.y - col.c.y, dz = p.z - col.c.z;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const rr = ball.r + col.r;
      if (d >= rr || d < 1e-9) return;
      ball.rollExtra = rollExtra;
      resolveContact(ball, dx / d, dy / d, dz / d, rr - d, col.e, fr, dt, 0, 0, 0, col);
      if (col.onHit) col.onHit(ball, col);
      return;
    }

    if (col.type === 'capsule') {
      const apx = p.x - col.a.x, apy = p.y - col.a.y, apz = p.z - col.a.z;
      const l2 = col.ab.lengthSq();
      let t = l2 > 1e-9 ? (apx * col.ab.x + apy * col.ab.y + apz * col.ab.z) / l2 : 0;
      t = clamp(t, 0, 1);
      const cx = col.a.x + col.ab.x * t, cy = col.a.y + col.ab.y * t, cz = col.a.z + col.ab.z * t;
      const dx = p.x - cx, dy = p.y - cy, dz = p.z - cz;
      const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const rr = ball.r + col.r;
      if (d >= rr || d < 1e-9) return;
      ball.rollExtra = rollExtra;
      resolveContact(ball, dx / d, dy / d, dz / d, rr - d, col.e, fr, dt, 0, 0, 0, col);
      return;
    }

    if (col.type === 'torusR') {
      if (p.y < col.yMin - ball.r || p.y > col.yMax + ball.r) return;
      const r = Math.hypot(p.x, p.z);
      if (r < col.rMin - ball.r || r > col.rMax + ball.r) return;
      const az = Math.atan2(p.z, p.x);
      if (!angIn(az, col.angFrom, col.angTo)) return;
      const dr = r - col.cr, dy = p.y - col.cy;
      const d = Math.hypot(dr, dy);
      const rr = ball.r + col.tube;
      if (d >= rr || d < 1e-9) return;
      const ux = r > 1e-6 ? p.x / r : 1, uz = r > 1e-6 ? p.z / r : 0;
      ball.rollExtra = rollExtra;
      resolveContact(ball, (dr / d) * ux, dy / d, (dr / d) * uz, rr - d, col.e, fr, dt, 0, 0, 0, col);
      return;
    }

    if (col.type === 'revolve') {
      if (p.y < col.yMin - ball.r || p.y > col.yMax + ball.r) return;
      const r = Math.hypot(p.x, p.z);
      if (r < col.rMin - ball.r - 0.05 || r > col.rMax + ball.r) return;
      const az = Math.atan2(p.z, p.x);
      if (!angIn(az, col.angFrom, col.angTo)) return;
      const ux = r > 1e-6 ? p.x / r : 1, uz = r > 1e-6 ? p.z / r : 0;

      // Тонкая плита имеет две грани в пределах радиуса шара, поэтому контакт
      // выбираем явно: ближайшая грань, со стороны которой шар НАРУЖИ (s ≥ 0).
      // Если шар уже внутри тела — выталкиваем по ближайшей грани.
      let bestPen = Infinity, bestNr = 0, bestNy = 1, found = false;
      let inPen = Infinity, inNr = 0, inNy = 1;
      const segs = col.segs;
      for (let i = 0; i < segs.length; i++) {
        const sg = segs[i];
        const pr = r - sg.r1, py = p.y - sg.y1;
        const t = (pr * sg.dr + py * sg.dy) / sg.l2;
        if (t < 0 || t > 1) continue;
        const dr2 = r - (sg.r1 + sg.dr * t), dy2 = p.y - (sg.y1 + sg.dy * t);
        if (dr2 * dr2 + dy2 * dy2 > ball.r * ball.r) continue;
        const sv = dr2 * sg.nr + dy2 * sg.ny;        // знаковое расстояние до грани
        if (sv >= 0) {
          const pen = ball.r - sv;
          if (pen < bestPen) { bestPen = pen; bestNr = sg.nr; bestNy = sg.ny; found = true; }
        } else if (-sv < inPen) {
          inPen = -sv; inNr = sg.nr; inNy = sg.ny;
        }
      }
      const verts = col.verts;
      for (let i = 0; i < verts.length; i++) {
        const v = verts[i];
        const dr2 = r - v.r, dy2 = p.y - v.y;
        const d2 = dr2 * dr2 + dy2 * dy2;
        if (d2 >= ball.r * ball.r || d2 < 1e-9) continue;
        const d = Math.sqrt(d2);
        const pen = ball.r - d;
        if (pen < bestPen) { bestPen = pen; bestNr = dr2 / d; bestNy = dy2 / d; found = true; }
      }
      if (!found && inPen < Infinity) { bestPen = ball.r + inPen; bestNr = inNr; bestNy = inNy; found = true; }
      if (found && bestPen > 0) {
        ball.rollExtra = rollExtra;
        resolveContact(ball, bestNr * ux, bestNy, bestNr * uz, bestPen, col.e, fr, dt, 0, 0, 0, col);
        if (col.onHit) col.onHit(ball, col);
      }
    }
  }


  // ===========================================================================
  // 7. ШАР
  // ===========================================================================
  let BALL_SEQ = 0;

  class Ball {
    constructor(opts) {
      this.id = 'ball_' + (++BALL_SEQ) + '_' + (opts.name || '');
      this.name = opts.name || this.id;
      this.p = new THREE.Vector3(opts.x || 0, opts.y || 0, opts.z || 0);
      this.v = new THREE.Vector3(0, 0, 0);
      this.baseR = opts.r;
      this.r = opts.r * SETTINGS.ballSize;
      this.m = opts.m === undefined ? (opts.r * opts.r * opts.r * 6.0) : opts.m;
      this.baseM = this.m;
      this.colorIdx = opts.colorIdx === undefined ? -1 : opts.colorIdx;   // -1 = бесцветный (белый)
      this.isPlayer = !!opts.isPlayer;
      this.isBody = !!opts.isBody;         // тело-загадка
      this.noMagic = !!opts.noMagic;       // v4.0: не участвует в магии (цепочка, мины)
      this.mounted = !!opts.mounted;       // примагничен → кинематический
      this.mountPos = this.p.clone();
      this.mountQuat = null;
      this.kinematic = this.mounted;
      this.contact = false;
      this.contactN = new THREE.Vector3(0, 1, 0);
      this.touched = {};                 // имена коллайдеров, которых касались в этом кадре
      this.kinV = new THREE.Vector3();   // скорость кинематического тела
      this.rollExtra = 0;                // доп. гашение качения от зоны контакта
      this.impact = 0;
      this.chargeT = 0;                    // остаток заряда магии, с
      this.chargeArmed = true;             // можно заряжаться по фронту нового касания
      this.groupId = -1;                   // id заряженной цепочки
      this.onNet = false;
      this.onGlass = false;
      this.glassT = 0;                     // сколько лежит на стекле
      this.dissolving = 0;                 // >0 — растворяется
      this.restT = 0;                      // время покоя (для анти-застревания)
      this.assistCd = 0;
      this.spinAxis = new THREE.Vector3(0, 0, 1);
      this.spinRate = 0;
      this.alive = true;
      this.mesh = null;
      this.ring = null;
      this.glow = null;
      this.trail = null;
      this.flash = 0;
      this.squash = 0;                     // v3.5: сквош-стретч после удара
      this.lastSpeed = 0;
      if (this.isPlayer) { this.m = LEVEL_CONFIG.player.mass; this.baseM = this.m; }
    }

    get colorNum() {
      if (this.colorIdx < 0) return LEVEL_CONFIG.player.colorNum;
      return LEVEL_CONFIG.palette[this.colorIdx].colorNum;
    }

    applySize() {
      const s = SETTINGS.ballSize;
      this.r = this.baseR * s;
      if (this.mesh) this.mesh.scale.setScalar(s);
      if (this.glow) this.glow.scale.setScalar(s);
    }

    demount(why) {
      if (!this.mounted || this.pipeLock) return;   // v4.4: К в кармане не выбить
      this.mounted = false;
      this.kinematic = false;
      this.v.set(0, 0, 0);
      // v4.4: касание = сдвиг с опоры В СТОРОНУ толчка (часть скорости толкателя):
      // иначе белый шар проходит сквозь ряд «призраком», ряд стоит, а возврат
      // сквозь стоящие шары расшвыряет их из жёлоба
      if (why && why.indexOf('touch:') === 0 && W && W.balls) {
        const pusher = W.balls.find(q => q.name === why.slice(6));
        if (pusher) {
          const s = Math.hypot(pusher.v.x, pusher.v.z);
          if (s > 0.05) {
            const k = Math.min(s * 0.55, 1.1) / s;
            this.v.x = pusher.v.x * k; this.v.z = pusher.v.z * k;
          }
        }
      }
      W.events.push({ t: W.time, type: 'demount', name: this.name, why: why || '' });
    }
  }

  // ===========================================================================
  // 8. МАТЕРИАЛЫ И МЕШИ
  // ===========================================================================
  const MAT = {};

  function initMaterials() {
    MAT.silver = new THREE.MeshStandardMaterial({
      color: 0x8899aa, metalness: 0.92, roughness: 0.28,
      transparent: true, opacity: 1.0, side: THREE.DoubleSide,
      emissive: 0x0a1420, emissiveIntensity: 0.5
    });
    MAT.silverDark = new THREE.MeshStandardMaterial({
      color: 0x556677, metalness: 0.9, roughness: 0.4,
      transparent: true, opacity: 1.0, side: THREE.DoubleSide
    });
    MAT.glass = new THREE.MeshPhysicalMaterial({
      color: 0x9fd8ff, metalness: 0.0, roughness: 0.06,
      transparent: true, opacity: 0.085, side: THREE.DoubleSide,
      depthWrite: false
    });
    MAT.glassFloor = new THREE.MeshPhysicalMaterial({
      color: 0xbfe6ff, metalness: 0.05, roughness: 0.12,
      transparent: true, opacity: 0.85, side: THREE.DoubleSide,
      emissive: 0x113344, emissiveIntensity: 0.35
    });
    MAT.net = new THREE.MeshStandardMaterial({
      color: 0x99aabb, metalness: 0.5, roughness: 0.6,
      transparent: true, opacity: 0.7, side: THREE.DoubleSide,
      map: makeNetTexture(), alphaMap: makeNetTexture(true)
    });
    MAT.rope = new THREE.MeshStandardMaterial({
      color: 0xd8c9a8, metalness: 0.1, roughness: 0.85, emissive: 0x221a08
    });
    MAT.button = new THREE.MeshStandardMaterial({
      color: 0xff2244, metalness: 0.3, roughness: 0.35,
      emissive: 0xff2244, emissiveIntensity: 1.1,
      transparent: true, opacity: 1.0, side: THREE.DoubleSide
    });
    MAT.core = new THREE.MeshStandardMaterial({
      color: 0xd946ef, metalness: 0.35, roughness: 0.25,
      emissive: 0xd946ef, emissiveIntensity: 1.5,
      transparent: true, opacity: 1.0
    });
    MAT.halo = new THREE.MeshBasicMaterial({
      color: 0xf0abfc, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false
    });
    MAT.player = new THREE.MeshStandardMaterial({
      color: 0xffffff, metalness: 0.15, roughness: 0.22,
      emissive: 0x88ddff, emissiveIntensity: 0.55
    });
    MAT.ring = new THREE.MeshBasicMaterial({
      color: 0x00ffaa, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false
    });
    MAT.glowSprite = new THREE.MeshBasicMaterial({
      color: 0xffffff, transparent: true, opacity: 0.22,
      side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending
    });
    MAT.palette = LEVEL_CONFIG.palette.map(c => new THREE.MeshStandardMaterial({
      color: c.colorNum, metalness: 0.25, roughness: 0.3,
      emissive: c.emissive, emissiveIntensity: 0.85
    }));
  }

  function makeNetTexture(asAlpha) {
    const S = 256;
    const cv = document.createElement('canvas');
    cv.width = S; cv.height = S;
    const g = cv.getContext('2d');
    if (asAlpha) {
      g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
      g.strokeStyle = '#fff'; g.lineWidth = 7;
      const step = S / 4;
      for (let i = 0; i <= 4; i++) {
        g.beginPath(); g.moveTo(i * step, 0); g.lineTo(i * step, S); g.stroke();
        g.beginPath(); g.moveTo(0, i * step); g.lineTo(S, i * step); g.stroke();
      }
    } else {
      g.fillStyle = '#7d8ea0'; g.fillRect(0, 0, S, S);
      g.strokeStyle = '#cfe4f5'; g.lineWidth = 7;
      const step = S / 4;
      for (let i = 0; i <= 4; i++) {
        g.beginPath(); g.moveTo(i * step, 0); g.lineTo(i * step, S); g.stroke();
        g.beginPath(); g.moveTo(0, i * step); g.lineTo(S, i * step); g.stroke();
      }
    }
    const tex = new THREE.CanvasTexture(cv);
    tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(14, 6);
    return tex;
  }

  function lathe(profile, segments, phiStart, phiLength) {
    const pts = profile.map(p => new THREE.Vector2(Math.max(0.001, p[0]), p[1]));
    const g = new THREE.LatheGeometry(pts, segments || 96, phiStart || 0, phiLength === undefined ? Math.PI * 2 : phiLength);
    g.computeVertexNormals();
    return g;
  }


  function ringMesh(r, tube, color, opacity) {
    const m = new THREE.Mesh(
      new THREE.TorusGeometry(r, tube, 8, 96),
      new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: opacity, depthWrite: false })
    );
    m.rotation.x = Math.PI / 2;
    return m;
  }

  // ===========================================================================
  // 9. СОСТОЯНИЕ МИРА
  // ===========================================================================
  const W = {
    scene: null, camera: null, renderer: null,
    glassGroup: null, fxGroup: null,
    colliders: [], balls: [], bodies: [], fadeables: [], important: [],
    player: null, core: null, coreAlive: true,
    buttonCol: null, netCol: null, buttonMesh: null, buttonGlow: null,
    coreMesh: null, halos: [], bodyOrbitT: 0,
    ropeMesh: null, ropeAnchorMesh: null, ropeCut: false, ropeLen: LEVEL_CONFIG.rope.length,
    events: [], contacts: [],
    time: 0, runTime: 0, state: 'menu',
    magicCount: 0, lostCount: 0, cutCount: 0, blastCount: 0,
    trapTimer: -1, winSeq: 0, loseSeq: 0,
    shakeCd: 0, shakeVisual: 0, shakeSeed: 0, orbitT: 0, ropeHover: false,
    slowmo: 0, slowmoScale: 1, screenShake: 0, screenShakeAmp: 0,
    tilt: { rotX: 0, rotZ: 0, tRotX: 0, tRotZ: 0, active: false },
    ffOpen: false, ffReason: null, floorsGhost: false, autoPull: null,
    cam: { theta: LEVEL_CONFIG.camera.defaultTheta, phi: LEVEL_CONFIG.camera.defaultPolar, dist: LEVEL_CONFIG.camera.defaultDist,
           tTheta: LEVEL_CONFIG.camera.defaultTheta, tPhi: LEVEL_CONFIG.camera.defaultPolar, tDist: LEVEL_CONFIG.camera.defaultDist,
           spinTheta: 0, spinPhi: 0 },
    camShake: new THREE.Vector3(),
    sparks: null, sparkData: [],
    fireworks: null, fwData: [],
    ghost: null,
    chargeGroups: [],
    fadeState: new Map(),
    glassOffset: new THREE.Vector3(),
    def: null,
    // --- v3.5: поток (re-wind), очки/комбо, интро, уровни, звёзды ---
    attempts: 0, failStreak: 0,
    rewind: { active: false, t: 0, from: new THREE.Vector3(), dur: 0.4 },
    intro: { active: false, t: 0, dur: 2.5 },
    introWasActive: false,
    cine: null, camTargetY: undefined,
    lowestY: 99, hintShownAt: 0,
    score: 0, bestScore: 0, combo: 1, lastEventTime: -999, perfectCuts: 0,
    progress: null, specials: null, sandbox: false, sandboxMenu: false, levelNameT: 0, // v4.1
    currentLevel: 0, magicTouched: false,
    flashT: 0, ropePulse: 0,
    visited: null,
    trail: null,
    // v4.0: этажи
    currentFloor: 0, floorGroup: null, floorState: null, floorSolvedFlag: false,
    floorGate: null, gateAnim: 0, floorEntry: null,
    floorTransition: null,      // { active, t, dur, to, toastShown }
    paletteNow: null, paletteTarget: 0, floorGlowRing: null,
    camTargetX: 0, camTargetZ: 0, camBreath: 0,
    echoQueue: null, lights: null
  };

  // ===========================================================================
  // 10. ПРОФИЛИ ПЛОЩАДОК
  // ===========================================================================
  // v4.1: диск этажа «Чаша» башни — юбка до стенки стакана, плоскость, чаша
  // с ЦЕНТРАЛЬНЫМ ЛЮКОМ вниз (дно чаши — горловина). Спуск — только через люк.
  function profilePlatformA() {
    const A = LEVEL_CONFIG.platformA;
    const R = LEVEL_CONFIG.glass.radius;
    const hole = LEVEL_CONFIG.floors.holeR * K();
    const r0 = hole + 0.1;
    const pts = [[R, A.y], [A.bowlRadius, A.y]];
    const N = 12;
    for (let i = 1; i <= N; i++) {
      const r = A.bowlRadius - (A.bowlRadius - r0) * (i / N);
      const t = (r - r0) / (A.bowlRadius - r0);
      pts.push([r, A.y - A.bowlDepth * (1 - t * t)]);
    }
    pts.push([hole, A.y - A.bowlDepth - 0.06]);        // губа горловины люка
    pts.push([hole, A.y - A.bowlDepth - 0.5]);         // трубка люка вниз
    pts.push([hole + 0.22, A.y - A.bowlDepth - 0.55]);
    pts.push([A.bowlRadius + 0.4, A.y - A.bowlDepth - 0.75]);
    pts.push([R, A.y - A.bowlDepth - 1.15]);
    pts.push([R, A.y]);
    return pts;
  }

  // Коэффициент размера шаров (настройка «Размер шаров»).
  // Всё, что обязано пропускать или удерживать шар, масштабируется вместе с ним:
  // горловина воронки, отверстие сетки, пробка, кнопка, ядро, орбита тел,
  // бортик площадки A и длина троса. Иначе на крупных шарах уровень
  // непроходим (шар не пролезает в горловину r=1.5), а на мелких
  // пробка перестаёт закрывать отверстие.
  function K() { return SETTINGS.ballSize; }

  // Площадка B: плоское кольцо тянется ДО СТЕНКИ стакана (иначе между краем
  // площадки и стеклом остаётся щель, в которую шар проваливается в ловушку,
  // минуя воронку), затем округлая губа и конус воронки к горловине.
  function profilePlatformB() {
    const B = LEVEL_CONFIG.platformB;
    const R = LEVEL_CONFIG.glass.radius;
    return [
      [R, B.y],                              // юбка у стенки стакана
      [B.funnelTopR + 0.3, B.y],             // плоское кольцо
      [B.funnelTopR + 0.15, B.funnelTopY - 0.05],
      [B.funnelTopR, B.funnelTopY],          // губа воронки (r=10, y=5.3)
      [(B.funnelBottomR * K()), B.funnelBottomY],    // конус к горловине (r=1.5, y=3.5)
      [(B.funnelBottomR * K()), B.funnelBottomY - 0.3],
      [B.funnelTopR, B.funnelTopY - 0.35],
      [B.funnelTopR + 0.3, B.y - B.thickness],
      [R, B.y - B.thickness - 0.3],
      [R, B.y]
    ];
  }

  // Зона воронки отдельно: гасящая поверхность (иначе шар играет в пинбол
  // и никогда не попадает в горловину r=1.5)
  function profileFunnelB() {
    const B = LEVEL_CONFIG.platformB;
    return [
      [B.funnelTopR, B.funnelTopY],
      [(B.funnelBottomR * K()), B.funnelBottomY],
      [(B.funnelBottomR * K()), B.funnelBottomY - 0.3],
      [B.funnelTopR, B.funnelTopY - 0.35]
    ];
  }

  // Чаша площадки A отдельно от плоского диска: чаша гасит прыжки,
  // диск остаётся строго бильярдным
  // v4.1: гасящая чаша — до горловины люка (центр открыт, крышка — отдельный коллайдер)
  function profileBowlA() {
    const A = LEVEL_CONFIG.platformA;
    const hole = LEVEL_CONFIG.floors.holeR * K();
    const r0 = hole + 0.12;
    const pts = [[A.bowlRadius + 0.02, A.y]];
    const N = 12;
    for (let i = 1; i <= N; i++) {
      const r = A.bowlRadius - (A.bowlRadius - r0) * (i / N);
      const t = (r - r0) / (A.bowlRadius - r0);
      pts.push([r, A.y - A.bowlDepth * (1 - t * t)]);
    }
    pts.push([r0, A.y - A.bowlDepth - 0.25]);
    pts.push([A.bowlRadius + 0.02, A.y - A.bowlDepth - 0.25]);
    pts.push([A.bowlRadius + 0.02, A.y]);
    return pts;
  }

  function profileDiscA() {
    const A = LEVEL_CONFIG.platformA;
    const R = LEVEL_CONFIG.glass.radius;   // v4.1: диск до стенки — щелей нет
    return [[R, A.y], [A.bowlRadius, A.y], [A.bowlRadius, A.y - A.thickness],
      [R, A.y - A.thickness], [R, A.y]];
  }

  function profileNet() {
    const T = LEVEL_CONFIG.trap;
    const drop = Math.tan(T.netTilt) * (T.netRadius - (T.netHole * K()));
    return [
      [LEVEL_CONFIG.glass.radius, T.netY],
      [T.netRadius, T.netY],
      [(T.netHole * K()), T.netY - drop],
      [(T.netHole * K()), T.netY - drop - 0.3]
    ];
  }

  function profileButton() {
    const B = LEVEL_CONFIG.button, R = B.radius * K();
    const top = B.y + B.thickness / 2, bot = B.y - B.thickness / 2;
    return [[R, top], [0.02, top], [0.02, bot], [R, bot], [R, top]];
  }

  // v4.0: плоский диск этажа «Труба»/«Резонанс»: кольцо до стенки стакана
  // + центральная трубка-горловина (люк вниз). Юбка вниз к стенке — как у
  // прежней площадки B, чтобы шар не проскальзывал между диском и стеклом.
  function profileFloorDisc(y) {
    const R = LEVEL_CONFIG.glass.radius, hole = (LEVEL_CONFIG.floors.holeR * K());
    return [
      [R, y],                                  // юбка у стенки
      [hole + 0.3, y],                         // плоское кольцо
      [hole, y - 0.05],                        // губа горловины
      [hole, y - 0.45],                        // трубка люка вниз
      [hole + 0.2, y - 0.5],
      [R, y - 0.8],                            // нижняя юбка к стенке
      [R, y]
    ];
  }

  // v4.0: кольцо-балкон финального этажа: площадка вокруг провала, сквозь который
  // ныряют к смещённому ядру. Внизу трубки нет — нырок уходит в открытую полость.
  // Обход сверху справа налево (от большего r к меньшему), иначе нормаль вниз.
  function profileFinalRing(y) {
    const R = LEVEL_CONFIG.glass.radius, hole = (LEVEL_CONFIG.floors.holeR * K());
    return [
      [R, y],                                  // юбка у стенки
      [hole + 0.3, y],                         // плоское кольцо-балкон
      [hole + 0.05, y - 0.06],
      [hole, y - 0.12],                        // скруглённая губа провала
      [hole + 0.25, y - 0.32],
      [R, y - 0.55],
      [R, y]
    ];
  }

  // v4.0: мини-профиль крышки люка (плоский диск по горловине).
  // Обход справа налево — иначе нормаль смотрит вниз и шар проваливается
  function profileGateLid(y) {
    const hole = (LEVEL_CONFIG.floors.holeR * K());
    return [[hole, y + 0.06], [0.02, y + 0.06]];
  }

  function funnelY(r) {
    const B = LEVEL_CONFIG.platformB;
    if (r >= B.funnelTopR) return B.y;
    if (r <= (B.funnelBottomR * K())) return B.funnelBottomY;
    const t = (B.funnelTopR - r) / (B.funnelTopR - (B.funnelBottomR * K()));
    return B.funnelTopY + (B.funnelBottomY - B.funnelTopY) * t;
  }

  // ===========================================================================
  // 11. ПОСТРОЕНИЕ УРОВНЯ
  // ===========================================================================
  function protectedMats() {
    const set = new Set();
    Object.keys(MAT).forEach(k => {
      const v = MAT[k];
      if (Array.isArray(v)) v.forEach(m => set.add(m)); else if (v) set.add(v);
    });
    return set;
  }

  function disposeGroup(g) {
    if (!g) return;
    const prot = protectedMats();
    g.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        const mm = Array.isArray(o.material) ? o.material : [o.material];
        mm.forEach(m => {
          if (!m || prot.has(m)) return;
          if (m.map) m.map.dispose();
          if (m.alphaMap) m.alphaMap.dispose();
          m.dispose();
        });
      }
    });
    if (g.parent) g.parent.remove(g);
  }

  // v4.4: тонировка «цилиндров башни» (дисков этажей) цветом текущего уровня.
  // Диски создаются клонами MAT.silver — красим материал каждого меша,
  // коллайдеры и физику не трогаем.
  function applyLevelPalette() {
    const idx = clamp(W.currentLevel || 0, 0, LEVELS.length - 1);
    const pal = LEVEL_PALETTES[idx % LEVEL_PALETTES.length];
    const c = new THREE.Color(pal[1]);
    const e = new THREE.Color(pal[2]);
    const tint = (m) => {
      if (!m || !m.material || !m.material.color) return;
      m.material.color.copy(new THREE.Color(0.75, 0.8, 0.9)).lerp(c, 0.55);
      if (m.material.emissive) { m.material.emissive.copy(e).multiplyScalar(0.16); }
    };
    const walk = (root) => {
      if (!root) return;
      (root.children || []).forEach(ch => {
        if (ch && ch.name && /^(platformA|floorPipe|platformB)$/.test(ch.name)) tint(ch);
        if (ch && ch.children && ch.children.length) walk(ch);
      });
    };
    if (W.floorViz) W.floorViz.forEach(walk);
    W.levelPalette = pal;   // для UI-свотчей и тестов
  }

  function buildLevel() {
    const C = LEVEL_CONFIG;
    // v3.5: параметры текущего уровня
    applyLevel(W.currentLevel || 0);
    // --- очистка ---
    disposeGroup(W.glassGroup);
    W.glassGroup = new THREE.Group();
    W.glassGroup.name = 'glassGroup';
    W.scene.add(W.glassGroup);
    const G = W.glassGroup;
    W.colliders = []; W.balls = []; W.bodies = []; W.fadeables = []; W.important = [];
    W.events = []; W.contacts = []; W.chargeGroups = []; W.fadeState = new Map();
    W.halos = []; W.important = []; W.glassOffset.set(0, 0, 0);
    W.coreAlive = true; W.ropeCut = false; W.trapTimer = -1; W.winSeq = 0; W.loseSeq = 0;
    W.time = 0; W.runTime = 0; W.magicCount = 0; W.lostCount = 0; W.cutCount = 0; W.blastCount = 0;
    W.shakeCd = 0; W.shakeVisual = 0; W.slowmo = 0; W.slowmoScale = 1;
    W.screenShake = 0; W.screenShakeAmp = 0; W.cam.spinTheta = 0; W.cam.spinPhi = 0; W.ropeHover = false;
    W.bodyOrbitT = 0; W.orbitT = 0; W.tilt.rotX = W.tilt.rotZ = W.tilt.tRotX = W.tilt.tRotZ = 0;
    W.glassOffset.set(0, 0, 0);
    BALL_SEQ = 0;
    // v3.5: сброс потока, очков и вспомогательных состояний
    W.attempts = 0; W.failStreak = 0; W.rewind.active = false; W.rewind.t = 0;
    W.score = 0; W.combo = 1; W.lastEventTime = -999; W.perfectCuts = 0; W.lowestY = 99;
    W.cine = null; W.camTargetY = LEVEL_CONFIG.camera.targetY;
    W.flashT = 0; W.ropePulse = 0;
    W.visited = { A: false, B: false, core: false, button: false, trap: false, floors: [false, false, false, false] };
    // v4.1: сброс этажей (башню строит buildAllFloors)
    W.currentFloor = 0; W.floorGroup = null; W.floorState = null; W.floorSolvedFlag = false;
    W.floorStates = null; W.floorSolvedArr = null; W.floorGates = null;
    W.floorGate = null; W.gateAnim = 0; W.floorTransition = null; W.echoQueue = [];
    W.camTargetX = 0; W.camTargetZ = 0; W.camBreath = 0;
    applyFloorPalette(0, true);
    if (W.trail) {
      W.trail.head = 0; W.trail.fade = 0; W.trail.dirty = true;
      W.trail.colors.fill(0);
    }

    // --- СОЛОД / ЦВЕТ ФОНА (v4.0: из палитры этажей) ---
    const PAL0 = LEVEL_CONFIG.floorPalettes[0];
    W.scene.background = new THREE.Color(PAL0.bg);
    W.scene.fog = new THREE.Fog(PAL0.bg, 90, 260);
    applyFloorPalette(0, true);

    // ============================ СТАКАН ============================
    const gR = C.glass.radius, gB = C.glass.yBottom, gT = C.glass.yTop;
    const LV = LEVELS[W.currentLevel || 0];
    const PAL = LEVEL_PALETTES[(W.currentLevel || 0) % LEVEL_PALETTES.length];
    // v4.4: стекло стакана — цвета текущего уровня (клон материала, тон + подсветка)
    const wallMat = MAT.glass.clone();
    try { wallMat.color.set(PAL[0]); wallMat.attenuationColor.set(PAL[0]); } catch (e) {}
    const wall = new THREE.Mesh(
      new THREE.CylinderGeometry(gR, gR, gT - gB, 96, 1, true),
      wallMat
    );
    wall.name = 'glassWallMesh';
    wall.position.y = (gT + gB) / 2;
    G.add(wall);

    // вертикальные швы и горизонтальные пояса стекла
    const seamMat = new THREE.LineBasicMaterial({ color: new THREE.Color(PAL[2]).getHex(), transparent: true, opacity: 0.42 });
    const seamPts = [];
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      seamPts.push(new THREE.Vector3(Math.cos(a) * gR, gB, Math.sin(a) * gR));
      seamPts.push(new THREE.Vector3(Math.cos(a) * gR, gT, Math.sin(a) * gR));
    }
    G.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(seamPts), seamMat));
    W.glassBelts = [];
    for (let y = gB; y <= gT + 0.01; y += 3.5) {
      const belt = ringMesh(gR, 0.045, new THREE.Color(PAL[2]).getHex(), 0.4);
      belt.position.y = y;
      G.add(belt);
      W.glassBelts.push(belt);
    }
    // верхний и нижний обод
    const rimTop = new THREE.Mesh(new THREE.TorusGeometry(gR, 0.28, 12, 120), MAT.silverDark.clone());
    rimTop.rotation.x = Math.PI / 2; rimTop.position.y = gT; G.add(rimTop);
    const rimBot = rimTop.clone(); rimBot.position.y = gB; G.add(rimBot);

    // стеклянное дно (ловушка, opacity 0.85)
    const floor = new THREE.Mesh(new THREE.CircleGeometry(gR, 96), MAT.glassFloor.clone());
    floor.rotation.x = -Math.PI / 2; floor.position.y = gB; G.add(floor);
    W.fadeables.push({ mesh: floor, base: 0.85, kind: 'floor' });

    // подсветка дна (v4.0: перекрашивается палитрой этажа; v4.4 — палитрой уровня)
    const floorGlow = ringMesh(gR * 0.72, 0.06, new THREE.Color(PAL[2]).getHex(), 0.5);
    floorGlow.position.y = gB + 0.02; G.add(floorGlow);
    W.floorGlowRing = floorGlow;

    // коллайдеры стакана
    W.colliders.push(makeCyl('glassWall', gR, gB, gT, { e: C.physics.restitutionWall, group: 'glass' }));
    W.colliders.push(makeRevolve('glassFloor', [[0.02, gB], [gR, gB]].reverse(), { e: 0.55, group: 'floor' }));
    W.colliders.push(makeRevolve('ceiling', [[0.02, gT + 1.0], [gR + 0.5, gT + 1.0]], { e: 0.35 }));

    // ============================ ЭТАЖИ (v4.1) ============================
    // Башня: все 4 этажа строятся сразу и сосуществуют до конца уровня.
    const A = C.platformA;
    W.runStats = { shakes: 0, plateFails: 0, mineHits: 0, echoBlasts: 0, socketFails: 0, dives: 0, cutMisses: 0 };
    buildAllFloors();
    applyLevelPalette();   // v4.4: диски этажей — цвет уровня

    // ============================ ЛОВУШКА: СЕТКА ============================
    const T = C.trap;
    const profN = profileNet();
    const meshN = new THREE.Mesh(lathe(profN, 128), MAT.net.clone());
    meshN.name = 'net';
    G.add(meshN);
    W.fadeables.push({ mesh: meshN, base: 0.7, kind: 'net', topY: T.netY });
    W.netCol = makeRevolve('net', profN, { e: 0.5, group: 'net' });
    W.colliders.push(W.netCol);
    const holeRing = ringMesh((T.netHole * K()), 0.07, 0xff3355, 0.9);
    holeRing.position.y = T.netY - Math.tan(T.netTilt) * (T.netRadius - (T.netHole * K())) + 0.02;
    G.add(holeRing);
    W.trapHoleRing = holeRing;

    // ============================ КНОПКА + КРОНШТЕЙНЫ ============================
    const BT = C.button;
    const SH = C.shield;
    const btnGroup = new THREE.Group();
    btnGroup.position.set(SH.x, 0, SH.z);   // v4.0: кнопка под смещённым ядром
    G.add(btnGroup);
    W.buttonGroup = btnGroup;

    const btnTop = new THREE.Mesh(new THREE.CylinderGeometry((BT.radius * K()), (BT.radius * K()), BT.thickness, 48), MAT.button.clone());
    btnTop.position.y = BT.y;
    btnGroup.add(btnTop);
    W.buttonMesh = btnTop;

    const btnBase = new THREE.Mesh(new THREE.CylinderGeometry((BT.radius * K()) * 1.25, (BT.radius * K()) * 1.45, 0.22, 48), MAT.silverDark.clone());
    btnBase.position.y = BT.y - BT.thickness / 2 - 0.12;
    btnGroup.add(btnBase);

    const btnGlow = new THREE.Mesh(new THREE.CircleGeometry(BT.glowRadius, 48),
      new THREE.MeshBasicMaterial({ color: 0xff3355, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    btnGlow.rotation.x = -Math.PI / 2;
    btnGlow.position.y = BT.y - BT.thickness / 2 - 0.24;
    btnGroup.add(btnGlow);
    W.buttonGlow = btnGlow;

    // v4.0: кнопка вне оси стакана — вместо поверхности вращения капсула
    W.buttonCol = makeCapsule('button',
      { x: SH.x, y: BT.y - BT.thickness / 2, z: SH.z },
      { x: SH.x, y: BT.y + BT.thickness / 2, z: SH.z },
      (BT.radius * K()), { e: 0.6, group: 'button' });
    W.colliders.push(W.buttonCol);

    BT.bracketAngles.forEach((a, i) => {
      const ax = Math.cos(a), az = Math.sin(a);
      const p1 = new THREE.Vector3(SH.x + ax * BT.bracketInner, BT.y, SH.z + az * BT.bracketInner);
      const p2 = new THREE.Vector3(ax * (gR - 0.2), BT.bracketWallY, az * (gR - 0.2));
      const dir = new THREE.Vector3().subVectors(p2, p1);
      const len = dir.length();
      const br = new THREE.Mesh(new THREE.CylinderGeometry(BT.bracketRadius, BT.bracketRadius * 1.25, len, 14), MAT.silverDark.clone());
      br.position.copy(p1).addScaledVector(dir, 0.5);
      br.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      br.name = 'bracket' + i;
      G.add(br);
      W.fadeables.push({ mesh: br, base: 1.0, kind: 'bracket', topY: BT.y });
      W.colliders.push(makeCapsule('bracket' + i, p1, p2, BT.bracketRadius, { e: 0.7 }));
      // крепёжные узлы к стене
      const pad = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.1, 0.9), MAT.silver.clone());
      pad.position.copy(p2);
      pad.lookAt(0, p2.y, 0);
      G.add(pad);
    });

    // ============================ ЯДРО ЩИТА ============================
    const S = C.shield;
    const coreGroup = new THREE.Group();
    coreGroup.position.set(S.x, S.y, S.z);   // v4.0: ядро смещено от оси
    G.add(coreGroup);
    W.coreGroup = coreGroup;

    const coreMesh = new THREE.Mesh(new THREE.IcosahedronGeometry((S.coreRadius * K()), 2), MAT.core.clone());
    coreGroup.add(coreMesh);
    W.coreMesh = coreMesh;

    const inner = new THREE.Mesh(new THREE.IcosahedronGeometry((S.coreRadius * K()) * 0.62, 1),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55 }));
    coreGroup.add(inner);
    W.coreInner = inner;

    for (let i = 0; i < 2; i++) {
      const h = new THREE.Mesh(new THREE.TorusGeometry((S.coreRadius * K()) * (1.5 + i * 0.42), 0.05, 8, 72), MAT.halo.clone());
      h.rotation.x = Math.PI / 2 + (i ? 0.5 : -0.35);
      h.rotation.y = i ? 0.6 : 0;
      coreGroup.add(h);
      W.halos.push(h);
    }

    W.coreCol = makeSphereCol('core', S.x, S.y, S.z, (S.coreRadius * K()), { e: 0.85, group: 'core' });
    W.colliders.push(W.coreCol);
    W.important.push({ obj: coreGroup, name: 'core' });

    // ============================ ТРОС ============================
    const anchor = new THREE.Vector3(C.rope.anchor.x, C.rope.anchor.y, C.rope.anchor.z);
    W.ropeAnchor = anchor;
    // длина троса = якорь − площадка A − радиус шара − зазор (при 1.00× это ровно 7.9)
    W.ropeLen = anchor.y - A.y - C.player.radius * K() - 0.35;
    const anchorMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.62, 0.5, 20), MAT.silverDark.clone());
    anchorMesh.position.copy(anchor).add(new THREE.Vector3(0, 0.25, 0));
    G.add(anchorMesh);
    W.ropeAnchorMesh = anchorMesh;
    const anchorHook = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.07, 8, 24), MAT.silver.clone());
    anchorHook.position.copy(anchor);
    G.add(anchorHook);

    const ropeMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 1, 8), MAT.rope.clone());
    G.add(ropeMesh);
    W.ropeMesh = ropeMesh;

    // ============================ ШАРЫ ============================
    // Игровой шар (белый, r = 0.75)
    const hangY = anchor.y - W.ropeLen;
    W.player = makeBall({
      name: 'player', x: anchor.x, y: hangY, z: anchor.z,
      r: C.player.radius, isPlayer: true, colorIdx: -1, m: C.player.mass
    });
    W.important.push({ obj: W.player.mesh, name: 'player', ball: W.player });

    // Тела-загадки на орбите вокруг ядра (3, на уровне 10 — 4: «ядро усилено»)
    const nb = (LEVELS[W.currentLevel | 0] || LEVELS[0]).bodies;
    for (let i = 0; i < nb; i++) {
      const b = makeBall({
        name: 'body' + i, x: 0, y: S.y, z: 0,
        r: S.bodyRadius, colorIdx: i % 3, m: S.bodyMass, isBody: true, mounted: true
      });
      b.orbitPhase = (i / nb) * Math.PI * 2;
      b.orbit = true;
      W.bodies.push(b);
    }

    // «важные» объекты для авто-затухания площадок
    W.important.push({ obj: W.buttonGroup, name: 'button' });

    updateKinematic(0);
    updateRopeVisual();
    applySettingsLive(true);
    return W;
  }

  // ===========================================================================
  // 11a. ЭТАЖИ (v4.0): постройка, люки, палитры, загадки
  // ===========================================================================
  const PAL_C = { red: 0, blue: 1, yellow: 2 };

  // кластер примагниченных шаров по дуге (шаг раздвигается при крупном шаре)
  function magnetRing(prefix, count, radius, anglesDeg, colorIdx, rBall, y) {
    const R2 = rBall * K();
    const need = 2 * Math.asin(Math.min(1, (R2 * 2 * 1.02) / (2 * radius))) * 180 / Math.PI;
    const spec = count > 1 ? (anglesDeg[count - 1] - anglesDeg[0]) / (count - 1) : 0;
    const step = Math.max(spec, need);
    const mid = (anglesDeg[0] + anglesDeg[count - 1]) / 2;
    for (let i = 0; i < count; i++) {
      const a = (mid + (i - (count - 1) / 2) * step) * Math.PI / 180;
      makeFloorBall({
        name: prefix + (i + 1), x: Math.cos(a) * radius, y: y, z: Math.sin(a) * radius,
        r: rBall, colorIdx: colorIdx, mounted: true
      });
    }
  }

  function addFloorCol(col) {
    col.floor = (W._buildFloor !== undefined && W._buildFloor >= 0) ? W._buildFloor : W.currentFloor;
    W.colliders.push(col);
    return col;
  }

  function makeFloorBall(opts) {
    const b = makeBall(opts);
    b.floor = (W._buildFloor !== undefined && W._buildFloor >= 0) ? W._buildFloor : W.currentFloor;
    // v4.2: «дом» шара — точка возврата, если шар ухнул в ловушку мимо загадки
    b.homePos = b.p.clone();
    b.homeMounted = !!opts.mounted;
    const vg = (W.floorViz && W.floorViz[b.floor]) || W.floorGroup;
    if (vg) {
      if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
      if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
      vg.add(b.mesh);
      vg.add(b.ring);
    }
    return b;
  }

  // v4.2: возврат «потерянного» шара этажа на его место (шары больше не исчезают)
  function respawnBallHome(b) {
    if (!b || !b.alive || !b.homePos) return;
    b.p.copy(b.homePos);
    b.v.set(0, 0, 0);
    b.mounted = b.homeMounted;
    b.kinematic = b.homeMounted;
    b.onNet = false; b.onGlass = false; b.glassT = 0; b.dissolving = 0;
    b.countedLost = false; b.inTrap = false;
    if (b.mesh) { b.mesh.scale.setScalar(SETTINGS.ballSize); b.mesh.position.copy(b.p); if (b.mesh.material) { b.mesh.material.opacity = 1; } }
    if (b.glow) b.glow.visible = true;
    if (b.pedestal) b.pedestal.visible = true;
    W.events.push({ t: W.time, type: 'ballRespawn', name: b.name });
    W.events.push({ t: W.time, type: 'zzH', name: b.name, x: +b.p.x.toFixed(1), z: +b.p.z.toFixed(1) });
  }

  // точка входа на этаж (для отката при проигрыше на этажах 1+)
  function entryPointOf(idx) {
    const C = LEVEL_CONFIG, ry = C.player.radius * K() + 0.06;
    if (idx <= 0) return null;                                            // этаж 0 — откат на трос
    if (idx === 1) return new THREE.Vector3(11.2, LEVEL_CONFIG.floorPipeY + ry, 0);
    if (idx === 3) return new THREE.Vector3(0, LEVEL_CONFIG.platformB.y + ry, 3.8);   // финал: дальше от воронки (r 2.2K + шар)
    return new THREE.Vector3(0, LEVEL_CONFIG.platformB.y + ry, 2.6);      // «Резонанс»: у люка (крышка закрыта)
  }

  // ===========================================================================
  // ПАЛИТРЫ ЭТАЖЕЙ
  // ===========================================================================
  const _palCols = LEVEL_CONFIG.floorPalettes.map(P => ({
    bg: new THREE.Color(P.bg), fog: new THREE.Color(P.fog), key: new THREE.Color(P.key),
    hemi: new THREE.Color(P.hemi), hemiG: new THREE.Color(P.hemiG), glow: new THREE.Color(P.glow)
  }));
  const _palKeys = ['bg', 'fog', 'key', 'hemi', 'hemiG', 'glow'];

  // v4.1: тёмный режим (L10): множитель яркости палитры
  const _darkMul = () => (LV().dark ? 0.32 : 1.0);

  function applyFloorPalette(idx, instant) {
    W.paletteTarget = clamp(idx | 0, 0, 3);
    if (instant) {
      if (!W.paletteNow) W.paletteNow = {};
      const t = _palCols[W.paletteTarget];
      for (const k of _palKeys) {
        if (!W.paletteNow[k]) W.paletteNow[k] = t[k].clone().multiplyScalar(_darkMul());
        else W.paletteNow[k].copy(t[k]).multiplyScalar(_darkMul());
      }
      applyPaletteNow();
    }
  }

  function applyPaletteNow() {
    const p = W.paletteNow;
    if (!p || !W.scene) return;
    if (W.scene.background && W.scene.background.copy) W.scene.background.copy(p.bg);
    if (W.scene.fog) W.scene.fog.color.copy(p.fog);
    if (W.lights) {
      W.lights.key.color.copy(p.key);
      W.lights.hemi.color.copy(p.hemi);
      W.lights.hemi.groundColor.copy(p.hemiG);
      if (W.lights.p1) W.lights.p1.color.copy(p.glow);
    }
    if (W.floorGlowRing && W.floorGlowRing.material) W.floorGlowRing.material.color.copy(p.glow);
  }

  function updatePalette(dt) {
    if (!W.paletteNow) return;
    const t = _palCols[W.paletteTarget];
    if (!t) return;
    const rate = 1 - Math.exp(-dt / 0.35);
    const mul = _darkMul();
    let moved = false;
    for (const k of _palKeys) {
      const c = W.paletteNow[k];
      const tr = t[k].r * mul, tg = t[k].g * mul, tb = t[k].b * mul;
      if (Math.abs(c.r - tr) > 1e-3 || Math.abs(c.g - tg) > 1e-3 || Math.abs(c.b - tb) > 1e-3) moved = true;
      c.r += (tr - c.r) * rate; c.g += (tg - c.g) * rate; c.b += (tb - c.b) * rate;
    }
    if (moved) applyPaletteNow();
  }

  // ===========================================================================
  // ЛЮКИ (ворота этажей)
  // ===========================================================================
  function openFloorGate() {
    const g = W.floorGate;
    if (!g || g.opened) return;
    g.opened = true;
    if (g.col) g.col.live = false;
    W.gateAnim = 0.001;
    Sound.floorDone();
  }

  // v4.1: закрыть крышку люка этажа (сброс загадки на уровнях 6-8)
  function closeGate(idx) {
    const g = W.floorGates && W.floorGates[idx];
    if (!g) return;
    g.opened = false;
    g.pulled = false;                // v4.2: сброс этажа возвращает магнитный поток
    if (g.col) g.col.live = true;
    if (g.lid) g.lid.material.opacity = 0.3;
    if (g.ringMesh) { g.ringMesh.material.color.setHex(0xff3355); g.ringMesh.material.opacity = 0.85; }
    if (g.arc) g.arc.material.opacity = 0.9;
    if (g.group) g.group.position.y = 0;
    W.gateAnim = 0;
  }

  // v4.1: полный сброс загадки этажа (модификатор Re-wind уровней 6-8)
  function resetFloorPuzzle(idx) {
    const st = W.floorStates && W.floorStates[idx];
    if (!st) return;
    if (idx === 0 && st.sockets) {
      for (const sk of st.sockets) {
        sk.count = 0; sk.full = false; sk.stack = 0;
        if (sk.collar) sk.collar.material.opacity = 0;
        if (sk.rim) sk.rim.material.color.setHex(LEVEL_CONFIG.palette[sk.color].colorNum);
        for (const c of sk.cols) c.live = true;
        drawSocketSprite(sk);
      }
      for (const b of W.balls) {
        if (!b.alive || b.isPlayer || b.floor !== 0 || !b.mountPos) continue;
        b.mounted = true; b.kinematic = true; b.orbit = false;
        b.p.copy(b.mountPos); b.v.set(0, 0, 0);
        if (b.mesh) b.mesh.position.copy(b.p);
      }
    } else if (idx === 1 && st.pipe) {
      for (const r of st.pipe.roads) resetPipeRoad(r, 'floorReset');
    } else if (idx === 2 && st.plates) {
      for (const pl of st.plates) {
        pl.active = false; pl.cool = 0; pl.lastV = 0; pl.insideBy = {};
        if (pl.mesh) { pl.mesh.material.emissive.setHex(pl.kindColor); pl.mesh.material.emissiveIntensity = 0.55; }
        if (pl.ring) pl.ring.material.color.setHex(pl.kindColor);
        drawPlateBar(pl, -1);
      }
      for (const b of (st.hazards || [])) respawnBallHome(b);
      drawHatchSprite();
    }
    closeGate(idx);
    const wasCur = W.currentFloor;
    W.currentFloor = idx; W.floorState = st;
    setSolvedFlag(false);
    W.currentFloor = wasCur; W.floorState = W.floorStates[wasCur];
    W.floorSolvedFlag = W.floorSolvedArr[wasCur];
    toast(D().floorReset, 'warn');
    Sound.reject();
    W.events.push({ t: W.time, type: 'floorReset', floor: idx });
  }

  function updateGateVisual(dt) {
    if (!W.floorGate || !W.floorGate.opened || W.gateAnim <= 0) return;
    W.gateAnim += dt;
    const g = W.floorGate;
    const t = clamp(W.gateAnim / LEVEL_CONFIG.floors.gateOpenTime, 0, 1);
    if (g.lid) g.lid.material.opacity = lerp(0.3, 0.03, t);
    if (g.ringMesh) { g.ringMesh.material.color.setHex(0x00ffaa); g.ringMesh.material.opacity = lerp(0.85, 0.35, t); }
    if (g.arc) g.arc.material.opacity = lerp(0.9, 0.12, t);
    if (g.group) g.group.position.y = -0.5 * t * t;   // створка проседает
    if (t >= 1) W.gateAnim = 0;
  }

  // крышка центрального люка этажа (0 — в дне чаши, 1/2 — в дисках)
  function makeGateLid(y, fIdx) {
    const hole = LEVEL_CONFIG.floors.holeR * K();
    const grp = new THREE.Group();
    const lid = new THREE.Mesh(new THREE.CircleGeometry(hole, 48),
      new THREE.MeshBasicMaterial({ color: 0xff3355, transparent: true, opacity: 0.3, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    lid.rotation.x = -Math.PI / 2;
    lid.position.y = y + 0.08;
    grp.add(lid);
    const ring = ringMesh(hole, 0.07, 0xff3355, 0.85);
    ring.position.y = y + 0.09;
    grp.add(ring);
    (W.floorViz && W.floorViz[fIdx] ? W.floorViz[fIdx] : W.floorGroup).add(grp);
    const col = addFloorCol(makeRevolve('gateLid' + fIdx, profileGateLid(y), { e: 0.35 }));
    // v4.2: кромка-«губа» вокруг люка — кольцо мелких капсул заполняет стык
    // крышки и диска: шары больше не заклинивает в щели и не выдавливает сквозь
    const curbR = 0.09 * K();
    for (let k = 0; k < 10; k++) {
      const a = k * Math.PI / 5;
      const fx = Math.cos(a) * (hole + curbR * 0.6), fz = Math.sin(a) * (hole + curbR * 0.6);
      addFloorCol(makeCapsule('lidcurb' + fIdx + '_' + k,
        { x: fx, y: y + 0.02, z: fz }, { x: fx, y: y + 0.02 + curbR, z: fz },
        curbR, { e: 0.25, group: 'lidcurb' }));
    }
    W.floorGates[fIdx] = { col: col, group: grp, lid: lid, ringMesh: ring, opened: false, floor: fIdx, cx: 0, cz: 0, cy: y };
    if (fIdx === W.currentFloor) W.floorGate = W.floorGates[fIdx];
  }

  // ===========================================================================
  // ГЛАВНЫЙ СТРОИТЕЛЬ ЭТАЖА
  // ===========================================================================
  // v4.1: вход на этаж — БЕЗ пересборки: башня из 4 этажей построена целиком
  // и этажи сосуществуют. Меняются только указатели состояния/палитры.
  // (имя buildFloor сохранено как тест-хук)
  function buildFloor(idx) {
    idx = clamp(idx | 0, 0, 3);
    W.currentFloor = idx;
    W.floorState = W.floorStates ? W.floorStates[idx] : null;
    W.floorSolvedFlag = W.floorSolvedArr ? W.floorSolvedArr[idx] : false;
    W.floorGate = (W.floorGates && W.floorGates[idx]) || null;
    W.floorEntry = entryPointOf(idx);
    // трос виден только на первом этаже
    if (W.ropeMesh) W.ropeMesh.visible = (idx === 0);
    if (W.ropeAnchorMesh) W.ropeAnchorMesh.visible = true;
  }

  // v4.1: БАШНЯ — все 4 этажа строятся одновременно (Чаша 11 / Труба 8 /
  // Резонанс 5 / Ядро внизу). Спуск между этажами — только через центральные
  // люки, крышки которых открывает решённая загадка этажа.
  function buildAllFloors() {
    if (W.floorGroup) disposeGroup(W.floorGroup);
    W.colliders = W.colliders.filter(c => c.floor === undefined);
    W.fadeables = W.fadeables.filter(f => f.floor === undefined);
    for (const b of W.balls) {
      if (b.floor !== undefined) {
        b.alive = false;
        if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
      }
    }
    W.floorGroup = new THREE.Group();
    W.floorGroup.name = 'floorGroup';
    W.glassGroup.add(W.floorGroup);
    // v4.2: отдельная визуальная группа на этаж — скрытие пройденных
    W.floorViz = [0, 1, 2, 3].map(i => {
      const g = new THREE.Group();
      g.name = 'floorViz' + i;
      W.floorGroup.add(g);
      return g;
    });
    W.floorStates = [
      { sockets: null, chain: null, plates: null, solved: false },
      { sockets: null, chain: null, plates: null, solved: false },
      { sockets: null, chain: null, plates: null, solved: false },
      { sockets: null, chain: null, plates: null, solved: false }
    ];
    W.floorSolvedArr = [false, false, false, false];
    W.floorGates = [null, null, null];
    W.gateAnim = 0;
    W.floorTransition = null;
    W.floorState = W.floorStates[0];
    W.floorSolvedFlag = false;
    W.floorGate = null;
    W._buildFloor = 0; buildFloorBowl();          // этаж 0 «ЧАША»
    W._buildFloor = 1; buildFloorPipe();          // этаж 1 «ТРУБА»
    W._buildFloor = 2; buildFloorResonance();     // этаж 2 «РЕЗОНАНС»
    W._buildFloor = 3; buildFloorCore();          // этаж 3 «ЯДРО»
    W._buildFloor = -1;
    buildFloor(0);
    syncFloorViz();                               // v4.2: скрыть/призрак пройденных
  }

  // ---------------------------------------------------------------------------
  // ЭТАЖ 0 «ЧАША»: существующая площадка A + числовые лунки
  // ---------------------------------------------------------------------------
  function buildFloorBowl() {
    const A = LEVEL_CONFIG.platformA;
    const F = W.floorViz[0];
    W.floorState = W.floorStates[0];

    const profA = profilePlatformA();
    const meshA = new THREE.Mesh(lathe(profA, 128), MAT.silver.clone());
    meshA.name = 'platformA';
    F.add(meshA);
    W.fadeables.push({ mesh: meshA, base: 1.0, kind: 'platform', topY: A.y, floor: 0 });
    addFloorCol(makeRevolve('platformA', profileDiscA(), { group: 'platformA' }));
    addFloorCol(makeRevolve('platformA', profileBowlA(), { group: 'platformA', e: 0.72, roll: 0.55 }));

    const bowlRing = ringMesh(A.bowlRadius, 0.05, 0x00ffaa, 0.65);
    bowlRing.position.y = A.y + 0.01; F.add(bowlRing);
    const bowlRing2 = ringMesh(A.bowlRadius * 0.55, 0.04, 0x00d4ff, 0.5);
    bowlRing2.position.y = A.y - A.bowlDepth * 0.72; F.add(bowlRing2);

    // v4.1: бортик — ПОЛНЫЙ круг у самой стенки: перила сомкнуты, за них
    // выкатиться нельзя; сход с этажа — только через центральный люк чаши.
    const rimY = A.y + (A.rimY - A.y) * K();
    const rimTube = A.rimTube * K();
    const rimGroup = new THREE.Group();
    rimGroup.position.y = rimY;
    rimGroup.name = 'rimA';
    F.add(rimGroup);
    const rimArc = new THREE.Mesh(
      new THREE.TorusGeometry(A.rimRadius, rimTube, 14, 128),
      MAT.silverDark.clone()
    );
    rimArc.rotation.x = Math.PI / 2;
    rimGroup.add(rimArc);
    W.rimGroup = rimGroup;
    W.fadeables.push({ mesh: rimArc, base: 1.0, kind: 'platform', topY: rimY, floor: 0 });
    addFloorCol(makeTorusR('rimA', A.rimRadius, rimY, rimTube, { group: 'platformA' }));

    // ЛЮК этажа 0 — в дне чаши: крышка открывается решённой загадкой лунок
    makeGateLid(A.y - A.bowlDepth + 0.02, 0);

    // ---------- ЛУНКИ ----------
    // Коллайдеры лунок — позиционированные примитивы (revolve всегда осевой!):
    // «забор» из 8 вертикальных капсул (вершина на 2 см НИЖЕ диска — шар
    // перекатывается сверху свободно) + сфера-дно + сфера-крышка для полных.
    const L = LEVELS[W.currentLevel];
    const spec = L.sockets;
    const angs = spec.length === 1 ? [115] :
      spec.length === 2 ? [115, 295] :
      spec.length === 3 ? [55, 175, 295] :
      spec.length === 4 ? [45, 135, 225, 315] : [90, 162, 234, 306, 18];
    const rS = 1.2 * K();
    const sockR = 6.2;
    W.floorState.sockets = [];
    const colorRun = { 0: 0, 1: 0, 2: 0 };
    const pref = ['R-A', 'B-A', 'Y-A'];
    const rStd = 0.62;

    spec.forEach((sp, i) => {
      const az = angs[i] * Math.PI / 180;
      const sx = Math.cos(az) * sockR, sz = Math.sin(az) * sockR;
      const sk = {
        id: i, color: sp[0], target: sp[1], count: 0, full: false,
        x: sx, z: sz, baseY: A.y, stack: 0, cols: []
      };
      // визуал: блюдце-гнездо на диске (револь-коллайдеры осевые, «настоящую»
      // дырку в диске сделать нельзя — лунка это зона с низким бортиком)
      const cupProf = [[0.06, A.y], [rS - 0.5, A.y], [rS - 0.12, A.y + 0.05], [rS, A.y + 0.1], [rS - 0.12, A.y + 0.05]];
      const cup = new THREE.Mesh(lathe(cupProf, 48), MAT.silver.clone());
      cup.position.set(sx, 0, sz);
      F.add(cup);
      // низкий бортик-губа: шары запрыгивают на скорости, медленные откатываются
      for (let k = 0; k < 8; k++) {
        const fa = k * Math.PI / 4;
        const fx = sx + Math.cos(fa) * rS, fz = sz + Math.sin(fa) * rS;
        const col = addFloorCol(makeCapsule('skf' + i + '_' + k,
          { x: fx, y: A.y - 0.06, z: fz }, { x: fx, y: A.y + 0.03, z: fz },
          0.12 * K(), { e: 0.5, group: 'socket' }));
        sk.cols.push(col);
      }
      // подсветка кромки цветом лунки
      const rim = ringMesh(rS + 0.1, 0.05, LEVEL_CONFIG.palette[sk.color].colorNum, 0.9);
      rim.position.set(sx, A.y + 0.03, sz);
      F.add(rim);
      sk.rim = rim;
      // «воротничок» заполненной лунки
      const collar = ringMesh(rS + 0.28, 0.07, 0x00ffaa, 0.0);
      collar.position.set(sx, A.y + 0.06, sz);
      F.add(collar);
      sk.collar = collar;
      // спрайт с цифрой и пи́псами прогресса
      makeSocketSprite(sk);
      W.floorState.sockets.push(sk);
      // патронташ: (target+1) шаров нужного цвета у лунки
      const rackN = sp[1] + 1;
      const rackR = 8.3;
      const need = 2 * Math.asin(Math.min(1, (rStd * K() * 2 * 1.02) / (2 * rackR))) * 180 / Math.PI;
      const stepDeg = Math.max(13, need);
      for (let j = 0; j < rackN; j++) {
        const a = az + (j - (rackN - 1) / 2) * stepDeg * Math.PI / 180;
        makeFloorBall({
          name: pref[sp[0]] + (++colorRun[sp[0]]),
          x: Math.cos(a) * rackR, y: A.y + rStd * K(), z: Math.sin(a) * rackR,
          r: rStd, colorIdx: sp[0], mounted: true
        });
      }
    });

    // v4.1: нейтральные тройки — только цвета, НЕ занятые лунками («сырьё» магии)
    const usedCols = {};
    spec.forEach(sp => usedCols[sp[0]] = true);
    if (!usedCols[PAL_C.blue]) magnetRing('B-A', 3, 7.0, [65, 80, 95], PAL_C.blue, rStd, A.y + rStd * K());
    if (!usedCols[PAL_C.yellow]) magnetRing('Y-A', 3, 7.0, [245, 260, 275], PAL_C.yellow, rStd, A.y + rStd * K());
    (function () {
      const a1 = 200 * Math.PI / 180, r1 = 8.4, rb1 = 0.95;
      makeFloorBall({ name: 'Lone-A1', x: Math.cos(a1) * r1, y: A.y + rb1 * K(), z: Math.sin(a1) * r1, r: rb1, colorIdx: PAL_C.red, mounted: true });
      const a2 = 95 * Math.PI / 180, r2 = 5.3, rb2 = 0.45;
      makeFloorBall({ name: 'Lone-A2', x: Math.cos(a2) * r2, y: A.y + rb2 * K(), z: Math.sin(a2) * r2, r: rb2, colorIdx: PAL_C.blue, mounted: true });
    })();
  }

  // спрайт лунки: цифра-цель + пи́псы прогресса
  function makeSocketSprite(sk) {
    const cv = document.createElement('canvas');
    cv.width = 128; cv.height = 168;
    const tex = new THREE.CanvasTexture(cv);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
    sp.scale.set(1.7, 2.2, 1);
    sp.position.set(sk.x, sk.baseY + 2.15, sk.z);
    if (W.floorGroup) W.floorGroup.add(sp);
    sk.sprite = sp; sk.cv = cv; sk.tex = tex;
    drawSocketSprite(sk);
  }

  function drawSocketSprite(sk) {
    const g = sk.cv.getContext('2d');
    if (!g) return;
    const col = sk.full ? '#00ffaa' : ('#' + LEVEL_CONFIG.palette[sk.color].colorNum.toString(16).padStart(6, '0'));
    g.clearRect(0, 0, 128, 168);
    g.fillStyle = 'rgba(4,10,24,0.78)';
    g.fillRect(10, 10, 108, 116);
    g.strokeStyle = col; g.lineWidth = 4;
    g.strokeRect(10, 10, 108, 116);
    g.fillStyle = col;
    g.font = 'bold 74px Arial';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(sk.target), 64, 66);
    // пи́псы
    for (let i = 0; i < sk.target; i++) {
      const px = 64 + (i - (sk.target - 1) / 2) * 32;
      g.beginPath();
      g.arc(px, 140, 10, 0, Math.PI * 2);
      if (i < sk.count) { g.fillStyle = '#00ffaa'; g.fill(); }
      else { g.strokeStyle = 'rgba(255,255,255,0.4)'; g.lineWidth = 3; g.stroke(); }
    }
    if (sk.full) {
      g.strokeStyle = '#00ffaa'; g.lineWidth = 6;
      g.beginPath(); g.moveTo(24, 24); g.lineTo(44, 44); g.moveTo(44, 24); g.lineTo(24, 44); g.stroke();
    }
    sk.tex.needsUpdate = true;
  }

  // попытка вставить шар в лунку (зона: шар в круге rS на высоте диска)
  function socketTryInsert(ball, sk) {
    if (W.currentFloor !== 0 || inTransition() || !ball.alive) return;
    if (ball.socketCd > 0 || sk.full) return;
    const A = LEVEL_CONFIG.platformA;
    if (ball.p.y > A.y + 1.6 || ball.p.y < A.y - 0.2) return;   // только у диска
    const kick = () => {
      ball.socketCd = 0.6;
      const dx = ball.p.x - sk.x, dz = ball.p.z - sk.z;
      const d = Math.hypot(dx, dz) || 1;
      ball.v.y += 4.2;
      ball.v.x += (dx / d) * 1.3 + rnd(-0.3, 0.3);   // выброс наружу от лунки
      ball.v.z += (dz / d) * 1.3 + rnd(-0.3, 0.3);
    };
    if (ball.isPlayer) { kick(); toast(D().socketPlayer, 'warn'); W.events.push({ t: W.time, type: 'socketPlayer' }); return; }
    if (ball.colorIdx !== sk.color) { kick(); Sound.reject(); if (W.runStats) W.runStats.socketFails++; toast(D().socketWrong, 'bad'); W.events.push({ t: W.time, type: 'socketWrong', ball: ball.name }); return; }
    if (sk.count >= sk.target) { kick(); Sound.reject(); toast(D().socketOverflow, 'bad'); return; }
    // приём: шар примагничивается в центр лунки (башенкой)
    sk.count++;
    ball.socketCd = 0;
    ball.mounted = true;
    ball.kinematic = true;
    ball.orbit = false;
    ball.noMagic = true;                        // вставленный шар больше не участвует в магии
    ball.mountPos.set(sk.x, A.y + ball.r + (sk.count - 1) * ball.r * 1.9, sk.z);
    ball.p.copy(ball.mountPos);
    ball.v.set(0, 0, 0);
    ball.flash = 0.25;
    drawSocketSprite(sk);
    Sound.socketIn();
    addScore(100, curLang === 'ru' ? 'лунка' : 'socket');
    W.events.push({ t: W.time, type: 'socketIn', socket: sk.id, ball: ball.name, count: sk.count });
    if (sk.count >= sk.target) {
      sk.full = true;
      for (const c of sk.cols) c.live = false;   // бортик больше не мешает
      if (sk.collar) sk.collar.material.opacity = 0.85;
      drawSocketSprite(sk);
      toast(D().socketFull + ' · ' + (sk.count + '/' + sk.target), 'good');
    }
    const all = W.floorState.sockets;
    if (all && all.every(q => q.full)) onFloorSolved();
  }

  // ---------------------------------------------------------------------------
  // ЭТАЖ 1 «ТРУБА»: плоский диск, жёлоб, домино-змейка
  // ---------------------------------------------------------------------------
  // ===========================================================================
  // ЭТАЖ 1 «ТРУБА» v4.2 — две дороги-жёлоба со спусковыми люками и мишенями
  // (ТЗ v4.2 п.2: закатить белый шар в люк дороги → цепочка катится к мишени,
  //  мишень засчитывает только шары целевого цвета; обе дороги решены → люк на
  //  этаж «Резонанс» открывается и шар магнитным потоком уходит вниз)
  // ===========================================================================
  const PIPE_ROADS = [
    { id: 0, letter: 'A', zc: 2.0, xIn: -9.0, xOut: 3.0 },   // дорога A
    { id: 1, letter: 'B', zc: -2.0, xIn: -2.0, xOut: 8.0 }   // дорога B
  ];

  function buildFloorPipe() {
    const y = LEVEL_CONFIG.floorPipeY;
    const L = LEVELS[W.currentLevel];
    const F = W.floorViz[1];
    W.floorState = W.floorStates[1];

    const prof = profileFloorDisc(y);
    const meshD = new THREE.Mesh(lathe(prof, 128), MAT.silver.clone());
    meshD.name = 'floorPipe';
    F.add(meshD);
    W.fadeables.push({ mesh: meshD, base: 1.0, kind: 'platform', topY: y, floor: 1 });
    addFloorCol(makeRevolve('floorPipe', prof, { group: 'floorPipe' }));
    makeGateLid(y, 1);

    // вход: светящаяся площадка под зазором бортика этажа 0
    const entry = ringMesh(1.15, 0.05, 0x00ffaa, 0.55);
    entry.position.set(11.2, y + 0.03, 0);
    F.add(entry);

    const tgtColor = LEVEL_CONFIG.palette[L.pipe.color].colorNum;
    W.floorState.pipe = { roads: [] };

    PIPE_ROADS.forEach((rd, ri) => {
      const layout = (L.pipe.roads && L.pipe.roads[ri]) || null;
      const st = {
        id: rd.id, letter: rd.letter, def: rd, layout: layout,
        balls: [], markers: [], hit: 0, need: 0, solved: false, resetT: -1,
        color: L.pipe.color, pocketFlashT: 0
      };
      W.floorState.pipe.roads.push(st);
      if (!layout) return;                                   // дороги нет (L1-2)

      // --- стенки жёлоба (капсулы вдоль X) ---
      const wallR = 0.28 * K();
      const wallY = y + 0.30;
      for (let sg = -1; sg <= 1; sg += 2) {
        const a = { x: rd.xIn - 0.9, y: wallY, z: rd.zc + sg * 1.05 }, b = { x: rd.xOut + 0.7, y: wallY, z: rd.zc + sg * 1.05 };
        addFloorCol(makeCapsule('rwall' + rd.letter + (sg < 0 ? 'L' : 'R'), a, b, wallR, { e: 0.5, group: 'trough' }));
        const rail = new THREE.Mesh(new THREE.CylinderGeometry(wallR, wallR, (rd.xOut + 0.7) - (rd.xIn - 0.9), 20), MAT.silverDark.clone());
        rail.rotation.z = Math.PI / 2;
        rail.position.set((rd.xIn - 0.9 + rd.xOut + 0.7) / 2, wallY, rd.zc + sg * 1.05);
        F.add(rail);
      }
      // тупик за мишенью
      addFloorCol(makeCapsule('rend' + rd.letter,
        { x: rd.xOut + 2.0, y: wallY, z: rd.zc - 1.05 }, { x: rd.xOut + 2.0, y: wallY, z: rd.zc + 1.05 }, wallR, { e: 0.4, group: 'trough' }));

      // --- спусковой люк (светящееся кольцо в полу у входа) ---
      const hatch = ringMesh(1.2, 0.09, tgtColor, 0.9);
      hatch.position.set(rd.xIn, y + 0.04, rd.zc);
      F.add(hatch);
      const hatchIn = ringMesh(0.9, 0.05, tgtColor, 0.35);
      hatchIn.position.set(rd.xIn, y + 0.02, rd.zc);
      F.add(hatchIn);
      st.hatch = hatch; st.hatchIn = hatchIn;

      // --- мишень: тёмная лунка у выхода + счётчик ---
      const pocket = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 0.8, 0.1, 32),
        new THREE.MeshStandardMaterial({ color: 0x101820, metalness: 0.6, roughness: 0.4, emissive: tgtColor, emissiveIntensity: 0.22 }));
      pocket.position.set(rd.xOut + 1.0, y + 0.015, rd.zc);
      F.add(pocket);
      st.pocket = pocket;

      // --- линейка шаров на носиках-опорах ---
      const rStd = 0.62;
      const pitch = rStd * 2 * K() + 0.05;
      st.need = layout.filter(q => q === 'K').length;
      let sIdx = 0;
      layout.forEach((t, i) => {
        const jz = (L.pipe.jitter && !W.sandbox) ? (((i * 137) % 7) - 3) / 3 * L.pipe.jitter : 0;
        const bx = rd.xIn + 0.9 + i * pitch;
        const bz = rd.zc + jz;
        let colorIdx = L.pipe.color;
        if (t === 'S') colorIdx = (i % 2 === 0) ? (L.pipe.color + 1) % 3 : (L.pipe.color + 2) % 3;
        if (t === 'M') colorIdx = -1;
        const b = makeFloorBall({
          name: 'P' + rd.letter + (i + 1), x: bx, y: y + rStd * K(), z: bz,
          r: rStd, colorIdx: colorIdx, mounted: true, noMagic: true
        });
        b.pipeType = t; b.pipeRoad = rd.id;
        st.balls.push(b);
        // опора-носик: визуальная сфера под шаром; «опора отключается» = demount
        const ped = new THREE.Mesh(new THREE.SphereGeometry(0.15 * K(), 12, 10), MAT.silverDark.clone());
        ped.position.set(bx, y + 0.08, bz);
        F.add(ped);
        b.pedestal = ped;
        // индикатор над шаром: точка для К, крест для М
        if (t === 'K' || t === 'M') {
          const mk = t === 'K'
            ? new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8),
                new THREE.MeshBasicMaterial({ color: tgtColor, transparent: true, opacity: 0.95, depthWrite: false, blending: THREE.AdditiveBlending }))
            : makeMineCross();
          mk.position.set(bx, y + rStd * K() + 1.05, bz);
          F.add(mk);
          st.markers.push({ ball: b, mesh: mk, mine: t === 'M' });
        }
      });
      void sIdx;
      makeRoadBar(st);
      drawRoadBar(st);
    });
  }

  function makeMineCross() {
    const cg = new THREE.Group();
    const cmat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9, depthWrite: false });
    const c1 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.07, 0.09), cmat);
    const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.07, 0.5), cmat);
    cg.add(c1); cg.add(c2);
    return cg;
  }

  // billboard-счётчик мишени дороги
  function makeRoadBar(st) {
    const cv = document.createElement('canvas');
    cv.width = 160; cv.height = 96;
    const tex = new THREE.CanvasTexture(cv);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0.92, depthWrite: false }));
    sp.scale.set(2.2, 1.32, 1);
    sp.position.set(st.def.xOut + 1.0, LEVEL_CONFIG.floorPipeY + 2.1, st.def.zc);
    if (W.floorViz && W.floorViz[1]) W.floorViz[1].add(sp);
    st.cv = cv; st.tex = tex; st.sprite = sp;
  }

  function drawRoadBar(st) {
    const g = st.cv && st.cv.getContext && st.cv.getContext('2d');
    if (!g) return;
    g.clearRect(0, 0, 160, 96);
    g.fillStyle = 'rgba(4,10,24,0.78)';
    g.fillRect(8, 8, 144, 80);
    const col = st.solved ? '#00ff88' : '#' + LEVEL_CONFIG.palette[st.color].colorNum.toString(16).padStart(6, '0');
    g.strokeStyle = col; g.lineWidth = 4;
    g.strokeRect(8, 8, 144, 80);
    g.fillStyle = col;
    g.font = '900 46px system-ui, sans-serif';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(st.hit + ' / ' + st.need, 80, 50);
    st.tex.needsUpdate = true;
  }

  // пересборка одной дороги (мина/кнопка/сброс этажа)
  function resetPipeRoad(st, reason) {
    if (!st || !st.layout) return;
    st.hit = 0; st.solved = false; st.resetT = -1;
    for (const b of st.balls) {
      if (!b.alive || b.pipeGone) continue;
      b.mounted = true; b.kinematic = true; b.v.set(0, 0, 0);
      b.p.copy(b.homePos);
      b.pipeEval = false; b.pipeDone = false; b.pipeLock = false; b.swallowT = 0;
      if (b.mesh) { b.mesh.scale.setScalar(SETTINGS.ballSize); b.mesh.position.copy(b.p); if (b.mesh.material) b.mesh.material.opacity = 1; }
      if (b.pedestal) b.pedestal.visible = true;
    }
    for (const mk of st.markers) if (mk.mesh) mk.mesh.visible = true;
    if (st.pocket) st.pocket.material.emissive.setHex(LEVEL_CONFIG.palette[st.color].colorNum), st.pocket.material.emissiveIntensity = 0.22;
    drawRoadBar(st);
    W.events.push({ t: W.time, type: 'pipeReset', road: st.id, reason: reason || '' });
    W.events.push({ t: W.time, type: 'zzR', name: 'rd' + st.id, x: st.hit, z: +(reason || '').slice(0, 6).length, hit: st.hit });
  }

  function resetPipeRoads(reason) {
    if (!W.floorStates || !W.floorStates[1].pipe) return;
    for (const st of W.floorStates[1].pipe.roads) resetPipeRoad(st, reason);
  }

  // ежекадровая логика этажа «Труба»
  function updatePipe(dt) {
    const ps = W.floorState && W.floorState.pipe;
    if (!ps) return;
    const y = LEVEL_CONFIG.floorPipeY;
    const pl = W.player;
    const live = (W.state === 'play') && !inTransition();

    for (const st of ps.roads) {
      if (!st.layout) continue;
      if (st.resetT > 0) {
        st.resetT -= dt;
        if (st.resetT <= 0) resetPipeRoad(st, 'mine');
        continue;
      }
      if (st.pocketFlashT > 0) {
        st.pocketFlashT -= dt;
        if (st.pocket) st.pocket.material.emissiveIntensity = 0.22 + Math.max(0, st.pocketFlashT) * 2.2;
      }
      // v4.2: уклона НЕТ — шары везёт наклон стакана (ядро игры);
      // опора шара складывается касанием (соседа слева или игроком).
      // пульс люка-обучение (первые секунды на этаже)
      if (st.pulseT > 0) {
        st.pulseT -= dt;
        const pk = 0.35 + 0.55 * (0.5 + 0.5 * Math.sin(W.time * 7));
        if (st.hatch) st.hatch.material.opacity = pk + 0.25;
        if (st.hatchIn) st.hatchIn.material.opacity = pk;
      }
      if (!live) continue;

      // мишень: шар, впервые дошедший до фронта очереди (карман или стопка К)
      const rd = st.def;
      const pitch = 0.62 * 2 * K() + 0.05;
      const frontX = st.hit > 0
        ? (rd.xOut + 1.0 - (st.hit - 1) * pitch - 1.34)
        : (rd.xOut + 0.35);
      for (const b of W.balls) {
        if (!b.alive) continue;
        const inPocket = b.p.x > frontX && b.p.x < rd.xOut + 2.0 &&
          Math.abs(b.p.z - rd.zc) < 1.1 && Math.abs(b.p.y - y) < 1.6;
        if (inPocket && !b.pipeEval && !st.solved) {
          b.pipeEval = true;
          pipeArrive(st, b);
        } else if (!inPocket && b.pipeEval && b.pipeRoad === st.id) {
          b.pipeEval = false;
        }
        // растворение «нейтралов» и проглоченных
        if (b.swallowT > 0) {
          b.swallowT -= dt;
          const k = clamp(b.swallowT / 0.3, 0, 1);
          if (b.mesh) { b.mesh.scale.setScalar(SETTINGS.ballSize * k); if (b.mesh.material) { b.mesh.material.opacity = k; b.mesh.material.transparent = true; } }
          if (b.swallowT <= 0) {
            b.alive = false;
            if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
            if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
          }
        }
      }

      // маркеры следуют за своими шарами
      for (const mk of st.markers) {
        if (!mk.mesh) continue;
        mk.mesh.visible = !!(mk.ball.alive && mk.ball.mounted);
        if (mk.ball.alive && mk.ball.mounted) mk.mesh.position.set(mk.ball.p.x, mk.ball.p.y + 1.05, mk.ball.p.z);
      }
    }

    // решение этажа: обе существующие дороги решены → поток к люку
    const roads = ps.roads.filter(q => q.layout);
    if (roads.length && roads.every(q => q.solved) && !W.floorStates[1].solved) {
      onFloorSolved();
    }
    if (W.floorStates[1].solved && W.currentFloor === 1) {
      const g = W.floorGates[1];
      if (g && g.opened && !g.pulled && !W.autoPull && pl && pl.alive && W.state === 'play' &&
          pl.p.y < y + 3 && pl.p.y > y - 0.5 && !inTransition()) {
        startAutoPull(1);
      }
    }
  }

  // шар прибыл в мишень дороги
  function pipeArrive(st, b) {
    const rd = st.def;
    const y = LEVEL_CONFIG.floorPipeY;
    if (b.isPlayer) {
      // белый шар в мишени = «нейтрал»: уходит в ловушку → перемотка
      b._pipeTrapT = 0.42;
      return;
    }
    if (b.pipeRoad !== st.id || b.pipeDone) return;
    if (b.pipeType === 'M') {
      // мина срабатывает и УБИРАЕТСЯ с дороги; дорога пересобирается, счётчик в 0
      if (W.runStats) W.runStats.mineHits++;
      b.pipeGone = true; b.alive = false;
      if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
      if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
      st.resetT = 1.2;
      toast(D().pipeMine, 'bad', 2000);
      Sound.chainFail();
      W.events.push({ t: W.time, type: 'pipeMineHit', road: st.id });
      return;
    }
    if (b.pipeType === 'K') {
      b.pipeDone = true;
      b.pipeLock = true;                             // v4.4: замок от демонта в кармане
      b.mounted = true; b.kinematic = true;
      b.v.set(0, 0, 0);
      st.hit++;
      b.p.set(rd.xOut + 1.0 - (st.hit - 1) * (0.62 * 2 * K() + 0.05), y + b.r * K(), rd.zc);
      b.mountPos.copy(b.p);   // v4.4: стопка К живёт В КАРМАНЕ (иначе шаг физики вернёт шар на рельс — и он перекроет жёлоб)

      // v4.4: анти-«выплеск» — заморозка К в кармане может пересечься со следующим
      // за ним шаром: resolveContact выплеснет его из жёлоба навсегда. Разводим
      // перекрытие мягко — возвращаем шар в жёлоб перед карманом.
      const rr = b.r * K();
      for (const o of st.balls) {
        if (o === b || !o.alive || o.pipeDone || o.isPlayer) continue;
        const d = Math.hypot(o.p.x - b.p.x, o.p.z - b.p.z);
        if (d < rr + o.r * K() + 0.15) {
          W.events.push({ t: W.time, type: 'zzFling', name: o.name, x: +o.p.x.toFixed(2), d: +d.toFixed(2) });
          o.p.set(rd.xOut + 1.0 - 2.35, y + o.r * K(), rd.zc);
          o.v.set(0, 0, 0);
        }
      }
      st.pocketFlashT = 0.6;
      drawRoadBar(st);
      if (st.hit >= st.need) {
        st.solved = true;
        if (st.pocket) { st.pocket.material.emissive.setHex(0x00ff88); st.pocket.material.emissiveIntensity = 1.2; }
        if (st.sprite) st.sprite.material.opacity = 1;
        drawRoadBar(st);
        Sound.floorDone();
        toast(D().pipeRoadDone.replace('{r}', st.letter), 'good', 1800);
      }
      return;
    }
    // нейтрал: проваливается в ловушку под мишенью и исчезает (насовсем)
    b.pipeGone = true;
    b.swallowT = 0.3;
    b.mounted = false; b.kinematic = false;
    Sound.fall();
    W.events.push({ t: W.time, type: 'pipeNeutral', road: st.id });
  }

  // ===========================================================================
  // v4.2: магнитный поток — решённый этаж сам уводит шар в центральный люк
  // ===========================================================================
  function startAutoPull(floorIdx) {
    const pl = W.player;
    if (!pl || !pl.alive) return;
    // один поток на решённый этаж: без флага триггер перезахватывал шар
    // сразу после отпускания, и шар зависал над люком
    const gg = W.floorGates && W.floorGates[floorIdx];
    if (gg) gg.pulled = true;
    W.autoPull = {
      active: true, t: 0, dur: 1.5, floor: floorIdx,
      from: { x: pl.p.x, z: pl.p.z }, y: pl.p.y
    };
    pl.kinematic = true;
    pl.v.set(0, 0, 0);
    Sound.ui();
    W.events.push({ t: W.time, type: 'autoPull', floor: floorIdx });
  }

  function updateAutoPull(dt) {
    const ap = W.autoPull;
    if (!ap || !ap.active) return;
    const pl = W.player;
    if (!pl || !pl.alive || W.state !== 'play') { W.autoPull = null; return; }
    W.tilt.active = false;
    W.tilt.tRotX = 0; W.tilt.tRotZ = 0;
    ap.t += dt;
    const k = clamp(ap.t / ap.dur, 0, 1);
    const e = k * k * (3 - 2 * k);
    const r = Math.hypot(pl.p.x, pl.p.z);
    const targetY = floorY(ap.floor) + pl.r + 0.05;
    pl.p.x = lerp(ap.from.x, 0, e);
    pl.p.z = lerp(ap.from.z, 0, e);
    pl.p.y = targetY + Math.max(0, (ap.y - targetY)) * (1 - e);
    if (pl.mesh) pl.mesh.position.copy(pl.p);
    if (k >= 1 || r < 0.35) {
      ap.active = false;
      W.autoPull = null;
      pl.kinematic = false;
      pl.mounted = false;
      pl.v.set(0, -0.8, 0);                     // отпуск в открытый люк
    }
  }

  // ===========================================================================
  // ЭТАЖ 2 «РЕЗОНАНС» v4.2 — три плиты-стенки: бей гранью с нужной скоростью
  // (ТЗ v4.2 п.3: зелёная слабо / жёлтая средне / красная сильно; чужой шар
  //  нужной силы ГАСИТ активную плиту — с 6-го уровня на полу шары-помехи)
  // ===========================================================================
  function buildFloorResonance() {
    const y = LEVEL_CONFIG.platformB.y;
    const L = LEVELS[W.currentLevel];
    const F = W.floorViz[2];
    W.floorState = W.floorStates[2];

    // v4.2: пол радиуса 8 (ТЗ) + сомкнутое перило по кромке — с этажа не сойти
    const R = 8.0, hole = LEVEL_CONFIG.floors.holeR * K();
    const prof = [
      [R, y],
      [hole + 0.3, y],
      [hole, y - 0.05],
      [hole, y - 0.45],
      [hole + 0.2, y - 0.5],
      [R - 0.3, y - 0.6],
      [R, y]
    ];
    const meshD = new THREE.Mesh(lathe(prof, 96), MAT.silver.clone());
    meshD.name = 'platformB';
    F.add(meshD);
    W.fadeables.push({ mesh: meshD, base: 1.0, kind: 'platform', topY: y, floor: 2 });
    addFloorCol(makeRevolve('platformB', prof, { group: 'platformB' }));
    makeGateLid(y, 2);
    // перила этажа
    const railT = 0.32 * K();
    const rim = new THREE.Mesh(new THREE.TorusGeometry(R - 0.28, railT, 12, 96), MAT.silverDark.clone());
    rim.rotation.x = Math.PI / 2;
    rim.position.y = y + 0.34;
    F.add(rim);
    addFloorCol(makeTorusR('rimB', R - 0.28, y + 0.34, railT, { group: 'platformB' }));

    // ---------- ТРИ ПЛИТЫ-СТЕНКИ ----------
    // v4.2: тройка плит повернута на 30° (300°/60°/180°) — ось люка x=0 и z<0
    // свободна для нырка к ядру: плиты не перегораживают разгонный коридор
    const P3 = [
      { id: 0, kind: 'weak',   colHex: 0x00ff88, x: 2.0,   z: -3.46 },
      { id: 1, kind: 'mid',    colHex: 0xffcc00, x: 2.0,   z: 3.46 },
      { id: 2, kind: 'strong', colHex: 0xff3355, x: -4.0,  z: 0.0 }
    ];
    W.floorState.plates = [];
    for (const pd of P3) {
      const band = L.plate3[pd.kind];
      const plate = {
        id: pd.id, kind: pd.kind, x: pd.x, z: pd.z, band: { min: band[0], max: band[1] },
        active: false, cool: 0, lastV: 0, insideBy: {}, barT: 0,
        kindColor: pd.colHex
      };
      // плита-стенка: квадрат 1.2×1.2 «лицом» к центру, толщина 0.4
      const ang = Math.atan2(pd.z, pd.x) + Math.PI / 2;   // ориентация грани к центру
      const hgt = 1.2, thk = 0.4;
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(1.2, hgt, thk),
        new THREE.MeshStandardMaterial({ color: 0x2a3348, metalness: 0.5, roughness: 0.35, emissive: pd.colHex, emissiveIntensity: 0.55 }));
      const rotY = -Math.atan2(pd.z, pd.x) + Math.PI / 2;
      mesh.position.set(pd.x, y + hgt / 2, pd.z);
      mesh.rotation.y = rotY;
      F.add(mesh);
      plate.mesh = mesh;
      plate.rotY = rotY;
      // физика: две капсулы вдоль ширины плиты (грань к центру — любая ориентация)
      const wx = Math.cos(rotY), wz = -Math.sin(rotY);
      for (let hy = 0.35; hy <= 0.95; hy += 0.5) {
        addFloorCol(makeCapsule('plate3_' + pd.id + '_' + hy,
          { x: pd.x - 0.55 * wx, y: y + hy, z: pd.z - 0.55 * wz },
          { x: pd.x + 0.55 * wx, y: y + hy, z: pd.z + 0.55 * wz }, 0.21, { e: 0.55, group: 'plate3' }));
      }
      const glow = ringMesh(0.95, 0.06, pd.colHex, 0.85);
      glow.rotation.x = -Math.PI / 2;
      glow.position.set(pd.x, y + 0.06, pd.z);
      F.add(glow);
      plate.ring = glow;
      makePlateBar(plate);
      drawPlateBar(plate, -1);
      W.floorState.plates.push(plate);
    }

    // индикатор люка: три квадратика над заглушкой
    {
      const cv = document.createElement('canvas');
      cv.width = 160; cv.height = 56;
      const tex = new THREE.CanvasTexture(cv);
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0.95, depthWrite: false }));
      sp.scale.set(2.0, 0.7, 1);
      sp.position.set(0, y + 2.3, 0);
      F.add(sp);
      W.floorState.hatchSprite = { cv, tex, sprite: sp };
    }

    // ---------- шары-помехи (L6+) ----------
    W.floorState.hazards = [];
    const hz = L.hazards || 0;
    const spots = hz === 1 ? [[0, -6.1]] : [[4.4, -6.2], [-4.4, -6.2]];
    for (let i = 0; i < hz; i++) {
      const b = makeFloorBall({
        name: 'Hz' + (i + 1), x: spots[i][0], y: y + 0.62 * K(), z: spots[i][1],
        r: 0.62, colorIdx: (i + 1) % 3, mounted: false
      });
      b.hazard = true;
      W.floorState.hazards.push(b);
    }
    drawHatchSprite();
  }

  function drawHatchSprite() {
    const hs = W.floorStates[2] && W.floorStates[2].hatchSprite;
    if (!hs || !hs.cv.getContext) return;
    const g = hs.cv.getContext('2d');
    g.clearRect(0, 0, 160, 56);
    const plates = W.floorStates[2].plates || [];
    for (let i = 0; i < 3; i++) {
      g.fillStyle = (plates[i] && plates[i].active) ? '#00ff88' : 'rgba(255,255,255,0.16)';
      g.fillRect(28 + i * 36, 12, 26, 26);
      g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = 2;
      g.strokeRect(28 + i * 36, 12, 26, 26);
    }
    hs.tex.needsUpdate = true;
  }

  // термометр скорости над плитой (v<0 — пустой)
  function makePlateBar(plate) {
    const cv = document.createElement('canvas');
    cv.width = 64; cv.height = 160;
    const tex = new THREE.CanvasTexture(cv);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0, depthWrite: false }));
    sp.scale.set(0.75, 1.9, 1);
    sp.position.set(plate.x, LEVEL_CONFIG.platformB.y + 2.0, plate.z);
    if (W.floorViz && W.floorViz[2]) W.floorViz[2].add(sp);
    plate.cv = cv; plate.tex = tex; plate.sprite = sp;
    drawPlateBar(plate, -1);
  }

  function drawPlateBar(plate, v) {
    const g = plate.cv && plate.cv.getContext && plate.cv.getContext('2d');
    if (!g) return;
    g.clearRect(0, 0, 64, 160);
    g.fillStyle = 'rgba(4,10,24,0.75)';
    g.fillRect(18, 8, 28, 144);
    if (v >= 0) {
      const VMAX = 14;
      const hgt = clamp(v / VMAX, 0, 1) * 140;
      let col = '#ff5566';
      if (v >= plate.band.min && v <= plate.band.max) col = '#00ff88';
      else if (v > plate.band.max) col = '#ffcc00';
      g.fillStyle = col;
      g.fillRect(20, 150 - hgt, 24, hgt);
    }
    const yOf = w => 150 - clamp(w / 14, 0, 1) * 140;
    g.strokeStyle = 'rgba(255,255,255,0.75)'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(16, yOf(plate.band.min)); g.lineTo(48, yOf(plate.band.min)); g.stroke();
    g.beginPath(); g.moveTo(16, yOf(plate.band.max)); g.lineTo(48, yOf(plate.band.max)); g.stroke();
    plate.tex.needsUpdate = true;
  }

  // v4.2: удар в плиту-стенку. ball — игровой ИЛИ чужой свободный шар
  function plateImpact(ball, plate) {
    if (plate.cool > 0) return;
    let v = ball.v.length();
    // v4.2: быстрый шар успевает воткнуться в капсулу грани в том же кадре,
    // что и вход в зону удара, — к моменту проверки ball.v уже «съеден»
    // отскоком. Скорость удара сохранил резолвер (b.impact: нормаль капсулы
    // грани совпадает с нормалью грани) — берём её, если она больше.
    if (ball.touched && (ball.impact || 0) > v) {
      for (const k in ball.touched) {
        if (k.indexOf('plate3_' + plate.id + '_') === 0) { v = ball.impact; break; }
      }
    }
    plate.lastV = v;
    plate.cool = 0.45;
    plate.barT = 0.65;
    drawPlateBar(plate, v);
    if (plate.sprite) plate.sprite.material.opacity = 1;
    const inBand = v >= plate.band.min && v <= plate.band.max;
    const bandStr = plate.band.min.toFixed(1) + '–' + plate.band.max.toFixed(1);

    if (ball.isPlayer) {
      if (plate.active) return;                       // активную игрок не гасит
      if (inBand) {
        plate.active = true;
        if (plate.mesh) { plate.mesh.material.emissive.setHex(0x00ff88); plate.mesh.material.emissiveIntensity = 1.6; }
        if (plate.ring) plate.ring.material.color.setHex(0x00ffaa);
        Sound.plateOk();
        toast(D().plateOn[plate.kind].replace('{v}', bandStr), 'good', 1500);
        addScore(150, curLang === 'ru' ? 'плита' : 'plate');
        W.events.push({ t: W.time, type: 'plateOn', plate: plate.id, v: v, by: 'player' });
        drawHatchSprite();
        checkPlatesSolved();
      } else if (v < plate.band.min) {
        toast(D().plateTooWeak.replace('{v}', bandStr), 'warn', 1200);
        Sound.plateBad();
        ball.v.multiplyScalar(0.7);
        W.runStats.plateFails++;
        W.events.push({ t: W.time, type: 'plateMiss', plate: plate.id, v: v, why: 'weak' });
      } else {
        toast(D().plateTooStrong.replace('{v}', bandStr), 'warn', 1200);
        Sound.plateBad();
        ball.v.multiplyScalar(0.9);
        W.runStats.plateFails++;
        W.events.push({ t: W.time, type: 'plateMiss', plate: plate.id, v: v, why: 'strong' });
      }
      return;
    }

    // чужой свободный шар той же силой: активную ГАСИТ, неактивную — включает
    if (!inBand) return;
    if (plate.active) {
      plate.active = false;
      if (plate.mesh) { plate.mesh.material.emissive.setHex(plate.kindColor); plate.mesh.material.emissiveIntensity = 0.55; }
      if (plate.ring) plate.ring.material.color.setHex(plate.kindColor);
      Sound.defeat();
      doShake(true);
      drawHatchSprite();
      W.events.push({ t: W.time, type: 'plateOff', plate: plate.id, v: v, by: ball.name });
      const st2 = W.floorStates[2];
      if (st2 && !st2.deactShown) {
        st2.deactShown = true;
        askFloorFail('plate');
      } else {
        toast(D().plateOff, 'bad', 1800);
      }
    } else {
      plate.active = true;
      if (plate.mesh) { plate.mesh.material.emissive.setHex(0x00ff88); plate.mesh.material.emissiveIntensity = 1.6; }
      if (plate.ring) plate.ring.material.color.setHex(0x00ffaa);
      Sound.plateOk();
      drawHatchSprite();
      W.events.push({ t: W.time, type: 'plateOn', plate: plate.id, v: v, by: ball.name });
      checkPlatesSolved();
    }
  }

  function checkPlatesSolved() {
    const st = W.floorStates[2];
    if (!st || !st.plates || st.solved) return;
    if (st.plates.every(q => q.active)) onFloorSolved();
  }

  // ежекадровая логика плит: вход в расширенную зону плиты = удар
  function updatePlates(dt) {
    const plates = W.floorState && W.floorState.plates;
    if (!plates) return;
    const live = (W.state === 'play') && !inTransition();
    const st2 = W.floorStates[2];
    if (st2 && st2.plPulse > 0) {                        // v4.2: обучение — пульс плит
      st2.plPulse -= dt;
      const pk = 0.55 + 0.5 * (0.5 + 0.5 * Math.sin(W.time * 7));
      for (const p of plates) {
        if (!p.active && p.mesh && p.mesh.material) p.mesh.material.emissiveIntensity = pk;
      }
    }
    for (const p of plates) {
      if (p.cool > 0) p.cool -= dt;
      if (p.barT > 0) {
        p.barT -= dt;
        if (p.sprite) p.sprite.material.opacity = clamp(p.barT / 0.3, 0, 1);
      }
      if (!live) continue;
      const py = LEVEL_CONFIG.platformB.y;
      const ct = Math.cos(p.rotY || 0), sn = Math.sin(p.rotY || 0);
      for (const b of W.balls) {
        if (!b.alive || b.kinematic || b.inTrap) continue;
        if (!b.isPlayer && (b.floor !== 2 || b.pipeType)) continue;   // чужие — только шары этого этажа
        const dx = b.p.x - p.x, dz = b.p.z - p.z;
        const lx = dx * ct - dz * sn;                     // вдоль ширины плиты
        const lz = dx * sn + dz * ct;                     // вдоль толщины (нормаль грани)
        const mW = 0.6 + b.r + 0.07, mN = 0.2 + b.r + 0.07, mY = 0.6 + b.r + 0.07;
        const inside = Math.abs(lx) < mW && Math.abs(lz) < mN && Math.abs(b.p.y - (py + 0.6)) < mY;
        const key = b.isPlayer ? 'P' : b.name;
        if (inside && !p.insideBy[key]) {
          p.insideBy[key] = true;
          if (p.cool <= 0) plateImpact(b, p);
        } else if (!inside && p.insideBy[key]) {
          p.insideBy[key] = false;
        }
      }
    }
    // поток к люку после решения
    const st = W.floorStates[2];
    if (st && st.solved && W.currentFloor === 2) {
      const g = W.floorGates[2];
      const pl = W.player;
      if (g && g.opened && !g.pulled && !W.autoPull && pl && pl.alive && W.state === 'play' &&
          pl.p.y < LEVEL_CONFIG.platformB.y + 3 && pl.p.y > LEVEL_CONFIG.platformB.y - 0.5 && !inTransition()) {
        startAutoPull(2);
      }
    }
  }

  // v4.2: рестарт этажа «Резонанс» (кнопка/модалка)
  function restartResonanceFloor() {
    const st = W.floorStates[2];
    if (!st) return;
    for (const p of (st.plates || [])) {
      p.active = false; p.cool = 0; p.lastV = 0; p.insideBy = {};
      if (p.mesh) { p.mesh.material.emissive.setHex(p.kindColor); p.mesh.material.emissiveIntensity = 0.55; }
      if (p.ring) p.ring.material.color.setHex(p.kindColor);
      drawPlateBar(p, -1);
    }
    for (const b of (st.hazards || [])) respawnBallHome(b);
    drawHatchSprite();
    // люк закрывается, флаг решения снимается
    closeGate(2);
    setFloorSolvedFlag(2, false);
    // шар на точку входа этажа
    const pl = W.player;
    if (pl && W.floorEntry) {
      pl.p.copy(W.floorEntry);
      pl.v.set(0, 0, 0);
      pl.kinematic = false; pl.mounted = false;
      pl.returning = false; pl.idleT = 0;
      W.trapTimer = -1;
    }
    W.autoPull = null;
    toast(D().floorRestarted, 'good', 1600);
    Sound.ui();
    W.events.push({ t: W.time, type: 'floorRestart', floor: 2 });
  }

  // ===========================================================================
  // v4.2: НЕВЫПОЛНИМЫЙ ЭТАЖ — модалка «заново / в меню»
  // ===========================================================================
  function askFloorFail(reason) {
    if (W.ffOpen || W.state !== 'play') return;
    W.ffOpen = true;
    W.ffReason = reason;
    if (W.player) W.player.v.set(0, 0, 0);
    if (el.ff_title) el.ff_title.textContent = D().ffTitle;
    if (el.ff_desc) el.ff_desc.textContent = (reason === 'plate') ? D().ffPlate : D().ffNoBalls;
    W.events.push({ t: W.time, type: 'floorFail', reason: reason });
    Sound.defeat();
    if (typeof App !== 'undefined' && App.syncModals) App.syncModals();
  }

  // v4.2: хватает ли на этаже 0 шаров, чтобы закрыть все лунки?
  // (шары стоят в патронташах примагниченными — они доступны; недоступны
  //  только растворённые/взорванные/утонувшие и тела-загадки ядра)
  function floor0Winnable() {
    const st = W.floorStates && W.floorStates[0];
    if (!st || !st.sockets) return true;
    const need = [0, 0, 0];
    let anyNeed = false;
    for (const sk of st.sockets) {
      if (!sk.full) { need[sk.color] += Math.max(0, (sk.target || 0) - (sk.count || 0)); anyNeed = true; }
    }
    if (!anyNeed) return true;
    const have = [0, 0, 0];
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer || b.dissolving || b.countedLost || b.inTrap) continue;
      if (b.colorIdx === null || b.colorIdx === undefined || b.colorIdx < 0) continue;
      if (W.bodies && W.bodies.indexOf(b) >= 0) continue;          // тела-загадки на орбите ядра
      if (b.floor !== undefined && b.floor !== null && b.floor !== 0) continue;
      have[b.colorIdx]++;
    }
    const inSocket = [0, 0, 0];
    for (const sk of st.sockets) inSocket[sk.color] += (sk.count || 0);   // уже стоят в лунках
    return need.every((n, c) => n <= have[c] - inSocket[c]);
  }

  // ===========================================================================
  // v4.2: видимость пройденных этажей — скрыть или «призрак» (кнопка ЭТАЖИ)
  // ===========================================================================
  function setGroupGhost(group, on) {
    if (!group) return;
    group.traverse(o => {
      if (!o.isMesh || !o.material) return;
      if (on) {
        if (o.userData._origMat) return;
        const src = o.material;
        const m = src.clone();
        m.transparent = true;
        m.opacity = (src.opacity !== undefined ? src.opacity : 1) * 0.3;
        if (m.emissiveIntensity !== undefined && src.emissiveIntensity !== undefined) m.emissiveIntensity = src.emissiveIntensity * 0.35;
        o.userData._origMat = src;
        o.material = m;
      } else {
        if (!o.userData._origMat) return;
        const m = o.material;
        o.material = o.userData._origMat;
        delete o.userData._origMat;
        if (m && m.dispose) m.dispose();
      }
    });
    group.userData._ghost = !!on;
  }

  function syncFloorViz() {
    if (!W.floorViz) return;
    for (let i = 0; i < 4; i++) {
      const g = W.floorViz[i];
      const passed = !!(W.floorSolvedArr && W.floorSolvedArr[i]) && i !== W.currentFloor;
      if (!passed) {
        if (g.userData._ghost) setGroupGhost(g, false);
        g.visible = true;
      } else if (W.floorsGhost) {
        g.visible = true;
        if (!g.userData._ghost) setGroupGhost(g, true);
      } else {
        if (g.userData._ghost) setGroupGhost(g, false);
        g.visible = false;
      }
    }
  }

  function setFloorSolvedFlag(idx, v) {
    if (!W.floorStates) return;
    const wasCur = W.currentFloor;
    W.currentFloor = idx; W.floorState = W.floorStates[idx];
    setSolvedFlag(v);
    W.currentFloor = wasCur; W.floorState = W.floorStates[wasCur];
    W.floorSolvedFlag = W.floorSolvedArr[wasCur];
  }

  function buildFloorCore() {
    const B = LEVEL_CONFIG.platformB;
    const S = LEVEL_CONFIG.shield;
    const F = W.floorGroup;
    W.floorState = W.floorStates[3];
    // v4.1: своего диска у этажа нет — платформа нырка это постоянный диск
    // этажа 2 (башня не разбирается, перемотка возвращает на него же).
    // световой «маяк»: направление нырка от люка к смещённому ядру
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, Math.hypot(B.y - 0.8 - S.y, S.x, S.z), 8),
      new THREE.MeshBasicMaterial({ color: 0xd946ef, transparent: true, opacity: 0.4, depthWrite: false, blending: THREE.AdditiveBlending }));
    const from = new THREE.Vector3(0, B.y - 0.8, 0), to = new THREE.Vector3(S.x, S.y, S.z);
    beam.position.copy(from).add(to).multiplyScalar(0.5);
    beam.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), to.clone().sub(from).normalize());
    F.add(beam);
    const ring = ringMesh(1.25, 0.06, 0xff3355, 0.7);
    ring.position.set(0, B.y - 0.62, 0);
    F.add(ring);
  }

  // ===========================================================================
  // ЛОГИКА ЭТАЖА: решение, переходы
  // ===========================================================================
  // переход идёт прямо сейчас? (сам объект W.floorTransition живёт и после)
  function inTransition() { return !!(W.floorTransition && W.floorTransition.active); }

  function setSolvedFlag(v) {
    W.floorSolvedFlag = v;
    if (W.floorSolvedArr) W.floorSolvedArr[W.currentFloor] = v;
    if (W.floorState) W.floorState.solved = v;
  }

  function onFloorSolved() {
    if (W.floorSolvedFlag || !W.floorState) return;
    setSolvedFlag(true);
    addScore(300, D().floorScore);
    openFloorGate();
    toast(D().floorSolved, 'good');
    W.events.push({ t: W.time, type: 'floorSolved', floor: W.currentFloor });
  }

  // ежекадровая логика этажей (из updateTriggers)
  function updateFloorState(dt) {
    if (!W.floorState) return;
    // кулдауны лунок/плит
    for (const b of W.balls) if (b.socketCd > 0) b.socketCd -= dt;
    // v4.0: зоны лунок — свободный шар в круге гнезда = попытка вставить
    if (W.currentFloor === 0 && W.floorState.sockets && !inTransition()) {
      const A = LEVEL_CONFIG.platformA;
      for (const sk of W.floorState.sockets) {
        if (sk.full) continue;
        const rr = (1.2 * K()) - 0.15;
        for (const b of W.balls) {
          if (!b.alive || b.kinematic || b.dissolving) continue;
          if (b.p.y > A.y + 1.6 || b.p.y < A.y - 0.2) continue;
          const dx = b.p.x - sk.x, dz = b.p.z - sk.z;
          if (dx * dx + dz * dz < rr * rr) socketTryInsert(b, sk);
        }
      }
    }
    // v4.2: этажи «Труба» и «Резонанс»
    if (W.currentFloor === 1 && W.floorState && W.floorState.pipe) updatePipe(dt);
    if (W.floorState && W.floorState.plates) updatePlates(dt);
    updateAutoPull(dt);
    // белый шар «проглочен» мишенью дороги → перемотка как из ловушки
    if (W.player && W.player._pipeTrapT > 0 && W.state === 'play' && !inTransition()) {
      W.player._pipeTrapT -= dt;
      if (W.player._pipeTrapT <= 0) {
        W.player._pipeTrapT = 0;
        if (W.player.p.y < LEVEL_CONFIG.floorPipeY + 1.2) {
          W.events.push({ t: W.time, type: 'pipeSwallowPlayer' });
          startRewind('pipe');
        }
      }
    }
    // шары-помехи, упавшие в открытый люк, исчезают без последствий
    if (W.floorStates && W.floorStates[2] && W.floorStates[2].hazards) {
      for (const b of W.floorStates[2].hazards) {
        if (b.alive && b.p.y < LEVEL_CONFIG.platformB.y - 1.2) {
          b.alive = false;
          if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
          if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
          W.events.push({ t: W.time, type: 'hazardGone', name: b.name });
        }
      }
    }
    // v4.2: не хватает шаров для лунок этажа 0 → вопрос игроку
    if (W.currentFloor === 0 && W.state === 'play' && !inTransition() && !W.floorSolvedFlag && !W.ffOpen) {
      W._noBallCheckT = (W._noBallCheckT || 0) + dt;
      if (W._noBallCheckT > 0.5) {
        W._noBallCheckT = 0;
        if (!floor0Winnable()) askFloorFail('noBalls');
      }
    }
    // переход: этаж решён и шар провалился ниже плоскости этажа
    if (W.state === 'play' && !inTransition() && W.floorSolvedFlag && W.currentFloor < 3) {
      const pl = W.player;
      if (pl && pl.alive && pl.p.y < floorY(W.currentFloor) - 0.9) {
        startFloorTransition(W.currentFloor + 1);
      }
    }
    if (W.floorTransition && W.floorTransition.active) {
      const tr = W.floorTransition;
      tr.t += dt;
      // «дыхание» камеры
      W.camBreath = Math.sin(Math.min(tr.t / tr.dur, 1) * Math.PI) * 10;
      if (tr.t >= tr.dur * 0.5 && !tr.toastShown) {
        tr.toastShown = true;
        const names = D().floorNames;
        toast(D().floorOf.replace('{n}', String(tr.to + 1)).replace('{name}', names[tr.to]), 'magic', 1800);
        // подсказка этажа — один раз за проход; v4.1: hints 0 — текстовые подсказки этажа выкл
        if (LV().hints >= 1 && W.visited && !W.visited.floors[tr.to]) {
          W.visited.floors[tr.to] = true;
          setTimeout(() => {
            if (W.state === 'play') toast(D()['floor' + tr.to + 'Hint'], 'magic', 3200);
          }, 900);
        }
      }
      if (tr.t >= tr.dur) {
        tr.active = false;
        W.camBreath = 0;
      }
    }
  }

  function startFloorTransition(to) {
    to = clamp(to | 0, 0, 3);
    W.events.push({ t: W.time, type: 'floorTransition', from: W.currentFloor, to: to });
    if (to === 3 && W.runStats) W.runStats.dives++;
    buildFloor(to);                               // v4.1: вход мгновенный, башня не пересобирается
    W.floorTransition = { active: true, t: 0, dur: LEVEL_CONFIG.floors.transitionDur, to: to, toastShown: false };
    applyFloorPalette(to);
    if (to > 0) W.ropeCut = true;                 // трос остался наверху
    // v4.2: подсветка-обучение при первом заходе на этаж
    if (to === 1 && W.floorStates[1] && W.floorStates[1].pipe) {
      const rdA = W.floorStates[1].pipe.roads[0];
      if (rdA && rdA.layout && rdA.hatch) rdA.pulseT = 3.4;
    }
    if (to === 2 && W.floorStates[2] && W.floorStates[2].plates) {
      W.floorStates[2].plPulse = 3.4;
    }
    syncFloorViz();                               // v4.2: пройденный этаж исчезает
  }

  function makeBall(opts) {
    const b = new Ball(opts);
    const mat = (b.isPlayer || b.colorIdx < 0) ? MAT.player.clone() : MAT.palette[b.colorIdx].clone();
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(b.baseR, 28, 20), mat);
    mesh.scale.setScalar(SETTINGS.ballSize);
    mesh.position.copy(b.p);
    mesh.name = b.name;
    W.glassGroup.add(mesh);
    b.mesh = mesh;

    // ореол
    const glow = new THREE.Mesh(new THREE.SphereGeometry(b.baseR * 1.28, 16, 12),
      new THREE.MeshBasicMaterial({
        color: b.isPlayer ? 0x88ddff : b.colorNum, transparent: true, opacity: b.isPlayer ? 0.2 : 0.12,
        depthWrite: false, blending: THREE.AdditiveBlending
      }));
    glow.scale.setScalar(SETTINGS.ballSize);
    mesh.add(glow);
    b.glow = glow;

    // кольцо заряда магии
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.82, 1.0, 40), MAT.ring.clone());
    ring.visible = false;
    ring.renderOrder = 3;
    W.glassGroup.add(ring);
    b.ring = ring;

    W.balls.push(b);
    return b;
  }

  // ===========================================================================
  // 12. ФИЗИКА
  // ===========================================================================
  const _gLocal = new THREE.Vector3();
  const _qInv = new THREE.Quaternion();
  const _tv = new THREE.Vector3();
  const _tv2 = new THREE.Vector3();

  function freeBalls() { return W.balls.filter(b => b.alive && !b.kinematic); }
  function minBallRadius() {
    let m = 99;
    for (const b of W.balls) if (b.alive && b.r < m) m = b.r;
    return m === 99 ? 0.4 : m;
  }

  function updateKinematic(h) {
    const S = LEVEL_CONFIG.shield;
    for (const b of W.balls) {
      if (!b.alive || !b.kinematic) continue;
      if (b.orbit) {
        const a = b.orbitPhase + W.orbitT * S.orbitOmega;
        const ca = Math.cos(a), sa = Math.sin(a);
        // v4.0: орбита вокруг смещённого ядра (S.x, S.z)
        b.p.set(S.x + ca * (S.orbitRadius * K()), S.y, S.z + sa * (S.orbitRadius * K()));
        b.kinV.set(-sa * S.orbitOmega * (S.orbitRadius * K()), 0, ca * S.orbitOmega * (S.orbitRadius * K()));
        b.v.copy(b.kinV);
        if (b.mesh) b.mesh.position.copy(b.p);
      } else if (b.mounted) {
        b.p.copy(b.mountPos);
        b.v.set(0, 0, 0);
        b.kinV.set(0, 0, 0);
      }
    }
  }

  function collideBalls(a, c, dt) {
    const dx = c.p.x - a.p.x, dy = c.p.y - a.p.y, dz = c.p.z - a.p.z;
    const rr = a.r + c.r;
    const d2 = dx * dx + dy * dy + dz * dz;
    if (d2 >= rr * rr || d2 < 1e-10) return;
    const d = Math.sqrt(d2);
    const nx = dx / d, ny = dy / d, nz = dz / d;
    const overlap = rr - d;
    const wa = a.kinematic ? 0 : 1 / a.m;
    const wc = c.kinematic ? 0 : 1 / c.m;
    const wsum = wa + wc;
    if (wsum <= 0) { W.contacts.push([a, c]); return; }

    a.p.x -= nx * overlap * (wa / wsum); a.p.y -= ny * overlap * (wa / wsum); a.p.z -= nz * overlap * (wa / wsum);
    c.p.x += nx * overlap * (wc / wsum); c.p.y += ny * overlap * (wc / wsum); c.p.z += nz * overlap * (wc / wsum);

    const rvx = c.v.x - a.v.x, rvy = c.v.y - a.v.y, rvz = c.v.z - a.v.z;
    const vn = rvx * nx + rvy * ny + rvz * nz;
    if (vn < 0) {
      const e0 = LEVEL_CONFIG.physics.restitutionBall;
      const e = (-vn < 1.2) ? e0 * clamp((-vn - 0.2) / 1.0, 0, 1) : e0;
      const j = -(1 + e) * vn / wsum;
      a.v.x -= nx * j * wa; a.v.y -= ny * j * wa; a.v.z -= nz * j * wa;
      c.v.x += nx * j * wc; c.v.y += ny * j * wc; c.v.z += nz * j * wc;
      const imp = -vn;
      if (imp > (a.impact || 0)) a.impact = imp;
      if (imp > (c.impact || 0)) c.impact = imp;
    }
    W.contacts.push([a, c]);
    a.touched[c.name] = true; c.touched[a.name] = true;

    // Примагниченный шар освобождается от касания любого свободного шара
    if (a.mounted && !c.mounted) a.demount('touch:' + c.name);
    if (c.mounted && !a.mounted) c.demount('touch:' + a.name);
  }

  function stepPhysics(dt) {
    const P = LEVEL_CONFIG.physics;
    const maxV = P.maxSpeed * Math.max(1, SETTINGS.ballSpeed);

    // гравитация в локальной системе стакана (наклон = поворот вектора g)
    _qInv.copy(W.glassGroup.quaternion).invert();
    _gLocal.set(0, -P.gravity, 0).applyQuaternion(_qInv);
    // v4.1: модификатор уровня — ускорение игрового шара (L10: ×1.1)
    const boost = LV().ballBoost || 1.0;

    // CCD: число подшагов так, чтобы перемещение за подшаг было << радиуса шара
    const mR = minBallRadius();
    const sub = clamp(Math.ceil((maxV * dt) / (0.28 * mR)), 4, 26);
    const h = dt / sub;

    for (const b of W.balls) { if (b.alive) b.touched = {}; }
    W.contacts.length = 0;

    for (let s = 0; s < sub; s++) {
      W.orbitT += h;
      updateKinematic(h);

      for (const b of W.balls) {
        if (!b.alive || b.kinematic) continue;
        b.contact = false;
        // интеграция
        const gk = (b.isPlayer && boost > 1) ? boost : 1;
        b.v.x += _gLocal.x * h * gk; b.v.y += _gLocal.y * h * gk; b.v.z += _gLocal.z * h * gk;
        const dragK = Math.max(0, 1 - P.airDrag * h);
        b.v.multiplyScalar(dragK);
        const sp = b.v.length();
        const cap = b.isPlayer ? maxV * SETTINGS.ballSpeed : maxV;
        if (sp > cap) b.v.multiplyScalar(cap / sp);
        b.p.x += b.v.x * h; b.p.y += b.v.y * h; b.p.z += b.v.z * h;

        // коллайдеры уровня
        for (let i = 0; i < W.colliders.length; i++) collideOne(b, W.colliders[i], h);

        // аварийный возврат в стакан
        if (b.p.y > LEVEL_CONFIG.glass.yTop + 3) { b.p.y = LEVEL_CONFIG.glass.yTop + 3; if (b.v.y > 0) b.v.y = -b.v.y * 0.3; }
        const rr = Math.hypot(b.p.x, b.p.z);
        if (rr > LEVEL_CONFIG.glass.radius + 1) {
          const k = (LEVEL_CONFIG.glass.radius + 1) / rr;
          b.p.x *= k; b.p.z *= k;
          b.v.x *= -0.4; b.v.z *= -0.4;
        }
        if (b.p.y < LEVEL_CONFIG.glass.yBottom - 1) { b.p.y = LEVEL_CONFIG.glass.yBottom - 1; b.v.y = Math.abs(b.v.y) * 0.3; }
      }

      // шар-шар
      const n = W.balls.length;
      for (let i = 0; i < n; i++) {
        const a = W.balls[i];
        if (!a.alive) continue;
        for (let j = i + 1; j < n; j++) {
          const c = W.balls[j];
          if (!c.alive) continue;
          if (a.kinematic && c.kinematic) continue;
          const dx = c.p.x - a.p.x, dy = c.p.y - a.p.y, dz = c.p.z - a.p.z;
          const rr2 = a.r + c.r;
          if (dx * dx + dy * dy + dz * dz < rr2 * rr2) collideBalls(a, c, h);
        }
      }
    }

    // вращение для визуала (качение)
    for (const b of W.balls) {
      if (!b.alive) continue;
      const sp = b.v.length();
      if (b.contact && sp > 0.02) {
        _tv.copy(b.v).normalize();
        _tv2.crossVectors(b.contactN, _tv);
        if (_tv2.lengthSq() > 1e-8) { b.spinAxis.copy(_tv2).normalize(); b.spinRate = sp / Math.max(0.05, b.r); }
      } else {
        b.spinRate *= 0.94;
      }
      b.lastSpeed = sp;
    }
  }

  // ===========================================================================
  // 13. МАГИЯ: match-3 с таймером 10 с
  //     Правила ТЗ: два свободных шара одного цвета коснулись → оба заряжаются
  //     (кольцо сужается, зеленеет→краснеет). Если за 10 с их коснётся третий
  //     того же цвета — взрываются ВСЕ шары цвета в этой цепочке (3, 4, 5…).
  //     Не успели — магия гаснет. Примагниченные и белый игровой шар не участвуют.
  // ===========================================================================
  const Magic = {
    /** компоненты связности по касаниям среди свободных цветных шаров */
    components() {
      // v4.0: шары цепочки/мины/вставленные в лунки помечены noMagic
      const pool = W.balls.filter(b => b.alive && !b.kinematic && b.colorIdx >= 0 && !b.dissolving && !b.noMagic);
      const seen = new Set();
      const comps = [];
      for (const b of pool) {
        if (seen.has(b.id)) continue;
        const stack = [b], comp = [];
        seen.add(b.id);
        while (stack.length) {
          const x = stack.pop();
          comp.push(x);
          for (const y of pool) {
            if (y === x || seen.has(y.id) || y.colorIdx !== x.colorIdx) continue;
            const dx = y.p.x - x.p.x, dy = y.p.y - x.p.y, dz = y.p.z - x.p.z;
            const rr = x.r + y.r + 0.06;               // небольшой допуск: касание
            if (dx * dx + dy * dy + dz * dz <= rr * rr) { seen.add(y.id); stack.push(y); }
          }
        }
        comps.push(comp);
      }
      return comps;
    },

    update(dt) {
      const MT = SETTINGS.magicTime;

      // v4.0: каскад — отложенные эхо-взрывы
      if (W.echoQueue && W.echoQueue.length) {
        for (let i = W.echoQueue.length - 1; i >= 0; i--) {
          const e = W.echoQueue[i];
          e.t -= dt;
          if (e.t <= 0) {
            W.echoQueue.splice(i, 1);
            const alive = e.balls.filter(b => b.alive && !b.kinematic && b.colorIdx === e.color && !b.noMagic && !b.dissolving);
            if (alive.length) this.explode(alive, true);
          }
        }
      }

      // таймеры заряда
      for (const b of W.balls) {
        if (!b.alive || b.chargeT <= 0) continue;
        b.chargeT -= dt;
        if (b.chargeT <= 0) {
          b.chargeT = 0;
          if (b.ring) b.ring.visible = false;
          W.magicFaded = true;
        }
      }

      const comps = this.components();

      // Шар, который сейчас НЕ входит в одноцветную пару, снова «вооружён»:
      // следующее касание зарядит его заново.
      const inGroup = new Set();
      for (const comp of comps) {
        if (comp.length < 2) continue;
        for (const b of comp) inGroup.add(b.id);
      }
      for (const b of W.balls) {
        if (b.alive && !inGroup.has(b.id)) b.chargeArmed = true;
      }

      for (const comp of comps) {
        if (comp.length >= 3) { this.explode(comp); continue; }
        if (comp.length === 2) {
          // Заряд — только ПО ФРОНТУ касания. Раньше условие «chargeT <= 0 → MT»
          // срабатывало каждый кадр, пока шары не разошлись: таймер истекал и
          // тут же перезапускался, то есть магия не гасла никогда. По ТЗ истёк
          // таймер — магия пропадает, и для нового заряда нужно касаться снова.
          let started = false;
          for (const b of comp) {
            if (!b.chargeArmed) continue;
            b.chargeT = MT;
            b.chargeArmed = false;
            started = true;
          }
          if (started) {
            Sound.charge();
            const cname = D()['color' + cap(LEVEL_CONFIG.palette[comp[0].colorIdx].id)];
            toast(D().toastCharge.replace('{c}', cname).replace('{t}', MT.toFixed(0)), 'magic');
            W.events.push({ t: W.time, type: 'charge', color: comp[0].colorIdx, names: comp.map(b => b.name) });
          }
        }
      }

      // визуал колец заряда
      for (const b of W.balls) {
        if (!b.alive || !b.ring) continue;
        if (b.chargeT > 0) {
          const k = clamp(b.chargeT / MT, 0, 1);
          b.ring.visible = true;
          const scale = b.r * (1.18 + 0.85 * k);
          b.ring.scale.setScalar(scale);
          const c = new THREE.Color(0xff2233).lerp(new THREE.Color(0x00ff88), k);
          b.ring.material.color.copy(c);
          b.ring.material.opacity = 0.55 + 0.35 * Math.sin(W.time * 11);
          if (b.mesh && b.mesh.material && b.mesh.material.emissive) {
            b.mesh.material.emissiveIntensity = 0.85 + 0.9 * (0.5 + 0.5 * Math.sin(W.time * 11));
          }
        } else {
          if (b.ring.visible) b.ring.visible = false;
          if (b.mesh && b.mesh.material && b.mesh.material.emissive && !b.isPlayer) {
            b.mesh.material.emissiveIntensity = 0.85;
          }
        }
      }

      if (W.magicFaded) {
        W.magicFaded = false;
        Sound.fade();
        toast(D().toastExpired, 'bad');
        W.events.push({ t: W.time, type: 'magicFade' });
      }
    },

    /** Взрыв цепочки: слоу-мо, вспышка, искры, арпеджио, тряска экрана */
    explode(comp, isEcho) {
      const colorIdx = comp[0].colorIdx;
      const colNum = LEVEL_CONFIG.palette[colorIdx].colorNum;
      const extra = comp.length - 3;
      W.blastCount++;
      W.magicCount = W.blastCount;
      if (isEcho) {
        // v4.0: каскад — очки без комбо
        const pts = 250 + extra * 60;
        W.score += pts;
        toast(D().cascade.replace('{n}', String(pts)), 'magic');
        W.events.push({ t: W.time, type: 'scoreEcho', amount: pts });
      } else {
        // v3.5: очки за магию (400 + 100 за каждый шар сверх трёх)
        addScore(400 + extra * 100, curLang === 'ru' ? 'магия' : 'magic');
      }

      W.slowmo = Math.max(W.slowmo, LEVEL_CONFIG.magic.slowmoTime);
      W.slowmoScale = LEVEL_CONFIG.magic.slowmoScale;
      W.screenShake = Math.max(W.screenShake, LEVEL_CONFIG.magic.screenShakeTime);
      W.screenShakeAmp = LEVEL_CONFIG.magic.screenShakeAmp;

      let cx = 0, cy = 0, cz = 0;
      for (const b of comp) { cx += b.p.x; cy += b.p.y; cz += b.p.z; }
      cx /= comp.length; cy /= comp.length; cz /= comp.length;

      // вспышка: шары белеют на 0.15 с и исчезают
      for (const b of comp) {
        b.flash = LEVEL_CONFIG.magic.flashTime;
        if (!isEcho) spawnShockwave(b.p.x, b.p.y, b.p.z, b.r * 2.4, colNum);
      }

      // импульс соседям (v4.0: шары цепочки/мины noMagic — взрыв их не расшатывает)
      const k = SETTINGS.impactForce * (isEcho ? 0.6 : 1);
      for (const b of W.balls) {
        if (!b.alive || comp.indexOf(b) >= 0 || b.noMagic) continue;
        const dx = b.p.x - cx, dy = b.p.y - cy, dz = b.p.z - cz;
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > 7 || d < 1e-6) continue;
        const f = (1 - d / 7) * 4.2 * k * (b.isPlayer ? SETTINGS.ballSpeed : 1);
        if (b.kinematic) { b.demount('blast'); }
        b.v.x += (dx / d) * f; b.v.y += (dy / d) * f + 0.6 * k; b.v.z += (dz / d) * f;
      }

      if (isEcho) {
        // v4.0: эхо — компактнее и быстрее
        spawnSparks(cx, cy, cz, Math.round((LEVEL_CONFIG.magic.sparks + extra * 8) * 0.6), LEVEL_CONFIG.magic.sparkSpeed * k * 1.3, colNum);
        spawnShockwave(cx, cy, cz, 3.2, colNum);
        Sound.boom(extra, true);
      } else {
        spawnSparks(cx, cy, cz, LEVEL_CONFIG.magic.sparks + extra * 8, LEVEL_CONFIG.magic.sparkSpeed * k, colNum);
        Sound.boom(extra);
      }

      const names = comp.map(b => b.name);
      setTimeoutBalls(comp);
      if (!isEcho) toast(D().toastBoom.replace('{n}', String(comp.length)), 'magic');
      W.events.push({ t: W.time, type: 'blast', color: colorIdx, count: comp.length, names: names, x: cx, y: cy, z: cz, echo: !!isEcho });
      W.lastBlast = { x: cx, y: cy, z: cz, color: colorIdx, count: comp.length };
      // v4.1: эхо включается с уровня 4 (LV().echo)
      if (isEcho && W.runStats) W.runStats.echoBlasts++;
      if (!isEcho && LV().echo) {
        const R2 = SETTINGS.echoRadius;
        const cands = [];
        for (const b of W.balls) {
          if (!b.alive || b.kinematic || b.noMagic || b.dissolving || b.colorIdx !== colorIdx || comp.indexOf(b) >= 0) continue;
          let near = false;
          for (const c of comp) {
            const dx = b.p.x - c.p.x, dy = b.p.y - c.p.y, dz = b.p.z - c.p.z;
            if (dx * dx + dy * dy + dz * dz <= R2 * R2) { near = true; break; }
          }
          if (near) cands.push(b);
        }
        if (cands.length) W.echoQueue.push({ t: SETTINGS.echoWindow, balls: cands, color: colorIdx });
      }
    }
  };

  function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

  function setTimeoutBalls(comp) {
    for (const b of comp) {
      b.alive = false;
      b.chargeT = 0;
      b.chargeArmed = true;
      if (b.mesh) { b.mesh.visible = false; if (b.mesh.parent) b.mesh.parent.remove(b.mesh); }
      if (b.ring) { b.ring.visible = false; if (b.ring.parent) b.ring.parent.remove(b.ring); }
    }
    const i = W.balls.indexOf(comp[0]);
    W.balls = W.balls.filter(x => x.alive);
    W.bodies = W.bodies.filter(x => x.alive);
    void i;
  }

  // ===========================================================================
  // 14. ВСТРЯСКА СТАКАНА
  // ===========================================================================
  function playerResting() {
    const b = W.player;
    if (!b || !b.alive) return false;
    const onSurface = b.touched['platformA'] || b.touched['platformB'] || b.touched['floorPipe'] || b.touched['net'] || b.touched['glassFloor'] || b.touched['button'];
    return b.contact && onSurface && b.v.length() < 0.3;
  }

  function doShake(force) {
    if (W.state !== 'play') return false;
    if (!force && W.shakeCd > 0) return false;
    if (W.runStats) W.runStats.shakes++;
    W.shakeCd = LEVEL_CONFIG.shake.cooldown;
    W.shakeVisual = LEVEL_CONFIG.shake.visualTime;
    W.shakeSeed = Math.random() * 1000;
    const k = SETTINGS.impactForce;
    let moved = 0;
    for (const b of W.balls) {
      if (!b.alive || b.kinematic) continue;
      if (b.isPlayer && playerResting()) continue;      // защита: покоящийся игровой шар не трясём
      const mag = rnd(LEVEL_CONFIG.shake.impulseMin, LEVEL_CONFIG.shake.impulseMax) * k;
      // направление: случайное, но НЕ вниз
      let x = rnd(-1, 1), y = rnd(0.1, 1), z = rnd(-1, 1);
      const l = Math.sqrt(x * x + y * y + z * z) || 1;
      const scale = b.isPlayer ? SETTINGS.ballSpeed : 1;
      b.v.x += (x / l) * mag * scale; b.v.y += (y / l) * mag * scale; b.v.z += (z / l) * mag * scale;
      moved++;
    }
    Sound.shake();
    W.screenShake = Math.max(W.screenShake, 0.18);
    W.screenShakeAmp = Math.max(W.screenShakeAmp, 0.12);
    toast(D().toastShake + ' (' + moved + ')', 'good');
    W.events.push({ t: W.time, type: 'shake', moved: moved });
    return true;
  }

  // ===========================================================================
  // 15. ЯДРО ЩИТА И ТРИ ТЕЛА
  // ===========================================================================
  function breakCore(byBall) {
    if (!W.coreAlive) return;
    W.coreAlive = false;
    W.coreCol.live = false;
    Sound.core();
    const S = LEVEL_CONFIG.shield;

    // осколки ядра
    spawnSparks(S.x, S.y, S.z, 40, 4.5 * SETTINGS.impactForce, 0xd946ef);
    spawnShockwave(S.x, S.y, S.z, (S.coreRadius * K()) * 4, 0xd946ef);
    if (W.coreGroup) W.coreGroup.visible = false;
    W.screenShake = Math.max(W.screenShake, 0.4);
    W.screenShakeAmp = 0.3;
    W.slowmo = Math.max(W.slowmo, 0.35);
    W.slowmoScale = 0.45;
    W.flashT = 0.25;                       // v3.5: вспышка tone-mapping
    W.failStreak = 0;                      // продвижение — серия фейлов сброшена
    addScore(500, curLang === 'ru' ? 'ядро' : 'core');

    // тела освобождаются: становятся динамическими с касательной скоростью 3 м/с
    for (const b of W.bodies) {
      if (!b.alive) continue;
      b.demount('coreBroken');
      b.orbit = false;
      b.kinematic = false;
      const rx = b.p.x - S.x, rz = b.p.z - S.z;
      const r = Math.hypot(rx, rz) || 1;
      const tx = -rz / r, tz = rx / r;
      const sp = S.releaseSpeed * SETTINGS.impactForce;
      b.v.set(tx * sp, rnd(-0.4, 0.6), tz * sp);
      if (b.mesh && b.mesh.material) b.mesh.material.emissiveIntensity = 1.4;
    }

    // шар, разбивший ядро, продолжает падение (§7.4). v4.0: ядро «гасит»
    // скорость нырка — иначе рикошет от сферы ядра отбрасывает шар от кнопки
    if (byBall && byBall.alive) {
      // v4.0: ядро полностью гасит снос и выносит шар на свою ось, НИЖЕ плоскости
      // орбиты тел — чистое короткое падение точно на кнопку (финал = нырок)
      byBall.v.set((Math.random() - 0.5) * 0.7, -4.0, (Math.random() - 0.5) * 0.7);
      byBall.p.set(S.x, Math.min(byBall.p.y, S.y), S.z);
      byBall.flash = 0.18;
      byBall.restT = 0; byBall.idleT = 0;
    }

    toast(D().toastCore, 'good');
    W.events.push({ t: W.time, type: 'coreBroken', by: byBall ? byBall.name : '' });
  }

  // ===========================================================================
  // 16. ТРОС
  // ===========================================================================
  function ropeHangPos(out) {
    const A = LEVEL_CONFIG.rope.anchor;
    const t = W.time;
    const sw = W.ropeCut ? 0 : LEVEL_CONFIG.rope.swing;
    const ax = Math.sin(t * 1.15) * sw * 0.6;
    const az = Math.cos(t * 0.83) * sw * 0.45;
    const L = W.ropeLen;
    return (out || new THREE.Vector3()).set(
      A.x + Math.sin(ax) * L,
      A.y - Math.cos(ax) * Math.cos(az) * L,
      A.z + Math.sin(az) * L
    );
  }

  function hangPlayer() {
    const b = W.player;
    if (!b) return;
    b.kinematic = true;
    b.mounted = false;
    b.v.set(0, 0, 0);
    ropeHangPos(b.p);
    b.mountPos.copy(b.p);
    b.restT = 0;
    W.ropeCut = false;
    if (b.mesh) b.mesh.position.copy(b.p);
  }

  function cutRope() {
    if (W.ropeCut || W.state !== 'play' || !W.player) return false;
    if (W.currentFloor !== 0) return false;   // v4.0: трос есть только на первом этаже
    W.ropeCut = true;
    W.cutCount++;
    const b = W.player;
    b.kinematic = false;
    b.mounted = false;
    // v3.5: perfect cut — рез без предварительного наклона стакана
    const tiltMag = Math.hypot(W.tilt.rotX, W.tilt.rotZ);
    const perfect = tiltMag < 0.03;
    // v4.1: на L8+ идеальный рез обязателен — неидеальный замедляет шар на 10%
    const cutPenalty = (LV().perfectCut && !perfect) ? 0.9 : 1.0;
    if (LV().perfectCut && !perfect && W.runStats) W.runStats.cutMisses++;
    const push = 0.6 * SETTINGS.ballSpeed * cutPenalty;
    b.v.set(rnd(-0.25, 0.25), -push, rnd(-0.25, 0.25));
    b.restT = 0;
    Sound.cut();
    if (cutPenalty < 1) toast(curLang === 'ru' ? 'Срез кривой — шар медленнее (−10%)' : 'Crooked cut — the ball is slower (−10%)', 'warn');
    else toast(D().toastCut, 'good');
    if (perfect) {
      W.perfectCuts++;
      addScore(150, curLang === 'ru' ? 'идеальный срез' : 'perfect cut');
      spawnSparks(b.p.x, b.p.y + b.r, b.p.z, 20, 3.0, 0xffd700);
    }
    W.events.push({ t: W.time, type: 'cut', perfect: perfect, slow: cutPenalty < 1 });
    spawnSparks(b.p.x, b.p.y + b.r, b.p.z, 12, 2.2, 0xffeecc);
    return true;
  }

  // v3.5: досрочно завершить интро и вернуть камеру на дефолт
  function skipIntro() {
    if (!W.intro.active) return;
    W.intro.active = false;
    W.cam.theta = LEVEL_CONFIG.camera.defaultTheta;
    W.cam.phi = LEVEL_CONFIG.camera.defaultPolar;
    W.cam.dist = LEVEL_CONFIG.camera.defaultDist;
    W.cam.spinTheta = 0; W.cam.spinPhi = 0;
    W.introWasActive = false;
    pulseRope();
    if (W.state === 'play') toast(D().statusRope, 'good');
  }

  // v3.5: подсветка троса после интро — три вспышки за 1.5 с
  function pulseRope() { W.ropePulse = 1.5; }

  function updateRopeVisual() {
    if (!W.ropeMesh || !W.player) return;
    const b = W.player;
    const A = LEVEL_CONFIG.rope.anchor;
    if (!W.ropeCut && !b.returning) {
      const dx = b.p.x - A.x, dy = b.p.y - A.y, dz = b.p.z - A.z;
      const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
      W.ropeMesh.visible = true;
      W.ropeMesh.scale.set(1, Math.max(0.01, len), 1);
      W.ropeMesh.position.set(A.x + dx / 2, A.y + dy / 2, A.z + dz / 2);
      W.ropeMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0),
        new THREE.Vector3(dx, dy, dz).normalize());
    } else {
      // обрубок у анкера (v4.0: на этажах 1+ трос не показываем вовсе)
      W.ropeMesh.visible = (W.currentFloor === 0);
      W.ropeMesh.scale.set(1, 0.9, 1);
      W.ropeMesh.position.set(A.x, A.y - 0.45, A.z);
      W.ropeMesh.quaternion.identity();
    }
    // подсветка, когда курсор в зоне разреза; пульс после интро (v3.5)
    const rm = W.ropeMesh.material;
    if (rm && rm.emissive) {
      if (W.ropePulse > 0 && !W.ropeCut) {
        const ph = Math.sin(W.ropePulse * 12.6);          // ~3 вспышки за 1.5 с
        rm.emissive.setHex(ph > 0 ? 0x00ffcc : 0x1a4a3f);
        rm.emissiveIntensity = 1.2 + 1.3 * Math.abs(ph);
      } else if (W.ropeHover && !W.ropeCut) {
        rm.emissive.setHex(0xffcc44);
        rm.emissiveIntensity = 1.5 + 0.9 * Math.sin(W.time * 13);
      } else {
        rm.emissive.setHex(0x221a08);
        rm.emissiveIntensity = 1;
      }
    }
  }

  // ===========================================================================
  // 17. ЭФФЕКТЫ: искры, ударные волны, салют
  // ===========================================================================
  const SPARK_N = 1500;
  const TRAIL_N = 32;                 // v3.5: длина трейла игрового шара

  function initFX() {
    if (W.sparks) { if (W.sparks.parent) W.sparks.parent.remove(W.sparks); }
    const pos = new Float32Array(SPARK_N * 3);
    const col = new Float32Array(SPARK_N * 3);
    for (let i = 0; i < SPARK_N; i++) { pos[i * 3 + 1] = -9999; }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const m = new THREE.PointsMaterial({
      size: 0.3, vertexColors: true, transparent: true, opacity: 0.95,
      depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true
    });
    W.sparks = new THREE.Points(g, m);
    W.sparks.frustumCulled = false;
    W.sparks.renderOrder = 6;
    W.glassGroup.add(W.sparks);
    W.sparkData = [];
    for (let i = 0; i < SPARK_N; i++) W.sparkData.push({ life: 0, max: 1, vx: 0, vy: 0, vz: 0, c: new THREE.Color(), drag: 1.6 });
    W.sparkCursor = 0;
    // v3.5: трейл игрового шара — 32 точки, создаётся один раз и переиспользуется
    if (!W.trail) {
      const tpos = new Float32Array(TRAIL_N * 3), tcol = new Float32Array(TRAIL_N * 3);
      for (let i = 0; i < TRAIL_N; i++) tpos[i * 3 + 1] = -9999;
      const tg = new THREE.BufferGeometry();
      tg.setAttribute('position', new THREE.BufferAttribute(tpos, 3));
      tg.setAttribute('color', new THREE.BufferAttribute(tcol, 3));
      tg.setDrawRange(0, TRAIL_N);
      const tm = new THREE.PointsMaterial({ size: 7, vertexColors: true, transparent: true, opacity: 0.85,
        sizeAttenuation: false, depthWrite: false, blending: THREE.AdditiveBlending });
      W.trail = { positions: tpos, colors: tcol, head: 0, points: new THREE.Points(tg, tm), fade: 0, dirty: false };
      W.trail.points.frustumCulled = false;
      W.trail.points.renderOrder = 4;
    }
    // в сцену, не в стакан: трейл пишется в мировых координатах и не должен
    // ни вращаться вместе со стаканом, ни попадать под disposeGroup
    if (W.trail.points.parent !== W.scene) W.scene.add(W.trail.points);
    W.waves = [];
    for (let i = 0; i < 14; i++) {
      const mesh = new THREE.Mesh(new THREE.RingGeometry(0.72, 1.0, 44),
        new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
      mesh.visible = false; mesh.renderOrder = 5;
      W.glassGroup.add(mesh);
      W.waves.push({ mesh: mesh, life: 0, max: 1, size: 1 });
    }
  }

  function spawnSparks(x, y, z, count, speed, colorNum) {
    if (!W.sparkData) return;
    const pos = W.sparks.geometry.attributes.position.array;
    const col = W.sparks.geometry.attributes.color.array;
    const c = new THREE.Color(colorNum);
    for (let i = 0; i < count; i++) {
      const idx = W.sparkCursor; W.sparkCursor = (W.sparkCursor + 1) % SPARK_N;
      const d = W.sparkData[idx];
      // случайное направление на сфере
      const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, s = Math.sqrt(1 - u * u);
      const sp = speed * rnd(0.45, 1.15);
      d.vx = Math.cos(th) * s * sp; d.vy = u * sp * 0.9 + 0.6; d.vz = Math.sin(th) * s * sp;
      d.max = d.life = LEVEL_CONFIG.magic.sparkLife * rnd(0.6, 1.5);
      d.c.copy(c).offsetHSL(rnd(-0.05, 0.05), 0, rnd(-0.05, 0.2));
      d.drag = rnd(1.1, 2.2);
      pos[idx * 3] = x; pos[idx * 3 + 1] = y; pos[idx * 3 + 2] = z;
      col[idx * 3] = d.c.r; col[idx * 3 + 1] = d.c.g; col[idx * 3 + 2] = d.c.b;
    }
    W.sparks.geometry.attributes.position.needsUpdate = true;
    W.sparks.geometry.attributes.color.needsUpdate = true;
  }

  function spawnShockwave(x, y, z, size, colorNum) {
    let slot = null;
    for (const w of W.waves) if (w.life <= 0) { slot = w; break; }
    if (!slot) slot = W.waves[0];
    slot.life = slot.max = 0.45;
    slot.size = size;
    slot.mesh.visible = true;
    slot.mesh.position.set(x, y, z);
    slot.mesh.material.color.set(colorNum);
    slot.mesh.scale.setScalar(size * 0.25);
  }

  function updateFX(dt) {
    if (W.sparks) {
      const pos = W.sparks.geometry.attributes.position.array;
      const col = W.sparks.geometry.attributes.color.array;
      let any = false;
      for (let i = 0; i < SPARK_N; i++) {
        const d = W.sparkData[i];
        if (d.life <= 0) continue;
        any = true;
        d.life -= dt;
        const k = Math.max(0, 1 - d.drag * dt);
        d.vx *= k; d.vy = d.vy * k - 6.0 * dt; d.vz *= k;
        pos[i * 3] += d.vx * dt; pos[i * 3 + 1] += d.vy * dt; pos[i * 3 + 2] += d.vz * dt;
        const f = Math.max(0, d.life / d.max);
        col[i * 3] = d.c.r * f; col[i * 3 + 1] = d.c.g * f; col[i * 3 + 2] = d.c.b * f;
        if (d.life <= 0) { pos[i * 3 + 1] = -9999; col[i * 3] = col[i * 3 + 1] = col[i * 3 + 2] = 0; }
      }
      if (any) {
        W.sparks.geometry.attributes.position.needsUpdate = true;
        W.sparks.geometry.attributes.color.needsUpdate = true;
      }
    }
    for (const w of W.waves) {
      if (w.life <= 0) { if (w.mesh.visible) w.mesh.visible = false; continue; }
      w.life -= dt;
      const t = 1 - Math.max(0, w.life / w.max);
      w.mesh.scale.setScalar(w.size * (0.25 + t * 1.9));
      w.mesh.material.opacity = 0.85 * (1 - t);
      billboard(w.mesh);
    }
    // v3.5: трейл гаснет сам (~0.92 за кадр)
    if (W.trail && W.trail.points) {
      if (W.trail.fade > 0) {
        W.trail.fade = Math.max(0, W.trail.fade - dt);
        const f = Math.pow(0.92, dt * 60);
        const tc = W.trail.colors;
        for (let i = 0; i < TRAIL_N; i++) {
          tc[i * 3] *= f; tc[i * 3 + 1] *= f; tc[i * 3 + 2] *= f;
        }
        if (W.trail.fade <= 0) W.trail.colors.fill(0);
        W.trail.dirty = true;
      }
      if (W.trail.dirty) {
        W.trail.points.geometry.attributes.position.needsUpdate = true;
        W.trail.points.geometry.attributes.color.needsUpdate = true;
        W.trail.dirty = false;
      }
    }
    if (W.fireworkT > 0) {
      W.fireworkT -= dt;
      W.fireworkAcc = (W.fireworkAcc || 0) + dt;
      if (W.fireworkAcc > 0.16) {
        W.fireworkAcc = 0;
        const a = Math.random() * Math.PI * 2, rr = rnd(2, 14);
        const y = rnd(-2, 12);
        const colors = [0xff3355, 0x00ffaa, 0xffcc00, 0x3d7bff, 0xd946ef, 0xffffff];
        spawnSparks(Math.cos(a) * rr, y, Math.sin(a) * rr, 34, rnd(4, 8), colors[(Math.random() * colors.length) | 0]);
        Sound.hit(0.5);
      }
    }
  }

  // v3.5: сквош-стретч — плоский «шлёп» после удара сильнее 5 м/с
  function updateSquash(dt) {
    const s = SETTINGS.ballSize;
    for (const b of W.balls) {
      if (!b.alive || !b.mesh || b.dissolving) continue;
      if ((b.impact || 0) > 5) b.squash = Math.min(0.22, b.impact / 60);
      if (b.squash > 0) {
        b.squash = Math.max(0, b.squash - dt * 1.8);
        b.mesh.scale.set(s * (1 + b.squash * 0.5), s * (1 - b.squash), s * (1 + b.squash * 0.5));
      } else if (Math.abs(b.mesh.scale.y - s) > 0.001) {
        b.mesh.scale.setScalar(s);
      }
    }
  }

  // v3.5: точка трейла игрового шара при скорости > 3 м/с
  function pushTrail() {
    if (!W.trail || !W.trail.points || !W.player || !W.player.alive) return;
    const pl = W.player;
    if (pl.v.length() <= 3.0) return;
    const i = W.trail.head;
    W.trail.positions[i * 3] = pl.p.x;
    W.trail.positions[i * 3 + 1] = pl.p.y;
    W.trail.positions[i * 3 + 2] = pl.p.z;
    W.trail.colors[i * 3] = 0.6; W.trail.colors[i * 3 + 1] = 0.9; W.trail.colors[i * 3 + 2] = 1.0;
    W.trail.head = (i + 1) % TRAIL_N;
    W.trail.fade = 1;
    W.trail.dirty = true;
  }

  const _bbQ = new THREE.Quaternion();
  function billboard(mesh) {
    if (!W.camera) return;
    _bbQ.copy(W.glassGroup.quaternion).invert().multiply(W.camera.quaternion);
    mesh.quaternion.copy(_bbQ);
  }

  // ===========================================================================
  // 18. ИГРОВАЯ ЛОГИКА: ядро, кнопка, ловушка, победа/поражение, авто-помощь
  // ===========================================================================
  const DEG = Math.PI / 180;
  const _up = new THREE.Vector3(), _dh = new THREE.Vector3();

  function localUp() {
    _qInv.copy(W.glassGroup.quaternion).invert();
    return _up.set(0, -1, 0).applyQuaternion(_qInv).negate();
  }

  function downhill(out) {
    // направление «под уклон» в локальной системе стакана
    localUp();
    _dh.copy(_gLocal);
    _dh.addScaledVector(_up, -_dh.dot(_up));      // убираем составляющую вдоль «верха»
    if (_dh.lengthSq() < 1e-8) {
      _dh.set(Math.random() * 2 - 1, 0, Math.random() * 2 - 1);
      if (_dh.lengthSq() < 1e-8) _dh.set(1, 0, 0);
    }
    return out.copy(_dh).normalize();
  }

  // Финальная шахта: участок между горловиной воронки и кнопкой.
  // Поле щита гасит боковой снос игрового шара и слегка тянет его к оси,
  // иначе шар, вылетевший из горловины со сносом 5–6 м/с, минует ядро (r=1.2)
  // и отбивается кронштейном кнопки на сетку — необъяснимое поражение.
  function shaftAssist(b, dt) {
    const C = LEVEL_CONFIG;
    const yTop = C.platformB.funnelBottomY - 0.3;          // низ горловины (3.2)
    const yBot = C.button.y + C.button.radius * K() + 0.1; // v4.0: выше купола кнопки — не мешаем скатиться к кольцу победы
    if (b.p.y > yTop || b.p.y < yBot) return;
    // v4.0: ось ствола — смещённое ядро, а не центр стакана
    const ax = C.shield.x, az = C.shield.z;
    const r = Math.hypot(b.p.x - ax, b.p.z - az);
    const k = Math.max(0, 1 - 0.9 * dt);                   // v4.0: мягче гасим разгон (нужен для нырка)
    b.v.x *= k; b.v.z *= k;
    if (r > 0.05) {                                        // тянем к оси ядра
      const f = 2.6 * dt;
      b.v.x -= ((b.p.x - ax) / r) * f;
      b.v.z -= ((b.p.z - az) / r) * f;
    }
  }

  function autoAssist(dt) {
    const P = LEVEL_CONFIG.physics;
    const tiltMag = Math.hypot(W.tilt.rotX, W.tilt.rotZ);
    localUp();
    for (const b of W.balls) {
      if (!b.alive || b.kinematic) continue;
      b.assistCd -= dt;
      const sp = b.v.length();
      if (b.isPlayer && W.state === 'play') shaftAssist(b, dt);
      // магнитный ассист: почти ровная поверхность + заметный наклон + шар еле ползёт
      if (b.contact && tiltMag > P.magneticAssistTilt && sp < 0.35 && b.assistCd <= 0) {
        const slopeAng = Math.acos(clamp(b.contactN.dot(_up), -1, 1));
        if (slopeAng < 4 * DEG) {
          downhill(_tv);
          const f = P.magneticAssistImpulse * SETTINGS.impactForce * (b.isPlayer ? SETTINGS.ballSpeed : 1);
          b.v.addScaledVector(_tv, f);
          b.assistCd = 0.55;
        }
      }
      // анти-застревание (шары дорог «Трубы» исключены: они ЗАДУМАНО стоят в жёлобе)
      if (b.pipeRoad !== undefined) { /* v4.4: не пинаем ряды дорог */ }
      else {
      if (sp < P.stuckSpeed) b.restT += dt; else b.restT = 0;
      if (b.restT > P.stuckTime && b.assistCd <= 0) {
        downhill(_tv);
        const f = P.stuckImpulse * SETTINGS.impactForce * (b.isPlayer ? SETTINGS.ballSpeed : 1);
        if (tiltMag > 2 * DEG) b.v.addScaledVector(_tv, f);
        else { _tv.set(rnd(-1, 1), 0.15, rnd(-1, 1)).normalize(); b.v.addScaledVector(_tv, f * 0.7); }
        b.restT = 0; b.assistCd = 0.7;
      }
      }
      // v4.2: заклинивание у люка (шар на кромке крышки) — радиальный выброс,
      // с 3-й попытки телепорт наружу; шар не остаётся замурованным в лунке
      // (v4.4: шары дорог «Трубы» не трогаем — ряд рядом с люком — это норма)
      if (!b.isPlayer && b.pipeRoad === undefined && b.floor !== undefined && b.floor >= 0 && b.floor <= 2 &&
          sp < 0.3 && b.assistCd <= 0) {
        const hy = floorY(b.floor);
        if (Math.abs(b.p.y - hy) < 1.4) {
          const rr = Math.hypot(b.p.x, b.p.z);
          const hole = LEVEL_CONFIG.floors.holeR * K();
          if (rr < hole + 1.0) {
            b.stuckHatch = (b.stuckHatch || 0) + 1;
            const ux = rr > 1e-6 ? b.p.x / rr : 1, uz = rr > 1e-6 ? b.p.z / rr : 0;
            if (b.stuckHatch >= 3) {
              const nr = hole + 1.7;
              b.p.set(ux * nr, hy + b.r + 0.02, uz * nr);
              b.v.set(0, 0, 0);
              b.stuckHatch = 0;
              W.events.push({ t: W.time, type: 'hatchUnstuck', name: b.name });
            } else {
              b.v.x += ux * 1.15; b.v.z += uz * 1.15; b.v.y += 0.28;
            }
            b.assistCd = 1.1;
            b.restT = 0;
          }
        }
      }
      // игровой шар: нет ПРОГРЕССА > 3 с → возврат на трос
      if (b.isPlayer) {
        if (sp < 0.5) {
          b.idleT = (b.idleT || 0) + dt;
          if (!b.idlePos) b.idlePos = b.p.clone();
          else if (b.p.distanceTo(b.idlePos) > 1.5) { b.idleT = 0; b.idlePos.copy(b.p); }
        } else { b.idleT = 0; if (!b.idlePos) b.idlePos = b.p.clone(); else b.idlePos.copy(b.p); }
      }
    }
  }

  function updateTriggers(dt) {
    const C = LEVEL_CONFIG, T = C.trap, BT = C.button;
    const pl = W.player;

    // v4.0: логика этажей (лунки, цепочка, плиты, переходы)
    updateFloorState(dt);

    // --- ядро щита: разбивается любым шаром ---
    if (W.coreAlive && pl && pl.alive && !pl.kinematic) {
      const rr = C.shield.coreRadius * K();
      const dx = pl.p.x - C.shield.x, dy = pl.p.y - C.shield.y, dz = pl.p.z - C.shield.z;
      // Граница поля — внешнее гало-кольцо (coreRadius × 1.5), а не сам шар ядра:
      // иначе быстрый шар проскакивает в 5 см от ядра и финал срывается.
      // Поле действует только СВЕРХУ: шар, лежащий на кнопке (ниже ядра),
      // не должен разбивать его через весь уровень.
      const lim = rr * 1.5 + pl.r;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (pl.touched['core'] || (d2 < lim * lim && pl.p.y > C.shield.y - 0.1)) breakCore(pl);
    }

    // --- шары в ловушке ---
    let inTrap = 0;
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer) continue;
      const r = Math.hypot(b.p.x, b.p.z);
      const netY = T.netY - Math.tan(T.netTilt) * (T.netRadius - Math.min(r, T.netRadius));
      b.onNet = !!b.touched['net'];
      b.onGlass = !!b.touched['glassFloor'];
      if (b.p.y < netY + b.r + 0.2) { b.inTrap = true; inTrap++; } else b.inTrap = false;
      // v4.2: шары этажей не исчезают в ловушке — возвращаются на свои места
      if (b.floor !== undefined && b.floor !== null && !b.pipeFree &&
          (b.onGlass || b.p.y < T.netY - 0.9)) {
        if (!b._respawnT) b._respawnT = 0.55;
        b._respawnT -= dt;
        if (b._respawnT <= 0) { respawnBallHome(b); b._respawnT = 0; }
        continue;
      }
      if ((b.onGlass || b.p.y < T.netY - 0.9) && !b.countedLost) {
        b.countedLost = true; W.lostCount++; Sound.fall();
        W.events.push({ t: W.time, type: 'lost', name: b.name });
      }
      if (b.onGlass) {
        b.glassT += dt;
        if (b.glassT > T.dissolveAfter && !b.dissolving) { b.dissolving = T.dissolveTime; }
      } else b.glassT = 0;
    }
    W.trapBalls = inTrap;

    // --- растворение трофеев на стекле ---
    for (const b of W.balls) {
      if (!b.alive || !b.dissolving) continue;
      b.dissolving -= dt;
      const k = clamp(b.dissolving / C.trap.dissolveTime, 0, 1);
      if (b.mesh) { b.mesh.scale.setScalar(SETTINGS.ballSize * k); if (b.mesh.material) b.mesh.material.opacity = k, b.mesh.material.transparent = true; }
      if (b.glow) b.glow.visible = k > 0.05;
      if (b.dissolving <= 0) {
        b.alive = false;
        if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
        if (b.ring && b.ring.parent) b.ring.parent.remove(b.ring);
        W.events.push({ t: W.time, type: 'dissolve', name: b.name });
      }
    }

    // --- игровой шар ---
    if (!pl || !pl.alive) return;
    const plR = Math.hypot(pl.p.x, pl.p.z);
    const plRBtn = Math.hypot(pl.p.x - LEVEL_CONFIG.shield.x, pl.p.z - LEVEL_CONFIG.shield.z);   // v4.0: ось кнопки
    const netYpl = T.netY - Math.tan(T.netTilt) * (T.netRadius - Math.min(plR, T.netRadius));
    pl.onNet = !!pl.touched['net'];
    pl.onGlass = !!pl.touched['glassFloor'];
    const inTrapZone = pl.p.y < netYpl + pl.r + 0.25 || pl.onGlass;

    if (inTrapZone && W.state === 'play' && W.trapTimer < 0 && !W.rewind.active) {
      W.trapTimer = T.gameOverDelay;
      Sound.trap();
      toast(D().toastTrap, 'bad');
      W.events.push({ t: W.time, type: 'trapEnter' });
    }
    if (W.trapTimer > 0 && W.state === 'play' && !W.rewind.active) {
      W.trapTimer -= dt;
      if (!inTrapZone) W.trapTimer = -1;                 // выбрался — отбой
      else if (W.trapTimer <= 0) {
        // v3.5: откат шара на трос вместо поражения
        startRewind('trap');
      }
    }

    // v3.5: продвижение вниз сбрасывает серию фейлов
    if (W.state === 'play' && pl.p.y < W.lowestY - 2) {
      W.lowestY = Math.min(W.lowestY, pl.p.y);
      if (W.failStreak > 0) W.failStreak = 0;
    }

    // v4.0: подсказка первого этажа — один раз после разреза троса
    // (подсказки этажей 2-4 показываются при переходе, см. updateFloorState)
    if (W.state === 'play' && W.visited && !W.rewind.active) {
      if (LV().hints >= 1 && !W.visited.floors[0] && W.ropeCut && W.currentFloor === 0 &&
          pl.p.y < LEVEL_CONFIG.platformA.y + 1.5 && pl.p.y > LEVEL_CONFIG.platformA.y - 2.5) {
        W.visited.floors[0] = true;
        toast(D().floor0Hint, 'magic', 3200);
      }
    }

    // v4.2: автовозврат на трос УДАЛЁН — трос не «восстанавливается»,
    // срезавшийся шар больше не подвешивается обратно сам по себе
    if (false && W.ropeCut && !pl.returning && W.state === 'play' && (pl.idleT || 0) > C.physics.returnAfter && !inTrapZone) {
      pl.returning = true; pl.returnT = 0; pl.returnFrom = pl.p.clone();
      pl.kinematic = true; pl.v.set(0, 0, 0);
      Sound.ui(); toast(D().toastReturned, 'good');
      W.events.push({ t: W.time, type: 'return' });
    }
    if (pl.returning) {
      pl.returnT += dt / C.physics.returnDuration;
      const k = pl.returnT >= 1 ? 1 : (pl.returnT < 0.5 ? 2 * pl.returnT * pl.returnT : 1 - Math.pow(-2 * pl.returnT + 2, 2) / 2);
      if (W.currentFloor > 0 && W.floorEntry) {
        // v4.0: на этажах 1+ возврат — к площадке входа этажа
        pl.p.lerpVectors(pl.returnFrom, W.floorEntry, k);
        if (pl.returnT >= 1) { pl.returning = false; pl.idleT = 0; pl.kinematic = false; pl.v.set(0, 0, 0); }
      } else {
        ropeHangPos(_tv);
        pl.p.lerpVectors(pl.returnFrom, _tv, k);
        if (pl.returnT >= 1) { pl.returning = false; pl.idleT = 0; hangPlayer(); }
      }
    } else if (!W.ropeCut && !pl.returning) {
      pl.kinematic = true;
      ropeHangPos(pl.p);
    }

    // --- кнопка: победа ---
    // v4.0: кнопка — капсула-купол радиусом radius*K; шар может покоиться на макушке
    // (y ≈ BT.y+thick/2+radius*K+pl.r), поэтому верхняя граница окна учитывает купол
    const onBtnTop = pl.touched['button'] && plRBtn < (BT.radius * K()) + pl.r * 0.6 &&
      pl.p.y > BT.y - 0.6 && pl.p.y < BT.y + BT.thickness / 2 + (BT.radius * K()) + pl.r + 0.35;
    if (onBtnTop && W.state === 'play') {
      if (W.coreAlive) {
        if ((W.coreWarnT || 0) <= 0) { toast(D().statusCore, 'warn'); W.coreWarnT = 2.5; }
      } else {
        startWin();
      }
    }
    if (W.coreWarnT > 0) W.coreWarnT -= dt;
  }

  function startWin() {
    if (W.state !== 'play') return;
    if (W.currentFloor !== 3) return;   // v4.0: победа — только на четвёртом этаже
    W.state = 'winning';
    W.winT = 0;
    W.slowmo = 1.0; W.slowmoScale = 0.3;
    // v3.5: финальный уровень — шестисекундный салют
    const finale = W.currentLevel === LEVELS.length - 1;
    W.fireworkT = finale ? 6.0 : 3.0; W.fireworkAcc = 0;
    W.flashT = 0.25;                       // v3.5: вспышка tone-mapping
    Sound.victory(finale);
    // v3.5: очки за финиш, ×2 если быстрее 45 с
    const speedBonus = W.runTime < 45 ? 2 : 1;
    addScore(1000 * speedBonus, curLang === 'ru' ? 'финиш' : 'finish');
    // v3.5: кинематографичный финал — камера ныряет к кнопке
    W.cine = { active: true, t: 0, dur: 1.6, fromDist: W.cam.dist,
      fromY: (W.camTargetY === undefined ? LEVEL_CONFIG.camera.targetY : W.camTargetY) };
    W.cam.tDist = 22;
    W.camTargetY = -1.5;
    W.camTargetX = LEVEL_CONFIG.shield.x;   // v4.0: кино смотрит на смещённую кнопку
    W.camTargetZ = LEVEL_CONFIG.shield.z;
    W.events.push({ t: W.time, type: 'win' });
    if (W.player) W.player.v.multiplyScalar(0.25);
  }

  function startLose(reason) {
    if (W.state !== 'play') return;
    W.state = 'losing';
    W.loseT = 0;
    W.loseReason = reason || 'trap';
    W.slowmo = 0.8; W.slowmoScale = 0.35;
    Sound.defeat();
    W.events.push({ t: W.time, type: 'lose', reason: W.loseReason });
  }

  // v4.0: цель отката — трос на этаже 0, площадка входа на этажах 1+
  function rewindTargetPos(out) {
    if (W.currentFloor <= 0) { ropeHangPos(out); return false; }
    if (!W.floorEntry) { ropeHangPos(out); return false; }
    out.copy(W.floorEntry);
    return true;
  }

  // v3.5: re-wind вместо модалки поражения. Игровой шар откатывается на трос,
  // поток не прерывается. Ядро, освобождённые тела и взорванные шары НЕ
  // откатываются. Модалка поражения — только с 3 фейлов подряд.
  function startRewind(reason) {
    if (W.state !== 'play' || !W.player || !W.player.alive) return false;
    W.failStreak++;
    W.attempts++;
    W.loseReason = reason || 'trap';
    W.rewind.active = true;
    W.rewind.t = 0;
    W.rewind.from.copy(W.player.p);
    W.player.kinematic = true;
    W.player.v.set(0, 0, 0);
    W.player.returning = false;
    W.player.idleT = 0;
    W.trapTimer = -1;
    W.combo = 1;                               // фейл сбивает комбо
    // v4.2: неудачные дороги этажа «Труба» — пересборка (этаж 1)
    if (W.currentFloor === 1 && W.floorState && W.floorState.pipe) {
      for (const r of W.floorState.pipe.roads) {
        if (r.layout && !r.solved) resetPipeRoad(r, 'rewind');
      }
    }
    // v4.1: модификаторы Rewind по уровню (LEVELS[].rewind)
    const rw = LV().rewind || 'free';
    if (rw === 'pen50') { W.score = Math.max(0, W.score - 50); }
    else if (rw === 'pen100') { W.score = Math.max(0, W.score - 100); }
    else if (rw === 'pen200') { W.score = Math.max(0, W.score - 200); W.failStreak++; }
    else if (rw === 'reset') { resetFloorPuzzle(W.currentFloor); }
    Sound.fade();
    const rwMsg = {
      pen50:  curLang === 'ru' ? 'Откат: −50 очков' : 'Rewind: −50 points',
      pen100: curLang === 'ru' ? 'Откат: −100 очков' : 'Rewind: −100 points',
      pen200: curLang === 'ru' ? 'Откат: −200 очков и −1 попытка' : 'Rewind: −200 points and −1 attempt',
      reset:  curLang === 'ru' ? 'Откат: этаж сброшен' : 'Rewind: floor reset'
    };
    if (rwMsg[rw]) toast(rwMsg[rw], 'bad');
    else toast(curLang === 'ru' ? 'Ещё раз!' : 'Again!', 'warn');
    W.events.push({ t: W.time, type: 'rewind', reason: W.loseReason });
    // v3.5 (1.2): модалка поражения — только с 3-го фейла подряд.
    // Откат доиграет, затем 1.4 с паузы — и модалка.
    if (W.failStreak >= 3) {
      W.state = 'losing';
      W.loseT = 0;
      W.slowmo = 0.8; W.slowmoScale = 0.35;
      Sound.defeat();
    }
    return true;
  }

  function updateSequences(dt) {
    // v3.5: откат игрового шара на трос (0.4 с, ease-in-out)
    if (W.rewind.active) {
      W.rewind.t += dt;
      const k = clamp(W.rewind.t / W.rewind.dur, 0, 1);
      const ease = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      const toEntry = rewindTargetPos(_tv);
      W.player.p.lerpVectors(W.rewind.from, _tv, ease);
      if (W.player.mesh) W.player.mesh.position.copy(W.player.p);
      if (k >= 1) {
        W.rewind.active = false;
        if (toEntry) {
          W.player.kinematic = false;
          W.player.v.set(0, 0, 0);
        } else {
          hangPlayer();
        }
        if (W.player.mesh && W.player.mesh.material && W.player.mesh.material.emissive) {
          W.player.mesh.material.emissive.setHex(0x88ddff);
          W.player.mesh.material.emissiveIntensity = 0.55;
        }
        // откат доиграл: при 3+ фейлах дальше пойдёт пауза поражения
      } else {
        return;                                 // пока шар летит на трос — ничего не считаем
      }
    }
    if (W.state === 'winning') {
      W.winT += dt;
      const BT = LEVEL_CONFIG.button;
      const press = clamp(W.winT / 0.25, 0, 1) * BT.pressDepth;
      if (W.buttonMesh) W.buttonMesh.position.y = BT.y - press;
      if (W.buttonGlow) W.buttonGlow.material.opacity = 0.16 + 0.4 * Math.abs(Math.sin(W.winT * 6));
      if (W.winT > 1.0) { W.slowmoScale = lerp(W.slowmoScale, 1, dt * 2); }
      // v3.5: конец кино-наездa камеры — вернуться на дефолт
      if (W.cine && W.cine.active) {
        W.cine.t += dt;
        if (W.cine.t > W.cine.dur) {
          W.cine.active = false;
          W.cam.tDist = LEVEL_CONFIG.camera.defaultDist;
          W.camTargetY = LEVEL_CONFIG.camera.targetY;
          W.camTargetX = 0; W.camTargetZ = 0;
        }
      }
      if (W.winT > 4.4) { W.state = 'win'; if (window.GB_AUTO && window.GB_AUTO.active) autoStop('end'); App.showVictory(); }
    } else if (W.state === 'losing') {
      W.loseT += dt;
      // v3.5: модалка поражения — только при 3+ фейлах подряд
      if (W.loseT > 1.4) {
        if (W.failStreak >= 3) { W.state = 'lose'; App.showDefeat(); }
        else { W.state = 'play'; }
      }
    }
  }

  // ===========================================================================
  // 19. НАКЛОН СТАКАНА, ВИЗУАЛ, ЗАТУХАНИЕ ПЛОЩАДОК, КАМЕРА
  // ===========================================================================
  const _e = new THREE.Euler();
  const _ray = null;                    // создаётся лениво (Raycaster)
  let _raycaster = null;
  const _vWorld = new THREE.Vector3();
  const _vCam = new THREE.Vector3();

  function applyTilt(dt) {
    const T = LEVEL_CONFIG.tilt;
    if (!W.tilt.active) { W.tilt.tRotX = 0; W.tilt.tRotZ = 0; }
    // ограничение суммарного наклона
    const tmag = Math.hypot(W.tilt.tRotX, W.tilt.tRotZ);
    if (tmag > T.max) { const s = T.max / tmag; W.tilt.tRotX *= s; W.tilt.tRotZ *= s; }
    const tau = (W.tilt.active ? T.lerpIn : T.lerpOut) / 3;
    const k = 1 - Math.exp(-dt / Math.max(0.001, tau));
    W.tilt.rotX += (W.tilt.tRotX - W.tilt.rotX) * k;
    W.tilt.rotZ += (W.tilt.tRotZ - W.tilt.rotZ) * k;
    if (!W.tilt.active) {
      // экспоненциальное сглаживание никогда не достигает нуля само:
      // фиксируем точный ноль, чтобы стакан гарантированно выравнивался
      if (Math.abs(W.tilt.rotX) < 1e-4) W.tilt.rotX = 0;
      if (Math.abs(W.tilt.rotZ) < 1e-4) W.tilt.rotZ = 0;
    }
    _e.set(W.tilt.rotX, 0, W.tilt.rotZ, 'XYZ');
    W.glassGroup.quaternion.setFromEuler(_e);

    // визуальная тряска стакана (±0.15 м, 0.3 с)
    const SV = LEVEL_CONFIG.shake;
    if (W.shakeVisual > 0) {
      W.shakeVisual -= dt;
      const a = SV.visualAmp * clamp(W.shakeVisual / SV.visualTime, 0, 1);
      const s = W.shakeSeed;
      W.glassGroup.position.set(
        Math.sin(W.time * 63 + s) * a,
        Math.sin(W.time * 51 + s * 1.7) * a * 0.3,
        Math.cos(W.time * 57 + s * 0.6) * a
      );
    } else if (W.glassGroup.position.lengthSq() > 0) {
      W.glassGroup.position.set(0, 0, 0);
    }
  }

  function updateVisuals(dt) {
    const C = LEVEL_CONFIG;
    // шары
    for (const b of W.balls) {
      if (!b.alive || !b.mesh) continue;
      b.mesh.position.copy(b.p);
      if (Math.abs(b.spinRate) > 0.001) {
        _qInv.setFromAxisAngle(b.spinAxis, b.spinRate * dt);
        b.mesh.quaternion.premultiply(_qInv);
      }
      const mat = b.mesh.material;
      if (b.flash > 0) {
        b.flash -= dt;
        if (mat.emissive) { mat.emissive.setHex(0xffffff); mat.emissiveIntensity = 3.2; }
        if (b.glow) b.glow.material.opacity = 0.7;
      } else if (mat.emissive && b.chargeT <= 0) {
        if (b.isPlayer) { mat.emissive.setHex(0x88ddff); mat.emissiveIntensity = 0.55; }
        else if (b.colorIdx >= 0) { mat.emissive.setHex(C.palette[b.colorIdx].emissive); mat.emissiveIntensity = 0.85; }
        if (b.glow) b.glow.material.opacity = b.isPlayer ? 0.2 : 0.12;
      }
      // кольца заряда
      if (b.ring && b.ring.visible) { b.ring.position.copy(b.p); billboard(b.ring); }
    }

    // ядро щита
    if (W.coreAlive && W.coreMesh) {
      W.coreMesh.rotation.y += dt * 0.8;
      W.coreMesh.rotation.x += dt * 0.35;
      const pulse = 1.15 + 0.45 * Math.sin(W.time * 3.1);
      W.coreMesh.material.emissiveIntensity = pulse;
      if (W.coreInner) { W.coreInner.rotation.y -= dt * 1.4; W.coreInner.scale.setScalar(0.9 + 0.12 * Math.sin(W.time * 4.4)); }
      for (let i = 0; i < W.halos.length; i++) {
        const h = W.halos[i];
        h.rotation.z += dt * (i ? -0.9 : 0.6);
        h.rotation.y += dt * (i ? 0.4 : -0.3);
        h.material.opacity = 0.35 + 0.25 * Math.sin(W.time * 2.4 + i);
      }
    }

    // кнопка
    if (W.buttonMesh && W.state !== 'winning' && W.state !== 'win') {
      const ready = !W.coreAlive;
      W.buttonMesh.material.emissiveIntensity = ready ? 1.5 + 0.8 * Math.sin(W.time * 4.5) : 0.55 + 0.2 * Math.sin(W.time * 2);
      if (W.buttonGlow) W.buttonGlow.material.opacity = ready ? 0.2 + 0.12 * Math.sin(W.time * 4.5) : 0.08;
    }
    if (W.trapHoleRing) {
      W.trapHoleRing.material.opacity = 0.6 + 0.35 * Math.sin(W.time * 3.3);
    }

    if (W.ropePulse > 0) W.ropePulse = Math.max(0, W.ropePulse - dt);
    updateRopeVisual();
    applyTilt(dt);
    updateFade(dt);
    updatePalette(dt);        // v4.0: плавная смена палитры этажей
    updateGateVisual(dt);     // v4.0: анимация открывания люка
  }

  function updateFade(dt) {
    if (!W.camera || !W.fadeables.length) return;
    if (!_raycaster) _raycaster = new THREE.Raycaster();
    W.scene.updateMatrixWorld();

    const meshes = W.fadeables.map(f => f.mesh).filter(Boolean);
    const blocked = new Set();

    // лучи от камеры к важным объектам
    const targets = [];
    if (W.player && W.player.alive) targets.push(W.player);
    // кнопка и ядро — цели финальной зоны: учитываем, когда шар уже ниже воронки
    // или ядро разбито (иначе площадки гасли бы при любом взгляде сверху)
    const finale = (W.player && W.player.p.y < LEVEL_CONFIG.platformB.y - 1) || !W.coreAlive;
    if (finale) {
      if (W.coreAlive && W.coreGroup) targets.push(W.coreGroup.position);
      if (W.buttonGroup) targets.push(W.buttonGroup.position);
    }

    _vCam.copy(W.camera.position);
    for (const t of targets) {
      _vWorld.copy(t.p !== undefined ? t.p : t);
      W.glassGroup.localToWorld(_vWorld);
      const dir = _vWorld.clone().sub(_vCam);
      const dist = dir.length();
      if (dist < 0.5) continue;
      dir.normalize();
      _raycaster.set(_vCam, dir);
      // запас: не считать перекрытием поверхность, на которой объект лежит
      _raycaster.far = dist - (t.p !== undefined ? (t.r + 0.3) : 0.45);
      if (_raycaster.far < 0.6) continue;
      const hits = _raycaster.intersectObjects(meshes, false);
      for (const h of hits) blocked.add(h.object);
    }
    _raycaster.far = Infinity;

    const rate = 1 - Math.exp(-dt / 0.07);        // ~0.2 с на полное затухание
    for (const f of W.fadeables) {
      const mat = f.mesh && f.mesh.material;
      if (!mat) continue;
      // камера сверху или снизу площадки
      let base = f.base;
      if (f.kind === 'platform' || f.kind === 'bracket' || f.kind === 'net') {
        const topY = f.topY === undefined ? 0 : f.topY;
        _vWorld.set(0, topY, 0);
        W.glassGroup.localToWorld(_vWorld);
        base = (W.camera.position.y > _vWorld.y) ? f.base : (f.kind === 'net' ? f.base * 0.7 : 0.25);
      }
      const target = blocked.has(f.mesh) ? Math.min(0.1, base * 0.35) : base;
      mat.opacity = lerp(mat.opacity === undefined ? target : mat.opacity, target, rate);
      mat.transparent = true;
      mat.depthWrite = mat.opacity > 0.65;
    }
  }

  function updateCamera(dt) {
    const C = LEVEL_CONFIG.camera;
    const k = 1 - Math.exp(-dt / 0.085);
    // v3.5: интро-полёт камеры (2.5 с, скипается любым тапом)
    if (W.intro.active) {
      W.intro.t += dt;
      const kk = clamp(W.intro.t / W.intro.dur, 0, 1);
      const ease = 1 - Math.pow(1 - kk, 3);
      W.cam.theta = lerp(-0.8 * Math.PI, C.defaultTheta, ease);
      W.cam.phi = lerp(1.35, C.defaultPolar, ease);
      W.cam.dist = lerp(78, C.defaultDist, ease);
      if (kk >= 1) W.intro.active = false;
    }
    // инерция вращения камеры после отпускания ПКМ (см. bindInput)
    if (W.cam.spinTheta !== 0 || W.cam.spinPhi !== 0) {
      W.cam.tTheta += W.cam.spinTheta * dt;
      W.cam.tPhi += W.cam.spinPhi * dt;
      const damp = Math.exp(-dt / 0.26);
      W.cam.spinTheta *= damp; W.cam.spinPhi *= damp;
      if (Math.abs(W.cam.spinTheta) < 0.004) W.cam.spinTheta = 0;
      if (Math.abs(W.cam.spinPhi) < 0.004) W.cam.spinPhi = 0;
    }
    W.cam.tPhi = clamp(W.cam.tPhi, C.minPolar, C.maxPolar);
    W.cam.tDist = clamp(W.cam.tDist, C.minDist, C.maxDist);
    if (!W.intro.active) {
      W.cam.theta += (W.cam.tTheta - W.cam.theta) * k;
      W.cam.phi += (W.cam.tPhi - W.cam.phi) * k;
      W.cam.dist += (W.cam.tDist - W.cam.dist) * k;
      if (Math.abs(W.cam.tTheta - W.cam.theta) < 1e-6) W.cam.theta = W.cam.tTheta;
      if (Math.abs(W.cam.tPhi - W.cam.phi) < 1e-6) W.cam.phi = W.cam.tPhi;
      if (Math.abs(W.cam.tDist - W.cam.dist) < 1e-6) W.cam.dist = W.cam.tDist;
    }

    const sp = Math.sin(W.cam.phi), cp = Math.cos(W.cam.phi);
    const tx = (W.camTargetX || 0), ty = (W.camTargetY === undefined ? C.targetY : W.camTargetY), tz = (W.camTargetZ || 0);
    const dist = W.cam.dist + (W.camBreath || 0);   // v4.0: «дыхание» при переходе этажей
    W.camera.position.set(
      tx + dist * sp * Math.sin(W.cam.theta),
      ty + dist * cp,
      tz + dist * sp * Math.cos(W.cam.theta)
    );
    // тряска экрана ОБЯЗАНА затухать до нуля: раньше W.screenShake только
    // устанавливался и никогда не уменьшался — после первой встряски/взрыва
    // камера дрожала всю оставшуюся игру
    if (W.screenShake > 0) {
      W.screenShake = Math.max(0, W.screenShake - dt);
      if (W.screenShake <= 0) W.screenShakeAmp = 0;
    }
    if (W.screenShake > 0) {
      const f = clamp(W.screenShake / 0.25, 0, 1);
      const a = W.screenShakeAmp * f * f;               // квадратичное затухание
      W.camera.position.x += Math.sin(W.time * 77) * a;
      W.camera.position.y += Math.sin(W.time * 91.7) * a * 0.8;
      W.camera.position.z += Math.cos(W.time * 83.3) * a;
    }
    W.camera.lookAt(tx, ty, tz);
    W.camera.updateMatrixWorld();
  }

  // ===========================================================================
  // 20. РЕПЛЕЙ СПУСКА
  // ===========================================================================
  const Replay = {
    samples: [], acc: 0, playing: false, t: 0, prevState: 'play',

    reset() { this.samples = []; this.acc = 0; this.playing = false; this.t = 0; },

    record(dt) {
      if (W.state !== 'play' || !W.player) return;
      this.acc += dt;
      if (this.acc < 1 / 40) return;
      this.acc = 0;
      const p = W.player.p;
      const q = W.glassGroup.quaternion;
      this.samples.push({ t: W.runTime, x: p.x, y: p.y, z: p.z, qx: q.x, qy: q.y, qz: q.z, qw: q.w, cut: W.ropeCut ? 1 : 0 });
      if (this.samples.length > 4200) this.samples.shift();
    },

    canPlay() { return this.samples.length > 12; },

    start() {
      if (!this.canPlay()) { toast(curLang === 'ru' ? 'Нет записи спуска' : 'No descent recorded', 'bad'); return false; }
      this.prevState = W.state;
      this.playing = true;
      this.t = 0;
      // v4.0: на этажах 1+ повтор играет с момента входа на текущий этаж
      const S = this.samples;
      this.startIdx = 0;
      if (W.currentFloor > 0) {
        const fy = floorY(W.currentFloor) + 2.4;
        for (let i = S.length - 1; i >= 0; i--) {
          if (S[i].y > fy) { this.startIdx = Math.min(i + 1, S.length - 2); break; }
        }
      }
      W.state = 'replay';
      W.slowmo = 0; W.slowmoScale = 1;
      if (!W.ghost) {
        W.ghost = new THREE.Mesh(new THREE.SphereGeometry(LEVEL_CONFIG.player.radius, 20, 14),
          new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.42, depthWrite: false }));
        const halo = new THREE.Mesh(new THREE.TorusGeometry(LEVEL_CONFIG.player.radius * 1.35, 0.05, 8, 40),
          new THREE.MeshBasicMaterial({ color: 0x00d4ff, transparent: true, opacity: 0.75 }));
        halo.rotation.x = Math.PI / 2;
        W.ghost.add(halo);
      }
      W.glassGroup.add(W.ghost);
      W.ghost.visible = true;
      if (W.player && W.player.mesh) W.player.mesh.visible = false;
      Sound.ui();
      return true;
    },

    update(dt) {
      if (!this.playing) return;
      const S = this.samples;
      const i0 = this.startIdx || 0;
      const dur = S[S.length - 1].t - S[i0].t;
      this.t += dt;
      const tt = S[i0].t + this.t;
      if (this.t > dur + 0.35) { this.stop(); return; }
      // бинарный поиск
      let lo = 0, hi = S.length - 1;
      while (lo < hi - 1) { const mid = (lo + hi) >> 1; if (S[mid].t <= tt) lo = mid; else hi = mid; }
      const a = S[lo], b = S[Math.min(S.length - 1, lo + 1)];
      const span = Math.max(1e-6, b.t - a.t);
      const k = clamp((tt - a.t) / span, 0, 1);
      W.ghost.position.set(lerp(a.x, b.x, k), lerp(a.y, b.y, k), lerp(a.z, b.z, k));
      _qInv.set(a.qx, a.qy, a.qz, a.qw).slerp(new THREE.Quaternion(b.qx, b.qy, b.qz, b.qw), k);
      W.glassGroup.quaternion.copy(_qInv);
      if (W.ghostTrail === undefined) W.ghostTrail = 0;
    },

    stop() {
      this.playing = false;
      if (W.ghost) W.ghost.visible = false;
      if (W.player && W.player.mesh) W.player.mesh.visible = true;
      // вернуть фактический наклон
      _e.set(W.tilt.rotX, 0, W.tilt.rotZ, 'XYZ');
      W.glassGroup.quaternion.setFromEuler(_e);
      W.state = this.prevState === 'play' ? 'play' : this.prevState;
      if (W.state === 'win' || W.state === 'lose') { /* модальное окно снова видно */ App.syncModals(); }
      Sound.ui();
    }
  };

  // ===========================================================================
  // 21. DOM / ЛОКАЛИЗАЦИЯ / HUD
  // ===========================================================================
  function $(id) { return document.getElementById(id); }
  const el = {};
  const EL_IDS = ['scene', 'txt-title', 'txt-subtitle', 'txt-time-label', 'time-val', 'txt-magic-label', 'magic-val',
    'txt-trap-label', 'trap-val', 'txt-btn-shake', 'txt-btn-shake2', 'btn-shake', 'btn-shake-top', 'shake-fill', 'btn-cut', 'txt-btn-cut',
    'txt-btn-replay', 'btn-replay', 'lang-text', 'btn-lang', 'audio-ico', 'btn-audio', 'btn-settings', 'btn-help',
    'txt-btn-restart', 'btn-restart', 'txt-tilt-l', 'txt-tilt-r', 'tilt-deg', 'tilt-fill',
    'txt-status-line', 'status-row', 'txt-legend-red', 'txt-legend-blue', 'txt-legend-yellow', 'txt-legend-core',
    'txt-legend-btn', 'txt-legend-stats', 'txt-hint', 'toasts', 'replay-overlay', 'txt-replay-badge',
    'settings-panel', 'txt-settings-title', 'btn-close-settings', 'txt-set-speed', 'val-speed', 'slider-speed',
    'txt-set-speed-note', 'txt-set-impact', 'val-impact', 'slider-impact', 'txt-set-impact-note',
    'txt-set-size', 'val-size', 'slider-size', 'txt-set-size-note', 'txt-set-magic', 'val-magic', 'slider-magic',
    'txt-set-magic-note', 'btn-settings-reset', 'txt-set-reset', 'btn-settings-apply', 'txt-set-apply', 'txt-set-hint',
    'modal-menu', 'txt-menu-title', 'txt-menu-subtitle', 'txt-menu-s1', 'txt-menu-s2', 'txt-menu-s3', 'txt-menu-s4',
    'btn-start', 'txt-menu-start', 'btn-menu-help', 'txt-menu-help',
    'modal-victory', 'txt-victory-title', 'txt-victory-desc', 'txt-stat-time', 'stat-time', 'txt-stat-magic',
    'stat-magic', 'txt-stat-lost', 'stat-lost', 'txt-stat-cuts', 'stat-cuts', 'btn-again', 'txt-victory-again',
    'btn-victory-replay', 'txt-victory-replay', 'btn-victory-menu', 'txt-victory-menu',
    'modal-defeat', 'txt-defeat-title', 'txt-defeat-desc', 'txt-dstat-time', 'dstat-time', 'txt-dstat-magic',
    'dstat-magic', 'txt-dstat-reason', 'dstat-reason', 'btn-retry', 'txt-defeat-retry', 'btn-defeat-replay',
    'txt-defeat-replay', 'btn-defeat-menu', 'txt-defeat-menu',
    'modal-help', 'txt-help-title', 'txt-help-body', 'btn-close-help', 'txt-help-close',
    'modal-pause', 'txt-pause-title', 'txt-pause-desc', 'btn-resume', 'txt-pause-resume',
    'btn-pause-restart', 'txt-pause-restart', 'btn-pause-menu', 'txt-pause-menu',
    'pill-magic', 'pill-trap', 'pill-score', 'txt-score-label', 'score-val',
    'pill-combo', 'combo-val', 'level-strip', 'win-stars', 'btn-next', 'txt-next',
    'lvl-total', 'btn-sandbox', 'txt-sandbox', 'txt-level-name',
    'stat-score', 'txt-stat-score', 'stat-perfect', 'txt-stat-perfect',
    'floor-ind', 'floor-task',
    'btn-pipe-reset', 'txt-pipe-reset', 'btn-floor-restart', 'txt-floor-restart',
    'btn-floors', 'txt-floors',
    'modal-floorfail', 'ff-title', 'ff-desc', 'btn-ff-restart', 'txt-ff-restart', 'btn-ff-menu', 'txt-ff-menu',
    'txt-set-echo-r', 'val-echo-r', 'slider-echo-r', 'txt-set-echo-r-note',
    'txt-set-echo-w', 'val-echo-w', 'slider-echo-w', 'txt-set-echo-w-note',
    // v4.4: архитектура «МАТ-БУМ! 3» — экраны, верхняя панель, боковые панели
    'scr-start', 'scr-select', 'scr-hall', 'scr-help', 'scr-game',
    'btn-back', 'btn-theme', 'theme-ico', 'btn-user',
    'b-play', 'txt-menu-play', 'b-train', 'txt-menu-train', 'b-hall', 'txt-menu-hall', 'b-help', 'txt-menu-help2',
    'txt-ver', 'side-recs', 'txt-side-rec-t', 'txt-side-open', 'side-prog', 'txt-side-prog-t', 'txt-side-stars',
    'txt-sel-title', 'txt-sel-sub', 'txt-hall-title', 'txt-hall-sub', 'hall-list', 'hall-total', 'hall-ya',
    'txt-help-scr-title', 'txt-help-scr-sub', 'txt-help-body2', 'txt-help-footer',
    'train-plate', 'tut-step', 'tut-text',
    'btn-auto', 'txt-btn-auto'];

  function cacheDom() {
    for (const id of EL_IDS) {
      const node = $(id);
      if (node) el[id.replace(/-/g, '_')] = node;
    }
  }

  // v3.5: очки с комбо. События реже 3 с подряд наращивают множитель ×2→×4.
  function addScore(amount, label) {
    if (W.time - W.lastEventTime < 3) W.combo = Math.min(4, W.combo * 2);
    else W.combo = 1;
    W.lastEventTime = W.time;
    const total = Math.round(amount * W.combo);
    W.score += total;
    toast('+' + total + (W.combo > 1 ? ' ×' + W.combo : '') + (label ? ' · ' + label : ''), 'good');
    W.events.push({ t: W.time, type: 'score', amount: total, combo: W.combo });
  }

  function toast(text, cls, duration) {
    const box = el.toasts;
    if (!box) return;
    while (box.children.length > 3) box.removeChild(box.firstChild);
    const d = document.createElement('div');
    d.className = 'toast' + (cls ? ' ' + cls : '');
    d.innerHTML = text;
    box.appendChild(d);
    setTimeout(() => { if (d.parentNode) d.parentNode.removeChild(d); }, duration || 2600);
  }

  // ===========================================================================
  // v4.1: ПРОГРЕСС, ЧЕЛЛЕНДЖИ, ПЕСОЧНИЦА
  // ===========================================================================
  const PROGRESS_KEY = 'graviboom_v4_levels';       // JSON: 10 × {time, score, stars, challenge}
  const BEST_KEY = 'graviboom_v4_bestScore';        // общий рекорд очков
  const SPECIALS_KEY = 'graviboom_v4_challenges';   // 5 спец-челленджей (bool × 5)

  function freshProgress() {
    return LEVELS.map(() => ({ time: 0, score: 0, stars: 0, challenge: false }));
  }
  function loadProgress() {
    try {
      const a = JSON.parse(window.localStorage.getItem(PROGRESS_KEY) || 'null');
      if (Array.isArray(a) && a.length === LEVELS.length) {
        const f = freshProgress();
        for (let i = 0; i < a.length; i++) {
          if (a[i] && typeof a[i] === 'object') {
            f[i].time = +a[i].time || 0; f[i].score = +a[i].score || 0;
            f[i].stars = Math.min(3, Math.max(0, a[i].stars | 0)); f[i].challenge = !!a[i].challenge;
          }
        }
        return f;
      }
    } catch (e) {}
    return freshProgress();
  }
  function saveProgress() {
    try { window.localStorage.setItem(PROGRESS_KEY, JSON.stringify(W.progress)); } catch (e) {}
  }
  function loadSpecials() {
    try {
      const a = JSON.parse(window.localStorage.getItem(SPECIALS_KEY) || 'null');
      if (Array.isArray(a) && a.length === 5) return a.map(Boolean);
    } catch (e) {}
    return [false, false, false, false, false];
  }
  function saveSpecials() {
    try { window.localStorage.setItem(SPECIALS_KEY, JSON.stringify(W.specials)); } catch (e) {}
  }
  // v4.1: 1–5 открыты сразу; 6–10 открываются прохождением предыдущего
  function levelUnlocked(i) {
    if (W.sandboxMenu) return true;
    if (i < 5) return true;
    return !!(W.progress && W.progress[i - 1] && W.progress[i - 1].stars > 0);
  }
  function sandboxUnlocked() {
    return !!(W.progress && W.progress[LEVELS.length - 1] && W.progress[LEVELS.length - 1].stars > 0);
  }
  function challengeCount() {
    let n = 0;
    for (const p of W.progress) if (p.challenge) n++;
    for (const sp of W.specials) if (sp) n++;
    return n;
  }

  // 15 челленджей: 10 по уровням (после 3 звёзд) + 5 специальных.
  // test(rs) получает срез runStats; спец-челленджи проверяются на победе.
  const CHALLENGES = [
    { lvl: 0,  name: ['Без магии', 'No Magic'],           test: () => W.blastCount === 0 },
    { lvl: 1,  name: ['Скорострел', 'Sharpshooter'],      test: () => W.runTime < 90 },
    { lvl: 2,  name: ['Мимо мин', 'Past the Mines'],      test: (rs) => rs.mineHits === 0 },
    { lvl: 3,  name: ['Эхоман', 'Echo Man'],              test: (rs) => rs.echoBlasts >= 3 },
    { lvl: 4,  name: ['Без штрафов', 'Penalty-Free'],     test: () => W.attempts === 0 },
    { lvl: 5,  name: ['Полный фокус', 'Full Focus'],      test: (rs) => rs.plateFails === 0 && rs.mineHits === 0 },
    { lvl: 6,  name: ['Ровная линия', 'Straight Line'],   test: (rs) => rs.mineHits === 0 && rs.socketFails === 0 },
    { lvl: 7,  name: ['Только идеальные', 'Perfect Only'],test: () => W.perfectCuts >= 1 && (W.runStats ? W.runStats.cutMisses : 0) === 0 },
    { lvl: 8,  name: ['В такт', 'In Rhythm'],             test: (rs) => rs.plateFails === 0 },
    { lvl: 9,  name: ['Без единого сбоя', 'Flawless'],    test: () => W.attempts === 0 },
    { sp: 0, name: ['Звёздное небо', 'Starry Sky'],       test: () => W.progress.every(p => p.stars >= 3) },
    { sp: 1, name: ['Быстрее света', 'Faster Than Light'],test: () => W.runTime < 45 },
    { sp: 2, name: ['Пацифист', 'Pacifist'],              test: (rs) => W.blastCount === 0 && rs.shakes === 0 },
    { sp: 3, name: ['Коллекционер', 'Collector'],         test: () => W.bestScore >= 5000 },
    { sp: 4, name: ['Архитектор', 'Architect'],           test: () => W.progress.every(p => p.stars >= 1) }
  ];

  // v4.1: полоса уровней в меню — 10 кнопок с замками/звёздами/рекордами
  function renderLevelStrip() {
    const box = el.level_strip;
    if (!box) return;
    box.innerHTML = '';
    while (box.children.length) box.removeChild(box.firstChild);
    // v4.1: сверху — общий счётчик ★ N/30, общий рекорд и челленджи
    let total = 0;
    for (const p of W.progress) total += (p.stars | 0);
    if (el.lvl_total) {
      el.lvl_total.innerHTML =
        '<span>★ <b>' + total + '</b>/30</span>' +
        '<span>' + D().totalBest.replace('{n}', '<b>' + (W.bestScore | 0) + '</b>') + '</span>' +
        '<span>' + D().challengeLine.replace('{n}', String(challengeCount())) + '</span>';
    }
    for (let i = 0; i < LEVELS.length; i++) {
      const locked = !levelUnlocked(i);
      const pr = W.progress[i] || { time: 0, score: 0, stars: 0, challenge: false };
      const nm = LEVELS[i].name[curLang === 'ru' ? 0 : 1];
      const d = document.createElement('button');
      d.className = 'colcard' + (i === W.currentLevel && !W.sandboxMenu ? ' cur' : '') + (locked ? ' locked' : '');
      // v4.4: карточка уровня в стиле МБ3 — номер, свотчи цвета башни, имя, звёзды, рекорд
      const sw = '<span class="sw"><i style="background:' + LEVEL_PALETTES[i][0] + '"></i>' +
                 '<i style="background:' + LEVEL_PALETTES[i][1] + '"></i>' +
                 '<i style="background:' + LEVEL_PALETTES[i][2] + '"></i></span>';
      d.innerHTML =
        (locked ? '<span class="lock">🔒</span>' : (pr.challenge ? '<span class="ch" title="' + D().challengeDoneShort + '">✓</span>' : '')) +
        '<span class="num">' + (i + 1) + '</span>' +
        sw +
        '<span class="nm">' + nm + '</span>' +
        '<span class="stars">' + (pr.stars > 0 ? '★'.repeat(pr.stars) : '·') + '</span>' +
        '<span class="bst">' + (pr.score > 0 ? pr.score : '') + '</span>';
      d.title = (curLang === 'ru' ? 'Уровень ' : 'Level ') + (i + 1) + ' · ' + nm +
        (pr.stars > 0 ? ' · ' + '★'.repeat(pr.stars) : '') +
        (pr.score > 0 ? ' · ' + D().totalBest.replace('{n}', pr.score) : '') +
        (locked ? ' · ' + D().levelLocked : '');
      d.addEventListener('click', () => {
        if (locked) { toast(D().levelLocked, 'warn'); Sound.reject(); return; }
        App.start(i, W.sandboxMenu);
      });
      box.appendChild(d);
    }
    if (el.btn_sandbox) {
      el.btn_sandbox.classList.toggle('hidden', !sandboxUnlocked());
      el.btn_sandbox.classList.toggle('primary', W.sandboxMenu);
    }
  }

  function applyTexts() {
    Motion.text();
    const d = D();
    const T = (key, id) => { if (el[id]) el[id].textContent = d[key]; };
    const H = (key, id) => { if (el[id]) el[id].innerHTML = d[key]; };
    T('title', 'txt_title'); T('subtitle', 'txt_subtitle');
    T('timeLabel', 'txt_time_label'); T('magicLabel', 'txt_magic_label'); T('trapLabel', 'txt_trap_label');
    T('scoreLabel', 'txt_score_label'); T('comboLabel', 'txt_combo_label');
    T('btnShake', 'txt_btn_shake'); T('btnShake2', 'txt_btn_shake2'); T('btnCut', 'txt_btn_cut'); T('btnReplay', 'txt_btn_replay');
    T('btnPipeReset', 'txt_pipe_reset'); T('btnFloorRestart', 'txt_floor_restart'); T('btnFloorsShow', 'txt_floors');
    T('ffTitle', 'ff_title'); T('ffRestart', 'txt_ff_restart'); T('ffMenu', 'txt_ff_menu');
    T('btnRestart', 'txt_btn_restart'); T('btnLang', 'lang_text');
    T('tiltL', 'txt_tilt_l'); T('tiltR', 'txt_tilt_r');
    T('legendRed', 'txt_legend_red'); T('legendBlue', 'txt_legend_blue'); T('legendYellow', 'txt_legend_yellow');
    T('legendCore', 'txt_legend_core'); T('legendBtn', 'txt_legend_btn');
    H('hint', 'txt_hint');
    T('replayBadge', 'txt_replay_badge');
    T('menuTitle', 'txt_menu_title'); T('menuSubtitle', 'txt_menu_subtitle');
    H('menuS1', 'txt_menu_s1'); H('menuS2', 'txt_menu_s2'); H('menuS3', 'txt_menu_s3'); H('menuS4', 'txt_menu_s4');
    T('menuStart', 'txt_menu_start'); T('menuHelp', 'txt_menu_help');
    // v4.4: экраны МБ3
    T('menuPlay', 'txt_menu_play'); T('menuTrain', 'txt_menu_train');
    T('menuHall', 'txt_menu_hall'); T('menuHelp2', 'txt_menu_help2');
    T('ver', 'txt_ver'); T('selTitle', 'txt_sel_title'); T('selSub', 'txt_sel_sub');
    T('hallTitle', 'txt_hall_title'); T('hallSub', 'txt_hall_sub');
    T('helpScrTitle', 'txt_help_scr_title'); T('helpScrSub', 'txt_help_scr_sub');
    T('helpFooter', 'txt_help_footer');
    T('sideRecT', 'txt_side_rec_t'); T('sideProgT', 'txt_side_prog_t'); T('btnAuto', 'txt_btn_auto');
    T('victoryTitle', 'txt_victory_title'); T('victoryDesc', 'txt_victory_desc');
    T('statTime', 'txt_stat_time'); T('statMagic', 'txt_stat_magic'); T('statLost', 'txt_stat_lost'); T('statCuts', 'txt_stat_cuts');
    T('statScore', 'txt_stat_score'); T('statPerfect', 'txt_stat_perfect');
    T('victoryAgain', 'txt_victory_again'); T('victoryReplay', 'txt_victory_replay'); T('victoryMenu', 'txt_victory_menu'); T('nextLevel', 'txt_next');
    T('defeatTitle', 'txt_defeat_title'); T('defeatDesc', 'txt_defeat_desc');
    T('statTime', 'txt_dstat_time'); T('statMagic', 'txt_dstat_magic'); T('statReason', 'txt_dstat_reason');
    T('defeatRetry', 'txt_defeat_retry'); T('defeatReplay', 'txt_defeat_replay'); T('defeatMenu', 'txt_defeat_menu');
    T('helpTitle', 'txt_help_title'); H('helpBody', 'txt_help_body'); T('helpClose', 'txt_help_close');
    T('pauseTitle', 'txt_pause_title'); T('pauseDesc', 'txt_pause_desc');
    T('pauseResume', 'txt_pause_resume'); T('pauseRestart', 'txt_pause_restart'); T('pauseMenu', 'txt_pause_menu');
    T('settingsTitle', 'txt_settings_title');
    T('setSpeed', 'txt_set_speed'); T('setSpeedNote', 'txt_set_speed_note');
    T('setImpact', 'txt_set_impact'); T('setImpactNote', 'txt_set_impact_note');
    T('setSize', 'txt_set_size'); T('setSizeNote', 'txt_set_size_note');
    T('setMagic', 'txt_set_magic'); T('setMagicNote', 'txt_set_magic_note');
    T('setEchoR', 'txt_set_echo_r'); T('setEchoW', 'txt_set_echo_w');
    if (el.txt_set_echo_r_note) el.txt_set_echo_r_note.textContent = D().setEchoRNote.replace('{v}', SETTINGS.echoRadius.toFixed(1));
    if (el.txt_set_echo_w_note) el.txt_set_echo_w_note.textContent = D().setEchoWNote.replace('{v}', SETTINGS.echoWindow.toFixed(2));
    T('setReset', 'txt_set_reset'); T('setApply', 'txt_set_apply'); T('setHint', 'txt_set_hint');
    if (document.documentElement) document.documentElement.lang = curLang;
    renderLevelStrip();
    updateHud(0.1, true);
    renderSidePanels();      // v4.4: колонки рекордов/прогресса в главном меню
    renderHall();            // v4.4: зал славы
    renderHelpScreen();      // v4.4: экран справки
    renderTrainPlate();      // v4.4: плашка обучения
  }

  function setLanguage(lang) {
    curLang = (lang === 'en') ? 'en' : 'ru';
    try { window.localStorage.setItem('graviboom_lang_v300', curLang); } catch (e) {}
    applyTexts();
    syncSettingsUi();
  }

  function applySettingsLive(full) {
    for (const b of W.balls) if (b.alive) b.applySize();
    if (full) {
      for (const b of W.balls) if (b.mounted) b.mountPos.copy(b.p);
    }
  }

  function syncSettingsUi() {
    if (!el.slider_speed) return;
    el.slider_speed.value = String(SETTINGS.ballSpeed);
    el.slider_impact.value = String(SETTINGS.impactForce);
    el.slider_size.value = String(SETTINGS.ballSize);
    el.slider_magic.value = String(SETTINGS.magicTime);
    if (el.slider_echo_r) el.slider_echo_r.value = String(SETTINGS.echoRadius);
    if (el.slider_echo_w) el.slider_echo_w.value = String(SETTINGS.echoWindow);
    fmtSettingValues();
  }

  function fmtSettingValues() {
    if (el.val_speed) el.val_speed.textContent = SETTINGS.ballSpeed.toFixed(2) + '×';
    if (el.val_impact) el.val_impact.textContent = SETTINGS.impactForce.toFixed(2) + '×';
    if (el.val_size) el.val_size.textContent = SETTINGS.ballSize.toFixed(2) + '×';
    if (el.val_magic) el.val_magic.textContent = SETTINGS.magicTime.toFixed(1) + (curLang === 'ru' ? ' с' : ' s');
    if (el.val_echo_r) el.val_echo_r.textContent = SETTINGS.echoRadius.toFixed(1) + (curLang === 'ru' ? ' м' : ' m');
    if (el.val_echo_w) el.val_echo_w.textContent = SETTINGS.echoWindow.toFixed(2) + (curLang === 'ru' ? ' с' : ' s');
  }

  function updateHud(dt, force) {
    W.hudAcc = (W.hudAcc || 0) + dt;
    if (!force && W.hudAcc < 0.1) return;
    const hudDt = W.hudAcc;                       // v4.1: реальный накопленный интервал
    W.hudAcc = 0;
    const d = D();

    if (el.time_val) el.time_val.textContent = fmtTime(W.runTime);

    // заряженные шары
    let charged = 0, mounted = 0, free = 0;
    for (const b of W.balls) {
      if (!b.alive) continue;
      if (b.chargeT > 0) charged++;
      if (b.kinematic) mounted++; else free++;
    }
    if (el.magic_val) el.magic_val.textContent = String(charged);
    if (el.trap_val) el.trap_val.textContent = String(W.trapBalls || 0);
    // v3.5 (4.2): легенда удалена, статистику шаров больше не показываем
    // v3.5 (2.3): таблетки видны только когда есть что показывать
    if (el.pill_magic) el.pill_magic.style.display = charged > 0 ? '' : 'none';
    if (el.pill_trap) el.pill_trap.style.display = (W.trapBalls || 0) > 0 ? '' : 'none';
    // v3.5 (1.4): очки и комбо
    if (el.score_val) el.score_val.textContent = String(W.score);
    if (el.combo_val) el.combo_val.textContent = '×' + W.combo;
    if (el.pill_combo) el.pill_combo.style.opacity = W.combo > 1 ? '1' : '0.35';
    // v3.5 (2.4): пульс HUD по BPM — тем чаще, чем глубже шар
    const hudTop = document.querySelector('.hud-top');
    if (W.state === 'play' && W.player && hudTop) {
      const depth = clamp(1 - (W.player.p.y - LEVEL_CONFIG.glass.yBottom) /
        (LEVEL_CONFIG.glass.yTop - LEVEL_CONFIG.glass.yBottom), 0, 1);
      const bpm = (70 + 60 * depth) / 60;
      if (hudTop.style && hudTop.style.setProperty) hudTop.style.setProperty('--bpm', bpm.toFixed(2) + 's');
      if (!hudTop.classList.contains('pulsing')) hudTop.classList.add('pulsing');
    } else if (hudTop) {
      hudTop.classList.remove('pulsing');
    }
    // v4.1: плашка названия уровня тает к концу прогона первых секунд
    if (el.txt_level_name) {
      if (W.levelNameT > 0 && W.state === 'play') {
        W.levelNameT -= hudDt;
        el.txt_level_name.classList.remove('hidden');
        el.txt_level_name.classList.toggle('fading', W.levelNameT < 0.9);
      } else if (!el.txt_level_name.classList.contains('hidden')) {
        el.txt_level_name.classList.add('hidden');
      }
    }
    // v3.5 (2.3): подсказка внизу гаснет через 5 с игры, возвращается в меню/паузе
    // v4.1: hints<=1 — нижняя подсказка выключена совсем (уровни 6-8 и 9-10)
    if (el.txt_hint) {
      if (LV().hints < 2) el.txt_hint.style.opacity = '0';
      else if (W.state === 'play' && W.time - W.hintShownAt > 5) el.txt_hint.style.opacity = '0';
      else el.txt_hint.style.opacity = '1';
      el.txt_hint.style.transition = 'opacity 0.8s';
    }

    // строка состояния
    if (el.txt_status_line) {
      let txt = d.statusRope, cls = '';
      const pl = W.player;
      if (W.state === 'win' || W.state === 'winning') { txt = d.statusWin; cls = ''; }
      else if (W.state === 'lose' || W.state === 'losing') { txt = d.statusTrap.replace('{n}', String(Math.max(0, Math.ceil(W.trapTimer)))); cls = 'bad'; }
      else if (W.trapTimer > 0) { txt = d.statusTrap.replace('{n}', String(Math.ceil(W.trapTimer))); cls = 'bad'; }
      else if (pl) {
        const y = pl.p.y;
        const f = W.currentFloor || 0;
        if (!W.ropeCut && f === 0) txt = d.statusRope;
        else if (f === 0) {
          const sks = W.floorState && W.floorState.sockets;
          const a = sks ? sks.filter(q => q.full).length : 0, b = sks ? sks.length : 0;
          txt = d.statusSocket.replace('{a}', String(a)).replace('{b}', String(b));
        } else if (f === 1) {
          const pp = W.floorState && W.floorState.pipe;
          if (W.floorSolvedFlag) txt = d.floorSolved;
          else if (pp) {
            const rds = pp.roads.filter(q => q.layout);
            const a = rds.reduce((sum, q) => sum + (q.hit || 0), 0);
            const b = rds.reduce((sum, q) => sum + (q.need || 0), 0);
            txt = d.taskPipe.replace('{a}', String(a)).replace('{b}', String(b));
          } else txt = d.taskPipe;
        } else if (f === 2) {
          const ps = W.floorState && W.floorState.plates;
          const a = ps ? ps.filter(q => q.active).length : 0, b = ps ? ps.length : 0;
          txt = d.plateStatus.replace('{a}', String(a)).replace('{b}', String(b));
        } else if (f === 3) {
          if (y >= -1.6) txt = d.statusCore;
          else txt = d.statusButton;
        } else { txt = d.statusRope; }
        if (charged > 0 && cls !== 'bad') {
          let tmin = 99;
          for (const b of W.balls) if (b.alive && b.chargeT > 0 && b.chargeT < tmin) tmin = b.chargeT;
          txt = d.statusCharged.replace('{n}', String(charged)).replace('{t}', tmin.toFixed(1));
          cls = 'warn';
        }
      }
      if (el.txt_status_line.textContent !== txt) el.txt_status_line.textContent = txt;
      el.txt_status_line.className = cls;
    }

    // v4.0: индикатор этажа (4 точки + n/4 + название)
    if (el.floor_ind) {
      if (!W._floorDots) {
        W._floorDots = [];
        for (let i = 0; i < 4; i++) {
          const dot = document.createElement('i');
          el.floor_ind.appendChild(dot);
          W._floorDots.push(dot);
        }
        const num = document.createElement('span');
        num.className = 'fnum';
        el.floor_ind.appendChild(num);
        W._floorNum = num;
        const nm = document.createElement('span');
        nm.className = 'fname';
        el.floor_ind.appendChild(nm);
        W._floorName = nm;
      }
      const f = clamp(W.currentFloor || 0, 0, 3);
      for (let i = 0; i < 4; i++) {
        W._floorDots[i].className = i < f ? 'done' : (i === f ? 'cur' : '');
      }
      if (W._floorNum.textContent !== undefined) W._floorNum.textContent = (f + 1) + '/4';
      if (W._floorName.textContent !== undefined) W._floorName.textContent = D().floorNames[f];
    }

    // v4.0: строка задания этажа
    if (el.floor_task) {
      const f = clamp(W.currentFloor || 0, 0, 3);
      const d2 = D();
      let task = '';
      if (f === 0) {
        const sks = W.floorState && W.floorState.sockets;
        if (W.floorSolvedFlag) task = d2.floorSolved;
        else if (sks) task = d2.taskSockets.replace('{a}', String(sks.filter(q => q.full).length)).replace('{b}', String(sks.length));
      } else if (f === 1) {
        const pp = W.floorState && W.floorState.pipe;
        if (W.floorSolvedFlag) task = d2.floorSolved;
        else if (pp) {
          const rds = pp.roads.filter(q => q.layout);
          const a = rds.reduce((sum, q) => sum + (q.hit || 0), 0);
          const b = rds.reduce((sum, q) => sum + (q.need || 0), 0);
          task = d2.taskPipe.replace('{a}', String(a)).replace('{b}', String(b));
        }
      } else if (f === 2) {
        const ps = W.floorState && W.floorState.plates;
        if (W.floorSolvedFlag) task = d2.floorSolved;
        else if (ps) task = d2.taskPlates.replace('{a}', String(ps.filter(q => q.active).length)).replace('{b}', String(ps.length));
      } else {
        task = d2.taskButton;
      }
      if (el.floor_task.textContent !== task) el.floor_task.textContent = task;
    }

    // v4.2: кнопки этажных действий (видимость зависит от этажа)
    const fBtn = clamp(W.currentFloor || 0, 0, 3);
    if (el.btn_pipe_reset) el.btn_pipe_reset.style.display =
      (W.state === 'play' && !W.ffOpen && fBtn === 1 && !W.floorSolvedFlag && W.floorState && W.floorState.pipe && !inTransition()) ? '' : 'none';
    if (el.btn_floor_restart) el.btn_floor_restart.style.display =
      (W.state === 'play' && !W.ffOpen && fBtn === 2 && !W.floorSolvedFlag && W.floorState && W.floorState.plates && W.floorState.deactShown && !inTransition()) ? '' : 'none';
    if (el.btn_floors) {
      const anySolved = W.floorSolvedArr && W.floorSolvedArr.some(v => v);
      el.btn_floors.style.display = (W.state === 'play' && anySolved) ? '' : 'none';
      const lbl = W.floorsGhost ? D().btnFloorsHide : D().btnFloorsShow;
      if (el.txt_floors && el.txt_floors.textContent !== lbl) el.txt_floors.textContent = lbl;
    }

    // наклон
    const tmag = Math.hypot(W.tilt.rotX, W.tilt.rotZ) / LEVEL_CONFIG.tilt.max;
    if (el.tilt_fill) {
      const side = Math.abs(W.tilt.rotZ) > Math.abs(W.tilt.rotX) ? (W.tilt.rotZ < 0 ? 1 : -1) : (W.tilt.rotX > 0 ? 1 : -1);
      const w = clamp(tmag, 0, 1) * 50;
      el.tilt_fill.style.width = w.toFixed(1) + '%';
      el.tilt_fill.style.left = (side > 0 ? 50 : 50 - w).toFixed(1) + '%';
      el.tilt_fill.style.background = tmag > 0.55
        ? 'linear-gradient(90deg,#ffcc00,#ff3355)'
        : 'linear-gradient(90deg,#00d4ff,#00ffaa)';
    }
    if (el.tilt_deg) el.tilt_deg.textContent = (Math.hypot(W.tilt.rotX, W.tilt.rotZ) / DEG).toFixed(0) + '°';

    // кулдаун встряски
    const cd = clamp(W.shakeCd / LEVEL_CONFIG.shake.cooldown, 0, 1);
    if (el.shake_fill) el.shake_fill.style.transform = 'scaleX(' + (1 - cd).toFixed(3) + ')';
    if (el.btn_cut) el.btn_cut.classList.toggle('hidden', !(!W.ropeCut && W.state === 'play' && W.currentFloor === 0));
    if (el.btn_shake) el.btn_shake.classList.toggle('cooling', cd > 0);
    if (el.btn_shake_top) el.btn_shake_top.classList.toggle('cooling', cd > 0);
  }

  // ===========================================================================
  // 22. ПРИЛОЖЕНИЕ
  // ===========================================================================
  const App = {
    renderer: null,
    canvas: null,
    running: false,
    audioOn: true,
    helpOpen: false,

    init() {
      cacheDom();
      this.canvas = el.scene;
      if (!this.canvas) throw new Error('canvas #scene не найден');

      // --- рендерер ---
      this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      this.renderer.setSize(window.innerWidth, window.innerHeight, false);
      try { if ('outputColorSpace' in this.renderer && THREE.SRGBColorSpace) this.renderer.outputColorSpace = THREE.SRGBColorSpace; } catch (e) {}
      try { this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.08; } catch (e) {}
      W.renderer = this.renderer;

      // --- сцена и камера ---
      W.scene = new THREE.Scene();
      W.scene.background = new THREE.Color(0x04060f);
      W.scene.fog = new THREE.Fog(0x04060f, 110, 300);
      const C = LEVEL_CONFIG.camera;
      W.camera = new THREE.PerspectiveCamera(C.fov, window.innerWidth / Math.max(1, window.innerHeight), C.near, C.far);
      W.camera.position.set(0, 20, 46);

      this.buildBackdrop();
      this.buildLights();

      // --- уровень ---
      initMaterials();
      // v4.1: прогресс 10 уровней + общий рекорд из localStorage
      try { W.bestScore = parseInt(window.localStorage.getItem(BEST_KEY) || '0', 10) || 0; } catch (e) { W.bestScore = 0; }
      W.progress = loadProgress();
      W.specials = loadSpecials();
      buildLevel();
      initFX();
      hangPlayer();

      this.bindUi();
      this.bindInput();

      try {
        const savedLang = window.localStorage.getItem('graviboom_lang_v300');
        curLang = (savedLang === 'en') ? 'en' : 'ru';
      } catch (e) {}
      applyTexts();
      syncSettingsUi();
      applyTheme(getTheme());          // v4.4: тема из localStorage
      bindPlatformGuards();            // v4.4: contextmenu off
      showScreen('scr-start');         // v4.4: главный экран-меню

      window.addEventListener('resize', () => this.onResize());
      window.addEventListener('blur', () => { if (W.state === 'play') this.pause(); Sound.setEnabled(false); });
      window.addEventListener('focus', () => { if (!document.hidden && !PLAT.adMuted) Sound.setEnabled(this.audioOn !== false); });
      document.addEventListener('visibilitychange', () => {
        // v4.4 (требование 1.3): при потере фокуса — пауза И глушение звука
        if (document.hidden) {
          if (W.state === 'play') this.pause();
          Sound.setEnabled(false);
        } else {
          Sound.setEnabled(this.audioOn !== false && !PLAT.adMuted);
        }
      });

      W.state = 'menu';
      this.syncModals();
      updateCamera(0.016);

      this.running = true;
      this.lastT = (window.performance && performance.now) ? performance.now() : Date.now();
      requestAnimationFrame(t => this.frame(t));
    },

    buildBackdrop() {
      // звёзды
      const N = 1400;
      const pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
      for (let i = 0; i < N; i++) {
        const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, s = Math.sqrt(1 - u * u);
        const rr = rnd(120, 260);
        pos[i * 3] = Math.cos(th) * s * rr; pos[i * 3 + 1] = u * rr * 0.8; pos[i * 3 + 2] = Math.sin(th) * s * rr;
        const t = Math.random();
        col[i * 3] = 0.55 + t * 0.45; col[i * 3 + 1] = 0.7 + t * 0.3; col[i * 3 + 2] = 1.0;
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      const stars = new THREE.Points(g, new THREE.PointsMaterial({
        size: 1.1, vertexColors: true, transparent: true, opacity: 0.85,
        depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true
      }));
      stars.frustumCulled = false;
      W.scene.add(stars);
      W.stars = stars;

      // дальнее свечение под стаканом
      const cv = document.createElement('canvas'); cv.width = cv.height = 256;
      const ctx = cv.getContext('2d');
      const grd = ctx.createRadialGradient(128, 128, 8, 128, 128, 126);
      grd.addColorStop(0, 'rgba(0,180,255,0.55)');
      grd.addColorStop(0.5, 'rgba(0,90,160,0.18)');
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd; ctx.fillRect(0, 0, 256, 256);
      const tex = new THREE.CanvasTexture(cv);
      const glow = new THREE.Mesh(new THREE.PlaneGeometry(220, 220),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
      glow.rotation.x = -Math.PI / 2;
      glow.position.y = -42;
      W.scene.add(glow);
    },

    buildLights() {
      const hemi = new THREE.HemisphereLight(0x9fd8ff, 0x0a1224, 1.15);
      W.scene.add(hemi);
      const key = new THREE.DirectionalLight(0xffffff, 2.6);
      key.position.set(22, 34, 26);
      W.scene.add(key);
      const fill = new THREE.DirectionalLight(0x66aaff, 1.1);
      fill.position.set(-24, 10, -18);
      W.scene.add(fill);
      const rim = new THREE.DirectionalLight(0xff88aa, 0.7);
      rim.position.set(0, -18, -22);
      W.scene.add(rim);
      const p1 = new THREE.PointLight(0x00d4ff, 260, 60, 2);
      p1.position.set(0, 8, 0);
      W.scene.add(p1);
      const p2 = new THREE.PointLight(0xff3355, 180, 34, 2);
      p2.position.set(0, -2.5, 0);
      W.scene.add(p2);
      const p3 = new THREE.PointLight(0xd946ef, 200, 30, 2);
      p3.position.set(0, 1.2, 0);
      W.scene.add(p3);
      W.lights = { hemi: hemi, key: key, fill: fill, rim: rim, p1: p1, p2: p2, p3: p3 };
    },

    onResize() {
      if (!this.renderer || !W.camera) return;
      const w = window.innerWidth, h = Math.max(1, window.innerHeight);
      this.renderer.setSize(w, h, false);
      W.camera.aspect = w / h;
      W.camera.updateProjectionMatrix();
    },

    // ---------------- СОСТОЯНИЯ ----------------
    start(levelIdx, sandbox) {
      autoStop('level');                   // v4.4: АВТО не переживает рестарт
      Sound.init();
      if (levelIdx !== undefined && levelIdx !== null) {
        W.currentLevel = clamp(levelIdx | 0, 0, LEVELS.length - 1);
      }
      W.sandbox = !!sandbox;                       // v4.1: песочница — без записи результатов
      W.ffOpen = false; W.ffReason = null; W.autoPull = null;   // v4.2
      Replay.reset();
      buildLevel();
      initFX();
      hangPlayer();
      W.state = 'play';
      W.runTime = 0;
      // v3.5: интро-полёт камеры 2.5 с (скипается любым тапом)
      W.intro.active = true;
      W.intro.t = 0;
      W.cam.theta = -0.8 * Math.PI;
      W.cam.phi = 1.35;
      W.cam.dist = 78;
      W.cam.tTheta = LEVEL_CONFIG.camera.defaultTheta;
      W.cam.tPhi = LEVEL_CONFIG.camera.defaultPolar;
      W.cam.tDist = LEVEL_CONFIG.camera.defaultDist;
      W.cam.spinTheta = 0; W.cam.spinPhi = 0;
      W.introWasActive = true;
      W.hintShownAt = W.time;
      // v4.1: название уровня в HUD (тает через ~4.5 с)
      W.levelNameT = 4.5;
      if (el.txt_level_name) {
        el.txt_level_name.innerHTML =
          (W.sandbox ? '🧪 ' : '') +
          (curLang === 'ru' ? 'УРОВЕНЬ ' : 'LEVEL ') + (W.currentLevel + 1) + ' · ' +
          LEVELS[W.currentLevel].name[curLang === 'ru' ? 0 : 1];
        el.txt_level_name.classList.remove('hidden', 'fading');
      }
      showScreen('scr-game');          // v4.4: игровой экран
      if (tut.active) renderTrainPlate(true);   // v4.4: плашка обучения на месте
      this.syncModals();
      applySettingsLive(true);
      updateHud(0.1, true);
    },

    restart() { this.start(); },
    // разрез троса по кнопке HUD / горячее клавише X (жест мышью — отдельно)
    tryCut() {
      if (W.state !== 'play' || W.ropeCut) return false;
      const ok = cutRope();
      if (ok) { W.ropeHover = false; if (this.canvas) this.canvas.style.cursor = 'grab'; }
      return ok;
    },

    pause() {
      if (W.state !== 'play') return;
      W.state = 'pause';
      this.syncModals();
      Sound.ui();
    },

    resume() {
      if (W.state !== 'pause' || PLAT.adMuted || document.hidden) return;
      W.state = 'play';
      this.syncModals();
      Sound.ui();
    },

    toMenu() {
      autoStop('level');                   // v4.4: выход — АВТО прочь
      W.state = 'menu';
      W.slowmo = 0; W.slowmoScale = 1; W.fireworkT = 0;
      if (Replay.playing) Replay.stop();
      stopTraining();                  // v4.4: выход из обучения
      showScreen('scr-start');         // v4.4: экран главного меню
      this.syncModals();
      Sound.ui();
      maybeAd();                       // v4.4: реклама в естественной паузе (≥180 с)
    },

    togglePause() {
      if (W.state === 'play') this.pause();
      else if (W.state === 'pause') this.resume();
    },

    showVictory() {
      // v4.1: рекорд очков — общий (graviboom_v4_bestScore)
      const isRecord = W.score > (W.bestScore || 0);
      if (isRecord) {
        W.bestScore = W.score;
        try { window.localStorage.setItem(BEST_KEY, String(W.bestScore)); } catch (e) {}
      }
      // v3.5: звёзды 1–3: победа / время < 60 с / ни одной ошибки
      let stars = 1;
      if (W.runTime < 60) stars++;
      if (W.failStreak === 0 && W.attempts === 0) stars++;
      // v4.1: запись прогресса уровня + челленджи (в песочнице не сохраняется)
      if (!W.sandbox && W.progress) {
        const pr = W.progress[W.currentLevel];
        pr.score = Math.max(pr.score, W.score);
        pr.stars = Math.max(pr.stars, stars);
        pr.time = (pr.time > 0) ? Math.min(pr.time, W.runTime) : W.runTime;
        saveProgress();        // челленджи: 10 по уровням (доступ после 3 звёзд) + 5 спец
        const rs = W.runStats || { shakes: 0, plateFails: 0, mineHits: 0, echoBlasts: 0, socketFails: 0, dives: 0, cutMisses: 0 };
        const li = curLang === 'ru' ? 0 : 1;
        const doneNames = [];
        for (const ch of CHALLENGES) {
          let ok = false;
          try { ok = ch.test(rs); } catch (e) { ok = false; }
          if (!ok) continue;
          if (ch.lvl !== undefined) {
            if (ch.lvl === W.currentLevel && pr.stars >= 3 && !pr.challenge) { pr.challenge = true; doneNames.push(ch.name[li]); }
          } else if (!W.specials[ch.sp]) {
            W.specials[ch.sp] = true; doneNames.push(ch.name[li]);
          }
        }
        if (doneNames.length) {
          saveProgress(); saveSpecials();
          setTimeout(() => { toast(D().challengeDone.replace('{n}', doneNames.join(' · ')), 'magic', 4000); }, 700);
          Sound.floorDone();
        }
        // v4.4: облако + лидерборд Яндекса (гостевой режим — тихо пропускается)
        cloudSave();
        lbSubmit(W.bestScore || 0);
      }
      if (el.stat_time) el.stat_time.textContent = fmtTime(W.runTime);
      if (el.stat_magic) el.stat_magic.textContent = String(W.blastCount);
      if (el.stat_lost) el.stat_lost.textContent = String(W.lostCount);
      if (el.stat_cuts) el.stat_cuts.textContent = String(W.cutCount);
      if (el.stat_score) el.stat_score.textContent = String(W.score);
      if (el.stat_perfect) el.stat_perfect.textContent = String(W.perfectCuts);
      if (el.txt_victory_title) el.txt_victory_title.textContent = D().victoryTitle + (isRecord ? ' · ' + D().newRecord : '');
      if (el.win_stars) {
        let sh = '';
        for (let i = 0; i < 3; i++) sh += '<span class="' + (i < stars ? 'on' : 'off') + '">★</span>';
        el.win_stars.innerHTML = sh;
      }
      // v3.5: «Следующий уровень» на всех уровнях, кроме последнего
      if (el.btn_next) el.btn_next.classList.toggle('hidden', W.currentLevel >= LEVELS.length - 1);
      // финальный уровень: салют продолжается и за модалкой
      W.fireworkT = (W.currentLevel === LEVELS.length - 1) ? Math.max(W.fireworkT, 1.7) : 0;
      this.syncModals();
    },

    showDefeat() {
      if (el.dstat_time) el.dstat_time.textContent = fmtTime(W.runTime);
      if (el.dstat_magic) el.dstat_magic.textContent = String(W.blastCount);
      if (el.dstat_reason) el.dstat_reason.textContent = W.loseReason === 'trap' ? D().reasonTrap : D().reasonMiss;
      this.syncModals();
    },

    syncModals() {
      const s = W.state;
      const show = (node, on) => { if (node) node.classList.toggle('hidden', !on); };
      show(el.modal_victory, s === 'win' && !this.helpOpen && !W.ffOpen);
      show(el.modal_defeat, s === 'lose' && !this.helpOpen && !W.ffOpen);
      show(el.modal_pause, s === 'pause' && !this.helpOpen && !W.ffOpen);
      show(el.modal_help, this.helpOpen && !W.ffOpen);
      show(el.modal_floorfail, !!W.ffOpen);
      show(el.replay_overlay, s === 'replay');
      if (s === 'menu') { renderLevelStrip(); renderSidePanels(); }   // v4.4: свежие данные меню
      // v4.4: геймплейная разметка для платформы (1.19.3)
      const inPlay = (s === 'play') && curScreen === 'scr-game' && !this.helpOpen && !W.ffOpen;
      if (inPlay) gameplayStart(); else gameplayStop();
    },

    openHelp() {
      this.helpOpen = true;
      if (W.state === 'play') W.state = 'pause';
      this.syncModals();
      Sound.ui();
    },

    // v4.2: закрыть модалку невыполнимого этажа
    closeFf(action) {
      const reason = W.ffReason;
      W.ffOpen = false;
      W.ffReason = null;
      this.syncModals();
      if (action === 'restart') {
        if (reason === 'plate') restartResonanceFloor();
        else this.start();
      } else if (action === 'menu') {
        this.toMenu();
      }
    },

    closeHelp() {
      this.helpOpen = false;
      this.syncModals();
      Sound.ui();
    },

    toggleSettings() {
      if (!el.settings_panel) return;
      const on = el.settings_panel.classList.contains('hidden');
      el.settings_panel.classList.toggle('hidden', !on);
      if (on) {
        this.settingsWasPlaying = W.state === 'play';
        if (App.resetInput) App.resetInput();
        if (this.settingsWasPlaying) this.pause();
      } else if (this.settingsWasPlaying) { this.settingsWasPlaying = false; this.resume(); }
      Sound.ui();
    },

    toggleReplay() {
      if (W.state === 'replay') { Replay.stop(); return; }
      if (!Replay.canPlay()) { toast(curLang === 'ru' ? 'Запись пуста: сначала разрежьте трос' : 'Recording empty: cut the rope first', 'bad'); return; }
      if (W.state === 'play') W.prevBeforeReplay = 'play';
      Replay.prevState = (W.state === 'play') ? 'play' : W.state;
      el.modal_victory && el.modal_victory.classList.add('hidden');
      el.modal_defeat && el.modal_defeat.classList.add('hidden');
      Replay.start();
      this.syncModals();
    },

    toggleLang() { setLanguage(curLang === 'ru' ? 'en' : 'ru'); Sound.ui(); },

    toggleAudio() {
      this.audioOn = !this.audioOn;
      Sound.init();
      Sound.setEnabled(this.audioOn && !PLAT.adMuted && !document.hidden);
      if (el.audio_ico) el.audio_ico.textContent = this.audioOn ? '🔊' : '🔇';
    },

    // ---------------- ВВОД ----------------
    bindUi() {
      const on = (node, ev, fn) => { if (node) node.addEventListener(ev, fn); };
      on(el.btn_start, 'click', () => this.start());
      on(el.btn_sandbox, 'click', () => {
        W.sandboxMenu = !W.sandboxMenu;
        toast(W.sandboxMenu ? D().sandboxOn : D().sandboxOff, W.sandboxMenu ? 'magic' : 'warn', 3000);
        Sound.ui();
        renderLevelStrip();
      });
      on(el.btn_menu_help, 'click', () => this.openHelp());
      on(el.btn_help, 'click', () => this.openHelp());
      on(el.btn_close_help, 'click', () => this.closeHelp());
      on(el.btn_resume, 'click', () => this.resume());
      on(el.btn_pipe_reset, 'click', () => {
        if (W.state !== 'play' || W.ffOpen || W.currentFloor !== 1 || inTransition()) return;
        if (W.floorStates && W.floorStates[1] && W.floorStates[1].pipe) {
          resetPipeRoads('button');
          Sound.ui();
        }
      });
      on(el.btn_floor_restart, 'click', () => {
        if (W.state !== 'play' || W.ffOpen || W.currentFloor !== 2 || inTransition()) return;
        restartResonanceFloor();
      });
      on(el.btn_floors, 'click', () => {
        W.floorsGhost = !W.floorsGhost;
        syncFloorViz();
        Sound.ui();
      });
      on(el.btn_victory_menu, 'click', () => this.toMenu());
      on(el.btn_defeat_menu, 'click', () => this.toMenu());
      on(el.btn_victory_replay, 'click', () => this.toggleReplay());
      on(el.btn_defeat_replay, 'click', () => this.toggleReplay());
      on(el.btn_replay, 'click', () => this.toggleReplay());
      on(el.btn_cut, 'click', () => this.tryCut());
      on(el.btn_shake, 'click', () => doShake());
      on(el.btn_shake_top, 'click', () => doShake());
      on(el.btn_lang, 'click', () => this.toggleLang());
      on(el.btn_audio, 'click', () => this.toggleAudio());
      on(el.btn_settings, 'click', () => this.toggleSettings());
      on(el.btn_close_settings, 'click', () => this.toggleSettings());
      on(el.btn_settings_reset, 'click', () => { resetSettings(); syncSettingsUi(); applySettingsLive(true); toast(curLang === 'ru' ? 'Настройки сброшены' : 'Settings reset', 'good'); });
      on(el.btn_settings_apply, 'click', () => { saveSettings(); this.start(); });

      // ---------------- v4.4: экраны «МАТ-БУМ! 3» ----------------
      on(el.b_play, 'click', () => { Sound.ui(); showScreen('scr-select'); });
      on(el.b_train, 'click', () => { Sound.ui(); startTraining(); });
      on(el.b_hall, 'click', () => { Sound.ui(); showScreen('scr-hall'); });
      on(el.b_help, 'click', () => { Sound.ui(); showScreen('scr-help'); });
      on(el.btn_theme, 'click', () => toggleTheme());
      on(el.btn_auto, 'click', () => autoToggle());   // v4.4: автосборка этажа
      on(el.btn_back, 'click', () => {
        Sound.ui();
        if (curScreen === 'scr-game') this.toMenu();
        else if (W.state === 'menu') showScreen('scr-start');
      });
      // реклама в естественных паузах: «ещё раз», «следующий», рестарты (≥180 с)
      on(el.btn_again, 'click', () => maybeAd(() => this.start()));
      on(el.btn_next, 'click', () => maybeAd(() => this.start(W.currentLevel + 1)));
      on(el.btn_retry, 'click', () => maybeAd(() => this.start()));
      on(el.btn_restart, 'click', () => maybeAd(() => this.start()));
      on(el.btn_pause_restart, 'click', () => maybeAd(() => this.start()));
      on(el.btn_ff_restart, 'click', () => maybeAd(() => this.closeFf('restart')));
      on(el.btn_pause_menu, 'click', () => this.toMenu());
      on(el.btn_ff_menu, 'click', () => this.closeFf('menu'));

      const bindSlider = (slider, valEl, key, fmt) => {
        if (!slider) return;
        slider.addEventListener('input', () => {
          const v = parseFloat(slider.value);
          if (!isFinite(v)) return;
          const L = SETTINGS_LIMITS[key];
          SETTINGS[key] = clamp(v, L.min, L.max);
          // v3.5: ручное изменение времени магии — дефолты уровней больше не применяем
          if (key === 'magicTime') W.magicTouched = true;
          fmtSettingValues();
          applySettingsLive(false);
        });
        slider.addEventListener('change', () => {
          saveSettings();
          // размер шаров меняет геометрию уровня (горловина, пробка, кнопка,
          // ядро, бортик, трос) — пересобираем уровень, иначе коллайдеры устареют
          if (key === 'ballSize') { App.start(); toast(D().toastSize, 'good'); }
        });
      };
      bindSlider(el.slider_speed, el.val_speed, 'ballSpeed');
      bindSlider(el.slider_impact, el.val_impact, 'impactForce');
      bindSlider(el.slider_size, el.val_size, 'ballSize');
      bindSlider(el.slider_magic, el.val_magic, 'magicTime');
      bindSlider(el.slider_echo_r, el.val_echo_r, 'echoRadius');
      bindSlider(el.slider_echo_w, el.val_echo_w, 'echoWindow');

      window.addEventListener('keydown', e => {
        if (PLAT.adMuted || document.hidden) return;
        const k = e.code && /^Key[A-Z]$/.test(e.code) ? e.code.slice(3).toLowerCase() : (e.key || '').toLowerCase();
        if (W.ffOpen) { e.preventDefault(); return; }   // v4.2: модалка этажа блокирует клавиши
        if (k === ' ' || e.code === 'Space') { e.preventDefault(); Sound.init(); doShake(); }
        else if (k === 'r') { this.start(); }
        else if (k === 't') { this.toggleReplay(); }
        else if (k === 'l') { this.toggleLang(); }
        else if (k === 's') { this.toggleSettings(); }
        else if (k === 'h' || k === '?') { this.helpOpen ? this.closeHelp() : this.openHelp(); }
        else if (k === 'escape') {
          if (this.helpOpen) this.closeHelp();
          else if (W.state === 'replay') Replay.stop();
          else if (el.settings_panel && !el.settings_panel.classList.contains('hidden')) this.toggleSettings();
          else this.togglePause();
        }
        else if (k === 'x' || k === 'с') { this.tryCut(); }
        else if (k === 'a' || k === 'ф') { autoToggle(); }   // v4.4: АВТО
        else if (k === 'm') { this.toggleAudio(); }
      });
    },

    bindInput() {
      const cv = this.canvas;
      const pointers = new Map();
      const inputAllowed = () => curScreen === 'scr-game' && W.state === 'play' && !W.ffOpen && !self.helpOpen && el.settings_panel.classList.contains('hidden') && !PLAT.adMuted;
      const resetInput = () => { pointers.clear(); mode = null; W.tilt.active = false; W.tilt.tRotX = W.tilt.tRotZ = 0; W.ropeHover = false; };
      this.resetInput = resetInput;
      window.addEventListener('blur', resetInput);
      document.addEventListener('visibilitychange', resetInput);
      cv.addEventListener('lostpointercapture', e => { if (pointers.has(e.pointerId)) resetInput(); });
      this.hasPointerInput = () => pointers.size > 0;

      let mode = null;                  // 'tilt' | 'cam' | 'cam2' | 'cut'
      let lastX = 0, lastY = 0, dragDX = 0, dragDY = 0, pinch0 = 0, dist0 = 0;
      let cutTravel = 0, cutDone = false;
      let camVelT = 0, camVelP = 0, lastMoveMs = 0;
      const self = this;
      const GRAB_PX = 36;               // зона захвата троса на экране, px
      const nowMs = () => (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();

      cv.addEventListener('contextmenu', e => e.preventDefault());

      function screenOf(v) {
        const p = v.clone().project(W.camera);
        return { x: (p.x * 0.5 + 0.5) * cv.clientWidth, y: (-p.y * 0.5 + 0.5) * cv.clientHeight };
      }

      function segHit(p1, p2, p3, p4) {
        const d1x = p2.x - p1.x, d1y = p2.y - p1.y;
        const d2x = p4.x - p3.x, d2y = p4.y - p3.y;
        const den = d1x * d2y - d1y * d2x;
        if (Math.abs(den) < 1e-9) return false;
        const t = ((p3.x - p1.x) * d2y - (p3.y - p1.y) * d2x) / den;
        const u = ((p3.x - p1.x) * d1y - (p3.y - p1.y) * d1x) / den;
        return t >= 0 && t <= 1 && u >= 0 && u <= 1;
      }

      function ropeSegment() {
        if (!W.player || !W.ropeAnchor || W.ropeCut) return null;
        const a = W.glassGroup.localToWorld(W.ropeAnchor.clone());
        const b = W.glassGroup.localToWorld(W.player.p.clone());
        return [screenOf(a), screenOf(b)];
      }

      function distPointSeg(px, py, a, b) {
        const vx = b.x - a.x, vy = b.y - a.y;
        const L2 = vx * vx + vy * vy;
        let t = L2 > 1e-9 ? ((px - a.x) * vx + (py - a.y) * vy) / L2 : 0;
        t = clamp(t, 0, 1);
        return Math.hypot(px - (a.x + vx * t), py - (a.y + vy * t));
      }

      function ropeGrabbable() { return !W.ropeCut && W.state === 'play'; }

      function nearRope(x, y) {
        if (!ropeGrabbable()) return false;
        const rs = ropeSegment();
        return !!rs && distPointSeg(x, y, rs[0], rs[1]) < GRAB_PX;
      }

      function setCursor() {
        cv.style.cursor = mode === 'cam' || mode === 'cam2' ? 'move'
          : (mode === 'cut' || W.ropeHover) ? 'crosshair'
          : (mode === 'tilt' ? 'grabbing' : 'grab');
      }

      // Наклон стакана. Экранное направление перетаскивания переводится в
      // мировое через базис камеры: вправо — по вектору «право» камеры,
      // ВВЕРХ — «от игрока» (вектор взгляда камеры), ВНИЗ — «к игроку».
      // Так верх стакана наклоняется ровно туда, куда тянет мышь.
      function applyTiltDrag() {
        const T = LEVEL_CONFIG.tilt;
        const len = Math.hypot(dragDX, dragDY);
        if (len < 1) { W.tilt.tRotX = 0; W.tilt.tRotZ = 0; return; }
        const fwd = new THREE.Vector3();
        W.camera.getWorldDirection(fwd);
        const right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0));
        if (right.lengthSq() < 1e-8) right.set(1, 0, 0);
        right.normalize();
        const fwdXZ = new THREE.Vector3(fwd.x, 0, fwd.z);
        if (fwdXZ.lengthSq() < 1e-8) fwdXZ.set(0, 0, -1);
        fwdXZ.normalize();
        // экранное «вверх» (dragDY < 0) — это направление ОТ игрока, fwdXZ
        const dxw = right.x * dragDX - fwdXZ.x * dragDY;
        const dzw = right.z * dragDX - fwdXZ.z * dragDY;
        const dl = Math.hypot(dxw, dzw) || 1;
        const mag = Math.min(T.max, len * T.sensitivity);
        // наклон верха стакана в сторону (dxw, dzw): rotX = +Lz, rotZ = −Lx
        W.tilt.tRotZ = -(dxw / dl) * mag;
        W.tilt.tRotX = (dzw / dl) * mag;
      }

      cv.addEventListener('pointerdown', e => {
        if (!inputAllowed()) return;
        e.preventDefault();
        Sound.init();
        pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (W.intro.active) skipIntro();               // v3.5: тап скипает интро
        try { cv.setPointerCapture(e.pointerId); } catch (err) {}
        if (pointers.size === 1) {
          lastX = e.clientX; lastY = e.clientY;
          dragDX = 0; dragDY = 0;
          cutTravel = 0; cutDone = false;
          camVelT = 0; camVelP = 0; lastMoveMs = nowMs();
          W.cam.spinTheta = 0; W.cam.spinPhi = 0;      // взяли камеру — инерция сброшена
          if (e.button === 2 || e.ctrlKey) mode = 'cam';
          else if (nearRope(e.clientX, e.clientY)) {
            // жест разреза: наклон стакана в этом жесте НЕ участвует
            mode = 'cut';
            W.ropeHover = true;
          } else mode = 'tilt';
          W.tilt.active = (mode === 'tilt');
        } else if (pointers.size === 2) {
          mode = 'cam2';
          W.tilt.active = false;
          W.ropeHover = false;
          const pts = Array.from(pointers.values());
          pinch0 = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
          dist0 = W.cam.tDist;
          lastX = (pts[0].x + pts[1].x) / 2; lastY = (pts[0].y + pts[1].y) / 2;
        }
        setCursor();
      });

      window.addEventListener('pointermove', e => {
        if (!inputAllowed()) { resetInput(); return; }
        if (!pointers.has(e.pointerId)) {
          // просто наведение: подсвечиваем трос, если курсор рядом
          const was = W.ropeHover;
          W.ropeHover = nearRope(e.clientX, e.clientY);
          if (was !== W.ropeHover || !mode) setCursor();
          return;
        }
        pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        const dx = e.clientX - lastX, dy = e.clientY - lastY;

        if (mode === 'cam2' && pointers.size >= 2) {
          const pts = Array.from(pointers.values());
          const mid = { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 };
          const d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
          W.cam.tTheta -= (mid.x - lastX) * 0.006;
          W.cam.tPhi = clamp(W.cam.tPhi - (mid.y - lastY) * 0.005, LEVEL_CONFIG.camera.minPolar, LEVEL_CONFIG.camera.maxPolar);
          if (pinch0 > 4) W.cam.tDist = clamp(dist0 * (pinch0 / Math.max(4, d)), LEVEL_CONFIG.camera.minDist, LEVEL_CONFIG.camera.maxDist);
          lastX = mid.x; lastY = mid.y;
        } else if (mode === 'cam') {
          const t1 = nowMs();
          const dtm = Math.min(0.12, Math.max(0.008, (t1 - lastMoveMs) / 1000 || 0.016));
          lastMoveMs = t1;
          W.cam.tTheta -= dx * 0.006;
          W.cam.tPhi = clamp(W.cam.tPhi - dy * 0.005, LEVEL_CONFIG.camera.minPolar, LEVEL_CONFIG.camera.maxPolar);
          // запоминаем угловую скорость для инерции после отпускания
          camVelT = camVelT * 0.4 + ((-dx * 0.006) / dtm) * 0.6;
          camVelP = camVelP * 0.4 + ((-dy * 0.005) / dtm) * 0.6;
          lastX = e.clientX; lastY = e.clientY;
        } else if (mode === 'cut') {
          cutTravel += Math.hypot(dx, dy);
          if (!cutDone && ropeGrabbable()) {
            const rs = ropeSegment();
            if (rs && segHit({ x: lastX, y: lastY }, { x: e.clientX, y: e.clientY }, rs[0], rs[1])) {
              cutDone = true;
              self.tryCut();
            }
          }
          lastX = e.clientX; lastY = e.clientY;
        } else if (mode === 'tilt') {
          dragDX += dx; dragDY += dy;
          applyTiltDrag();
          lastX = e.clientX; lastY = e.clientY;
        }
      });

      function endPointer(e) {
        if (!pointers.has(e.pointerId)) return;
        if (e.type === 'pointercancel' || !inputAllowed()) { resetInput(); return; }
        pointers.delete(e.pointerId);
        if (pointers.size === 0) {
          if (mode === 'tilt') W.tilt.active = false;
          if (mode === 'cam') {
            // небольшая инерция: стакан докручивается и плавно останавливается
            W.cam.spinTheta = clamp(camVelT, -12, 12) * 0.055;
            W.cam.spinPhi = clamp(camVelP, -12, 12) * 0.032;
            camVelT = 0; camVelP = 0;
          }
          if (mode === 'cut' && !cutDone && cutTravel < 14) self.tryCut();  // тап по тросу
          mode = null;
          W.ropeHover = false;
          setCursor();
        } else if (pointers.size === 1) {
          mode = 'tilt';
          const p = Array.from(pointers.values())[0];
          lastX = p.x; lastY = p.y;
          dragDX = 0; dragDY = 0;
          W.tilt.active = true;
          setCursor();
        }
      }
      window.addEventListener('pointerup', endPointer);
      window.addEventListener('pointercancel', endPointer);
      cv.addEventListener('pointerleave', () => { if (!mode) { W.ropeHover = false; setCursor(); } });

      cv.addEventListener('wheel', e => {
        if (!inputAllowed()) return;
        e.preventDefault();
        const C = LEVEL_CONFIG.camera;
        W.cam.tDist = clamp(W.cam.tDist * Math.exp((e.deltaY || 0) * 0.0011), C.minDist, C.maxDist);
      }, { passive: false });

      setCursor();
      void self;
    },

    // ---------------- ГЛАВНЫЙ ЦИКЛ ----------------
    frame(now) {
      requestAnimationFrame(t => this.frame(t));
      if (!this.running) return;
      let dtReal = (now - this.lastT) / 1000;
      this.lastT = now;
      if (!isFinite(dtReal) || dtReal <= 0) dtReal = 1 / 60;
      dtReal = Math.min(dtReal, 0.05);

      const live = !PLAT.adMuted && !document.hidden && (W.state === 'play' || W.state === 'winning' || W.state === 'losing') && !W.ffOpen;
      let dt = 0;

      if (live) {
        if (W.slowmo > 0) { W.slowmo -= dtReal; dt = dtReal * clamp(W.slowmoScale, 0.05, 1); }
        else { W.slowmoScale = 1; dt = dtReal; }
        W.time += dt; W.runTime += dt;
        Motion.update();
        autoUpdate(dt);                     // v4.4: автопилот наклона (до физики)
        stepPhysics(dt);
        autoAssist(dt);
        Magic.update(dt);
        updateTriggers(dt);
        updateSequences(dt);
        Replay.record(dt);
        updateSquash(dt);                       // v3.5: сквош-стретч по ударам
        pushTrail();                            // v3.5: точка трейла
        if (W.shakeCd > 0) W.shakeCd = Math.max(0, W.shakeCd - dtReal);
        // звуки качения/ударов
        playContactSounds();
      } else if (W.state === 'replay') {
        W.time += dtReal;
        Replay.update(dtReal);
      } else if (!W.ffOpen) {
        W.time += dtReal * (this.helpOpen || W.state === 'pause' ? 0.15 : 0.6);
      }

      // v3.5: интро закончилось само — подсветить трос и подсказать разрез
      if (W.introWasActive && !W.intro.active) {
        W.introWasActive = false;
        pulseRope();
        if (W.state === 'play') toast(D().statusRope, 'good');
      }
      // v3.5: вспышка tone-mapping (ядро/победа)
      if (W.flashT > 0) {
        W.flashT -= dtReal;
        const fk = clamp(W.flashT / 0.25, 0, 1);
        if (this.renderer) this.renderer.toneMappingExposure = 1.08 + fk * 0.35;
      } else if (this.renderer && this.renderer.toneMappingExposure !== 1.08) {
        this.renderer.toneMappingExposure = 1.08;
      }

      const vdt = live ? dt : dtReal;
      updateVisuals(vdt);
      updateFX(dtReal * (live && W.slowmoScale < 1 ? Math.max(W.slowmoScale, 0.4) : 1));
      updateCamera(dtReal);
      updateHud(dtReal);
      updateTraining();               // v4.4: шаги обучения по фактическим событиям
      if (W.stars) W.stars.rotation.y += dtReal * 0.0035;

      this.renderer.render(W.scene, W.camera);
    }
  };

  function playContactSounds() {
    let maxImp = 0, rollMax = 0;
    for (const b of W.balls) {
      if (!b.alive) continue;
      if (b.impact > maxImp) maxImp = b.impact;
      if (b.contact) { const sp = b.v.length(); if (sp > rollMax) rollMax = sp; }
      b.impact = 0;
    }
    if (maxImp > 0.45) Sound.hit(clamp(maxImp / 9, 0.06, 1));
    if (rollMax > 0.6) Sound.roll(clamp(rollMax / 12, 0, 1));
  }

  // ===========================================================================
  // 22b. v4.4: ПЛАТФОРМА ЯНДЕКС ИГР (адаптер по схеме «МАТ-БУМ! 3» 5.0.3)
  // Одиночный файл: SDK грузится динамически с '/sdk.js' только на платформе;
  // локально/в песочнице молча деградирует в гостевой офлайн-режим.
  // Требования: LoadingAPI.ready при готовности, GameplayAPI start/stop по
  // фактам геймплея, реклама только в естественных паузах и не чаще 180 с,
  // язык из environment.i18n.lang (до getPlayer), облачные сейвы, пауза/звук
  // на game_api_pause / hidden, контекстное меню и выделение выключены.
  // ===========================================================================
  const PLAT = {
    ysdk: null, player: null, lang: null, ready: false, adMuted: false, lastAdT: -1e9, inGameplay: false
  };
  window.PLAT = PLAT;

  function plIsHttps() {
    try { return (typeof location !== 'undefined') && /^https?:$/.test(location.protocol); } catch (e) { return false; }
  }
  function plLoadScript(src, ms) {
    return new Promise(resolve => {
      let done = false;
      const finish = (ok) => { if (!done) { done = true; resolve(ok); } };
      try {
        if (typeof document === 'undefined' || !document.createElement || !document.head ||
            typeof window === 'undefined') { finish(false); return; }
        const s = document.createElement('script');
        s.src = src; s.async = true;
        s.onload = () => finish(true);
        s.onerror = () => finish(false);
        document.head.appendChild(s);
        window.setTimeout(() => finish(false), ms || 6000);
      } catch (e) { finish(false); }
    });
  }
  function plSafe(fn) { try { return fn(); } catch (e) { return undefined; } }

  async function initPlatform() {
    if (window.GRAVI_SOLO || !plIsHttps()) return PLAT;             // file:// / vm-песочница — гостевой режим
    const ok = await plLoadScript('/sdk.js', 6000);
    if (!ok || typeof window.YaGames === 'undefined') return PLAT;
    const ysdk = await new Promise(resolve => {
      let done = false;
      try {
        window.YaGames.init().then(y => { if (!done) { done = true; resolve(y); } })
          .catch(() => { if (!done) { done = true; resolve(null); } });
        window.setTimeout(() => { if (!done) { done = true; resolve(null); } }, 8000);
      } catch (e) { resolve(null); }
    });
    if (!ysdk) return PLAT;
    PLAT.ysdk = ysdk;
    // 1.7: автоязык — читаем сразу после init, ДО getPlayer/облака
    PLAT.lang = plSafe(() => (ysdk.environment && ysdk.environment.i18n && ysdk.environment.i18n.lang) || null);
    // game_api_pause / game_api_resume (1.19.4): пауза + глушение звука
    plSafe(() => ysdk.on('game_api_pause', () => {
      PLAT.adMuted = true;
      plSafe(() => Sound.setEnabled(false));
      if (W.state === 'play') App.pause();
    }));
    plSafe(() => ysdk.on('game_api_resume', () => {
      if (document.getElementById('app').inert) return;
      PLAT.adMuted = false;
      plSafe(() => Sound.setEnabled(App.audioOn !== false && !document.hidden));
    }));
    // игрок: авторизация ТОЛЬКО по добровольному жесту (требование 1.2)
    // — здесь мы лишь проверяем уже существующую сессию, окно логина не открываем
    await plSafe(async () => {
      const p = await ysdk.getPlayer({ scopes: false }).catch(() => null);
      if (p) {
        PLAT.player = p;
      }
    });
    return PLAT;
  }
  function gameReady() {
    if (PLAT.ready) return;
    PLAT.ready = true;
    plSafe(() => PLAT.ysdk && PLAT.ysdk.features && PLAT.ysdk.features.LoadingAPI && PLAT.ysdk.features.LoadingAPI.ready());
  }
  function gameplayStart() {
    if (PLAT.inGameplay) return;
    PLAT.inGameplay = true;
    plSafe(() => PLAT.ysdk && PLAT.ysdk.features && PLAT.ysdk.features.GameplayAPI && PLAT.ysdk.features.GameplayAPI.start());
  }
  function gameplayStop() {
    if (!PLAT.inGameplay) return;
    PLAT.inGameplay = false;
    plSafe(() => PLAT.ysdk && PLAT.ysdk.features.GameplayAPI && PLAT.ysdk.features.GameplayAPI.stop());
  }
  function showInterstitial(after) {
    if (!PLAT.ysdk || !PLAT.ysdk.adv) { if (after) after(); return; }
    if (PLAT.adMuted) return;
    if (W.state === 'play') App.pause();
    gameplayStop();
    PLAT.adMuted = true;
    if (App.resetInput) App.resetInput();
    Sound.setEnabled(false);
    const root = document.getElementById('app');
    root.inert = true;
    const running = App.running; App.running = false;
    let finished = false;
    const finish = () => {
      if (finished) return; finished = true;
      PLAT.adMuted = false; root.inert = false;
      App.running = running; App.lastT = performance.now();
      Sound.setEnabled(App.audioOn !== false && !document.hidden);
      if (after) after();
      if (document.hidden && W.state === 'play') App.pause();
    };
    try { PLAT.ysdk.adv.showFullscreenAdv({ callbacks: {
      onOpen: () => { PLAT.adMuted = true; Sound.setEnabled(false); },
      onClose: finish, onError: finish, onOffline: finish
    }}); } catch (e) { finish(); }
  }
  // Реклама только в естественной паузе и не чаще раза в 180 с (рекомендация платформы)
  function maybeAd(after) {
    const t = (window.performance && performance.now) ? performance.now() : Date.now();
    if (t - PLAT.lastAdT < 180000) { if (after) after(); return; }
    PLAT.lastAdT = t;
    showInterstitial(after);
  }
  async function cloudSave() {
    if (!PLAT.player) return;
    const payload = {
      progress: W.progress, best: W.bestScore, specials: W.specials,
      theme: getTheme(), lang: curLang, v: VERSION
    };
    plSafe(() => PLAT.player.setData({ graviboom: payload }, true).catch(() => {}));
  }
  async function cloudLoad() {
    if (!PLAT.player) return null;
    return plSafe(async () => {
      const d = await PLAT.player.getData(['graviboom']).catch(() => null);
      return (d && d.graviboom) ? d.graviboom : null;
    });
  }
  // Слияние облачного прогресса с локальным (берем лучшие результаты)
  function mergeCloudProgress(cloud) {
    if (!cloud || typeof cloud !== 'object') return;
    try {
      if (Array.isArray(cloud.progress) && cloud.progress.length === LEVELS.length) {
        let changed = false;
        for (let i = 0; i < LEVELS.length; i++) {
          const c = cloud.progress[i] || {}; const p = W.progress[i];
          if ((c.stars | 0) > p.stars) { p.stars = c.stars | 0; changed = true; }
          if ((c.score | 0) > p.score) { p.score = c.score | 0; changed = true; }
          if (c.time > 0 && (p.time === 0 || c.time < p.time)) { p.time = c.time; changed = true; }
          if (c.challenge && !p.challenge) { p.challenge = true; changed = true; }
        }
        if (changed) saveProgress();
      }
      if ((cloud.best | 0) > (W.bestScore | 0)) { W.bestScore = cloud.best | 0; try { window.localStorage.setItem(BEST_KEY, String(W.bestScore)); } catch (e) {} }
      if (cloud.specials && typeof cloud.specials === 'object') {
        for (const k of Object.keys(cloud.specials)) if (cloud.specials[k] && !W.specials[k]) { W.specials[k] = true; }
        saveSpecials();
      }
    } catch (e) {}
  }
  async function lbSubmit(score) {
    if (!PLAT.ysdk) return;
    const n = Math.max(0, score | 0);
    if (n <= 0) return;
    plSafe(() => PLAT.ysdk.leaderboards && PLAT.ysdk.leaderboards.setLeaderboardScore('main', n).catch(() => {}));
  }
  async function lbTop(n) {
    if (!PLAT.ysdk) return null;
    return plSafe(async () => {
      const r = await PLAT.ysdk.leaderboards.getLeaderboardEntries('main', { quantityTop: n || 5, includeUser: true, quantityAround: 2 }).catch(() => null);
      return r;
    });
  }

  // -------------------------------------------------------------------------
  // v4.4: ТЕМЫ (тёмная/светлая, как в МБ3; 3D-сцена остаётся космосом в обеих)
  // -------------------------------------------------------------------------
  const THEME_KEY = 'gb_theme';
  function getTheme() {
    try { return (window.localStorage.getItem(THEME_KEY) === 'light') ? 'light' : 'dark'; } catch (e) { return 'dark'; }
  }
  function applyTheme(t) {
    try { window.localStorage.setItem(THEME_KEY, t); } catch (e) {}
    try {
      document.documentElement.setAttribute('data-theme', t);
    } catch (e) {}
    if (el.theme_ico) el.theme_ico.textContent = (t === 'light') ? '🌙' : '☀';
  }
  function toggleTheme() {
    applyTheme(getTheme() === 'light' ? 'dark' : 'light');
    Sound.ui();
  }

  // -------------------------------------------------------------------------
  // v4.4: ЭКРАНЫ (show как в МБ3) + геймплейная разметка для платформы
  // -------------------------------------------------------------------------
  const SCR_IDS = ['scr-start', 'scr-select', 'scr-hall', 'scr-help', 'scr-game'];
  let curScreen = 'scr-start';
  function showScreen(id) {
    if (SCR_IDS.indexOf(id) < 0) return;
    curScreen = id;
    document.getElementById('chrome').classList.toggle('playing', id === 'scr-game');
    for (const s of SCR_IDS) {
      const n = el[s.replace(/-/g, '_')];
      if (n) n.classList.toggle('on', s === id);
    }
    if (el.btn_back) el.btn_back.hidden = (id === 'scr-start');   // 1.8: без «выхода» из меню
    if (id === 'scr-select') renderLevelStrip();
    if (id === 'scr-hall') renderHall();
    if (id === 'scr-help') renderHelpScreen();
    if (id === 'scr-start') renderSidePanels();
    if (id !== 'scr-game' && W.state !== 'play' && W.state !== 'pause') gameplayStop();
  }

  // -------------------------------------------------------------------------
  // v4.4: боковые колонки главного меню (десктоп ≥1080px — видны, телефон — нет)
  // -------------------------------------------------------------------------
  function renderSidePanels() {
    if (!el.side_recs && !el.side_prog) return;
    const li = curLang === 'ru' ? 0 : 1;
    // рекорды: топ-5 уровней по счёту
    if (el.side_recs) {
      const rows = [];
      for (let i = 0; i < LEVELS.length; i++) {
        const pr = W.progress[i] || {};
        if ((pr.score | 0) > 0) rows.push({ i, score: pr.score | 0, stars: pr.stars | 0, nm: LEVELS[i].name[li] });
      }
      rows.sort((a, b) => b.score - a.score);
      let opened = 0;
      for (let i = 0; i < LEVELS.length; i++) if (levelUnlocked(i)) opened++;
      el.side_recs.innerHTML = rows.length
        ? rows.slice(0, 5).map(r =>
            '<div class="hall-row"><span class="nm">' + (r.i + 1) + '. ' + r.nm + '</span>' +
            '<span class="st">' + '★'.repeat(r.stars) + '</span><span class="sc">' + r.score + '</span></div>').join('')
        : '<div class="hall-empty">' + D().sideNoRec + '</div>';
      if (el.txt_side_open) el.txt_side_open.textContent = D().sideOpen.replace('{n}', String(opened));
    }
    // прогресс: все 10 уровней по порядку
    if (el.side_prog) {
      let totalStars = 0;
      for (let i = 0; i < LEVELS.length; i++) totalStars += ((W.progress[i] || {}).stars | 0);
      el.side_prog.innerHTML = LEVELS.map((L, i) => {
        const pr = W.progress[i] || {};
        const st = pr.stars | 0;
        const col = LEVEL_PALETTES[i][2];
        return '<div class="prog-row"><span class="nm" style="display:flex;align-items:center;gap:6px">' +
          '<i style="width:10px;height:10px;border-radius:50%;background:' + col + ';display:inline-block;flex:none"></i>' +
          (i + 1) + '. ' + L.name[li] + '</span>' +
          '<span class="sc">' + ((pr.score | 0) > 0 ? pr.score : '·') + '</span>' +
          '<span class="st">' + (st > 0 ? '★'.repeat(st) : '·') + '</span></div>';
      }).join('');
      if (el.txt_side_stars) el.txt_side_stars.textContent =
        D().sideStars.replace('{s}', String(totalStars)).replace('{c}', String(challengeCount()));
    }
  }

  // -------------------------------------------------------------------------
  // v4.4: ЗАЛ СЛАВЫ — локальные таблицы + таблица Яндекса (на платформе)
  // -------------------------------------------------------------------------
  let hallYaRendered = false;
  function renderHall() {
    if (!el.hall_list) return;
    const li = curLang === 'ru' ? 0 : 1;
    let totalStars = 0;
    for (let i = 0; i < LEVELS.length; i++) totalStars += ((W.progress[i] || {}).stars | 0);
    el.hall_list.innerHTML =
      '<p class="hall-sub-t">' + D().hallLevelT + '</p>' +
      LEVELS.map((L, i) => {
        const pr = W.progress[i] || {};
        const col = LEVEL_PALETTES[i][2];
        return '<div class="hall-row"><span class="nm" style="display:flex;align-items:center;gap:6px">' +
          '<i style="width:10px;height:10px;border-radius:50%;background:' + col + ';display:inline-block;flex:none"></i>' +
          (i + 1) + '. ' + L.name[li] + '</span>' +
          '<span class="st">' + ((pr.stars | 0) > 0 ? '★'.repeat(pr.stars) : '·') + '</span>' +
          '<span class="sc">' + ((pr.score | 0) > 0 ? pr.score : '·') + '</span></div>';
      }).join('');
    if (el.hall_total) el.hall_total.textContent =
      D().hallTotalLine.replace('{s}', String(totalStars)).replace('{b}', String(W.bestScore | 0));
    if (el.hall_ya && !hallYaRendered) {
      el.hall_ya.innerHTML = '<p class="hall-sub-t">' + D().hallYandexT + '</p><div class="hall-empty">' + D().hallYaNo + '</div>';
      hallYaRendered = true;
      if (PLAT.ysdk) {
        lbTop(5).then(r => {
          if (!r || !r.entries || !r.entries.length) return;
          el.hall_ya.innerHTML = '<p class="hall-sub-t">' + D().hallYandexT + '</p>' + r.entries.map(e => {
            const nm = (e.player && (e.player.publicName || e.player.lang)) || '…';
            return '<div class="hall-ya-row"><span class="rk">' + (e.rank) + '</span>' +
              '<span class="nm">' + nm + '</span><span class="sc">' + (e.score) + '</span></div>';
          }).join('');
        }).catch(() => {});
      }
    }
  }

  // -------------------------------------------------------------------------
  // v4.4: экран СПРАВКА (тот же текст, что в игровой модалке)
  // -------------------------------------------------------------------------
  function renderHelpScreen() {
    if (el.txt_help_body2) el.txt_help_body2.innerHTML = D().helpBody;
    if (el.txt_help_footer) el.txt_help_footer.textContent = D().helpFooter;
  }

  // -------------------------------------------------------------------------
  // v4.4: ОБУЧЕНИЕ — уровень 1 с плашкой шагов (как в МБ3, без карточек/музея)
  // -------------------------------------------------------------------------
  let tut = { active: false, step: 0 };
  const TUT_KEYS = ['tut1', 'tut2', 'tut3', 'tut4', 'tut5', 'tut6'];
  function startTraining() {
    tut.active = true; tut.step = 0;
    App.start(0);
    renderTrainPlate(true);
    toast(D().tutTitle.replace('{n}', '1').replace('{m}', String(TUT_KEYS.length)), 'magic', 2600);
  }
  function renderTrainPlate(reset) {
    if (!el.train_plate) return;
    if (!tut.active) { el.train_plate.classList.add('hidden'); return; }
    el.train_plate.classList.remove('hidden');
    if (el.tut_step) el.tut_step.textContent = D().tutTitle.replace('{n}', String(tut.step + 1)).replace('{m}', String(TUT_KEYS.length));
    if (el.tut_text) el.tut_text.textContent = D()[TUT_KEYS[tut.step]] || '';
  }
  // продвижение шагов по фактическим событиям игры; вызывается из кадра
  function updateTraining() {
    if (!tut.active) return;
    const fs = W.floorSolvedArr || [false, false, false, false];
    const stepDone = [
      W.cutCount > 0,                        // 1: трос разрезан
      W.cutCount > 0 && W.lowestY < 16.5,    // 2: шар катится по чаше
      fs[0] === true,                        // 3: ЧАША решена
      fs[1] === true,                        // 4: ТРУБА решена
      fs[2] === true,                        // 5: РЕЗОНАНС решена
      W.state === 'win' || W.state === 'winning'
    ][tut.step];
    if (stepDone) {
      tut.step++;
      if (tut.step >= TUT_KEYS.length) {
        tut.active = false;
        renderTrainPlate();
        toast(D().tutDone, 'good', 4200);
        Sound.floorDone();
      } else {
        renderTrainPlate();
        Sound.ui();
      }
    }
  }
  function stopTraining() {
    if (!tut.active) return;
    tut.active = false;
    renderTrainPlate();
  }

  // -------------------------------------------------------------------------
  // v4.4: КНОПКА «АВТО» (как в МАТ-БУМ! 3): автосборка ТЕКУЩЕГО этажа.
  // Башня сама наклоняется и лёгкие ассист-толчки (как у авто-помощи игрока)
  // ведут шары к решению головоломки — все срабатывания (лунки, дороги, плиты,
  // ядро, кнопка) идут через обычную физику, без прямых изменений состояния.
  // Когда этаж решён и шар уходит к следующему — АВТО отключается,
  // управление снова у игрока.
  // -------------------------------------------------------------------------
  const AUTO = { active: false, floor: -1, t: 0, deadline: 110, retreatT: 0, dive: false, plateSt: null, runOn: false, wp2: false, shakeT: 0, stuckP: null };
  window.GB_AUTO = AUTO;

  function autoUpdateBtn() {
    if (el.btn_auto) el.btn_auto.classList.toggle('on', AUTO.active);
  }
  function autoStart() {
    if (W.state !== 'play' || W.ffOpen || inTransition()) { toast(D().autoBusy, 'warn'); return; }
    AUTO.active = true;
    AUTO.floor = W.currentFloor;
    AUTO.t = 0; AUTO.retreatT = 0; AUTO.dive = false; AUTO.plateSt = null; AUTO.runOn = false; AUTO.wp2 = false; AUTO.shakeT = 0; AUTO.stuckP = null; AUTO.stuckB = null; AUTO.f1Tries = 0; AUTO.shakeN = 0; AUTO.pullT = 0;
    autoUpdateBtn();
    toast(D().autoOn, 'magic', 2200);
    Sound.ui();
  }
  function autoStop(reason) {
    if (!AUTO.active) return;
    AUTO.active = false;
    W.tilt.active = false; W.tilt.tRotX = 0; W.tilt.tRotZ = 0;
    autoUpdateBtn();
    if (reason === 'floorDone') toast(D().autoFloorDone, 'good', 2800);
    else if (reason === 'timeout') toast(D().autoTimeout, 'warn', 3200);
    else if (reason === 'manual') toast(D().autoOff, 'warn');
  }
  function autoToggle() { AUTO.active ? autoStop('manual') : autoStart(); }

  // наклон верха стакана в мировом направлении (dx, dz): как applyTiltDrag
  function autoTilt(dx, dz, mag01) {
    const T = LEVEL_CONFIG.tilt;
    const dl = Math.hypot(dx, dz);
    W.tilt.active = true;
    if (dl < 1e-6) { W.tilt.tRotX = 0; W.tilt.tRotZ = 0; return; }
    const mag = clamp(mag01 === undefined ? 1 : mag01, 0.05, 1) * T.max;
    W.tilt.tRotZ = -(dx / dl) * mag;
    W.tilt.tRotX = (dz / dl) * mag;
  }
  // мягкий ассист-толчок фокус-шара к цели (разумный «магнитный» доводчик);
  // wantCap — целевая скорость ассиста (по умолчанию 3.4, для разгона выше)
  function autoNudge(b, tx, tz, aMax, dt, wantCap) {
    if (!b || !b.alive || b.kinematic || b.mounted) return;
    const dx = tx - b.p.x, dz = tz - b.p.z;
    const d = Math.hypot(dx, dz);
    if (d < 1e-6) return;
    const vAlong = (b.v.x * dx + b.v.z * dz) / d;
    const want = (wantCap !== undefined) ? Math.min(wantCap, 15)
      : Math.min(3.4, Math.sqrt(0.9 * d) + 0.35);
    const add = clamp((want - vAlong) * 1.7, 0, aMax);
    if (add <= 0.01) return;
    b.v.x += (dx / d) * add * dt;
    b.v.z += (dz / d) * add * dt;
  }
  // ПД-наведение игрока на точку: наклон = ошибка скорости (тянет и тормозит)
  function autoSeek(pl, tx, tz, dt, cap) {
    const cx = tx - pl.p.x, cz = tz - pl.p.z;
    const d = Math.hypot(cx, cz);
    const sp = Math.min(cap || 3.2, Math.sqrt(1.1 * Math.max(d, 0)));
    const wx = (d > 1e-6 ? cx / d : 0) * sp;
    const wz = (d > 1e-6 ? cz / d : 0) * sp;
    const ex = wx - pl.v.x, ez = wz - pl.v.z;
    const em = Math.hypot(ex, ez);
    if (em < 0.05) { autoTilt(ex + 0.01, ez, 0.08); return; }
    autoTilt(ex, ez, clamp(0.15 + em * 0.28, 0.1, 0.95));
    autoNudge(pl, tx, tz, 1.8, dt);
  }

  // детектор застревания: шар почти не сместился за 3с — круговая тряска наклоном
  function autoStuckShake(b, dt) {
    if (!b || !b.alive) return false;
    if (AUTO.stuckB !== b) { AUTO.stuckB = b; AUTO.stuckP = { x: b.p.x, z: b.p.z, t: 0 }; }
    if (!AUTO.stuckP) AUTO.stuckP = { x: b.p.x, z: b.p.z, t: 0 };
    AUTO.stuckP.t += dt;
    if (AUTO.stuckP.t >= 3) {
      const disp = Math.hypot(b.p.x - AUTO.stuckP.x, b.p.z - AUTO.stuckP.z);
      const spd = Math.hypot(b.v.x, b.v.z);
      if (disp < 0.8 && spd < 0.3) {                     // медленно ползёт (вдоль стенки) — НЕ застревание
        AUTO.shakeN = (AUTO.shakeN || 0) + 1;
        if (AUTO.shakeN % 4 !== 0) AUTO.shakeT = 1.6;   // пауза каждую 4-ю: пусть ведёт обычная ветка
      }
      AUTO.stuckP = { x: b.p.x, z: b.p.z, t: 0 };
    }
    if (AUTO.shakeT > 0) {
      AUTO.shakeT -= dt;
      const an = W.time * 4;
      autoTilt(Math.cos(an), Math.sin(an), 0.95);
      return true;
    }
    return false;
  }

  // --- ЭТАЖ 0 «ЧАША»: разрезать трос → освободить патронташ → катить в лунку
  function autoFloor0(dt) {
    const A = LEVEL_CONFIG.platformA;
    const pl = W.player;
    if (!pl || !pl.alive) return;
    if (!W.ropeCut) {                                    // фаза 1: трос
      if (AUTO.t > 0.5) { cutRope(); } else autoTilt(0, 0, 0.15);
      return;
    }
    const socks = W.floorState && W.floorState.sockets;
    if (!socks) return;
    const open = socks.filter(s => !s.full);
    if (!open.length) {                                  // решено: ведём шар к люку чаши
      autoTilt(-pl.p.x, -pl.p.z, 0.7);
      autoNudge(pl, 0, 0, 1.2, dt);
      return;
    }
    const sk = open[0];
    // фаза 3: свободный шар нужного цвета → катим в лунку
    let free = null, fd = 1e9;
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer || b.mounted || b.kinematic || b.noMagic) continue;
      if (b.colorIdx !== sk.color || b.floor !== 0) continue;
      if (b.p.y < A.y - 1 || b.p.y > A.y + 3) continue;
      const d = Math.hypot(b.p.x - sk.x, b.p.z - sk.z);
      if (d < fd) { fd = d; free = b; }
    }
    if (free) {
      if (autoStuckShake(free, dt)) return;              // свободный шар в клине — тряска
      autoTilt(sk.x - free.p.x, sk.z - free.p.z, 0.6);
      autoNudge(free, sk.x, sk.z, 1.6, dt);
      // игрок не должен торчать у лунки (его отскакивает)
      if (Math.hypot(pl.p.x - sk.x, pl.p.z - sk.z) < 1.7) {
        autoNudge(pl, sk.x * 2 + 0.01, sk.z * 2, 1.0, dt);
      }
      return;
    }
    // фаза 2: освобождаем патронташ — катим игрока в ближайший шар нужного цвета
    if (pl.p.y > A.y + 1.6 && pl.p.y < A.y + 4.5) {      // v4.4: насест на патронташе — скатываемся к чаше
      autoTilt(-pl.p.x, -pl.p.z, 0.8);
      return;
    }
    if (autoStuckShake(pl, dt)) return;                  // игрок в клине — тряска
    let rack = null, rd2 = 1e9;
    for (const b of W.balls) {
      if (!b.alive || b.isPlayer || !b.mounted || b.noMagic) continue;
      if (b.colorIdx !== sk.color || b.floor !== 0) continue;
      const d = Math.hypot(b.p.x - pl.p.x, b.p.z - pl.p.z);
      if (d < rd2) { rd2 = d; rack = b; }
    }
    if (rack) {
      autoTilt(rack.p.x - pl.p.x, rack.p.z - pl.p.z, 0.85);
      autoNudge(pl, rack.p.x, rack.p.z, 1.8, dt);
    }
  }

  // --- ЭТАЖ 1 «ТРУБА»: завести игрока в жёлоб и толкнуть цепочку к мишени
  function autoFloor1(dt) {
    const ps = W.floorState && W.floorState.pipe;
    if (!ps) return;
    const pl = W.player;
    if (!pl || !pl.alive) return;
    const y = LEVEL_CONFIG.floorPipeY;
    // приоритет — дорога с шарами на рельсе; сбрасывающиеся (мина) пропускаем
    let road = ps.roads.find(r => r.layout && !r.solved && r.resetT <= 0 &&
      r.balls.some(q => q.alive && q.mounted && !q.pipeDone));
    if (!road) road = ps.roads.find(r => r.layout && !r.solved && r.resetT <= 0);
    if (!road) {
      if (ps.roads.some(r => r.layout && !r.solved)) {
        autoTilt(0, 0, 0);                                // мина: дорога пересобирается — ждём
        return;
      }
      autoTilt(-pl.p.x, -pl.p.z, 0.6);                    // всё решено: к люку (автопоток)
      autoNudge(pl, 0, 0, 1.0, dt);
      return;
    }
    const rd = road.def;
    // насест на стенке/кромке — скатываемся ко входу жёлоба
    if (pl.p.y > y + 1.35 && pl.p.y < y + 3.2 && Math.hypot(pl.v.x, pl.v.z) < 1.0) {
      autoTilt(rd.xIn - 2.4 - pl.p.x, rd.zc - pl.p.z, 0.8);
      return;
    }
    // шар в «чужом» жёлобе (эта дорога решена/не наша) — выходим западнее, в коридор
    // между жёлобами; прямая линия через стенку невозможна (прибивается к ней)
    for (const r2 of ps.roads) {
      if (!r2.layout || r2 === road) continue;
      const rd2 = r2.def;
      if (Math.abs(pl.p.z - rd2.zc) < 1.05 && pl.p.x > rd2.xIn - 1.0 && pl.p.x < rd2.xOut + 0.7 &&
          pl.p.y > y - 0.4 && pl.p.y < y + 2.0) {
        autoSeek(pl, rd2.xIn - 2.5, 0, dt, 3.2);
        return;
      }
    }
    const mounted = road.balls.filter(q => q.alive && q.mounted && !q.pipeDone);
    const inTrough = Math.abs(pl.p.z - rd.zc) < 1.0 && pl.p.x < rd.xOut - 0.3 &&
      pl.p.y > y - 0.4 && pl.p.y < y + 2.2;
    // анти-орбита: разогнался у борта — сначала тормозим (иначе не свернуть)
    if (Math.hypot(pl.v.x, pl.v.z) > 4.2 && pl.p.y > y - 0.3 && pl.p.y < y + 2.4) {
      autoTilt(-pl.v.x, -pl.v.z, 1);
      return;
    }
    // застревание: почти нет смещения 3с — тряска; 3 тряски без толку — вытягивание
    if (autoStuckShake(pl, dt)) return;
    if ((AUTO.shakeN || 0) >= 3 && !AUTO.pullT) AUTO.pullT = 2.5, AUTO.shakeN = 0;
    if (AUTO.pullT > 0) { AUTO.pullT -= dt; autoSeek(pl, rd.xIn - 2.4, rd.zc, dt, 3.4); return; }
    // отступ: шар у кармана, но на рельсе остались шары позади — выходим из жёлоба
    // ко входу и заходим заново (выход — за последним рельсовым шаром или из жёлоба)
    if (AUTO.retreatT > 0) {
      AUTO.retreatT -= dt;
      const outOfTrough = Math.abs(pl.p.z - rd.zc) > 1.5 || pl.p.x < rd.xIn + 0.2;
      const noBehind = !mounted.some(q => q.p.x < pl.p.x - 1.2);
      if (outOfTrough || noBehind) AUTO.retreatT = 0;
      else autoSeek(pl, rd.xIn - 2.4, rd.zc, dt, 3.4);
      return;
    }
    if (inTrough && (rd.xOut - pl.p.x) < 2.2 && mounted.some(q => q.p.x < pl.p.x - 1.5)) {
      AUTO.retreatT = 14;
      AUTO.f1Tries = (AUTO.f1Tries || 0) + 1;
      return;
    }
    // граница ловушки кармана зависит от счёта (стопка К растёт назад) —
    // сами в зону кармана не заходим НИКОГДА (0.42с внутри = перемотка)
    const pitch = 0.62 * 2 * K() + 0.05;
    const frontX = road.hit > 0 ? (rd.xOut + 1.0 - (road.hit - 1) * pitch - 1.34) : (rd.xOut + 0.35);
    if (pl.p.y > y - 0.4 && pl.p.y < y + 2.2 && Math.abs(pl.p.z - rd.zc) < 1.1 && pl.p.x > frontX - 0.15) {
      autoTilt(-1, 0, 0.6);
      return;
    }
    // хвост/голова колонны — живые недоставленные шары ряда в жёлобе
    let head = null, tail = null, nIn = 0;
    for (const q of road.balls) {
      if (!q.alive || q.isPlayer || q.pipeDone) continue;
      if (Math.abs(q.p.z - rd.zc) < 1.2 && q.p.y > y - 0.4 && q.p.y < y + 2.0) {
        nIn++;
        if (!head || q.p.x > head.p.x) head = q;
        if (!tail || q.p.x < tail.p.x) tail = q;
      }
    }
    if (inTrough && nIn > 0) {
      // голова у кармана и катится — накат
      if (head && (rd.xOut + 1.6 - head.p.x) < 2.6 && head.v.x > 0.25) {
        autoTilt(0, 0, 0);
        return;
      }
      // эскорт: держимся за хвостом, мягко толкаем колонну к карману
      const holdX = tail.p.x - 0.95;
      if (pl.p.x <= holdX + 0.35) {
        autoTilt(1, 0, 0.45);
        autoNudge(pl, Math.min(frontX - 0.6, holdX + 1.4), rd.zc, 1.6, dt, 1.25);
      } else {
        // просочился вперёд хвоста — мягко возвращаемся (без расшвыривания)
        autoSeek(pl, rd.xIn - 2.4, rd.zc, dt, 1.1);
      }
      return;
    }
    // спасение: К улетел из жёлоба, на рельсе пусто — возвращаем ко рту жёлоба
    if (!mounted.length) {
      const freeK = road.balls.find(q => q.alive && !q.pipeDone && !q.isPlayer &&
        q.pipeType === 'K' && !(Math.abs(q.p.z - rd.zc) < 1.1 && q.p.x > rd.xOut + 0.3));
      if (freeK) {
        const kSp = Math.hypot(freeK.v.x, freeK.v.z);
        if (kSp > 1.6) {                                  // беглец разогнан — тормозим его наклоном «против»
          autoTilt(-freeK.v.x, -freeK.v.z, 0.8);
          AUTO.stuckP = { x: pl.p.x, z: pl.p.z, t: 0 };   // ожидание — не «застревание», тряску не запускаем
          return;
        }
        // толкаем беглеца ко РТУ жёлоба (открытый конец у xIn); во рту — вдоль жёлоба к карману
        const inMouth = freeK.p.x < rd.xIn + 0.5 && Math.abs(freeK.p.z - rd.zc) < 1.3;
        const tx = inMouth ? (rd.xOut + 1.0) : (rd.xIn - 1.6);
        const dz0 = rd.zc - freeK.p.z, dx0 = tx - freeK.p.x;
        const dl0 = Math.hypot(dx0, dz0) || 1;
        const bx = freeK.p.x - dx0 / dl0 * 1.9, bz = freeK.p.z - dz0 / dl0 * 1.9;
        let wx = bx, wz = bz;                             // путь к тылу беглеца
        // тыл за восточным концом жёлоба → идём вокруг северной стороны (не через карман)
        if (pl.p.x < rd.xOut + 0.7 && bx > rd.xOut + 0.7 && Math.abs(pl.p.z - rd.zc) < 3.2) {
          wx = rd.xOut + 3.4; wz = rd.zc + 4.4;
        }
        if (Math.hypot(pl.p.x - wx, pl.p.z - wz) > 1.1) autoSeek(pl, wx, wz, dt, 3.0);
        else {                                            // толкаем мягко, без расшвыривания
          autoTilt(dx0 / dl0, dz0 / dl0, 0.55);
          autoNudge(pl, tx, rd.zc, 1.8, dt, 1.8);
        }
        return;
      }
    }
    // ведём игрока ко входу жёлоба (с запасом по x); после отступа — энергичнее
    autoSeek(pl, rd.xIn - 2.4, rd.zc, dt, AUTO.f1Tries ? 4.0 : 3.2);
  }

  // --- ЭТАЖ 2 «РЕЗОНАНС»: для каждой плиты — разгонная позиция напротив (через
  // центр), прямой прогон с фидбеком скорости в полосе плиты.
  function autoFloor2(dt) {
    const plates = W.floorState && W.floorState.plates;
    if (!plates) return;
    const pl = W.player;
    if (!pl || !pl.alive) return;
    const plate = plates.find(p => !p.active);
    if (!plate) {                                        // все плиты горят: к люку (автопоток)
      AUTO.plateSt = null;
      autoTilt(-pl.p.x, -pl.p.z, 0.55);
      autoNudge(pl, 0, 0, 0.8, dt);
      return;
    }
    if (AUTO.plateSt !== plate) {                        // новая плита — новая подготовка
      AUTO.plateSt = plate;
      AUTO.retreatT = 0;
      AUTO.runOn = false;
    }
    const band = plate.band;
    const vT = band.min + (band.max - band.min) * 0.55;  // цель — середина полосы (запас на кромку люка)
    const rp = Math.hypot(plate.x, plate.z) || 1;
    // разгонная точка на противоположной стороне диска: прогон идёт через центр
    const runD = clamp(0.85 * vT * vT / 4.4 + 1.6, 3.2, 7.4);
    const sx = -(plate.x / rp) * runD, sz = -(plate.z / rp) * runD;
    const dSt = Math.hypot(pl.p.x - sx, pl.p.z - sz);
    const dirX = plate.x - pl.p.x, dirZ = plate.z - pl.p.z;
    const dist = Math.hypot(dirX, dirZ) || 1;
    const vAlong = (pl.v.x * dirX + pl.v.z * dirZ) / dist;
    const speed = pl.v.length();
    if (AUTO.retreatT > 0) {                             // короткий откат на 3 м от плиты
      AUTO.retreatT -= dt;
      AUTO.runOn = false;
      const ux = sx - plate.x, uz = sz - plate.z;
      const ul = Math.hypot(ux, uz) || 1;
      autoSeek(pl, plate.x + ux / ul * 3.2, plate.z + uz / ul * 3.2, dt, 2.6);
      return;
    }
    // фиксация фазы: пока плита та же, прогон не сбрасывается
    if (!AUTO.runOn && dSt <= 1.25 && vAlong > -0.3) AUTO.runOn = true;
    if (!AUTO.runOn) {
      // этап «подготовка»: встать на разгонную линию напротив плиты (ПД-наведение)
      autoSeek(pl, sx, sz, dt, 3.4);
      return;
    }
    // этап «прогон»: скорость вдоль ПРЯМОЙ линии стенд→плита (удар меряет полную
    // скорость — гасим боковую составляющую, чтобы вход в зону был в полосе)
    const rlx = plate.x - sx, rlz = plate.z - sz;
    const rll = Math.hypot(rlx, rlz) || 1;
    const ux = rlx / rll, uz = rlz / rll;                // направление разгона
    const nx = -uz, nz = ux;                             // нормаль линии
    const off = (pl.p.x - sx) * nx + (pl.p.z - sz) * nz; // смещение от линии
    const vRun = pl.v.x * ux + pl.v.z * uz;              // скорость вдоль линии
    const err = vT - Math.max(vRun, 0);
    // контроллер скорости ведёт до самой плиты: вход в зону ровно на vT,
    // боковая составляющая погашена, смещение с линии плавно убирается
    const wx = ux * vT - nx * clamp(off, -2.5, 2.5) * 0.7;
    const wz = uz * vT - nz * clamp(off, -2.5, 2.5) * 0.7;
    const exv = wx - pl.v.x, ezv = wz - pl.v.z;
    const em = Math.hypot(exv, ezv);
    autoTilt(exv, ezv, clamp(0.15 + em * 0.25, 0.12, 1));
    if (err > 0.3) autoNudge(pl, pl.p.x + wx * 0.5, pl.p.z + wz * 0.5, Math.min(err * 1.4, 2.6), dt, vT + 1.4);
    // отскок от плиты/кромки — откат для нового захода
    if (vAlong < -1.3 && dist < 3.2) AUTO.retreatT = 0.8;
  }

  // --- ЭТАЖ 3 «ЯДРО»: разгон с противоположной стороны диска, нырок через люк
  // к ядру (схема «робота» §31.9: заход по линии z, наведение по времени падения),
  // затем — на кнопку (ось кнопки = ось ядра, v4.0).
  function autoFloor3(dt) {
    const pl = W.player;
    if (!pl || !pl.alive) return;
    const S = LEVEL_CONFIG.shield;
    if (W.coreAlive) {
      // ниже ядра без шанса — ждём перемотку, не дёргаем стакан
      if (pl.p.y < S.y - 0.6 && pl.p.y < 4.0 && !AUTO.dive) {
        autoTilt(0, 0, 0.05);
        return;
      }
      const discY = LEVEL_CONFIG.platformB.y;
      const onDisc = pl.p.y > discY + 0.5;
      if (onDisc && !AUTO.dive) {
        // этап 1 — маршрут мимо люка (два вэйпоинта, строго по порядку):
        // борт (±4.6, 0.2) → задняя точка (0, −4.8) → нырок
        if (!AUTO.wp2) {
          const sideX = (pl.p.x >= 0 ? 1 : -1) * 4.6;
          if (Math.abs(pl.p.x - sideX) < 1.15 && Math.abs(pl.p.z - 0.2) < 1.15) AUTO.wp2 = true;
          else { autoSeek(pl, sideX, 0.2, dt, 3.4); return; }
        }
        if (!(Math.abs(pl.p.x) < 1.5 && pl.p.z < -3.6)) {
          autoSeek(pl, 0, -4.8, dt, 3.4);
          return;
        }
        AUTO.dive = true;                                 // на разгонной линии — ныряем
      }
      if (AUTO.dive || !onDisc) {
        // этап 2: наведение на ядро — нужная горизонтальная скорость = остаток/время падения
        const dy = pl.p.y - S.y;
        if (dy > 0.25) {
          const tf = Math.sqrt(2 * dy / 9.8);
          const nvx = (S.x - pl.p.x) / Math.max(tf, 0.22);
          const nvz = (S.z - pl.p.z) / Math.max(tf, 0.22);
          const evx = nvx - pl.v.x, evz = nvz - pl.v.z;
          const ev = Math.hypot(evx, evz);
          if (ev > 0.15) autoTilt(evx, evz, clamp(0.2 + ev * 0.22, 0.15, 1));
          else autoTilt(evx || 0.001, evz || 0.001, 0.2);
          const vNeed = Math.hypot(nvx, nvz);
          autoNudge(pl, pl.p.x + nvx * Math.max(tf, 0.25), pl.p.z + nvz * Math.max(tf, 0.25), 3.0, dt, Math.max(3.4, vNeed + 1.0));
        } else {
          autoTilt(S.x - pl.p.x, S.z - pl.p.z, 0.8);     // у самого ядра — прямо в него
          autoNudge(pl, S.x, S.z, 2.2, dt);
        }
        return;
      }
    } else {
      AUTO.dive = false;
    }
    // ядро разбито: на кнопку (ось кнопки = ось ядра, v4.0)
    const BT = LEVEL_CONFIG.shield;
    autoTilt(BT.x - pl.p.x, BT.z - pl.p.z, 0.75);
    autoNudge(pl, BT.x, BT.z, 1.6, dt);
  }

  function autoUpdate(dt) {
    if (!AUTO.active) return;
    if (W.state === 'lose' || W.state === 'win') { autoStop(W.state === 'win' ? 'floorDone' : 'end'); return; }
    if (W.state !== 'play' || W.ffOpen) return;          // пауза/модалка — стоим, не сдаёмся
    if (W.currentFloor !== AUTO.floor) { autoStop('floorDone'); return; }
    AUTO.t += dt;
    if (AUTO.t > AUTO.deadline) { autoStop('timeout'); return; }
    if (W.autoPull && W.autoPull.active) { W.tilt.active = false; W.tilt.tRotX = 0; W.tilt.tRotZ = 0; return; }
    if (W.currentFloor === 0) autoFloor0(dt);
    else if (W.currentFloor === 1) autoFloor1(dt);
    else if (W.currentFloor === 2) autoFloor2(dt);
    else autoFloor3(dt);
  }

  // -------------------------------------------------------------------------
  // v4.4: контекстное меню и выделение выключены (требование Яндекс Игр)
  // -------------------------------------------------------------------------
  function bindPlatformGuards() {
    try {
      document.addEventListener('contextmenu', e => e.preventDefault());
    } catch (e) {}
  }

  // ===========================================================================
  // 23. СТАРТ
  // ===========================================================================
  // Optional device tilt. No permission prompt until an explicit button click.
  const Motion = {
    enabled:false, owned:false, base:null, sample:null, received:0, timer:null, reason:'',
    text() {
      const ru=curLang==='ru';
      const b=document.getElementById('btn-motion'), c=document.getElementById('btn-calibrate');
      if (!b) return;
      b.textContent=(this.enabled?'✓ ':'▱ ')+(ru?'Наклон устройства':'Device tilt')+(this.enabled?(ru?': вкл.':': on'):(ru?': выкл.':': off'));
      b.setAttribute('aria-pressed',String(this.enabled));
      c.textContent=ru?'◎ Калибровать':'◎ Calibrate'; c.disabled=!this.enabled;
      document.getElementById('motion-status').textContent=this.reason || (ru?'Палец — наклон; два пальца — камера и масштаб. Включите датчик, держа устройство удобно. После поворота экрана нужна новая калибровка.':'One finger tilts; two fingers rotate and zoom. Enable the sensor while holding the device comfortably. Recalibrate after screen rotation.');
    },
    clear() { this.base=null; this.sample=null; if (App.resetInput) App.resetInput(); },
    async toggle() {
      if(this.enabled){this.enabled=false;clearTimeout(this.timer);this.reason='';this.clear();this.text();return;}
      const ru=curLang==='ru';
      try {
        if(!window.DeviceOrientationEvent) throw Error('unsupported');
        if(typeof DeviceOrientationEvent.requestPermission==='function') {
          if(await DeviceOrientationEvent.requestPermission()!=='granted') throw Error('denied');
        }
        this.enabled=true;this.reason='';this.clear();this.received=0;this.text();
        this.timer=setTimeout(()=>{
          if(this.enabled&&!this.received){this.enabled=false;this.reason=curLang==='ru'?'Датчик недоступен. Используйте управление пальцами.':'Sensor unavailable. Use touch controls.';this.clear();this.text();}
        },4000);
      } catch(e) {this.enabled=false;this.reason=ru?'Нет доступа к датчику. Управление пальцами работает без разрешений.':'Sensor access unavailable. Touch controls need no permission.';this.text();}
    },
    update() {
      if (this.owned && !(App.hasPointerInput && App.hasPointerInput()) && !AUTO.active) { W.tilt.active=false; W.tilt.tRotX=W.tilt.tRotZ=0; }
      this.owned=false;
      if(!this.enabled || !this.sample || !this.base || performance.now()-this.received>700 || W.state!=='play' || W.ffOpen || App.helpOpen || !el.settings_panel.classList.contains('hidden') || PLAT.adMuted || AUTO.active || (App.hasPointerInput && App.hasPointerInput())) return;
      const wrap=v=>((v+540)%360)-180;
      const beta=wrap(this.sample.beta-this.base.beta), gamma=wrap(this.sample.gamma-this.base.gamma);
      const a=((screen.orientation && screen.orientation.angle)||window.orientation||0)*Math.PI/180;
      let x=gamma*Math.cos(a)+beta*Math.sin(a), y=beta*Math.cos(a)-gamma*Math.sin(a);
      const dead=v=>Math.sign(v)*Math.max(0,Math.abs(v)-1.5);
      x=dead(x); y=dead(y);
      const f=new THREE.Vector3();W.camera.getWorldDirection(f);f.y=0;f.normalize();
      const r=new THREE.Vector3().crossVectors(f,new THREE.Vector3(0,1,0)).normalize();
      const dx=r.x*x-f.x*y, dz=r.z*x-f.z*y, len=Math.hypot(dx,dz);
      const mag=Math.min(LEVEL_CONFIG.tilt.max,len/25*LEVEL_CONFIG.tilt.max);
      this.owned=true;W.tilt.active=true;W.tilt.tRotZ=len?-dx/len*mag:0;W.tilt.tRotX=len?dz/len*mag:0;
    },
    init() {
      document.getElementById('btn-motion').onclick=()=>this.toggle();
      document.getElementById('btn-calibrate').onclick=()=>{this.clear();this.reason=curLang==='ru'?'Держите устройство удобно: это нейтральное положение.':'Hold the device comfortably: this is the neutral position.';this.text();};
      window.addEventListener('deviceorientation',e=>{
        if(!this.enabled || !Number.isFinite(e.beta)||!Number.isFinite(e.gamma))return;
        this.sample={beta:e.beta,gamma:e.gamma};this.received=performance.now();
        if(!this.base)this.base={...this.sample};
      });
      const rotate=()=>{this.clear();this.reason='';this.text();};
      window.addEventListener('orientationchange',rotate);
      if(screen.orientation && screen.orientation.addEventListener)screen.orientation.addEventListener('change',rotate);
      window.addEventListener('blur',()=>this.clear());
      document.addEventListener('visibilitychange',()=>this.clear());
      this.text();
      // Reparent the existing buttons, retaining their handlers and game state.
      const toolbar=document.getElementById('hud-side'), game=document.getElementById('scr-game'), chrome=document.getElementById('chrome');
      const layout=()=>{const mobile=matchMedia('(max-width:1079px), (pointer:coarse)').matches;(mobile?chrome:game).appendChild(toolbar);};
      window.addEventListener('resize',layout);layout();
      const labels=()=>toolbar.querySelectorAll('button').forEach(b=>b.setAttribute('aria-label',b.title||b.textContent.trim()));labels();
    }
  };
  I18N.ru.helpBody += '<br><b>Наклон устройства:</b> в настройках нажмите «Наклон устройства», при запросе разрешите датчик. Держите телефон удобно и нажмите «Калибровать». Наклон влево/вправо и на себя/от себя наклоняет башню в том же направлении относительно камеры. Датчик необязателен: один палец наклоняет башню, два вращают камеру и меняют масштаб. Кнопка «Резать трос» работает одним касанием. После поворота экрана нейтральное положение устанавливается заново.';
  I18N.en.helpBody += '<br><b>Device tilt:</b> open settings, enable Device tilt and allow sensor access if asked. Hold the phone comfortably and tap Calibrate. Lean left/right or toward/away from you to tilt the tower in the same direction relative to the camera. The sensor is optional: drag one finger to tilt, use two fingers to rotate and pinch to zoom. Tap Cut rope to release the ball. Screen rotation resets the neutral position.';

  function boot() {
    loadSettings();
    App.init();
    Motion.init();
    window.GB = { W: W, VERSION: VERSION, LEVEL_CONFIG: LEVEL_CONFIG, LEVELS: LEVELS, SETTINGS: SETTINGS, App: App, Magic: Magic, Replay: Replay,
      Sound: Sound, I18N: I18N, doShake: doShake, cutRope: cutRope, breakCore: breakCore, stepPhysics: stepPhysics,
      buildLevel: buildLevel, buildFloor: buildFloor, buildAllFloors: buildAllFloors, setLanguage: setLanguage, fmtTime: fmtTime, skipIntro: skipIntro, addScore: addScore,
      PLAT: PLAT, LEVEL_PALETTES: LEVEL_PALETTES, showScreen: showScreen, startTraining: startTraining, getTheme: getTheme, applyTheme: applyTheme };   // v4.4
    // v4.4: платформа Яндекс Игр — SDK грузится только на платформе;
    // локально/в песочнице тихий гостевой режим, LoadingAPI.ready всё равно вызывается.
    initPlatform().then(() => {
      try {
        // 1.7 автоязык: платформа задаёт язык, только если игрок не выбирал сам
        let hadChoice = null;
        try { hadChoice = window.localStorage.getItem('graviboom_lang_v300'); } catch (e) {}
        if (PLAT.lang && !hadChoice) setLanguage(/^(be|kk|ru|uk|uz)$/i.test(PLAT.lang) ? 'ru' : 'en');
      } catch (e) {}
      cloudLoad().then(cloud => {
        if (cloud) {
          mergeCloudProgress(cloud);
          renderSidePanels();
        }
        gameReady();          // 1.19.2 LoadingAPI.ready: меню готово — можно играть
      }).catch(() => gameReady());
    }).catch(() => gameReady());
  }

  if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', boot);
  else boot();

})();

  